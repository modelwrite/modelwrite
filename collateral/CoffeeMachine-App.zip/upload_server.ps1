# Tiny upload endpoint: POST /save?name=x with a data:image/png;base64 body -> writes to img dir
$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add("http://localhost:8001/")
$listener.Start()
$dir = "C:\Users\vdiuser10\cmm_deck\img"
New-Item -ItemType Directory -Path $dir -Force | Out-Null
Write-Host "upload server on 8001"
while ($listener.IsListening) {
  try {
    $ctx = $listener.GetContext()
    $ctx.Response.Headers.Add("Access-Control-Allow-Origin","*")
    $ctx.Response.Headers.Add("Access-Control-Allow-Headers","*")
    if ($ctx.Request.HttpMethod -eq "OPTIONS") { $ctx.Response.StatusCode=200; $ctx.Response.Close(); continue }
    if ($ctx.Request.HttpMethod -eq "POST") {
      $name = $ctx.Request.QueryString["name"]; if (-not $name) { $name = "shot.png" }
      $name = ($name -replace '[^a-zA-Z0-9_.-]','_')
      $sr = New-Object System.IO.StreamReader($ctx.Request.InputStream, $ctx.Request.ContentEncoding)
      $body = $sr.ReadToEnd(); $sr.Close()
      $b64 = $body -replace '^data:image/\w+;base64,',''
      try { [IO.File]::WriteAllBytes((Join-Path $dir $name), [Convert]::FromBase64String($b64)); $msg="OK $name" } catch { $msg="ERR $($_.Exception.Message)" }
      $buf=[Text.Encoding]::UTF8.GetBytes($msg); $ctx.Response.OutputStream.Write($buf,0,$buf.Length)
    }
    $ctx.Response.Close()
  } catch {}
}
