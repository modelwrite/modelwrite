# Requirements column fix — report

## Status

DONE_WITH_CONCERNS

## Commit

d115b71d935dd6be7aacc3a2c68b7cf85b020f16 — "Fix requirements satisfied-by column overflow"

## One-line test summary

`cargo test --workspace --no-fail-fast` green (all crates, 24 postgres tests skipped as expected), `cargo clippy --workspace --all-targets -- -D warnings` clean, `cargo fmt --all` clean, and 12/12 Playwright tests pass (11 existing + 1 new regression test).

## The fix

The SATISFIED BY cell was clipping the opaque element ids mid-string at the column's right edge (row 1.1's `satisfy: unresolved _2026x_…` ran 286px of content through a 151px column and bled toward COVERAGE).

- `server/src/ui/layout.rs`: `li.allocation { overflow-wrap: anywhere; }` so a long target wraps inside the column instead of crossing the boundary.
- `server/src/ui/model.rs` `allocation_list_markup`: every allocation target now carries `title=<element_id>`, so the full id is available on hover (the same treatment the ID column already gives). Broken links now read `unresolved link <id>` — the word "link" scopes the state to the individual link.
- `server/src/ui/model.rs` `coverage_badge`: the chip is titled "Requirement coverage: …" so the green `covered` chip reads as the requirement-level verdict, distinct from the per-link `unresolved link` marker.
- `e2e/tests/requirements-table.spec.js`: new test asserting no `td.req-satisfied` overflows its column, the broken span is `unresolved link` with a full-id `title`, and the coverage chip carries the requirement-scope `title`.

### What the cell looks like now (row 1.1)

```
satisfy: unresolved link _2026x_1_12a70364_1789524431087_459748_5711
satisfy: unresolved link _2026x_1_12a70364_1789524431091_435540_5713
refine: Water Temperature Constraint
satisfy: Boiler
verify: Water Heating Analysis Context
```

The opaque ids wrap (verified: no cell reports `scrollWidth > clientWidth`), "unresolved" is red and scoped by "link", and hovering any target shows the full element id.

## Concerns

1. **Pre-existing minor bleeds left as-is (out of scope).** Two other columns still overflow by ~7px, both present before this change and explicitly outside "the one precise defect":
   - The red `uncovered` chip in the COVERAGE column is ~69px in a 72px cell and pokes ~7px past the table's right edge.
   - The reqId column (`3.1.1` etc.) pokes ~7px into the text column for 5-char reqIds.
   I did not touch these because the controller said everything else is good and not to redesign the column budget; widening COVERAGE would shrink SATISFIED BY and worsen the reported defect.
2. **Wrap vs ellipsis.** I chose wrap (full id visible) over ellipsis per the report's "a clipped id is worse than a short one" and "reader cannot see which element a link points at". A 44-char id in a ~130px column therefore wraps to ~3 lines per broken link, making that row tall. The requirement explicitly permits this ("breaking is acceptable for an id"), but ellipsis+title is the alternative if a compact row is preferred.

3. **Concurrent workspace edits.** After the commit, the working tree gained uncommitted changes that are NOT part of this fix: `server/src/ui/mod.rs` (`pub mod composition;`), `server/src/ui/layout.rs` (+101 lines of composition CSS), and `server/src/ui/model.rs` (`LoadedView`/`load_view` made `pub(crate)`) — another agent is adding a `composition` UI module concurrently. My commit `d115b71` is isolated to its three files, but the current working tree is not green because of that in-flight WIP; I did not touch, stage, or revert it.

## Note

Model is not image-capable; verified by DOM/layout measurement (column widths, `scrollWidth`/`clientWidth`, line-box counts, and title attributes) rather than reading the screenshot.
