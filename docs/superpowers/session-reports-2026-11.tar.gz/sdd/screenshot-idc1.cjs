const { chromium } = require('C:/Users/alexk/projects/modelwrite/e2e/node_modules/playwright');
const TOKEN = '71e6652c4980128f654b957fb40fb275b5ae02096253727f3f3ea5e14ef90267';
const OUT = 'C:/Users/alexk/projects/modelwrite/.superpowers/sdd/';
(async () => {
  const browser = await chromium.launch();
  const context = await browser.newContext({
    viewport: { width: 1280, height: 900 },
    extraHTTPHeaders: { Authorization: 'Bearer ' + TOKEN },
  });
  const page = await context.newPage();
  const shots = [
    ['/ui', 'idc1-projects.png'],
    ['/ui/projects/cafe-stand/composition', 'idc1-composition.png'],
    ['/ui/projects/cafe-stand/compare?from=main&to=with-microduck', 'idc1-compare.png'],
  ];
  for (const [path, file] of shots) {
    await page.goto('http://127.0.0.1:14102' + path, { waitUntil: 'networkidle', timeout: 30000 });
    await page.screenshot({ path: OUT + file, fullPage: true });
    console.log('saved', file);
  }
  await browser.close();
  console.log('SCREENSHOTS_DONE');
})().catch((e) => { console.error('SCREENSHOT_FAIL:', e.message); process.exit(1); });
