# Modelwrite Capability Acceptance Test

**Status: DONE_WITH_CONCERNS**

Date: 2026-09-20 · Tester: delegated subagent (capability acceptance test)
Target: mw-server trial at http://127.0.0.1:8080 (open mode, SQLite), mw-mcp at target/debug/mw-mcp.exe.

## Summary

I exercised all ten claimed capabilities against the six deployed models plus two scratch
projects (cap-test, cap-import) I created for the write-path tests. Every claim was tested
against the running server, not the test suite. The core platform is real and works; the
gaps are in AI-assisted change quality, import provenance, and summary integrity.

**Matrix totals (capability level): 8 PASS · 2 PARTIAL · 0 FAIL**

---

## 1. Capability Matrix

Rows = capability; columns = the models it applies to. Evidence note per cell is the command
or URL and what came back. Where a capability was exercised through a scratch model, the cell
names it.

| Capability | coffee-machine | sandwich-toaster | purchasing-terminal | floor-robot | microduck | cafe-stand |
|---|---|---|---|---|---|---|
| **1. Read** (page/structure/reqs/traceability/diagram counts match stored doc; coverage from engine) | PASS — overview 49 elements / 25 reqs / "15/25" matches doc; coverage == engine requirement_coverage | PASS — 8 blocks / 5 reqs / "5/5" | PASS — 9 blocks / 6 reqs / "6/6" | PASS — 11 blocks / 7 reqs / "6/7" (but summary.blocks=10 is stale) | PASS — 8 blocks / 6 reqs / "6/6" | PASS — 4 blocks / 4 reqs / "4/4" (but summary is stale) |
| **2. Coverage truth** (uncovered req shown uncovered; covered req's satisfying element exists) | PASS — reqId 3.2.1 "Regulatory Compliance Mark" = uncovered; reqId 1.2 "Overheating" → "Boiler" (block exists). Independent recompute = 15/25, 10 uncovered | PASS (5/5) | PASS (6/6) | PASS (1 uncovered) | PASS (6/6) | PASS (4/4; engine + composition coverage.local agree) |
| **3. Version control** (branch/commit/compare/merge, diff names change, merge record) | N/A | N/A | N/A | N/A | N/A | N/A (exercised on scratch cap-test: branch feature → commit "add Test Block" → gate diff "extraElements: structure:cap-test-block-1" → merge.clean, 2-parent merge commit) |
| **4. Gate** (verdict + evidence + same-rev determinism) | PASS — self-gate passed; evidence byte-identical on 2 runs; checks → checked:true | N/A | N/A | N/A | N/A | PASS — compositional gate resolves 4 refs, flags un-gated subsystems, diff names reference:floor-robot→microduck |
| **5. Provenance + checks** (imported vs authored; artifact hash; checks endpoint) | **PARTIAL** — provenance is authored, NOT imported (no artifact hash), despite being "imported from MagicDraw" | PASS — authored | PASS — authored | PASS — authored | PASS — authored | PASS — authored + one accepted commit (agent mw-assist) |
| **6. Composition** (cafe-stand refs resolve; branches differ in COMPARE) | N/A | N/A | N/A | N/A | N/A | PASS — 4 refs resolve at pinned revisions on both branches; main→with-microduck diff = reference:floor-robot → reference:microduck |
| **7. Diagram** (structure+process render; every node/edge; orthogonal; no box crossing; deterministic) | PASS — 99/99 nodes, 165/165 edges, 2 dangling markers; 0 non-orthogonal segments; 0 box crossings; byte-identical twice | PASS (renders) | PASS | PASS | PASS | PASS (renders; isolated menu-block drawn as disconnected) |
| **8. Assist** (proposal recorded, nothing committed, accept provenance names agent+human) | N/A | N/A | N/A | N/A | N/A | **PARTIAL** — live reasoner mw-assist worked; proposal recorded (undecided) then accepted → commit provenance {agent: mw-assist, acceptedBy: anonymous, acceptedItems: [heater-block]}; BUT output is a graph orphan (see F1) |
| **9. Locks + audit** (element lock; 2nd editor refused; audit log) | N/A | N/A | N/A | N/A | N/A | N/A (scratch cap-test: lock "heater-block" by editor-a → commit by editor-b refused 409 → audit lock.acquire + commit.refused) |
| **10. MCP agent surface** (repo.projects/read/checks/importReport/propose; agent cannot write) | PASS — mw-mcp over stdio: 13 tools (4 doc + 9 repo, read+propose only); repo.* read real data with env; no write tool exposed | (same) | (same) | (same) | (same) | (same) |

---

## 2. Matrix totals

- **PASS: 8** — Read, Coverage truth, Version control, Gate, Composition, Diagram, Locks+audit, MCP.
- **PARTIAL: 2** — Provenance+checks (authored works; imported path not demonstrated), Assist (flow works; output quality defect).
- **FAIL: 0.**

At cell granularity (counting every model-column cell that was actually exercised): 27 PASS, 2 PARTIAL, 0 FAIL, 31 N/A.

---

## 3. Findings (ranked)

### F1 — HIGH · Assist produces graph-orphan changes (isolated nodes); the propose loop does not gate

- **Expected:** the platform claims (design §4.4) AI-generated change meets "graph integration (no orphans,
  one component)" and "every loop iteration ends in a gate run". An assist-proposed element should arrive
  wired into the graph.
- **Actual:** POST /projects/cap-test/assist {"request":"Add a heater block"} returned a proposal whose
  candidate document added heater-block as a **graph node with no edges** — an isolated node. The live
  demo data proves this is not hypothetical: cafe-stand's Menu block (menu-block) was added by an
  accepted mw-assist proposal and is isolated — cafe-stand graphs as **3 connected components, 1 isolated
  node** (verified: {Service Window/Cafe Stand/Provisioning Bay}, {10 activity+requirement nodes}, {Menu}).
  The gate correctly reports integration: 1 isolated nodes / integration: 3 connected components, but
  the assist endpoint records the proposal without running that gate.
- **Reproduction:** POST /projects/cafe-stand/assist with any additive request; accept it; run
  POST /projects/cafe-stand/gate (self) — the isolated node is flagged.
- **Classification:** **defect** (assist output violates the platform's own graph-integration quality bar;
  the gate is not wired into the propose path).

### F2 — MEDIUM · "imported" provenance is not demonstrated by any deployed model; corpus import does not complete cleanly

- **Expected:** the corpus model (coffee-machine, "imported from a real MagicDraw export") has provenance
  imported with its retained artifact hash; repo.importReport reads its loss report.
- **Actual:** every one of the six models has provenance {kind: "authored"} — coffee-machine included
  (GET /projects/coffee-machine/commits/<tip>/record → provenance.kind = "authored", no artifact hash).
  The import endpoint *does* work: POST /projects/cap-import/import with the extracted
  com.nomagic.magicdraw.uml_model.model XMI (193 KB, from the corpus .mdzip) returns **422 with 252
  blocking losses** (128 Lossy + 124 Unmappable — mostly unmapped visibility attributes and dropped
  xmi:id slots). Accepting those 252 and re-importing surfaced a **further** blocking set
  (useCase, client, supplier as "unknown XMI element"), so the acceptance-by-name path did not
  converge in one pass.
- **Reproduction:** extract com.nomagic.magicdraw.uml_model.model from
  sample/corpus/coffee-machine/legacy/CoffeeMachine-SysML-Model.mdzip, POST it to
  /projects/<p>/import with binding=sysml-v1-xmi@2.4.
- **Classification:** **missing feature / honest gap** — the import machinery exists and is gated, but the
  corpus was seeded as "authored" (committed from the already-exported OKF, not through the import flow),
  and the corpus import itself is blocked by a long loss list. Should either be completed and demonstrated,
  or DOCUMENTED as "import of the MagicDraw corpus requires accepting N losses".

### F3 — MEDIUM · The OKF summary cross-check is stale and never regenerated on write

- **Expected:** summary counts are a sanity cross-check that matches section sizes (OKF spec §2/§6).
- **Actual:** cafe-stand tip summary = {activities:5, blocks:4, graphEdges:0, graphNodes:1, interfaces:0,
  requirements:3, signals:3} while the actual document is {activities:6, blocks:4, graphEdges:15,
  graphNodes:14, interfaces:1, requirements:4, signals:3}. floor-robot summary.blocks=10 vs actual
  structure=11. Root cause: the plain commit path trusts the client-supplied summary, and the
  edit/assist paths only increment fields they touch from whatever base they find. The mismatch is
  warning-only (never surfaced), so it silently persists.
- **Reproduction:** GET /projects/cafe-stand/commits/85a3317e… and compare .summary to section sizes.
- **Classification:** **defect** (a documented cross-check that is allowed to go permanently stale defeats
  its own purpose; the write path should regenerate or at least reject a stale summary).

### F4 — MEDIUM · Import surface has exactly ONE binding (XMI); the open-source examples are largely un-importable

- **Expected:** Slice 4 "Interoperability" brings SysML v2 / ReqIF / XMI / Excel connectors.
- **Actual:** the binding registry (server/src/binding_registry.rs) registers only
  sysml-v1-xmi@2.4. The open-source examples that landed in sample/examples/ are: Gaphor
  (.gaphor), Open-MBEE TMT (tmt-2022x.model.xmi, 36 MB), and SysML v2 (.sysml — Airbus Apollo 11,
  GFSE, MBSE4U Batmobile). Only the XMI is even *attemptable*; Gaphor and SysML v2 have **no binding**, and
  there is no registered SysML v2 importer despite engine/sysml2 existing.
- **Classification:** **missing feature** (interoperability beyond XMI is not built; should be documented,
  not claimed).

### F5 — LOW · Model-change acceptance records commit.create, not the documented proposal.accept

- **Expected:** the audit vocabulary (docs/agents/mcp-agent.md) lists proposal.accept.
- **Actual:** accepting a model-change proposal records commit.create (detail "accept … proposal"); the
  proposal.accept action is only emitted by the import-scoped acceptance path
  (server/src/binding_api.rs). The proposal *record* does carry decidedBy, so the decision is not lost —
  the discrepancy is the audit action name.
- **Classification:** **documentation/behaviour inconsistency** (minor).

### F6 — LOW · docs/guide/limits.md does not exist

- **Expected:** the task points at docs/guide/limits.md as the source of claims "if the guide task has
  landed".
- **Actual:** the path does not exist (verified). Claims were therefore tested against the README, the specs
  in docs/superpowers/specs/, and the machine-readable docs/agents/mcp-tools.json.
- **Classification:** **documentation gap** (the limits guide has not landed; nothing to test against).

### F7 — INFO · sample/examples/ is present but incomplete and untracked

- **Actual:** sample/examples/ landed during the run (untracked). Present: gaphor-examples,
  openmbee-tmt, gfse-models, mbse4u-batmobile, airbus-apollo-11. **Missing** vs the fetch script
  (Get-OpenMbseExamples.ps1): omg-sysml-v2-release, both arcadia-capella repos, and
  mbse4u-sysmlv2-book — the latter is the source of the **"real Cameo .mdzip/.mdszip"** (~90 MB), which
  therefore did **not** land. The only .mdzip in the tree remains the coffee-machine corpus.
- **Classification:** **in-progress task**, not a platform defect; flagging so the examples claim is not
  overstated.

### F8 — INFO · Open mode limits attribution

- **Actual:** all audit/provenance records show actor=anonymous, mechanism=open. The assist commit's
  provenance correctly names both parties, but the "human" slot is anonymous (there is no identity system
  configured). Agent-token write-refusal (403) and distinct human/agent identities are only meaningful under
  static/jwt/agent auth, which this trial does not exercise.
- **Classification:** **expected limitation** of open mode (documented in mcp-agent.md §Authentication).

---

## 4. Per-capability readiness verdict

- **Read — READY to rely on.** Counts are computed from the parsed document (never the stale summary), and
  coverage is the engine's graph::requirement_coverage, triple-confirmed against the gate evidence and an
  independent recompute.
- **Coverage truth — READY.** Uncovered/covered verdicts are the engine's, and a covered requirement's
  satisfying element was confirmed to exist.
- **Version control — READY.** Branch/commit/compare/merge round-trip is complete and audited; diff names the
  changed element; merge records a two-parent commit and a merge.clean audit entry.
- **Gate — READY.** Deterministic evidence (byte-identical on re-run), verdict + evidence + composition
  checks all coherent; checks endpoint reports exactly what ran against a commit.
- **Provenance + checks — NEEDS WORK before relying on the "imported" story.** The authored path is solid and
  the checks endpoint is correct, but "imported with artifact hash" is not demonstrated by any model and the
  corpus import is blocked by ~252 losses.
- **Composition — READY.** All references resolve at pinned revisions; the branch comparison names the exact
  reference swap; the measured-vs-asserted boundary is reported as data.
- **Diagram — READY.** Complete, deterministic, orthogonal, no box crossings, safe SVG.
- **Assist — NEEDS WORK first.** The propose→accept→provenance mechanics work, but the output is a graph
  orphan and the propose loop does not run the gate, so the "no orphans / one component" quality bar is not
  met at proposal time.
- **Locks + audit — READY.** Lock refusal (409) and the append-only audit log (including refusals) both work.
- **MCP agent surface — READY.** The tool set is read-and-propose only (structurally no write tool), and the
  repo.* tools read the live service correctly.

---

## 5. What could not be tested

1. **Agent-token write refusal (403) and distinct agent identity** — require agent/static auth; the trial
   runs in open mode (every call is anonymous admin). Only the *structural* "no write tool" enforcement was
   verifiable, plus the write-route permission model in code.
2. **PostgreSQL backend** — the trial uses SQLite (trial.db).
3. **A completed import (imported-provenance commit)** — the corpus XMI import is blocked by ~252 losses and
   did not converge in one accept pass.
4. **SysML v2 / Gaphor import** — no binding is registered.
5. **"Real Cameo .mdzip" example** — the MBSE4U sysmlv2-book (Cameo .mdszip) did not land in sample/examples/.

## 6. Test artifacts created (no git commits made)

- Scratch projects in the running server's DB: cap-test (version control, gate, locks, assist, MCP
  propose), cap-import (import attempts). Not in the git tree.
- Scratch files under .superpowers/ (OKF copies, HTML/SVG captures, MCP message transcripts).
- Three generated gate-evidence files in docs/evidence/ (written by the server's own gate endpoint):
  server-d427e847…-d427e847….json, server-edb11339…-d40fb3b6….json, server-85a3317e…-51b9078e….json.
- The trial server was left running as instructed; no source files were modified by this test.
