# Assist speed — report

## Status

DONE_WITH_CONCERNS

## Commits

- `24fc923` — assist: shrink the inventory to names/kinds, cap the answer at 512 tokens, disable fleet reasoning

## One-line test summary

`cargo test -p mw-server`: 275 passed / 0 failed / 24 ignored (postgres); `cargo clippy -p mw-server --all-targets` clean for this crate; my files are `cargo fmt` clean. The workspace-wide test/clippy/fmt runs are red ONLY in the concurrent task's `engine/graph` code (2 clippy warnings, a `routing_geometry` test compile error, fmt diffs) — none in `server/src/assist.rs` or its tests.

## What changed (`server/src/assist.rs` + `server/tests/assist_openai.rs`)

1. **FIX 1 — shrink the inventory.** `model_inventory` now sends each element's/requirement's `name` + `kind` only. The full opaque ids (43 chars each) and `stereotypes`/`reqId` are gone; graph node/edge counts are kept. Validation is untouched: `validate_changes` still rejects a duplicate id within the proposal, and a readable kebab-case id cannot collide with the corpus's opaque scheme.
2. **FIX 2 — cap the answer.** `OPENAI_MAX_TOKENS` 2048 → 512, so generation is bounded by the work (1–3 changes), not the ceiling.
3. **Reasoning off (required companion).** `call_openai` now sends `chat_template_kwargs: {"enable_thinking": false}`. The fleet's qwen3 models reason before answering; without this the 512 cap is spent on a thinking pass and the model returns `{"changes": []}`. The pre-fix server measured **6.1 s and 0 proposals** for the proof request; with reasoning off the same request returns a proposal in ~1 s.

## prompt_tokens (from the endpoint's `usage` field, qwen3-8b @ idc-1:8017)

| | before | after |
|---|---|---|
| inventory alone | 4,884 | 847 |
| full prompt (system + inventory + request) | 5,273 | 1,238 |

(The controller's before figure was 4,268; my measurement of the actual trial-DB coffee-machine inventory — 49 structure + 9 signals + 25 requirements = 83 elements — is 4,884 because structure entries also carried `stereotypes`.)

## wall-clock (MW_PORT=8090, trial-DB copy, `/projects/coffee-machine/assist`)

| request | before | after |
|---|---|---|
| "add a grinder block" | 5.8 s (controller) | **~1.0 s** (0.9 s warm / 1.3 s cold), 201 with 1 proposal |
| multi-change | — | ~2.2 s, 201 with 2 proposals |

A successful proposal is still produced: "add a grinder block" → `grinder` (EditElement, High). A multi-change proposal still validates: "add a water pump block, and separately draft a requirement that the pump delivers 9 bar of pressure" → 201 with `water-pump` (EditElement) + `pump-pressure-requirement` (DraftText), plus the scripted 2-change end-to-end tests and the `a_multi_change_proposal_fits_inside_the_answer_cap` unit test.

## Concerns

1. **Workspace not fully green due to the concurrent task.** `engine/graph/src/routing.rs` (2 clippy warnings, fmt diffs) and `engine/graph/tests/routing_geometry.rs` (compile error: `no field points on type Lane`) are the other task's in-flight edits. I did not touch them; my crate and files are clean.
2. **Reasoning-off is a third change beyond the stated two.** It is necessary: the controller profiled with "reasoning off", and with reasoning on the tighter cap is consumed by thinking (the pre-fix server returned an empty proposal). Flagged so it is not mistaken for scope creep.
3. **`chat_template_kwargs` is fleet-specific.** It is ignored by a strict OpenAI-compatible endpoint; it is correct for this deployment's qwen3 fleet (verified live), but a deployment pointed at a different backend that rejects unknown params would need this guarded.
