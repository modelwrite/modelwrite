# Handoff - modelwrite, current state

## Live
- **Trial**: https://trial.modelwrite.org (open mode, tunnelled from a dev machine)
- **Website**: https://modelwrite.github.io/modelwrite/
- **Repo**: https://github.com/modelwrite/modelwrite (main)
- **Published**: npm modelwrite-mcp@0.1.0; 10 engine crates on crates.io; ghcr.io/modelwrite/modelwrite; release v0.1.0 (5 binaries)
- **Tests**: ~501 Rust, 20 Playwright, clippy/fmt clean, CI green

## Models in the deployment
| project | what it is |
|---|---|
| coffee-machine | corpus model imported from a real MagicDraw export |
| sandwich-toaster | 8 blocks, 5 requirements |
| purchasing-terminal | 9 blocks, 6 requirements - EFTPOS, secure element, PIN privacy |
| **floor-robot** | **Beni**: all-terrain camera robot adapted to clear cups from the cafe floor |
| **cafe-stand** | **the PLATFORM model**: references all four subsystems at pinned revisions (payment, beverage, food, floor-care); the compositional gate resolves all four; holds the business process |

## Views
/ui plus, per model: overview, structure, requirements, traceability, **composition**, diagram (?view=structure|process), checks, changes, proposals, import, assist.

## Decision specs (read before designing)
system-of-systems (S0/S1 built) - analyses and simulations (frame spec) - visual outputs - visual vocabulary (shapes in; icons/2525 pending) - renderer decision - domain symbology (three licence classes).

## Queue
1. **Version control (N3)** - IN FLIGHT: version selector, new version, compare, make-current with the gate shown first.
2. **Analyses frame (A1)** then A2 library, A3 LLM-authored, A4 model-level simulation, A5 narrative.
3. **Visual outputs (V1-V4)**: SVG export + presentation view, print stylesheet, model document, evidence pack.
4. **Visual vocabulary (S1-S4)**: symbol boundary, MIL-STD-2525/APP-6, operator packs.
5. **Large-model default zoom** - 99 nodes fit-to-view is unreadable.

## Standing limits, stated on the product
- Analysis and model-level simulation yes; numeric/physical simulation NO (no solvers).
- Native XMI-to-OKF fidelity is assisted, not independently measured.
- Activity-to-subsystem-element link is a role name, not a first-class cross-model edge.
- Trial is open mode and ephemeral: a real host plus a static token are needed before real use.

## Process lessons
**Serialise tasks that touch the same files** - two tasks were lost to concurrency on server/src/ui.
**Verify visually** - the subagents cannot see images; every UI defect that mattered passed every test and was caught only by looking.
