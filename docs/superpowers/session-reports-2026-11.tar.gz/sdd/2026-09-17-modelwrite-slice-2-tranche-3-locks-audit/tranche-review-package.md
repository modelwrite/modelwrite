﻿# Slice 2 tranche 3 - whole-tranche review package (locks and audit)

## Commits

0f476bf fix: pin the guard to the tip it was computed against and refuse before storing
c314b12 feat: add the append-only audit log
003d5ff fix: enforce locks inside the commit transaction, not before it
adfac47 feat: refuse a commit that changes a locked element

## Diff stat

 ...-17-modelwrite-slice-2-tranche-3-locks-audit.md |  41 +-
 server/src/api.rs                                  | 151 ++++++-
 server/src/audit_api.rs                            |  40 ++
 server/src/gate_api.rs                             |  22 +-
 server/src/lib.rs                                  |  13 +
 server/src/locks_api.rs                            | 154 +++++++
 server/src/merge_api.rs                            |  26 +-
 server/src/store/mod.rs                            | 122 +++++
 server/src/store/sqlite.rs                         | 320 +++++++++++++-
 server/tests/audit.rs                              | 392 ++++++++++++++++
 server/tests/locks.rs                              | 492 +++++++++++++++++++++
 server/tests/store.rs                              | 174 +++++++-
 12 files changed, 1929 insertions(+), 18 deletions(-)

## Verification observed by the controller

```
cargo test --workspace --no-fail-fast -> 101 tests pass (engine 44, service 57)
cargo fmt --all -- --check and cargo clippy --workspace --all-targets -- -D warnings -> clean
```

## Full diff (-U10)

diff --git a/server/src/audit_api.rs b/server/src/audit_api.rs
new file mode 100644
index 0000000..f202717
--- /dev/null
+++ b/server/src/audit_api.rs
@@ -0,0 +1,40 @@
+// SPDX-License-Identifier: AGPL-3.0-or-later
+use axum::extract::{Path, Query, State};
+use axum::Json;
+use serde::Deserialize;
+
+use crate::api::{map_store_error, ApiState};
+use crate::error::ApiError;
+use crate::store::AuditEntry;
+
+#[derive(Deserialize)]
+pub struct AuditQuery {
+    pub limit: Option<i64>,
+}
+
+/// The append-only audit log for a project, newest first. The log records what was
+/// attempted as well as what succeeded, and can never be edited: the store exposes only
+/// an append and this read, never an update or a delete.
+pub async fn list_audit(
+    State(state): State<ApiState>,
+    Path(project): Path<String>,
+    Query(query): Query<AuditQuery>,
+) -> Result<Json<Vec<AuditEntry>>, ApiError> {
+    if state
+        .store
+        .project(&project)
+        .map_err(map_store_error)?
+        .is_none()
+    {
+        return Err(ApiError::not_found(format!("project {}", project)));
+    }
+    let limit = query.limit.unwrap_or(1000);
+    if limit < 1 {
+        return Err(ApiError::bad_request("limit must be at least 1"));
+    }
+    let entries = state
+        .store
+        .audit(&project, limit)
+        .map_err(map_store_error)?;
+    Ok(Json(entries))
+}
diff --git a/server/src/locks_api.rs b/server/src/locks_api.rs
new file mode 100644
index 0000000..3bfb48c
--- /dev/null
+++ b/server/src/locks_api.rs
@@ -0,0 +1,154 @@
+// SPDX-License-Identifier: AGPL-3.0-or-later
+use axum::extract::{Path, State};
+use axum::http::StatusCode;
+use axum::Json;
+use serde::Deserialize;
+use serde_json::{json, Value};
+
+use crate::api::{map_store_error, validate_name, ApiState};
+use crate::error::ApiError;
+use crate::store::{now_epoch, AuditEntry, Lock};
+
+/// The real clock in seconds, as the store requires it. The store itself never reads the
+/// clock: time is passed in so lock expiry is testable without sleeping.
+fn now_seconds() -> i64 {
+    now_epoch().parse().unwrap_or(0)
+}
+
+#[derive(Deserialize)]
+#[serde(rename_all = "camelCase")]
+pub struct AcquireLocks {
+    pub branch: String,
+    pub elements: Vec<String>,
+    pub holder: String,
+    pub ttl_seconds: i64,
+}
+
+pub async fn acquire_locks(
+    State(state): State<ApiState>,
+    Path(project): Path<String>,
+    Json(body): Json<AcquireLocks>,
+) -> Result<(StatusCode, Json<Vec<Lock>>), ApiError> {
+    validate_name("branch name", &body.branch)?;
+    if body.elements.is_empty() {
+        return Err(ApiError::bad_request("at least one element is required"));
+    }
+    for element in &body.elements {
+        validate_name("element name", element)?;
+    }
+    // A repeated element would acquire one lease but be reported twice, which reads as two
+    // leases for one element. Deduplicate before anything is written.
+    let elements: Vec<String> = {
+        let mut seen = std::collections::BTreeSet::new();
+        body.elements
+            .iter()
+            .filter(|e| seen.insert((*e).clone()))
+            .cloned()
+            .collect()
+    };
+    if !(30..=86400).contains(&body.ttl_seconds) {
+        return Err(ApiError::bad_request(
+            "ttlSeconds must be between 30 and 86400",
+        ));
+    }
+    if state
+        .store
+        .project(&project)
+        .map_err(map_store_error)?
+        .is_none()
+    {
+        return Err(ApiError::not_found(format!("project {}", project)));
+    }
+
+    let locks = state
+        .store
+        .acquire_locks(
+            &project,
+            &body.branch,
+            &elements,
+            &body.holder,
+            body.ttl_seconds,
+            now_seconds(),
+        )
+        .map_err(map_store_error)?;
+    let expiry = locks.first().map(|l| l.expires_at).unwrap_or(0);
+    state
+        .store
+        .append_audit(&AuditEntry {
+            id: 0,
+            project: project.clone(),
+            at: now_seconds(),
+            actor: body.holder.clone(),
+            action: "lock.acquire".to_string(),
+            subject: elements.join(","),
+            detail: format!(
+                "{} element(s) by {} until {}",
+                locks.len(),
+                body.holder,
+                expiry
+            ),
+        })
+        .map_err(map_store_error)?;
+    Ok((StatusCode::CREATED, Json(locks)))
+}
+
+pub async fn list_locks(
+    State(state): State<ApiState>,
+    Path(project): Path<String>,
+) -> Result<Json<Vec<Lock>>, ApiError> {
+    if state
+        .store
+        .project(&project)
+        .map_err(map_store_error)?
+        .is_none()
+    {
+        return Err(ApiError::not_found(format!("project {}", project)));
+    }
+    let locks = state
+        .store
+        .locks(&project, now_seconds())
+        .map_err(map_store_error)?;
+    Ok(Json(locks))
+}
+
+#[derive(Deserialize)]
+pub struct ReleaseLocks {
+    pub holder: String,
+    pub ids: Vec<String>,
+}
+
+pub async fn release_locks(
+    State(state): State<ApiState>,
+    Path(project): Path<String>,
+    Json(body): Json<ReleaseLocks>,
+) -> Result<Json<Value>, ApiError> {
+    if state
+        .store
+        .project(&project)
+        .map_err(map_store_error)?
+        .is_none()
+    {
+        return Err(ApiError::not_found(format!("project {}", project)));
+    }
+    let released = state
+        .store
+        .release_locks(&project, &body.holder, &body.ids)
+        .map_err(map_store_error)?;
+    // A release that removes nothing is not a mutation (a foreign holder, or already
+    // released ids), so it writes no audit entry.
+    if released > 0 {
+        state
+            .store
+            .append_audit(&AuditEntry {
+                id: 0,
+                project: project.clone(),
+                at: now_seconds(),
+                actor: body.holder.clone(),
+                action: "lock.release".to_string(),
+                subject: body.ids.join(","),
+                detail: format!("released {} lock(s)", released),
+            })
+            .map_err(map_store_error)?;
+    }
+    Ok(Json(json!({ "released": released })))
+}
diff --git a/server/src/store/mod.rs b/server/src/store/mod.rs
index b8892a2..9ddbf48 100644
--- a/server/src/store/mod.rs
+++ b/server/src/store/mod.rs
@@ -1,11 +1,12 @@
 // SPDX-License-Identifier: AGPL-3.0-or-later
+use serde::Serialize;
 use sha2::{Digest, Sha256};
 
 pub mod sqlite;
 
 #[derive(Debug, Clone, PartialEq)]
 pub struct Project {
     pub name: String,
     pub created_at: String,
 }
 
@@ -25,20 +26,51 @@ pub struct Commit {
 pub struct GateRun {
     pub project: String,
     pub branch: String,
     pub reference_hash: String,
     pub candidate_hash: String,
     pub passed: bool,
     pub evidence: String,
     pub created_at: String,
 }
 
+/// A lease on one element. A lock always carries an expiry, so a crashed client cannot
+/// block an element forever. The `branch` records where the holder intends to edit, while
+/// the lock itself is keyed on the element: two branches cannot edit one element at once.
+#[derive(Debug, Clone, PartialEq, Serialize)]
+#[serde(rename_all = "camelCase")]
+pub struct Lock {
+    pub id: String,
+    pub project: String,
+    pub branch: String,
+    pub element: String,
+    pub holder: String,
+    pub acquired_at: i64,
+    pub expires_at: i64,
+}
+
+/// One entry in the append-only audit log. The `id` is assigned by the store on append
+/// (callers pass 0); `at` is the wall-clock time supplied by the HTTP layer, never read
+/// inside the store; `actor` is what the request SAID it was - its author or holder - not
+/// a verified identity, which is a later tranche.
+#[derive(Debug, Clone, PartialEq, Serialize)]
+#[serde(rename_all = "camelCase")]
+pub struct AuditEntry {
+    pub id: i64,
+    pub project: String,
+    pub at: i64,
+    pub actor: String,
+    pub action: String,
+    pub subject: String,
+    pub detail: String,
+}
+
 #[derive(Debug)]
 pub enum StoreError {
     NotFound(String),
     Conflict(String),
     Backend(String),
 }
 
 impl std::fmt::Display for StoreError {
     fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
         match self {
@@ -77,64 +109,154 @@ pub fn commit_hash(
         "branch": branch,
         "parents": sorted_parents,
         "okfHash": okf_hash,
         "author": author,
         "message": message
     });
     let bytes = serde_json::to_vec(&payload).expect("commit payload serializes");
     blob_hash(&bytes)
 }
 
+/// Deterministic identifier for a lock row: the project, branch, element and holder
+/// scoped by the acquisition time, so tests can predict the id without a random source.
+/// Truncated to 32 hex characters, ample for a lease measured in minutes.
+fn lock_id(project: &str, branch: &str, element: &str, holder: &str, now: i64) -> String {
+    let digest =
+        Sha256::digest(format!("{}|{}|{}|{}|{}", project, branch, element, holder, now).as_bytes());
+    let encoded = hex::encode(digest);
+    encoded[..32].to_string()
+}
+
 /// Seconds since the epoch, stored beside a commit and never inside its hash.
 pub fn now_epoch() -> String {
     match std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH) {
         Ok(d) => d.as_secs().to_string(),
         Err(_) => "0".to_string(),
     }
 }
 
+/// The real clock in seconds, for callers that pass time INTO the store (lock expiry,
+/// audit timestamps). The store itself never calls this.
+pub fn now_seconds() -> i64 {
+    now_epoch().parse().unwrap_or(0)
+}
+
+/// What a guarded commit must not change. The holder is the one asking; any element in
+/// `elements` held by a DIFFERENT holder with a live lease refuses the commit.
+///
+/// `expected_tip` is the branch tip the caller computed `elements` against. The guard is
+/// only meaningful for that tip: if the branch moved since, the touched set describes a
+/// document that is no longer there, and enforcing it would protect the wrong elements -
+/// a race that a fresh check cannot catch from outside the transaction. The store refuses
+/// instead, and the caller re-reads and retries.
+///
+/// Lock scope: a lock is keyed by project and element, NOT by branch. The branch is recorded
+/// as context for whoever looks at the lock table, but the protection is deliberately
+/// cross-branch - two people editing one element from two branches is exactly the overwrite
+/// this exists to prevent.
+pub struct CommitGuard<'a> {
+    pub holder: &'a str,
+    pub elements: &'a [String],
+    pub now: i64,
+    pub expected_tip: Option<&'a str>,
+}
+
 pub trait Store: Send + Sync {
     fn create_project(&self, name: &str) -> Result<Project, StoreError>;
     fn project(&self, name: &str) -> Result<Option<Project>, StoreError>;
     fn list_projects(&self) -> Result<Vec<Project>, StoreError>;
     fn put_blob(&self, bytes: &[u8]) -> Result<String, StoreError>;
     fn blob(&self, hash: &str) -> Result<Option<Vec<u8>>, StoreError>;
 
     /// Commit a model onto a branch atomically: the tip is read, the parents and the
     /// commit hash are derived from it, and the commit row and the branch tip are written
     /// inside ONE lock and transaction. Resolving the parents a layer above would be a
     /// read-modify-write race: two concurrent commits would both read the same tip and
     /// fork the history, the later one orphaning the earlier while the branch lists both.
+    ///
+    /// An optional guard says "refuse this commit if any of these elements is locked by
+    /// somebody else". The check runs INSIDE the transaction, not before it: checking first
+    /// and writing afterwards leaves a window in which another holder acquires the lock and
+    /// the guarded commit lands anyway, which would make a lock advisory in the worst way -
+    /// it would look enforced and not be.
+    #[allow(clippy::too_many_arguments)]
     fn commit_model(
         &self,
         project: &str,
         branch: &str,
         okf_hash: &str,
         author: &str,
         message: &str,
+        guard: Option<CommitGuard<'_>>,
+        audit: Option<&AuditEntry>,
     ) -> Result<Commit, StoreError>;
 
     /// Write a commit with EXPLICIT parents and move the branch tip, in one transaction.
     /// A merge commit has two parents, so the parent list cannot be derived from the tip.
+    #[allow(clippy::too_many_arguments)]
     fn commit_merge(
         &self,
         project: &str,
         branch: &str,
         parents: &[String],
         okf_hash: &str,
         author: &str,
         message: &str,
+        audit: Option<&AuditEntry>,
     ) -> Result<Commit, StoreError>;
 
     fn commit(&self, project: &str, hash: &str) -> Result<Option<Commit>, StoreError>;
     fn commits_on(&self, project: &str, branch: &str) -> Result<Vec<Commit>, StoreError>;
     fn branch_tip(&self, project: &str, branch: &str) -> Result<Option<String>, StoreError>;
     fn create_branch(&self, project: &str, name: &str, from: &str) -> Result<(), StoreError>;
 
     /// Remove a branch pointer. This never deletes commits: the objects a branch pointed
     /// at stay in the store, so a deleted branch can be recreated at the same hash and no
     /// history is ever lost.
     fn delete_branch(&self, project: &str, name: &str) -> Result<(), StoreError>;
     fn list_branches(&self, project: &str) -> Result<Vec<(String, String)>, StoreError>;
     fn record_gate_run(&self, run: &GateRun) -> Result<(), StoreError>;
     fn gate_runs(&self, project: &str) -> Result<Vec<GateRun>, StoreError>;
+
+    /// Acquire a lease on each of `elements`, all or nothing. If any element is held by a
+    /// live lease owned by a DIFFERENT holder, nothing is acquired and a Conflict is
+    /// returned naming the holder and the expiry. Re-acquiring an element the same holder
+    /// already holds extends the lease rather than failing.
+    fn acquire_locks(
+        &self,
+        project: &str,
+        branch: &str,
+        elements: &[String],
+        holder: &str,
+        ttl_seconds: i64,
+        now: i64,
+    ) -> Result<Vec<Lock>, StoreError>;
+
+    /// Release locks by id; only the listed holder may release them. Returns how many
+    /// rows were actually removed.
+    fn release_locks(
+        &self,
+        project: &str,
+        holder: &str,
+        ids: &[String],
+    ) -> Result<usize, StoreError>;
+
+    /// Live locks on a project: expired rows are reported as gone.
+    fn locks(&self, project: &str, now: i64) -> Result<Vec<Lock>, StoreError>;
+
+    /// The live locks covering any of the given elements, used by the commit path to see
+    /// who holds an element before changing it.
+    fn holders_of(
+        &self,
+        project: &str,
+        elements: &[String],
+        now: i64,
+    ) -> Result<Vec<Lock>, StoreError>;
+
+    /// Append one entry to the audit log and return its row id. There is deliberately NO
+    /// update, delete or truncate method anywhere in this trait: the log is append-only by
+    /// construction rather than by convention, so a written entry can never be rewritten.
+    fn append_audit(&self, entry: &AuditEntry) -> Result<i64, StoreError>;
+
+    /// The audit entries for a project, newest first, at most `limit` rows (capped at 1000).
+    fn audit(&self, project: &str, limit: i64) -> Result<Vec<AuditEntry>, StoreError>;
 }
