﻿## Global Constraints

- Rust stable; edition 2021; rust-version 1.75; no new dependencies.
- Every source file begins with: // SPDX-License-Identifier: AGPL-3.0-or-later
- Cargo is not on PATH in fresh shells: begin every shell command sequence with $env:Path = "$env:USERPROFILE\\.cargo\\bin;" + $env:Path
- Use --no-fail-fast when running a test suite.
- Stage and commit only the paths a task owns. Never amend or rewrite a commit.
- History stays append-only: no operation deletes or rewrites a commit row.
- THE AUDIT LOG IS APPEND-ONLY: the Store exposes an append and a read, never an update or a delete, and a test must prove that a second append cannot alter an earlier entry.
- A lock is a LEASE: it carries an expiry, and an expired lock is available to anyone. A crashed client must never be able to block an element forever.
- Time is passed IN to the store, never read inside it, so lock expiry and audit timestamps are testable without sleeping. The store takes a now: i64 parameter; the HTTP layer supplies the real clock.
- Every request path returns a structured error and never panics: 400 malformed, 404 missing, 409 held by someone else or conflict, 422 invalid model, 500 internal with a generic message.
- Names (project, branch) are validated by api::validate_name before use.
- Tests drive the router in process with tower oneshot; no port is bound.


## Task 3: The append-only audit log

**Files:**
- Modify: server/src/store/mod.rs (AuditEntry type, two trait methods)
- Modify: server/src/store/sqlite.rs (the audit table, append and read)
- Modify: server/src/api.rs, gate_api.rs, merge_api.rs, locks_api.rs (record on every mutation)
- Create: server/src/audit_api.rs
- Modify: server/src/lib.rs (pub mod audit_api, one route)
- Test: server/tests/audit.rs

**Interfaces:**
- Produces:
  - `pub struct AuditEntry { pub id: i64, pub project: String, pub at: i64, pub actor: String, pub action: String, pub subject: String, pub detail: String }`, serialised camelCase.
  - `Store::append_audit(&self, entry: &AuditEntry) -> Result<i64, StoreError>` - returns the row id; there is deliberately NO update, delete or truncate method anywhere.
  - `Store::audit(&self, project: &str, limit: i64) -> Result<Vec<AuditEntry>, StoreError>` - newest first, capped at 1000.
  - Actions recorded, with their subject: `project.create`, `commit.create`, `branch.create`, `branch.delete`, `branch.reset`, `merge.clean`, `merge.conflict`, `lock.acquire`, `lock.release`, `gate.run`. The actor is the request's author or holder.
  - `GET /projects/:project/audit?limit=n` -> 200 [AuditEntry] newest first.

**Steps:**

- [ ] **Step 1: The table**, append-only in shape as well as intent:

```sql
CREATE TABLE IF NOT EXISTS audit (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    project TEXT NOT NULL,
    at INTEGER NOT NULL,
    actor TEXT NOT NULL,
    action TEXT NOT NULL,
    subject TEXT NOT NULL,
    detail TEXT NOT NULL
);
```

- [ ] **Step 2: Append and read** in the store, one transaction each, with the project's auditing written INSIDE the same transaction as the mutation it describes wherever that is practical (a commit and its audit row succeed or fail together). Where a mutation already owns a transaction - commit_model, commit_merge - the audit insert belongs inside it; the implementer must add an optional audit entry parameter to those two rather than writing the audit row in a second transaction, and must say so in the report if that proves awkward.

- [ ] **Step 3: Record from every mutation path.** A gate run records `gate.run` with the reference and candidate hashes and the verdict, including a FAILED gate: the audit trail exists to record what was attempted, not only what succeeded.

- [ ] **Step 4: server/src/audit_api.rs and the route** `GET /projects/:project/audit`.

- [ ] **Step 5: Tests** in server/tests/audit.rs:

1. `every_mutation_is_recorded` - create a project, commit, branch, merge cleanly, reset, acquire and release a lock, run a gate; then GET the audit and assert all nine actions appear with actor, subject and a non-empty detail.
2. `a_failed_gate_is_recorded` - run the gate on the corrupted corpus model and assert a `gate.run` entry whose detail says the run failed.
3. `a_conflicting_merge_is_recorded` - assert `merge.conflict` names the branches.
4. `entries_are_never_rewritten` - read the audit, append two more actions, read again, and assert the earlier entries are BYTE IDENTICAL (same ids, timestamps, actors, subjects and details) rather than merely present. This is the test that proves append-only.
5. `the_log_is_newest_first_and_capped` - request limit=2 and assert exactly two entries, newest first.

- [ ] **Step 6: Run, lint and commit** as before; expected 54 service tests, and the whole workspace green.

---


