﻿## Global Constraints

- Rust stable; edition 2021; rust-version 1.75; no new dependencies.
- Every source file begins with: // SPDX-License-Identifier: AGPL-3.0-or-later
- Cargo is not on PATH in fresh shells: begin every shell command sequence with $env:Path = "$env:USERPROFILE\\.cargo\\bin;" + $env:Path
- Use --no-fail-fast when running a test suite.
- Stage and commit only the paths a task owns. Never amend or rewrite a commit.
- History stays append-only: no operation deletes or rewrites a commit row.
- THE AUDIT LOG IS APPEND-ONLY: the Store exposes an append and a read, never an update or a delete, and a test must prove that a second append cannot alter an earlier entry.
- A lock is a LEASE: it carries an expiry, and an expired lock is available to anyone. A crashed client must never be able to block an element forever.
- Time is passed IN to the store, never read inside it, so lock expiry and audit timestamps are testable without sleeping. The store takes a now: i64 parameter; the HTTP layer supplies the real clock.
- Every request path returns a structured error and never panics: 400 malformed, 404 missing, 409 held by someone else or conflict, 422 invalid model, 500 internal with a generic message.
- Names (project, branch) are validated by api::validate_name before use.
- Tests drive the router in process with tower oneshot; no port is bound.


## Task 1: Element locks with leases

**Files:**
- Modify: server/src/store/mod.rs (Lock type, four trait methods)
- Modify: server/src/store/sqlite.rs (the locks table, the four methods)
- Create: server/src/locks_api.rs
- Modify: server/src/lib.rs (pub mod locks_api, three routes)
- Test: server/tests/locks.rs

**Interfaces:**
- Consumes: Store, ApiState, validate_name, map_store_error, now_epoch.
- Produces:
  - `pub struct Lock { pub id: String, pub project: String, pub branch: String, pub element: String, pub holder: String, pub acquired_at: i64, pub expires_at: i64 }`, serialised camelCase.
  - `Store::acquire_locks(&self, project: &str, branch: &str, elements: &[String], holder: &str, ttl_seconds: i64, now: i64) -> Result<Vec<Lock>, StoreError>` - all or nothing: if ANY element is held by another live lease, nothing is acquired and the error is Conflict naming the holder. Re-acquiring an element the same holder already holds EXTENDS the lease rather than failing.
  - `Store::release_locks(&self, project: &str, holder: &str, ids: &[String]) -> Result<usize, StoreError>` - only the holder may release; returns how many were released.
  - `Store::locks(&self, project: &str, now: i64) -> Result<Vec<Lock>, StoreError>` - live locks only; expired rows are reported as gone (and may be swept).
  - `Store::holders_of(&self, project: &str, elements: &[String], now: i64) -> Result<Vec<Lock>, StoreError>` - the live locks covering any of those elements, used by the commit path in Task 2.
  - `POST /projects/:project/locks` {"branch", "elements": [...], "holder", "ttlSeconds"} -> 201 [Lock] or 409.
  - `DELETE /projects/:project/locks` {"holder", "ids": [...]} -> 200 {"released": n}; a DELETE with a body is unusual, so ALSO accept `POST /projects/:project/locks/release` with the same body, which is what the CLI and agents use.
  - `GET /projects/:project/locks` -> 200 [Lock], live only.

**Steps:**

- [ ] **Step 1: Add the locks table to the schema** in server/src/store/sqlite.rs, next to the existing tables:

```sql
CREATE TABLE IF NOT EXISTS locks (
    id TEXT PRIMARY KEY,
    project TEXT NOT NULL,
    branch TEXT NOT NULL,
    element TEXT NOT NULL,
    holder TEXT NOT NULL,
    acquired_at INTEGER NOT NULL,
    expires_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS locks_element ON locks(project, element);
```

- [ ] **Step 2: Add the four trait methods** to server/src/store/mod.rs with the interfaces above, and implement them in sqlite.rs inside a single transaction each. The id is a hash of project, branch, element and holder plus a random-free counter derived from now, so it is deterministic in tests: `format!("{:x}", Sha256::digest(format!("{}|{}|{}|{}|{}", project, branch, element, holder, now)))` truncated to 32 hex characters. Reuse the crate's existing sha2 and hex dependencies.

- [ ] **Step 3: Implement acquire_locks** so that, inside one transaction, it first deletes rows whose expires_at <= now (sweeping dead leases), then checks for any remaining live lease on the requested elements held by a DIFFERENT holder, returning Conflict with the holder and expiry if found, then inserts or updates the rows for this holder. **All or nothing**: on conflict nothing is inserted.

- [ ] **Step 4: Write server/src/locks_api.rs** with the three handlers, following the gate_api.rs pattern for state, error mapping and validation. `ttlSeconds` is validated to be between 30 and 86400, so a lease cannot be infinite or uselessly short. `elements` must be non-empty and each name validated with validate_name.

- [ ] **Step 5: Add the routes** in server/src/lib.rs:

```rust
        .route(
            "/projects/:project/locks",
            post(locks_api::acquire_locks).get(locks_api::list_locks),
        )
        .route("/projects/:project/locks/release", post(locks_api::release_locks))
```

- [ ] **Step 6: Write server/tests/locks.rs** with these tests, each using its own temporary store:

1. `a_lock_can_be_acquired_listed_and_released` - acquire two elements, assert both appear in GET, release by id, assert GET is empty and the released count is 2.
2. `a_second_holder_is_refused_and_nothing_is_acquired` - holder A locks b1; holder B requests [b1, b2] and gets 409; GET shows ONLY A's lock, proving the request was all-or-nothing rather than partially applied.
3. `the_same_holder_can_extend_its_own_lease` - A locks b1, then A locks b1 again with a longer ttl and gets 201, and exactly one lock exists for b1.
4. `an_expired_lease_stops_blocking` - this is the one that needs the injected clock: acquire with a store-level call at now = 1000 and ttl 30, assert a request at now = 1000 is refused, then assert a request at now = 1031 succeeds. Drive it through the store directly, because the HTTP layer always passes the real clock.
5. `only_the_holder_can_release` - A locks b1, B tries to release A's id and releases zero; A's lock is still listed.

- [ ] **Step 7: Run, lint and commit**

```powershell
cargo test -p mw-server --no-fail-fast
cargo fmt --all
cargo clippy -p mw-server --all-targets -- -D warnings
git add server
git commit -m "feat: add element locks with leases"
```

Expected: 47 service tests pass (42 plus the five lock tests).

---


