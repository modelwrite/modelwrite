# Task 1 Report: Element locks with leases

## Status

DONE

## Commits

- `9543d53` feat: add element locks with leases (server/ only: store/mod.rs, store/sqlite.rs, locks_api.rs, lib.rs, tests/locks.rs)

## Test summary

`cargo test -p mw-server --no-fail-fast`: 47 passed, 0 failed (locks: 5, api: 11, store: 6, merge: 15, merge_api: 4, gate_api: 3, http: 2, corpus: 1).

`cargo fmt --all`: clean. `cargo clippy -p mw-server --all-targets -- -D warnings`: clean.

## What was implemented

- `locks` table + `locks_element` index in server/src/store/sqlite.rs.
- `Lock` type (serialised camelCase) and four trait methods in server/src/store/mod.rs:
  `acquire_locks`, `release_locks`, `locks`, `holders_of`.
- SQLite implementations, each in a single transaction. `acquire_locks` sweeps dead
  leases, then refuses (Conflict naming holder + expiry) if any requested element is held
  by a different live lease, then upserts this holder's rows (extend on re-acquire).
- `server/src/locks_api.rs`: `acquire_locks` (POST, 201), `list_locks` (GET, 200),
  `release_locks` (POST /release, 200 {"released": n}). ttlSeconds validated to [30, 86400];
  elements non-empty and name-validated; branch name validated.
- Routes in `server/src/lib.rs` per the brief's Step 5.
- `server/tests/locks.rs` with the five required tests.

## Self-review

- All-or-nothing is genuinely tested: `a_second_holder_is_refused_and_nothing_is_acquired`
  requests [b1, b2] while b1 is held, gets 409, and GET then shows ONLY the holder's b1 lock
  (nothing was partially acquired).
- Expiry is tested with an injected clock (`now = 1000` / `now = 1031`) driving the store
  directly; no sleep.
- No request path panics: handlers map every store error through `map_store_error` and
  return structured ApiError responses.
- SPDX headers present on all five touched files.

## Concerns

None.

## Deviations

None. One deliberate, requirement-aligned addition: the three handlers return 404 for an
unknown project (consistent with the brief's "404 missing" constraint and the existing
`create_commit`/`list_branches` pattern), rather than letting a lock be created against a
non-existent project.
