# Task 2 Report: A commit refuses to change an element someone else has locked

## Status

DONE

## Commits

- `adfac47` feat: refuse a commit that changes a locked element (server/ only: src/api.rs, tests/locks.rs)

## Test summary

`cargo test -p mw-server --no-fail-fast`: 50 passed, 0 failed (locks: 8, merge: 15, api: 11, store: 6, merge_api: 4, gate_api: 3, http: 2, corpus: 1).

`cargo fmt --all`: clean. `cargo clippy -p mw-server --all-targets -- -D warnings`: clean (exit 0).

## What was implemented

- `touched_elements` helper in server/src/api.rs, verbatim from the corrected brief: it reads
  `missing_elements` + `extra_elements` + `changed_attributes` (section-scoped
  `<section>:<id>` keys), skips `doc:` and `activity:` keys, and separately decodes the
  edge fields (`missing_edges` / `extra_edges`, canonical JSON arrays) to add both endpoints.
- `CreateCommit` gained `pub holder: Option<String>` (serde Option, so absent -> None).
- The lock assertion in `create_commit` sits after OKF validation and before `put_blob`:
  when a holder is supplied it diffs the branch tip against the incoming model, resolves the
  touched ids through `Store::holders_of`, and returns 409 naming element + holder + expiry if
  any touched element is held by a different holder. Absent holder, the path is unchanged.
- Two tests in server/tests/locks.rs (7 and 8, per the brief's numbering 6 and 7).

## Self-review

- A commit touching a locked element is refused AND writes nothing: test 7 renames b1 (locked by
  alex) as bob, asserts 409 naming b1 and alex, then asserts the branch tip is byte-for-byte the
  seed hash (nothing landed).
- A commit touching an UNLOCKED element succeeds while another element stays locked: test 7's
  second commit renames b2 (unlocked) while b1 remains locked and present in the document, and
  succeeds — proving a lock guards change, not mere presence.
- The holder may commit its own locked element: test 8 renames b1 as the lock's own holder (alex)
  and gets 201.
- A commit with no holder is unaffected: every pre-existing test commits without a holder and all
  42 still pass unchanged; no existing test was modified.

## Concerns

- The lock assertion is read-check-then-write inside create_commit (holders_of, then commit_model),
  exactly as the corrected brief specifies, so there is a small window in which a lock could be
  acquired between the check and the commit. This matches the brief's design and is not addressed
  in this task; it is the kind of race the tranche-3 plan defers to lock-aware merge/commit.

## Deviations

- The brief's "Files" header still lists server/src/store/mod.rs and sqlite.rs ("commit_model gains
  an optional allowed-holder check"), but the corrected Steps (Step 2) and the Interfaces perform
  the assertion in create_commit using the existing `Store::holders_of`, and the task instruction
  limits this task to "the touched_elements helper, the lock assertion in create_commit, and the two
  tests" with "do not add new lock storage". I therefore did NOT modify the store: the whole check
  lives in api.rs. This is a faithful reading of the corrected Steps, not a behaviour change.
- The brief's Step 2 snippet names the parsed model `incoming`; the existing handler already
  names it `root`, so I kept `root` (and use `root.clone()` for the no-tip case). Cosmetic
  only — the logic is identical to the snippet.
