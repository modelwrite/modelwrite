﻿# Tranche 3 fix round - re-review package (regenerated in full)

## Commits under review

7b92185 fix: make a lock refusal a structured error and let a holder finish its own work
8a3d7a2 fix(server): enforce locks on all write paths and make audit writes atomic

## Files changed

 server/src/api.rs          | 265 ++++++++++++++++---------
 server/src/gate_api.rs     |  30 +--
 server/src/locks_api.rs    | 119 +++++++-----
 server/src/merge_api.rs    |  38 +++-
 server/src/store/mod.rs    |  78 +++++++-
 server/src/store/sqlite.rs | 243 ++++++++++++++++-------
 server/tests/locks.rs      | 471 ++++++++++++++++++++++++++++++++++++++++++++-
 server/tests/store.rs      | 174 +++++++++++++++--
 8 files changed, 1151 insertions(+), 267 deletions(-)

## FILE: server/src/store/mod.rs

diff --git a/server/src/store/mod.rs b/server/src/store/mod.rs
index 9ddbf48..c2744a1 100644
--- a/server/src/store/mod.rs
+++ b/server/src/store/mod.rs
@@ -66,20 +66,37 @@ pub struct AuditEntry {
 
 #[derive(Debug)]
 pub enum StoreError {
     NotFound(String),
     Conflict(String),
     Backend(String),
+    /// A guarded write would change an element somebody else holds a live lease on.
+    ///
+    /// This is its own variant rather than a `Conflict` with particular wording, because
+    /// the caller must tell a LOCKED refusal from a stale-tip refusal: the first is
+    /// recorded as an attempt to overwrite someone's work, the second is an ordinary
+    /// retry. Deciding that by searching the message for a phrase would make a record of
+    /// who tried to overwrite whom depend on the wording of an error string.
+    Locked {
+        element: String,
+        holder: String,
+        expires_at: i64,
+    },
 }
 
 impl std::fmt::Display for StoreError {
     fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
         match self {
             StoreError::NotFound(m) => write!(f, "not found: {}", m),
             StoreError::Conflict(m) => write!(f, "conflict: {}", m),
             StoreError::Backend(m) => write!(f, "storage error: {}", m),
+            StoreError::Locked {
+                element,
+                holder,
+                expires_at,
+            } => write!(f, "{} is held by {} until {}", element, holder, expires_at),
         }
     }
 }
 
 impl std::error::Error for StoreError {}
 
@@ -137,14 +154,18 @@ pub fn now_epoch() -> String {
 /// The real clock in seconds, for callers that pass time INTO the store (lock expiry,
 /// audit timestamps). The store itself never calls this.
 pub fn now_seconds() -> i64 {
     now_epoch().parse().unwrap_or(0)
 }
 
-/// What a guarded commit must not change. The holder is the one asking; any element in
-/// `elements` held by a DIFFERENT holder with a live lease refuses the commit.
+/// What a guarded commit must not change. Any element in `elements` held by a DIFFERENT
+/// holder with a live lease refuses the commit. The holder is the one asking; an empty
+/// holder is a request that supplied none, so it can never be the holder and any live
+/// lease on a touched element refuses it. Locks are therefore enforced by default: every
+/// write path passes a guard, and a writer that omits the holder is refused, not let
+/// through.
 ///
 /// `expected_tip` is the branch tip the caller computed `elements` against. The guard is
 /// only meaningful for that tip: if the branch moved since, the touched set describes a
 /// document that is no longer there, and enforcing it would protect the wrong elements -
 /// a race that a fresh check cannot catch from outside the transaction. The store refuses
 /// instead, and the caller re-reads and retries.
@@ -157,14 +178,34 @@ pub struct CommitGuard<'a> {
     pub holder: &'a str,
     pub elements: &'a [String],
     pub now: i64,
     pub expected_tip: Option<&'a str>,
 }
 
+/// The refusal every guarded write path produces when it would change a locked element.
+/// It names the element, the holder and the lease expiry, and tells a caller who IS the
+/// holder to supply the holder field: a request without a holder cannot be the holder, so
+/// a live lease on a touched element refuses it too.
+pub fn lock_refusal(element: &str, holder: &str, expires_at: i64) -> StoreError {
+    StoreError::Locked {
+        element: element.to_string(),
+        holder: holder.to_string(),
+        expires_at,
+    }
+}
+
+/// True when the store refused because somebody else holds the element.
+pub fn is_lock_refusal(error: &StoreError) -> bool {
+    matches!(error, StoreError::Locked { .. })
+}
+
 pub trait Store: Send + Sync {
-    fn create_project(&self, name: &str) -> Result<Project, StoreError>;
+    /// Create a project and, when `audit` is supplied, write its audit row inside the
+    /// same transaction, so a durable project always has a record and vice versa.
+    fn create_project(&self, name: &str, audit: Option<&AuditEntry>)
+        -> Result<Project, StoreError>;
     fn project(&self, name: &str) -> Result<Option<Project>, StoreError>;
     fn list_projects(&self) -> Result<Vec<Project>, StoreError>;
     fn put_blob(&self, bytes: &[u8]) -> Result<String, StoreError>;
     fn blob(&self, hash: &str) -> Result<Option<Vec<u8>>, StoreError>;
 
     /// Commit a model onto a branch atomically: the tip is read, the parents and the
@@ -189,58 +230,79 @@ pub trait Store: Send + Sync {
         guard: Option<CommitGuard<'_>>,
         audit: Option<&AuditEntry>,
     ) -> Result<Commit, StoreError>;
 
     /// Write a commit with EXPLICIT parents and move the branch tip, in one transaction.
     /// A merge commit has two parents, so the parent list cannot be derived from the tip.
+    /// The optional guard is checked inside that transaction, exactly as `commit_model`
+    /// does: a merge that would change a locked element is refused rather than overwriting
+    /// the holder's work.
     #[allow(clippy::too_many_arguments)]
     fn commit_merge(
         &self,
         project: &str,
         branch: &str,
         parents: &[String],
         okf_hash: &str,
         author: &str,
         message: &str,
+        guard: Option<CommitGuard<'_>>,
         audit: Option<&AuditEntry>,
     ) -> Result<Commit, StoreError>;
 
     fn commit(&self, project: &str, hash: &str) -> Result<Option<Commit>, StoreError>;
     fn commits_on(&self, project: &str, branch: &str) -> Result<Vec<Commit>, StoreError>;
     fn branch_tip(&self, project: &str, branch: &str) -> Result<Option<String>, StoreError>;
-    fn create_branch(&self, project: &str, name: &str, from: &str) -> Result<(), StoreError>;
+    fn create_branch(
+        &self,
+        project: &str,
+        name: &str,
+        from: &str,
+        audit: Option<&AuditEntry>,
+    ) -> Result<(), StoreError>;
 
     /// Remove a branch pointer. This never deletes commits: the objects a branch pointed
     /// at stay in the store, so a deleted branch can be recreated at the same hash and no
-    /// history is ever lost.
-    fn delete_branch(&self, project: &str, name: &str) -> Result<(), StoreError>;
+    /// history is ever lost. The audit row, when supplied, is written in the same
+    /// transaction as the deletion.
+    fn delete_branch(
+        &self,
+        project: &str,
+        name: &str,
+        audit: Option<&AuditEntry>,
+    ) -> Result<(), StoreError>;
     fn list_branches(&self, project: &str) -> Result<Vec<(String, String)>, StoreError>;
-    fn record_gate_run(&self, run: &GateRun) -> Result<(), StoreError>;
+    fn record_gate_run(&self, run: &GateRun, audit: Option<&AuditEntry>) -> Result<(), StoreError>;
     fn gate_runs(&self, project: &str) -> Result<Vec<GateRun>, StoreError>;
 
     /// Acquire a lease on each of `elements`, all or nothing. If any element is held by a
     /// live lease owned by a DIFFERENT holder, nothing is acquired and a Conflict is
     /// returned naming the holder and the expiry. Re-acquiring an element the same holder
     /// already holds extends the lease rather than failing.
+    #[allow(clippy::too_many_arguments)]
     fn acquire_locks(
         &self,
         project: &str,
         branch: &str,
         elements: &[String],
         holder: &str,
         ttl_seconds: i64,
         now: i64,
+        audit: Option<&AuditEntry>,
     ) -> Result<Vec<Lock>, StoreError>;
 
     /// Release locks by id; only the listed holder may release them. Returns how many
-    /// rows were actually removed.
+    /// rows were actually removed. The audit row, when supplied, is written inside the
+    /// same transaction, and only when at least one row was actually removed: a no-op
+    /// release is not a mutation and writes no entry.
     fn release_locks(
         &self,
         project: &str,
         holder: &str,
         ids: &[String],
+        audit: Option<&AuditEntry>,
     ) -> Result<usize, StoreError>;
 
     /// Live locks on a project: expired rows are reported as gone.
     fn locks(&self, project: &str, now: i64) -> Result<Vec<Lock>, StoreError>;
 
     /// The live locks covering any of the given elements, used by the commit path to see

## FILE: server/src/store/sqlite.rs

diff --git a/server/src/store/sqlite.rs b/server/src/store/sqlite.rs
index 4b3a53c..2fa23d3 100644
--- a/server/src/store/sqlite.rs
+++ b/server/src/store/sqlite.rs
@@ -59,12 +59,25 @@ CREATE TABLE IF NOT EXISTS audit (
     at INTEGER NOT NULL,
     actor TEXT NOT NULL,
     action TEXT NOT NULL,
     subject TEXT NOT NULL,
     detail TEXT NOT NULL
 );
+-- Append-only is a property of the DATABASE, not a convention of the trait: these
+-- triggers make UPDATE and DELETE on the audit table fail outright, so a written entry
+-- can never be rewritten or removed by any code path that reaches SQLite.
+CREATE TRIGGER IF NOT EXISTS audit_no_update
+BEFORE UPDATE ON audit
+BEGIN
+    SELECT RAISE(ABORT, 'audit entries are append-only');
+END;
+CREATE TRIGGER IF NOT EXISTS audit_no_delete
+BEFORE DELETE ON audit
+BEGIN
+    SELECT RAISE(ABORT, 'audit entries are append-only');
+END;
 ";
 
 pub struct SqliteStore {
     connection: std::sync::Mutex<Connection>,
 }
 
@@ -106,40 +119,101 @@ fn parse_parents(hash: &str, raw: &str) -> Result<Vec<String>, StoreError> {
         StoreError::Backend(format!("corrupt parents column for commit {}: {}", hash, e))
     })
 }
 
 /// Insert one audit row and return its AUTOINCREMENT id. The caller's `id` field is
 /// ignored: the store assigns ids, and no update or delete path ever reuses or rewrites one.
-/// Shared by `append_audit` and by the commit/merge transactions that must write the audit
-/// row atomically with the mutation it describes.
+/// Shared by `append_audit` and by the transactions that must write the audit row
+/// atomically with the mutation it describes.
 fn insert_audit(c: &Connection, entry: &AuditEntry) -> rusqlite::Result<i64> {
     c.execute(
         "INSERT INTO audit (project, at, actor, action, subject, detail) VALUES (?1, ?2, ?3, ?4, ?5, ?6)",
         params![entry.project, entry.at, entry.actor, entry.action, entry.subject, entry.detail],
     )?;
     Ok(c.last_insert_rowid())
 }
 
+/// Run a closure inside ONE write transaction, committing only when it succeeds. On
+/// failure the transaction is dropped, which rolls back every statement the closure ran.
+/// This is what makes a mutation and its audit row land together or not at all.
+fn with_tx<T>(
+    connection: &std::sync::Mutex<Connection>,
+    f: impl FnOnce(&rusqlite::Transaction<'_>) -> Result<T, StoreError>,
+) -> Result<T, StoreError> {
+    let guard = connection
+        .lock()
+        .map_err(|_| StoreError::Backend("connection lock poisoned".to_string()))?;
+    let tx = guard
+        .unchecked_transaction()
+        .map_err(|e| StoreError::Backend(e.to_string()))?;
+    let result = f(&tx);
+    if result.is_ok() {
+        tx.commit()
+            .map_err(|e| StoreError::Backend(e.to_string()))?;
+    }
+    result
+}
+
+/// Refuse a guarded write when any element carries a live lease owned by a different
+/// holder. Every write path — commit, merge and reset — funnels through this one rule, so
+/// a lock protects an element from being changed no matter which path is used. An empty
+/// holder cannot own a lease, so any live lease on a touched element refuses it: a request
+/// without a holder is checked, not exempted.
+fn enforce_guard(
+    tx: &rusqlite::Transaction<'_>,
+    project: &str,
+    guard: &CommitGuard<'_>,
+) -> Result<(), StoreError> {
+    for element in guard.elements {
+        let held: Option<(String, i64)> = (|| -> rusqlite::Result<Option<(String, i64)>> {
+            let mut stmt = tx.prepare(
+                "SELECT holder, expires_at FROM locks WHERE project = ?1 AND element = ?2 AND expires_at > ?3 AND holder != ?4 LIMIT 1",
+            )?;
+            let mut rows = stmt.query(params![project, element, guard.now, guard.holder])?;
+            match rows.next()? {
+                Some(row) => Ok(Some((row.get(0)?, row.get(1)?))),
+                None => Ok(None),
+            }
+        })()
+        .map_err(|e| StoreError::Backend(e.to_string()))?;
+        if let Some((holder, expires_at)) = held {
+            return Err(super::lock_refusal(element, &holder, expires_at));
+        }
+    }
+    Ok(())
+}
+
 impl Store for SqliteStore {
-    fn create_project(&self, name: &str) -> Result<Project, StoreError> {
+    fn create_project(
+        &self,
+        name: &str,
+        audit: Option<&AuditEntry>,
+    ) -> Result<Project, StoreError> {
         // Check-then-insert would be a time-of-check window: two concurrent callers could
         // both pass the check. The primary key settles it instead, and an insert that
-        // changed nothing is reported as the conflict it is.
+        // changed nothing is reported as the conflict it is. The audit row, when supplied,
+        // rides the same transaction, so a project and its record land together.
         let created_at = now_epoch();
-        let inserted = self.with(|c| {
-            c.execute(
-                "INSERT OR IGNORE INTO projects (name, created_at) VALUES (?1, ?2)",
-                params![name, created_at],
-            )
+        with_tx(&self.connection, |tx| {
+            let inserted = tx
+                .execute(
+                    "INSERT OR IGNORE INTO projects (name, created_at) VALUES (?1, ?2)",
+                    params![name, created_at],
+                )
+                .map_err(|e| StoreError::Backend(e.to_string()))?;
+            if inserted == 0 {
+                return Err(StoreError::Conflict(format!(
+                    "project {} already exists",
+                    name
+                )));
+            }
+            if let Some(audit) = audit {
+                insert_audit(tx, audit).map_err(|e| StoreError::Backend(e.to_string()))?;
+            }
+            Ok(())
         })?;
-        if inserted == 0 {
-            return Err(StoreError::Conflict(format!(
-                "project {} already exists",
-                name
-            )));
-        }
         Ok(Project {
             name: name.to_string(),
             created_at,
         })
     }
 
@@ -212,32 +286,13 @@ impl Store for SqliteStore {
             .map_err(|e| StoreError::Backend(e.to_string()))?;
 
         // The lock check happens HERE, inside the transaction that writes the commit. A
         // check performed by the caller before this call would leave a window in which
         // another holder takes the lock and the guarded commit lands regardless.
         if let Some(guard) = guard.as_ref() {
-            for element in guard.elements {
-                let held: Option<(String, i64)> = (|| -> rusqlite::Result<Option<(String, i64)>> {
-                    let mut stmt = tx.prepare(
-                        "SELECT holder, expires_at FROM locks WHERE project = ?1 AND element = ?2 AND expires_at > ?3 AND holder != ?4 LIMIT 1",
-                    )?;
-                    let mut rows =
-                        stmt.query(params![project, element, guard.now, guard.holder])?;
-                    match rows.next()? {
-                        Some(row) => Ok(Some((row.get(0)?, row.get(1)?))),
-                        None => Ok(None),
-                    }
-                })()
-                .map_err(|e| StoreError::Backend(e.to_string()))?;
-                if let Some((holder, expires_at)) = held {
-                    return Err(StoreError::Conflict(format!(
-                        "{} is locked by {} until {}",
-                        element, holder, expires_at
-                    )));
-                }
-            }
+            enforce_guard(&tx, project, guard)?;
         }
 
         // The tip is read inside the same lock and transaction that writes the commit, so
         // two concurrent commits to one branch chain rather than fork.
         let tip: Option<String> = (|| -> rusqlite::Result<Option<String>> {
             let mut stmt =
@@ -303,28 +358,29 @@ impl Store for SqliteStore {
         project: &str,
         branch: &str,
         parents: &[String],
         okf_hash: &str,
         author: &str,
         message: &str,
+        guard: Option<CommitGuard<'_>>,
         audit: Option<&AuditEntry>,
     ) -> Result<Commit, StoreError> {
         // A merge commit has exactly two parents. Anything else is a caller mistake, and it
         // would quietly write a root commit or an ordinary single-parent commit under the
         // name of a merge.
         if parents.len() != 2 {
             return Err(StoreError::Backend(format!(
                 "a merge commit needs exactly two parents, got {}",
                 parents.len()
             )));
         }
-        let guard = self
+        let connection = self
             .connection
             .lock()
             .map_err(|_| StoreError::Backend("connection lock poisoned".to_string()))?;
-        let tx = guard
+        let tx = connection
             .unchecked_transaction()
             .map_err(|e| StoreError::Backend(e.to_string()))?;
 
         // The first parent must still BE the branch tip. A merge is computed from tips read
         // BEFORE this call, so if anything landed in between - another commit, a merge or a
         // reset - writing this commit would move the branch off that work and leave it
@@ -346,12 +402,18 @@ impl Store for SqliteStore {
                 branch,
                 parents[0],
                 current_tip.as_deref().unwrap_or("nothing")
             )));
         }
 
+        // The merge's guard runs inside the transaction that writes it, so a lock taken
+        // between the caller's read and this write cannot be bypassed.
+        if let Some(guard) = guard.as_ref() {
+            enforce_guard(&tx, project, guard)?;
+        }
+
         // Every parent must already exist: a merge commit can only cite ancestry that is
         // really there, never invent it.
         for parent in parents {
             let exists: bool = (|| -> rusqlite::Result<bool> {
                 let mut stmt =
                     tx.prepare("SELECT 1 FROM commits WHERE project = ?1 AND hash = ?2")?;
@@ -488,67 +550,93 @@ impl Store for SqliteStore {
                 Some(row) => Ok(Some(row.get(0)?)),
                 None => Ok(None),
             }
         })
     }
 
-    fn create_branch(&self, project: &str, name: &str, from: &str) -> Result<(), StoreError> {
+    fn create_branch(
+        &self,
+        project: &str,
+        name: &str,
+        from: &str,
+        audit: Option<&AuditEntry>,
+    ) -> Result<(), StoreError> {
         if self.commit(project, from)?.is_none() {
             return Err(StoreError::NotFound(format!("commit {}", from)));
         }
-        // The composite primary key decides a duplicate branch, not a prior read.
-        let inserted = self.with(|c| {
-            c.execute(
-                "INSERT OR IGNORE INTO branches (project, name, tip) VALUES (?1, ?2, ?3)",
-                params![project, name, from],
-            )
-        })?;
-        if inserted == 0 {
-            return Err(StoreError::Conflict(format!(
-                "branch {} already exists",
-                name
-            )));
-        }
-        Ok(())
+        // The composite primary key decides a duplicate branch, not a prior read. The
+        // audit row rides the same transaction as the branch insert.
+        with_tx(&self.connection, |tx| {
+            let inserted = tx
+                .execute(
+                    "INSERT OR IGNORE INTO branches (project, name, tip) VALUES (?1, ?2, ?3)",
+                    params![project, name, from],
+                )
+                .map_err(|e| StoreError::Backend(e.to_string()))?;
+            if inserted == 0 {
+                return Err(StoreError::Conflict(format!(
+                    "branch {} already exists",
+                    name
+                )));
+            }
+            if let Some(audit) = audit {
+                insert_audit(tx, audit).map_err(|e| StoreError::Backend(e.to_string()))?;
+            }
+            Ok(())
+        })
     }
 
-    fn delete_branch(&self, project: &str, name: &str) -> Result<(), StoreError> {
+    fn delete_branch(
+        &self,
+        project: &str,
+        name: &str,
+        audit: Option<&AuditEntry>,
+    ) -> Result<(), StoreError> {
         // Ask which thing is missing, so the 404 says so: a delete on an unknown project
         // would otherwise report a branch that was never the problem.
         if self.project(project)?.is_none() {
             return Err(StoreError::NotFound(format!("project {}", project)));
         }
-        let removed = self.with(|c| {
-            c.execute(
-                "DELETE FROM branches WHERE project = ?1 AND name = ?2",
-                params![project, name],
-            )
-        })?;
-        if removed == 0 {
-            return Err(StoreError::NotFound(format!("branch {}", name)));
-        }
-        Ok(())
+        with_tx(&self.connection, |tx| {
+            let removed = tx
+                .execute(
+                    "DELETE FROM branches WHERE project = ?1 AND name = ?2",
+                    params![project, name],
+                )
+                .map_err(|e| StoreError::Backend(e.to_string()))?;
+            if removed == 0 {
+                return Err(StoreError::NotFound(format!("branch {}", name)));
+            }
+            if let Some(audit) = audit {
+                insert_audit(tx, audit).map_err(|e| StoreError::Backend(e.to_string()))?;
+            }
+            Ok(())
+        })
     }
 
     fn list_branches(&self, project: &str) -> Result<Vec<(String, String)>, StoreError> {
         self.with(|c| {
             let mut stmt =
                 c.prepare("SELECT name, tip FROM branches WHERE project = ?1 ORDER BY name")?;
             let rows = stmt.query_map(params![project], |row| Ok((row.get(0)?, row.get(1)?)))?;
             rows.collect()
         })
     }
 
-    fn record_gate_run(&self, run: &GateRun) -> Result<(), StoreError> {
-        self.with(|c| {
-            c.execute(
+    fn record_gate_run(&self, run: &GateRun, audit: Option<&AuditEntry>) -> Result<(), StoreError> {
+        with_tx(&self.connection, |tx| {
+            tx.execute(
                 "INSERT INTO gate_runs (project, branch, reference_hash, candidate_hash, passed, evidence, created_at) VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7)",
                 params![run.project, run.branch, run.reference_hash, run.candidate_hash, run.passed as i64, run.evidence, run.created_at],
             )
-        })?;
-        Ok(())
+            .map_err(|e| StoreError::Backend(e.to_string()))?;
+            if let Some(audit) = audit {
+                insert_audit(tx, audit).map_err(|e| StoreError::Backend(e.to_string()))?;
+            }
+            Ok(())
+        })
     }
 
     fn gate_runs(&self, project: &str) -> Result<Vec<GateRun>, StoreError> {
         self.with(|c| {
             let mut stmt = c.prepare(
                 "SELECT project, branch, reference_hash, candidate_hash, passed, evidence, created_at FROM gate_runs WHERE project = ?1 ORDER BY id",
@@ -590,20 +678,22 @@ impl Store for SqliteStore {
                 })
             })?;
             rows.collect()
         })
     }
 
+    #[allow(clippy::too_many_arguments)]
     fn acquire_locks(
         &self,
         project: &str,
         branch: &str,
         elements: &[String],
         holder: &str,
         ttl_seconds: i64,
         now: i64,
+        audit: Option<&AuditEntry>,
     ) -> Result<Vec<Lock>, StoreError> {
         let guard = self
             .connection
             .lock()
             .map_err(|_| StoreError::Backend("connection lock poisoned".to_string()))?;
         let tx = guard
@@ -628,16 +718,13 @@ impl Store for SqliteStore {
                         None => Ok(None),
                     }
                 })()
                 .map_err(|e| StoreError::Backend(e.to_string()))?;
 
             if let Some((other, expires_at)) = conflict {
-                return Err(StoreError::Conflict(format!(
-                    "element {} is held by {} (expires at {})",
-                    element, other, expires_at
-                )));
+                return Err(super::lock_refusal(element, &other, expires_at));
             }
         }
 
         // Upsert this holder's rows: extend an existing lease, insert a new one otherwise.
         let mut locks = Vec::with_capacity(elements.len());
         for element in elements {
@@ -683,23 +770,27 @@ impl Store for SqliteStore {
                 holder: holder.to_string(),
                 acquired_at,
                 expires_at,
             });
         }
 
+        if let Some(audit) = audit {
+            insert_audit(&tx, audit).map_err(|e| StoreError::Backend(e.to_string()))?;
+        }
         tx.commit()
             .map_err(|e| StoreError::Backend(e.to_string()))?;
 
         Ok(locks)
     }
 
     fn release_locks(
         &self,
         project: &str,
         holder: &str,
         ids: &[String],
+        audit: Option<&AuditEntry>,
     ) -> Result<usize, StoreError> {
         let guard = self
             .connection
             .lock()
             .map_err(|_| StoreError::Backend("connection lock poisoned".to_string()))?;
         let tx = guard
@@ -715,12 +806,20 @@ impl Store for SqliteStore {
                     "DELETE FROM locks WHERE project = ?1 AND holder = ?2 AND id = ?3",
                     params![project, holder, id],
                 )
                 .map_err(|e| StoreError::Backend(e.to_string()))?;
         }
 
+        // A release that removes nothing is not a mutation and writes no audit entry. The
+        // entry, when written, rides this transaction so it cannot outlive its rows.
+        if released > 0 {
+            if let Some(audit) = audit {
+                insert_audit(&tx, audit).map_err(|e| StoreError::Backend(e.to_string()))?;
+            }
+        }
+
         tx.commit()
             .map_err(|e| StoreError::Backend(e.to_string()))?;
         Ok(released)
     }
 
     fn locks(&self, project: &str, now: i64) -> Result<Vec<Lock>, StoreError> {

## FILE: server/src/api.rs

diff --git a/server/src/api.rs b/server/src/api.rs
index d090656..3d681e3 100644
--- a/server/src/api.rs
+++ b/server/src/api.rs
@@ -5,13 +5,15 @@ use axum::extract::{Path, Query, State};
 use axum::http::StatusCode;
 use axum::Json;
 use serde::Deserialize;
 use serde_json::{json, Value};
 
 use crate::error::ApiError;
-use crate::store::{now_epoch, AuditEntry, Commit, CommitGuard, Store, StoreError};
+use crate::store::{
+    is_lock_refusal, now_epoch, AuditEntry, Commit, CommitGuard, Store, StoreError,
+};
 
 #[derive(Clone)]
 pub struct ApiState {
     pub store: Arc<dyn Store>,
     pub evidence_dir: std::path::PathBuf,
 }
@@ -49,19 +51,48 @@ pub fn validate_name(kind: &str, name: &str) -> Result<(), ApiError> {
             kind
         )));
     }
     Ok(())
 }
 
+/// Validate an element id taken from an OKF document. This is deliberately wider than
+/// `validate_name`: element ids come from the model itself, and their charset may include
+/// characters `validate_name` rejects. An element that can be CHANGED must also be LOCKED,
+/// so the only requirements are non-empty, no control characters, and at most 256 bytes.
+pub fn validate_element_name(name: &str) -> Result<(), ApiError> {
+    if name.is_empty() {
+        return Err(ApiError::bad_request("element name must not be empty"));
+    }
+    if name.len() > 256 {
+        return Err(ApiError::bad_request(
+            "element name must be 256 bytes or fewer",
+        ));
+    }
+    if name.chars().any(|c| c.is_control()) {
+        return Err(ApiError::bad_request(
+            "element name must not contain control characters",
+        ));
+    }
+    Ok(())
+}
+
 /// Storage failures are logged with their detail and reported to the caller as a generic
 /// internal error: the detail names schema objects and hashes, which is not the client's
 /// business once this stops binding to localhost.
 pub fn map_store_error(e: StoreError) -> ApiError {
     match e {
         StoreError::NotFound(m) => ApiError::not_found(m),
         StoreError::Conflict(m) => ApiError::conflict(m),
+        StoreError::Locked {
+            element,
+            holder,
+            expires_at,
+        } => ApiError::conflict(format!(
+            "{} is locked by {} until {}; a caller who holds this lease must supply the holder field to proceed",
+            element, holder, expires_at
+        )),
         StoreError::Backend(m) => {
             eprintln!("storage error: {}", m);
             ApiError::internal("internal storage error")
         }
     }
 }
@@ -94,16 +125,69 @@ pub fn load_model(
 /// The real clock in seconds, as the store requires it. The store itself never reads the
 /// clock: time is passed in so lock expiry is testable without sleeping.
 fn now_seconds() -> i64 {
     now_epoch().parse().unwrap_or(0)
 }
 
+/// Record a refusal - an action that was ATTEMPTED but refused - in the audit log. A
+/// refusal is not a mutation, so it appends directly rather than riding a transaction; the
+/// event matters even though nothing changed.
+pub fn record_refusal(
+    store: &dyn Store,
+    project: &str,
+    actor: &str,
+    action: &str,
+    subject: &str,
+    detail: &str,
+) -> Result<(), ApiError> {
+    store
+        .append_audit(&AuditEntry {
+            id: 0,
+            project: project.to_string(),
+            at: now_seconds(),
+            actor: actor.to_string(),
+            action: action.to_string(),
+            subject: subject.to_string(),
+            detail: detail.to_string(),
+        })
+        .map(|_| ())
+        .map_err(map_store_error)
+}
+
+/// Call a commit-producing store method and, if it is refused because an element is
+/// locked, record commit.refused before surfacing the 409. A lock refusal is the
+/// highest-value event this feature produces: it is the overwrite the lock prevented.
+pub fn commit_refusal_guard(
+    state: &ApiState,
+    project: &str,
+    branch: &str,
+    author: &str,
+    result: Result<Commit, StoreError>,
+) -> Result<Commit, ApiError> {
+    match result {
+        Ok(commit) => Ok(commit),
+        Err(error) if is_lock_refusal(&error) => {
+            let detail = error.to_string();
+            record_refusal(
+                state.store.as_ref(),
+                project,
+                author,
+                "commit.refused",
+                branch,
+                &detail,
+            )?;
+            Err(map_store_error(error))
+        }
+        Err(error) => Err(map_store_error(error)),
+    }
+}
+
 /// The elements a commit changes: every diff entry that names an element, plus the
 /// endpoints of changed edges. A lock protects an element from being CHANGED, so an
 /// untouched element elsewhere in the document does not block the commit.
-fn touched_elements(
+pub fn touched_elements(
     reference: &okf::types::OkfRoot,
     candidate: &okf::types::OkfRoot,
 ) -> Vec<String> {
     let report = okf::diff::diff(reference, candidate);
     let mut ids: std::collections::BTreeSet<String> = std::collections::BTreeSet::new();
 
@@ -159,27 +243,24 @@ pub struct CreateProject {
 
 pub async fn create_project(
     State(state): State<ApiState>,
     Json(body): Json<CreateProject>,
 ) -> Result<(StatusCode, Json<Value>), ApiError> {
     validate_name("project name", &body.name)?;
+    let audit = AuditEntry {
+        id: 0,
+        project: body.name.clone(),
+        at: now_seconds(),
+        actor: "unknown".to_string(),
+        action: "project.create".to_string(),
+        subject: body.name.clone(),
+        detail: "project created".to_string(),
+    };
     let project = state
         .store
-        .create_project(&body.name)
-        .map_err(map_store_error)?;
-    state
-        .store
-        .append_audit(&AuditEntry {
-            id: 0,
-            project: project.name.clone(),
-            at: now_seconds(),
-            actor: "unknown".to_string(),
-            action: "project.create".to_string(),
-            subject: project.name.clone(),
-            detail: "project created".to_string(),
-        })
+        .create_project(&body.name, Some(&audit))
         .map_err(map_store_error)?;
     Ok((
         StatusCode::CREATED,
         Json(json!({ "name": project.name, "createdAt": project.created_at })),
     ))
 }
@@ -227,77 +308,63 @@ pub async fn create_commit(
         return Err(ApiError::unprocessable(
             "the model failed validation",
             report.errors,
         ));
     }
 
-    // A holder that asks the commit to respect locks: refuse to change any element held by
-    // someone else. Absent, the commit behaves exactly as before - locks are opt-in. The
-    // check itself happens INSIDE the store's commit transaction, so a lock taken between
-    // this point and the write cannot be bypassed.
-    let mut tip_hash: Option<String> = None;
-    let touched: Vec<String> = match body.holder.as_deref() {
-        Some(holder) => {
-            tip_hash = state
-                .store
-                .branch_tip(&project, &body.branch)
-                .map_err(map_store_error)?;
-            let tip_model = match tip_hash.as_deref() {
-                Some(tip) => load_model(&state, &project, tip)?,
-                None => root.clone(),
-            };
-            let touched = touched_elements(&tip_model, &root);
-            // Refuse BEFORE storing anything, so a rejected commit leaves no orphaned blob
-            // behind. The store checks again inside its transaction; this is the cheap path.
-            let held = state
-                .store
-                .holders_of(&project, &touched, now_seconds())
-                .map_err(map_store_error)?;
-            if let Some(blocked) = held.iter().find(|l| l.holder != holder) {
-                return Err(ApiError::conflict(format!(
-                    "{} is locked by {} until {}",
-                    blocked.element, blocked.holder, blocked.expires_at
-                )));
-            }
-            touched
-        }
-        None => Vec::new(),
+    // Locks are enforced by default, not by opt-in. Every commit computes the elements it
+    // would change and refuses to change any element with a live lease held by a different
+    // holder. A missing holder is still checked: it cannot be the holder, so a live lease
+    // on a touched element refuses it too. The authoritative check runs inside the store's
+    // commit transaction, so a lock taken after this point cannot be bypassed.
+    let now = now_seconds();
+    let tip_hash = state
+        .store
+        .branch_tip(&project, &body.branch)
+        .map_err(map_store_error)?;
+    let tip_model = match tip_hash.as_deref() {
+        Some(tip) => load_model(&state, &project, tip)?,
+        None => root.clone(),
     };
-    let guard = body.holder.as_deref().map(|holder| CommitGuard {
-        holder,
+    let touched = touched_elements(&tip_model, &root);
+    let guard = CommitGuard {
+        holder: body.holder.as_deref().unwrap_or(""),
         elements: &touched,
-        now: now_seconds(),
+        now,
         expected_tip: tip_hash.as_deref(),
-    });
+    };
 
     let okf_hash = state.store.put_blob(&bytes).map_err(map_store_error)?;
     // One call, one transaction: the parents come from the tip the store reads inside the
     // same lock that writes the commit, so two concurrent commits to one branch chain
     // instead of forking the history. The audit row rides the SAME transaction, so the
     // commit and its record of who made it succeed or fail together.
     let audit = AuditEntry {
         id: 0,
         project: project.clone(),
-        at: now_seconds(),
+        at: now,
         actor: body.author.clone(),
         action: "commit.create".to_string(),
         subject: body.branch.clone(),
         detail: body.message.clone(),
     };
-    let commit = state
-        .store
-        .commit_model(
+    let commit = commit_refusal_guard(
+        &state,
+        &project,
+        &body.branch,
+        &body.author,
+        state.store.commit_model(
             &project,
             &body.branch,
             &okf_hash,
             &body.author,
             &body.message,
-            guard,
+            Some(guard),
             Some(&audit),
-        )
-        .map_err(map_store_error)?;
+        ),
+    )?;
     Ok((StatusCode::CREATED, Json(commit_json(&commit))))
 }
 
 #[derive(Deserialize)]
 pub struct BranchQuery {
     pub branch: Option<String>,
@@ -351,27 +418,24 @@ pub struct CreateBranch {
 pub async fn create_branch(
     State(state): State<ApiState>,
     Path(project): Path<String>,
     Json(body): Json<CreateBranch>,
 ) -> Result<(StatusCode, Json<Value>), ApiError> {
     validate_name("branch name", &body.name)?;
+    let audit = AuditEntry {
+        id: 0,
+        project: project.clone(),
+        at: now_seconds(),
+        actor: "unknown".to_string(),
+        action: "branch.create".to_string(),
+        subject: body.name.clone(),
+        detail: format!("from {}", body.from),
+    };
     state
         .store
-        .create_branch(&project, &body.name, &body.from)
-        .map_err(map_store_error)?;
-    state
-        .store
-        .append_audit(&AuditEntry {
-            id: 0,
-            project: project.clone(),
-            at: now_seconds(),
-            actor: "unknown".to_string(),
-            action: "branch.create".to_string(),
-            subject: body.name.clone(),
-            detail: format!("from {}", body.from),
-        })
+        .create_branch(&project, &body.name, &body.from, Some(&audit))
         .map_err(map_store_error)?;
     Ok((
         StatusCode::CREATED,
         Json(json!({ "name": body.name, "tip": body.from })),
     ))
 }
@@ -401,36 +465,36 @@ pub async fn list_branches(
 
 pub async fn delete_branch(
     State(state): State<ApiState>,
     Path((project, name)): Path<(String, String)>,
 ) -> Result<StatusCode, ApiError> {
     validate_name("branch name", &name)?;
+    let audit = AuditEntry {
+        id: 0,
+        project: project.clone(),
+        at: now_seconds(),
+        actor: "unknown".to_string(),
+        action: "branch.delete".to_string(),
+        subject: name.clone(),
+        detail: "branch deleted".to_string(),
+    };
     state
         .store
-        .delete_branch(&project, &name)
-        .map_err(map_store_error)?;
-    state
-        .store
-        .append_audit(&AuditEntry {
-            id: 0,
-            project: project.clone(),
-            at: now_seconds(),
-            actor: "unknown".to_string(),
-            action: "branch.delete".to_string(),
-            subject: name.clone(),
-            detail: "branch deleted".to_string(),
-        })
+        .delete_branch(&project, &name, Some(&audit))
         .map_err(map_store_error)?;
     Ok(StatusCode::NO_CONTENT)
 }
 
 #[derive(Deserialize)]
 pub struct ResetBranch {
     pub to: String,
     pub author: String,
     pub message: String,
+    /// Who is reverting. As with a commit, supplying the holder lets the lease holder
+    /// proceed; omitting it means any live lease on a changed element refuses the reset.
+    pub holder: Option<String>,
 }
 
 /// Restore a branch to the CONTENT of an earlier commit by appending a new commit. The
 /// history is never rewritten: the old tip stays reachable, and the revert is itself a
 /// commit with an author and a message.
 pub async fn reset_branch(
@@ -444,44 +508,57 @@ pub async fn reset_branch(
         .project(&project)
         .map_err(map_store_error)?
         .is_none()
     {
         return Err(ApiError::not_found(format!("project {}", project)));
     }
-    if state
+    let tip_hash = state
         .store
         .branch_tip(&project, &name)
         .map_err(map_store_error)?
-        .is_none()
-    {
-        return Err(ApiError::not_found(format!("branch {}", name)));
-    }
+        .ok_or_else(|| ApiError::not_found(format!("branch {}", name)))?;
     let target = state
         .store
         .commit(&project, &body.to)
         .map_err(map_store_error)?
         .ok_or_else(|| ApiError::not_found(format!("commit {}", body.to)))?;
+    // A reset is a write path like any other: it refuses to change an element another
+    // holder has locked. The touched set is the difference between the CURRENT tip model
+    // and the TARGET model. A caller that holds the leases passes its holder and proceeds;
+    // a caller that does not is refused, because an absent holder cannot be the holder.
+    let tip_model = load_model(&state, &project, &tip_hash)?;
+    let target_model = load_model(&state, &project, &body.to)?;
+    let touched = touched_elements(&tip_model, &target_model);
+    let guard = CommitGuard {
+        holder: body.holder.as_deref().unwrap_or(""),
+        elements: &touched,
+        now: now_seconds(),
+        expected_tip: Some(&tip_hash),
+    };
     // The target's model is already stored, so this reuses its blob rather than copying
     // the bytes: the restored content is byte-identical to the original by construction.
     let audit = AuditEntry {
         id: 0,
         project: project.clone(),
         at: now_seconds(),
         actor: body.author.clone(),
         action: "branch.reset".to_string(),
         subject: name.clone(),
         detail: format!("reset to {}", body.to),
     };
-    let commit = state
-        .store
-        .commit_model(
+    let commit = commit_refusal_guard(
+        &state,
+        &project,
+        &name,
+        &body.author,
+        state.store.commit_model(
             &project,
             &name,
             &target.okf_hash,
             &body.author,
             &body.message,
-            None,
+            Some(guard),
             Some(&audit),
-        )
-        .map_err(map_store_error)?;
+        ),
+    )?;
     Ok((StatusCode::CREATED, Json(commit_json(&commit))))
 }

## FILE: server/src/merge_api.rs

diff --git a/server/src/merge_api.rs b/server/src/merge_api.rs
index 202ba60..711db4b 100644
--- a/server/src/merge_api.rs
+++ b/server/src/merge_api.rs
@@ -2,23 +2,30 @@
 use axum::extract::{Path, State};
 use axum::http::StatusCode;
 use axum::Json;
 use serde::Deserialize;
 use serde_json::{json, Value};
 
-use crate::api::{commit_json, load_model, map_store_error, validate_name, ApiState};
+use crate::api::{
+    commit_json, commit_refusal_guard, load_model, map_store_error, touched_elements,
+    validate_name, ApiState,
+};
 use crate::error::ApiError;
 use crate::merge::merge;
-use crate::store::{now_seconds, AuditEntry};
+use crate::store::{now_seconds, AuditEntry, CommitGuard};
 
 #[derive(Deserialize)]
 pub struct MergeRequest {
     pub branch: String,
     pub other: String,
     pub author: String,
     pub message: String,
+    /// Who is merging. Supplying it lets a caller proceed on elements it holds a lease on;
+    /// omitting it means the caller cannot be the holder, so any live lease on a changed
+    /// element refuses the merge rather than overwriting somebody else's work.
+    pub holder: Option<String>,
 }
 
 /// Every commit reachable from a tip, as a set. The walk stops at a commit already seen, so
 /// a malformed cycle in stored data cannot loop forever, and membership is constant time.
 fn ancestry_set(
     state: &ApiState,
@@ -183,33 +190,48 @@ pub async fn merge_branches(
 
     let bytes = serde_json::to_vec(&merged).map_err(|e| {
         eprintln!("merged model could not be serialised: {}", e);
         ApiError::internal("the merged model could not be stored")
     })?;
     let okf_hash = state.store.put_blob(&bytes).map_err(map_store_error)?;
+    // A merge is a write path like any other: it refuses to change an element another
+    // holder has locked. The touched set is the difference between OUR tip model and the
+    // MERGED model. A caller that holds the leases passes its holder and proceeds.
+    let touched = touched_elements(&ours, &merged);
+    let parents = vec![ours_tip, theirs_tip];
+    let guard = CommitGuard {
+        holder: body.holder.as_deref().unwrap_or(""),
+        elements: &touched,
+        now: now_seconds(),
+        expected_tip: Some(&parents[0]),
+    };
     let audit = AuditEntry {
         id: 0,
         project: project.clone(),
         at: now_seconds(),
         actor: body.author.clone(),
         action: "merge.clean".to_string(),
         subject: body.branch.clone(),
         detail: format!("merged {} into {}", body.other, body.branch),
     };
-    let commit = state
-        .store
-        .commit_merge(
+    let commit = commit_refusal_guard(
+        &state,
+        &project,
+        &body.branch,
+        &body.author,
+        state.store.commit_merge(
             &project,
             &body.branch,
-            &[ours_tip, theirs_tip],
+            &parents,
             &okf_hash,
             &body.author,
             &body.message,
+            Some(guard),
             Some(&audit),
-        )
-        .map_err(map_store_error)?;
+        ),
+    )?;
 
     Ok((
         StatusCode::CREATED,
         Json(json!({ "commit": commit_json(&commit), "base": base_hash })),
     ))
 }

## FILE: server/src/locks_api.rs

diff --git a/server/src/locks_api.rs b/server/src/locks_api.rs
index 3bfb48c..ca02d0b 100644
--- a/server/src/locks_api.rs
+++ b/server/src/locks_api.rs
@@ -2,22 +2,37 @@
 use axum::extract::{Path, State};
 use axum::http::StatusCode;
 use axum::Json;
 use serde::Deserialize;
 use serde_json::{json, Value};
 
-use crate::api::{map_store_error, validate_name, ApiState};
+use crate::api::{map_store_error, record_refusal, validate_element_name, validate_name, ApiState};
 use crate::error::ApiError;
 use crate::store::{now_epoch, AuditEntry, Lock};
 
 /// The real clock in seconds, as the store requires it. The store itself never reads the
 /// clock: time is passed in so lock expiry is testable without sleeping.
 fn now_seconds() -> i64 {
     now_epoch().parse().unwrap_or(0)
 }
 
+/// A holder must be a real, bounded name. An empty holder could acquire a lease that blocks
+/// everyone — it can never be the holder on a later write — so it is rejected outright.
+/// 128 characters is ample for a username or an agent id.
+fn validate_holder(holder: &str) -> Result<(), ApiError> {
+    if holder.is_empty() {
+        return Err(ApiError::bad_request("holder must not be empty"));
+    }
+    if holder.chars().count() > 128 {
+        return Err(ApiError::bad_request(
+            "holder must be 128 characters or fewer",
+        ));
+    }
+    Ok(())
+}
+
 #[derive(Deserialize)]
 #[serde(rename_all = "camelCase")]
 pub struct AcquireLocks {
     pub branch: String,
     pub elements: Vec<String>,
     pub holder: String,
@@ -27,17 +42,18 @@ pub struct AcquireLocks {
 pub async fn acquire_locks(
     State(state): State<ApiState>,
     Path(project): Path<String>,
     Json(body): Json<AcquireLocks>,
 ) -> Result<(StatusCode, Json<Vec<Lock>>), ApiError> {
     validate_name("branch name", &body.branch)?;
+    validate_holder(&body.holder)?;
     if body.elements.is_empty() {
         return Err(ApiError::bad_request("at least one element is required"));
     }
     for element in &body.elements {
-        validate_name("element name", element)?;
+        validate_element_name(element)?;
     }
     // A repeated element would acquire one lease but be reported twice, which reads as two
     // leases for one element. Deduplicate before anything is written.
     let elements: Vec<String> = {
         let mut seen = std::collections::BTreeSet::new();
         body.elements
@@ -57,41 +73,53 @@ pub async fn acquire_locks(
         .map_err(map_store_error)?
         .is_none()
     {
         return Err(ApiError::not_found(format!("project {}", project)));
     }
 
-    let locks = state
-        .store
-        .acquire_locks(
-            &project,
-            &body.branch,
-            &elements,
-            &body.holder,
-            body.ttl_seconds,
-            now_seconds(),
-        )
-        .map_err(map_store_error)?;
-    let expiry = locks.first().map(|l| l.expires_at).unwrap_or(0);
-    state
-        .store
-        .append_audit(&AuditEntry {
-            id: 0,
-            project: project.clone(),
-            at: now_seconds(),
-            actor: body.holder.clone(),
-            action: "lock.acquire".to_string(),
-            subject: elements.join(","),
-            detail: format!(
-                "{} element(s) by {} until {}",
-                locks.len(),
-                body.holder,
-                expiry
-            ),
-        })
-        .map_err(map_store_error)?;
+    let now = now_seconds();
+    let audit = AuditEntry {
+        id: 0,
+        project: project.clone(),
+        at: now,
+        actor: body.holder.clone(),
+        action: "lock.acquire".to_string(),
+        subject: elements.join(","),
+        detail: format!(
+            "{} element(s) by {} until {}",
+            elements.len(),
+            body.holder,
+            now + body.ttl_seconds
+        ),
+    };
+    let locks = match state.store.acquire_locks(
+        &project,
+        &body.branch,
+        &elements,
+        &body.holder,
+        body.ttl_seconds,
+        now,
+        Some(&audit),
+    ) {
+        Ok(locks) => locks,
+        Err(error) => {
+            // A refused acquire is a refusal worth recording: another holder's lease denied
+            // this one. Nothing was written, so the entry appends on its own.
+            if crate::store::is_lock_refusal(&error) {
+                record_refusal(
+                    state.store.as_ref(),
+                    &project,
+                    &body.holder,
+                    "lock.denied",
+                    &elements.join(","),
+                    &error.to_string(),
+                )?;
+            }
+            return Err(map_store_error(error));
+        }
+    };
     Ok((StatusCode::CREATED, Json(locks)))
 }
 
 pub async fn list_locks(
     State(state): State<ApiState>,
     Path(project): Path<String>,
@@ -127,28 +155,23 @@ pub async fn release_locks(
         .project(&project)
         .map_err(map_store_error)?
         .is_none()
     {
         return Err(ApiError::not_found(format!("project {}", project)));
     }
+    // A release that removes nothing is not a mutation (a foreign holder, or already
+    // released ids), so the store writes the audit row only when it actually removed one.
+    let audit = AuditEntry {
+        id: 0,
+        project: project.clone(),
+        at: now_seconds(),
+        actor: body.holder.clone(),
+        action: "lock.release".to_string(),
+        subject: body.ids.join(","),
+        detail: "released lock(s)".to_string(),
+    };
     let released = state
         .store
-        .release_locks(&project, &body.holder, &body.ids)
+        .release_locks(&project, &body.holder, &body.ids, Some(&audit))
         .map_err(map_store_error)?;
-    // A release that removes nothing is not a mutation (a foreign holder, or already
-    // released ids), so it writes no audit entry.
-    if released > 0 {
-        state
-            .store
-            .append_audit(&AuditEntry {
-                id: 0,
-                project: project.clone(),
-                at: now_seconds(),
-                actor: body.holder.clone(),
-                action: "lock.release".to_string(),
-                subject: body.ids.join(","),
-                detail: format!("released {} lock(s)", released),
-            })
-            .map_err(map_store_error)?;
-    }
     Ok(Json(json!({ "released": released })))
 }

## FILE: server/tests/locks.rs

diff --git a/server/tests/locks.rs b/server/tests/locks.rs
index cca7878..39876a2 100644
--- a/server/tests/locks.rs
+++ b/server/tests/locks.rs
@@ -211,24 +211,34 @@ fn an_expired_lease_stops_blocking() {
     // directly with an injected clock: no sleeping, and the boundary is exact.
     let dir = tempfile::tempdir().unwrap();
     let store = SqliteStore::open(&dir.path().join("mw.db")).unwrap();
 
     // A acquires b1 at now = 1000 with ttl 30, so the lease expires at 1030.
     store
-        .acquire_locks("coffee", "main", &["b1".to_string()], "alex", 30, 1000)
+        .acquire_locks(
+            "coffee",
+            "main",
+            &["b1".to_string()],
+            "alex",
+            30,
+            1000,
+            None,
+        )
         .unwrap();
 
     // Still inside the lease: a second holder is refused.
-    match store.acquire_locks("coffee", "main", &["b1".to_string()], "bob", 30, 1000) {
-        Err(StoreError::Conflict(_)) => {}
-        other => panic!("expected a conflict at now=1000, got {:?}", other),
+    match store.acquire_locks("coffee", "main", &["b1".to_string()], "bob", 30, 1000, None) {
+        Err(StoreError::Locked { holder, .. }) => {
+            assert_eq!(holder, "alex", "the refusal must name the holder");
+        }
+        other => panic!("expected a lock refusal at now=1000, got {:?}", other),
     }
 
     // Past the lease (1030): the lease is dead and the second holder succeeds.
     let acquired = store
-        .acquire_locks("coffee", "main", &["b1".to_string()], "bob", 30, 1031)
+        .acquire_locks("coffee", "main", &["b1".to_string()], "bob", 30, 1031, None)
         .unwrap();
     assert_eq!(acquired.len(), 1);
     assert_eq!(acquired[0].holder, "bob");
 }
 
 #[tokio::test]
@@ -487,6 +497,457 @@ async fn the_holder_may_commit_its_own_locked_element() {
             }),
         ))
         .await
         .unwrap();
     assert_eq!(committed.status(), StatusCode::CREATED);
 }
+
+#[tokio::test]
+async fn a_commit_without_a_holder_is_refused_when_it_touches_a_locked_element() {
+    // A writer that omits the holder field is still checked: it cannot be the holder, so a
+    // live lease on a touched element refuses it. This is the overwrite locks exist to
+    // prevent, and it must not depend on the writer cooperating.
+    let dir = tempfile::tempdir().unwrap();
+    let router = server::app(state(dir.path()));
+    seed_project(&router).await;
+
+    let seeded = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/commits",
+            serde_json::json!({
+                "branch": "main",
+                "author": "alex",
+                "message": "seed",
+                "okf": model_with_nodes(&["b1", "b2"])
+            }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(seeded.status(), StatusCode::CREATED);
+    let tip = json_body(seeded).await["hash"]
+        .as_str()
+        .unwrap()
+        .to_string();
+
+    let locked = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/locks",
+            serde_json::json!({
+                "branch": "main",
+                "elements": ["b1"],
+                "holder": "alex",
+                "ttlSeconds": 300
+            }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(locked.status(), StatusCode::CREATED);
+
+    // No holder field: the commit still refuses to change the locked b1.
+    let refused = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/commits",
+            serde_json::json!({
+                "branch": "main",
+                "author": "bob",
+                "message": "rename b1",
+                "okf": model_with_nodes(&["b1-renamed", "b2"])
+            }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(refused.status(), StatusCode::CONFLICT);
+    let message = json_body(refused).await["error"]
+        .as_str()
+        .unwrap()
+        .to_string();
+    assert!(message.contains("b1"), "the 409 must name the element");
+    assert!(message.contains("alex"), "the 409 must name the holder");
+    assert!(
+        message.contains("supply the holder"),
+        "the 409 must tell the holder to supply the field: {}",
+        message
+    );
+
+    // Nothing landed, and the refusal is recorded.
+    let branches = router
+        .clone()
+        .oneshot(get("/projects/coffee/branches"))
+        .await
+        .unwrap();
+    let main = json_body(branches).await;
+    let main = main
+        .as_array()
+        .unwrap()
+        .iter()
+        .find(|b| b["name"] == "main")
+        .unwrap();
+    assert_eq!(main["tip"].as_str().unwrap(), tip.as_str());
+
+    let audit = router.oneshot(get("/projects/coffee/audit")).await.unwrap();
+    let entries = json_body(audit).await;
+    assert!(
+        entries
+            .as_array()
+            .unwrap()
+            .iter()
+            .any(|e| e["action"] == "commit.refused"),
+        "a refused overwrite must be recorded as commit.refused"
+    );
+}
+
+#[tokio::test]
+async fn a_reset_that_would_change_a_locked_element_is_refused() {
+    let dir = tempfile::tempdir().unwrap();
+    let router = server::app(state(dir.path()));
+    seed_project(&router).await;
+
+    let first = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/commits",
+            serde_json::json!({
+                "branch": "main",
+                "author": "alex",
+                "message": "one",
+                "okf": model_with_nodes(&["b1"])
+            }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(first.status(), StatusCode::CREATED);
+    let first_hash = json_body(first).await["hash"].as_str().unwrap().to_string();
+
+    let second = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/commits",
+            serde_json::json!({
+                "branch": "main",
+                "author": "alex",
+                "message": "two",
+                "okf": model_with_nodes(&["b1-renamed"])
+            }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(second.status(), StatusCode::CREATED);
+
+    let locked = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/locks",
+            serde_json::json!({
+                "branch": "main",
+                "elements": ["b1"],
+                "holder": "alex",
+                "ttlSeconds": 300
+            }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(locked.status(), StatusCode::CREATED);
+
+    // Resetting back to the first commit restores b1, so it changes a locked element.
+    let refused = router
+        .oneshot(post(
+            "/projects/coffee/branches/main/reset",
+            serde_json::json!({ "to": first_hash, "author": "alex", "message": "revert" }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(refused.status(), StatusCode::CONFLICT);
+    assert!(
+        json_body(refused).await["error"]
+            .as_str()
+            .unwrap()
+            .contains("b1"),
+        "the reset refusal must name the locked element"
+    );
+}
+
+#[tokio::test]
+async fn a_merge_that_would_change_a_locked_element_is_refused() {
+    let dir = tempfile::tempdir().unwrap();
+    let router = server::app(state(dir.path()));
+    seed_project(&router).await;
+
+    let base = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/commits",
+            serde_json::json!({
+                "branch": "main",
+                "author": "alex",
+                "message": "base",
+                "okf": model_with_nodes(&["b1"])
+            }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(base.status(), StatusCode::CREATED);
+    let base_hash = json_body(base).await["hash"].as_str().unwrap().to_string();
+
+    let branched = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/branches",
+            serde_json::json!({ "name": "feature", "from": base_hash }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(branched.status(), StatusCode::CREATED);
+
+    let renamed = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/commits",
+            serde_json::json!({
+                "branch": "feature",
+                "author": "alex",
+                "message": "rename",
+                "okf": model_with_nodes(&["b1-renamed"])
+            }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(renamed.status(), StatusCode::CREATED);
+
+    let locked = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/locks",
+            serde_json::json!({
+                "branch": "main",
+                "elements": ["b1"],
+                "holder": "alex",
+                "ttlSeconds": 300
+            }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(locked.status(), StatusCode::CREATED);
+
+    // The merge would move main's b1 to b1-renamed, changing the locked element.
+    let refused = router
+        .oneshot(post(
+            "/projects/coffee/merge",
+            serde_json::json!({ "branch": "main", "other": "feature", "author": "alex", "message": "merge" }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(refused.status(), StatusCode::CONFLICT);
+    assert!(
+        json_body(refused).await["error"]
+            .as_str()
+            .unwrap()
+            .contains("b1"),
+        "the merge refusal must name the locked element"
+    );
+}
+
+#[tokio::test]
+async fn a_denied_lock_is_recorded() {
+    let dir = tempfile::tempdir().unwrap();
+    let router = server::app(state(dir.path()));
+    seed_project(&router).await;
+
+    let acquired = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/locks",
+            serde_json::json!({
+                "branch": "main",
+                "elements": ["b1"],
+                "holder": "alex",
+                "ttlSeconds": 300
+            }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(acquired.status(), StatusCode::CREATED);
+
+    let denied = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/locks",
+            serde_json::json!({
+                "branch": "main",
+                "elements": ["b1"],
+                "holder": "bob",
+                "ttlSeconds": 300
+            }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(denied.status(), StatusCode::CONFLICT);
+
+    let audit = router.oneshot(get("/projects/coffee/audit")).await.unwrap();
+    let entries = json_body(audit).await;
+    assert!(
+        entries
+            .as_array()
+            .unwrap()
+            .iter()
+            .any(|e| e["action"] == "lock.denied"),
+        "a refused acquire must be recorded as lock.denied"
+    );
+}
+
+#[tokio::test]
+async fn locks_validate_the_holder_and_allow_okf_element_ids() {
+    let dir = tempfile::tempdir().unwrap();
+    let router = server::app(state(dir.path()));
+    seed_project(&router).await;
+
+    // An empty holder could never be the holder on a later write, so it must be rejected
+    // rather than acquiring a lease that blocks everyone.
+    let empty_holder = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/locks",
+            serde_json::json!({
+                "branch": "main",
+                "elements": ["b1"],
+                "holder": "",
+                "ttlSeconds": 300
+            }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(empty_holder.status(), StatusCode::BAD_REQUEST);
+
+    // Element ids may contain characters validate_name rejects: an element that can be
+    // CHANGED must also be LOCKED.
+    let special = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/locks",
+            serde_json::json!({
+                "branch": "main",
+                "elements": ["sysml/block:1"],
+                "holder": "alex",
+                "ttlSeconds": 300
+            }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(special.status(), StatusCode::CREATED);
+
+    // A control character is still rejected.
+    let control = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/locks",
+            serde_json::json!({
+                "branch": "main",
+                "elements": ["badid"],
+                "holder": "alex",
+                "ttlSeconds": 300
+            }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(control.status(), StatusCode::BAD_REQUEST);
+}
+#[tokio::test]
+async fn the_holder_may_finish_its_own_work_through_merge_and_reset() {
+    // Enforcing locks on every write path is only useful if the person holding the lock can
+    // still do their job. A holder must be able to commit, merge and revert the elements it
+    // holds; everyone else must be refused. This test drives both halves.
+    let dir = tempfile::tempdir().unwrap();
+    let router = server::app(state(dir.path()));
+    seed_project(&router).await;
+
+    let base = model_with_nodes(&["b1"]);
+    let committed = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/commits",
+            serde_json::json!({ "branch": "main", "author": "alex", "message": "base", "okf": base, "holder": "alex" }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(committed.status(), StatusCode::CREATED);
+    let base_hash = json_body(committed).await["hash"]
+        .as_str()
+        .unwrap()
+        .to_string();
+
+    // Alex takes the element and works on a branch.
+    router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/locks",
+            serde_json::json!({ "branch": "main", "elements": ["b1"], "holder": "alex", "ttlSeconds": 600 }),
+        ))
+        .await
+        .unwrap();
+    router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/branches",
+            serde_json::json!({ "name": "feature", "from": base_hash }),
+        ))
+        .await
+        .unwrap();
+
+    // model_with_nodes builds a graph-only document, so the change is to the graph node.
+    let mut changed = model_with_nodes(&["b1"]);
+    changed["graph"]["nodes"][0]["name"] = serde_json::json!("Renamed");
+    let on_feature = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/commits",
+            serde_json::json!({ "branch": "feature", "author": "alex", "message": "rename", "okf": changed, "holder": "alex" }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(
+        on_feature.status(),
+        StatusCode::CREATED,
+        "the holder may change what it holds"
+    );
+
+    // Sam tries to merge that in and is refused: alex holds b1.
+    let refused = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/merge",
+            serde_json::json!({ "branch": "main", "other": "feature", "author": "sam", "message": "merge", "holder": "sam" }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(refused.status(), StatusCode::CONFLICT);
+
+    // Alex merges its own work and succeeds.
+    let merged = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/merge",
+            serde_json::json!({ "branch": "main", "other": "feature", "author": "alex", "message": "merge", "holder": "alex" }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(
+        merged.status(),
+        StatusCode::CREATED,
+        "the holder may merge what it holds"
+    );
+
+    // And alex may revert its own branch back, again because it holds the element.
+    let reverted = router
+        .oneshot(post(
+            "/projects/coffee/branches/main/reset",
+            serde_json::json!({ "to": base_hash, "author": "alex", "message": "revert", "holder": "alex" }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(
+        reverted.status(),
+        StatusCode::CREATED,
+        "the holder may revert what it holds"
+    );
+}

## FILE: server/tests/store.rs

diff --git a/server/tests/store.rs b/server/tests/store.rs
index 9648e84..cb87ca2 100644
--- a/server/tests/store.rs
+++ b/server/tests/store.rs
@@ -1,8 +1,8 @@
 // SPDX-License-Identifier: AGPL-3.0-or-later
-use server::store::{commit_hash, sqlite::SqliteStore, Store, StoreError};
+use server::store::{commit_hash, sqlite::SqliteStore, AuditEntry, GateRun, Store, StoreError};
 
 fn store() -> (SqliteStore, tempfile::TempDir) {
     let dir = tempfile::tempdir().unwrap();
     let store = SqliteStore::open(&dir.path().join("mw.db")).unwrap();
     (store, dir)
 }
@@ -28,13 +28,13 @@ fn a_commit_hash_ignores_time_but_not_content() {
     assert_ne!(a, c);
 }
 
 #[test]
 fn commits_land_on_a_branch_and_move_its_tip() {
     let (store, _dir) = store();
-    store.create_project("coffee").unwrap();
+    store.create_project("coffee", None).unwrap();
     let first = store
         .commit_model("coffee", "main", "okf1", "alex", "first commit", None, None)
         .unwrap();
     assert_eq!(
         store.branch_tip("coffee", "main").unwrap().unwrap(),
         first.hash
@@ -62,28 +62,28 @@ fn commits_land_on_a_branch_and_move_its_tip() {
     assert_eq!(second.parents, vec![first.hash.clone()]);
 }
 
 #[test]
 fn duplicate_projects_and_branches_are_conflicts() {
     let (store, _dir) = store();
-    store.create_project("coffee").unwrap();
-    match store.create_project("coffee") {
+    store.create_project("coffee", None).unwrap();
+    match store.create_project("coffee", None) {
         Err(StoreError::Conflict(_)) => {}
         other => panic!("expected a conflict, got {:?}", other),
     }
     let commit = store
         .commit_model("coffee", "main", "okf1", "alex", "first commit", None, None)
         .unwrap();
     store
-        .create_branch("coffee", "review", &commit.hash)
+        .create_branch("coffee", "review", &commit.hash, None)
         .unwrap();
-    match store.create_branch("coffee", "review", &commit.hash) {
+    match store.create_branch("coffee", "review", &commit.hash, None) {
         Err(StoreError::Conflict(_)) => {}
         other => panic!("expected a conflict, got {:?}", other),
     }
-    match store.create_branch("coffee", "other", "missing-commit") {
+    match store.create_branch("coffee", "other", "missing-commit", None) {
         Err(StoreError::NotFound(_)) => {}
         other => panic!("expected not found, got {:?}", other),
     }
 }
 #[test]
 fn concurrent_commits_to_one_branch_form_a_linear_chain() {
@@ -91,13 +91,13 @@ fn concurrent_commits_to_one_branch_form_a_linear_chain() {
     // If that atomicity were lost, two concurrent commits would read the same tip and
     // become SIBLINGS: both land, one orphans the other. Counting roots would not see
     // that - a sibling fork still has one root - so linearity is checked the only way
     // that catches it: by counting each commit's children and by walking the parents
     // from the tip back to the root.
     let (store, _dir) = store();
-    store.create_project("coffee").unwrap();
+    store.create_project("coffee", None).unwrap();
     let store = std::sync::Arc::new(store);
 
     let mut handles = Vec::new();
     for i in 0..8 {
         let store = store.clone();
         handles.push(std::thread::spawn(move || {
@@ -168,18 +168,18 @@ fn concurrent_commits_to_one_branch_form_a_linear_chain() {
 #[test]
 fn a_merge_refuses_when_the_branch_moved_under_it() {
     // A merge is computed from tips read before the write. If a commit lands in between,
     // writing the merge would move the branch off that commit and orphan it: stored, but
     // unreachable from any branch. The store must refuse instead of losing it.
     let (store, _dir) = store();
-    store.create_project("coffee").unwrap();
+    store.create_project("coffee", None).unwrap();
     let root = store
         .commit_model("coffee", "main", "okf-root", "alex", "root", None, None)
         .unwrap();
     store
-        .create_branch("coffee", "feature", &root.hash)
+        .create_branch("coffee", "feature", &root.hash, None)
         .unwrap();
     let their_side = store
         .commit_model(
             "coffee",
             "feature",
             "okf-feature",
@@ -208,12 +208,13 @@ fn a_merge_refuses_when_the_branch_moved_under_it() {
         "main",
         &[root.hash.clone(), their_side.hash.clone()],
         "okf-merged",
         "alex",
         "merge",
         None,
+        None,
     );
     match refused {
         Err(StoreError::Conflict(_)) => {}
         other => panic!("expected a conflict, got {:?}", other.map(|c| c.hash)),
     }
 
@@ -236,21 +237,29 @@ fn a_guarded_commit_is_refused_inside_the_transaction() {
     // before the write leaves a window in which another holder takes the lock and the
     // guarded commit lands anyway - a lock that looks enforced and is not. This test drives
     // the store directly, with no API layer to do the checking for it.
     use server::store::CommitGuard;
 
     let (store, _dir) = store();
-    store.create_project("coffee").unwrap();
+    store.create_project("coffee", None).unwrap();
     let root = store
         .commit_model("coffee", "main", "okf-root", "alex", "root", None, None)
         .unwrap();
     let root_hash = root.hash.clone();
 
     // Alex holds b1.
     store
-        .acquire_locks("coffee", "main", &["b1".to_string()], "alex", 600, 1000)
+        .acquire_locks(
+            "coffee",
+            "main",
+            &["b1".to_string()],
+            "alex",
+            600,
+            1000,
+            None,
+        )
         .unwrap();
 
     // Sam's commit touches b1: the store must refuse it, with nothing written.
     let touched = vec!["b1".to_string()];
     let refused = store.commit_model(
         "coffee",
@@ -264,15 +273,17 @@ fn a_guarded_commit_is_refused_inside_the_transaction() {
             now: 1000,
             expected_tip: Some(&root_hash),
         }),
         None,
     );
     match refused {
-        Err(StoreError::Conflict(message)) => {
-            assert!(message.contains("b1"), "the refusal must name the element");
-            assert!(message.contains("alex"), "the refusal must name the holder");
+        Err(StoreError::Locked {
+            element, holder, ..
+        }) => {
+            assert_eq!(element, "b1", "the refusal must name the element");
+            assert_eq!(holder, "alex", "the refusal must name the holder");
         }
         other => panic!("expected a conflict, got {:?}", other.map(|c| c.hash)),
     }
     assert_eq!(store.commits_on("coffee", "main").unwrap().len(), 1);
 
     // An expired lease is not a lock: the same commit succeeds once the lease lapses.
@@ -293,13 +304,21 @@ fn a_guarded_commit_is_refused_inside_the_transaction() {
     assert!(allowed.is_ok(), "an expired lease must not block a commit");
 
     // A guard for an element nobody holds blocks nothing, even while a DIFFERENT element is
     // locked: a lock protects the elements it names, not the document around them.
     let elsewhere = vec!["b3".to_string()];
     store
-        .acquire_locks("coffee", "main", &["b2".to_string()], "alex", 600, 1000)
+        .acquire_locks(
+            "coffee",
+            "main",
+            &["b2".to_string()],
+            "alex",
+            600,
+            1000,
+            None,
+        )
         .unwrap();
     let tip_now = store.branch_tip("coffee", "main").unwrap();
     let unrelated = store.commit_model(
         "coffee",
         "main",
         "okf-other",
@@ -321,13 +340,13 @@ fn a_guard_computed_against_an_old_tip_is_refused() {
     // branch has moved since, that document is gone and the guard describes the WRONG
     // elements: enforcing it would protect something nobody is editing while a locked
     // element slips through. The store refuses rather than answering a stale question.
     use server::store::CommitGuard;
 
     let (store, _dir) = store();
-    store.create_project("coffee").unwrap();
+    store.create_project("coffee", None).unwrap();
     let root = store
         .commit_model("coffee", "main", "okf-root", "alex", "root", None, None)
         .unwrap();
 
     // A concurrent commit moves the branch after the caller read the tip.
     store
@@ -362,6 +381,127 @@ fn a_guard_computed_against_an_old_tip_is_refused() {
     assert_eq!(
         store.commits_on("coffee", "main").unwrap().len(),
         2,
         "nothing may be written"
     );
 }
+
+#[test]
+fn audit_rows_ride_each_mutation_transaction() {
+    // Every mutation method takes an optional audit entry and writes it inside its OWN
+    // transaction. This drives the store directly so a mutation and its row are seen to
+    // land together, with no HTTP layer in between to append the row afterwards.
+    let (store, _dir) = store();
+    let entry = |action: &str| AuditEntry {
+        id: 0,
+        project: "coffee".to_string(),
+        at: 1,
+        actor: "alex".to_string(),
+        action: action.to_string(),
+        subject: "s".to_string(),
+        detail: "d".to_string(),
+    };
+
+    store
+        .create_project("coffee", Some(&entry("project.create")))
+        .unwrap();
+    let root = store
+        .commit_model("coffee", "main", "okf-root", "alex", "root", None, None)
+        .unwrap();
+    store
+        .create_branch(
+            "coffee",
+            "feature",
+            &root.hash,
+            Some(&entry("branch.create")),
+        )
+        .unwrap();
+    store
+        .acquire_locks(
+            "coffee",
+            "main",
+            &["b1".to_string()],
+            "alex",
+            600,
+            1000,
+            Some(&entry("lock.acquire")),
+        )
+        .unwrap();
+    let ids: Vec<String> = store
+        .locks("coffee", 1000)
+        .unwrap()
+        .into_iter()
+        .map(|l| l.id)
+        .collect();
+    store
+        .release_locks("coffee", "alex", &ids, Some(&entry("lock.release")))
+        .unwrap();
+    store
+        .record_gate_run(
+            &GateRun {
+                project: "coffee".to_string(),
+                branch: "main".to_string(),
+                reference_hash: "r".to_string(),
+                candidate_hash: "c".to_string(),
+                passed: true,
+                evidence: "{}".to_string(),
+                created_at: "1".to_string(),
+            },
+            Some(&entry("gate.run")),
+        )
+        .unwrap();
+    store
+        .delete_branch("coffee", "feature", Some(&entry("branch.delete")))
+        .unwrap();
+
+    let actions: Vec<String> = store
+        .audit("coffee", 1000)
+        .unwrap()
+        .into_iter()
+        .map(|e| e.action)
+        .collect();
+    for action in [
+        "project.create",
+        "branch.create",
+        "lock.acquire",
+        "lock.release",
+        "gate.run",
+        "branch.delete",
+    ] {
+        assert!(
+            actions.contains(&action.to_string()),
+            "missing audit action {}",
+            action
+        );
+    }
+}
+
+#[test]
+fn the_audit_table_refuses_update_and_delete() {
+    // Append-only is a DATABASE property now, not a trait convention: triggers make UPDATE
+    // and DELETE fail outright, so a written entry can never be rewritten or removed even by
+    // a caller with raw SQL access to the same file.
+    let (store, dir) = store();
+    store.create_project("coffee", None).unwrap();
+    store
+        .append_audit(&AuditEntry {
+            id: 0,
+            project: "coffee".to_string(),
+            at: 1,
+            actor: "a".to_string(),
+            action: "x".to_string(),
+            subject: "s".to_string(),
+            detail: "d".to_string(),
+        })
+        .unwrap();
+
+    let conn = rusqlite::Connection::open(dir.path().join("mw.db")).unwrap();
+    assert!(
+        conn.execute("UPDATE audit SET detail = 'rewritten' WHERE id = 1", [])
+            .is_err(),
+        "UPDATE on the audit table must be refused by the trigger"
+    );
+    assert!(
+        conn.execute("DELETE FROM audit WHERE id = 1", []).is_err(),
+        "DELETE on the audit table must be refused by the trigger"
+    );
+}

## FILE: server/tests/audit.rs

