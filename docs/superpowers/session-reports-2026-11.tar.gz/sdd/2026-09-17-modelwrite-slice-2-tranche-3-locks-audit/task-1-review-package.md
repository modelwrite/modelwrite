﻿# Tranche 3 Task 1 review package (element locks)

## Commit

9543d53 feat: add element locks with leases

## Diff stat

 server/src/lib.rs          |   9 ++
 server/src/locks_api.rs    | 110 ++++++++++++++++++
 server/src/store/mod.rs    |  61 ++++++++++
 server/src/store/sqlite.rs | 219 +++++++++++++++++++++++++++++++++++-
 server/tests/locks.rs      | 274 +++++++++++++++++++++++++++++++++++++++++++++
 5 files changed, 672 insertions(+), 1 deletion(-)

## Full diff (-U10)

diff --git a/server/src/lib.rs b/server/src/lib.rs
index b47a565..642b031 100644
--- a/server/src/lib.rs
+++ b/server/src/lib.rs
@@ -1,14 +1,15 @@
 // SPDX-License-Identifier: AGPL-3.0-or-later
 pub mod api;
 pub mod error;
 pub mod gate_api;
+pub mod locks_api;
 pub mod merge;
 pub mod merge_api;
 pub mod store;
 
 pub use error::ApiError;
 
 use std::sync::Arc;
 
 use axum::routing::{get, post};
 use axum::{Json, Router};
@@ -54,20 +55,28 @@ pub fn app(state: AppState) -> Router {
         .route(
             "/projects/:project/branches/:name/reset",
             post(api::reset_branch),
         )
         .route("/projects/:project/gate", post(gate_api::run_gate))
         .route("/projects/:project/merge", post(merge_api::merge_branches))
         .route(
             "/projects/:project/gate-runs",
             get(gate_api::list_gate_runs),
         )
+        .route(
+            "/projects/:project/locks",
+            post(locks_api::acquire_locks).get(locks_api::list_locks),
+        )
+        .route(
+            "/projects/:project/locks/release",
+            post(locks_api::release_locks),
+        )
         .with_state(api_state)
 }
 
 async fn health() -> Json<serde_json::Value> {
     Json(json!({ "status": "ok" }))
 }
 
 async fn version() -> Json<serde_json::Value> {
     Json(json!({
         "server": env!("CARGO_PKG_VERSION"),
diff --git a/server/src/locks_api.rs b/server/src/locks_api.rs
new file mode 100644
index 0000000..0193908
--- /dev/null
+++ b/server/src/locks_api.rs
@@ -0,0 +1,110 @@
+// SPDX-License-Identifier: AGPL-3.0-or-later
+use axum::extract::{Path, State};
+use axum::http::StatusCode;
+use axum::Json;
+use serde::Deserialize;
+use serde_json::{json, Value};
+
+use crate::api::{map_store_error, validate_name, ApiState};
+use crate::error::ApiError;
+use crate::store::{now_epoch, Lock};
+
+/// The real clock in seconds, as the store requires it. The store itself never reads the
+/// clock: time is passed in so lock expiry is testable without sleeping.
+fn now_seconds() -> i64 {
+    now_epoch().parse().unwrap_or(0)
+}
+
+#[derive(Deserialize)]
+#[serde(rename_all = "camelCase")]
+pub struct AcquireLocks {
+    pub branch: String,
+    pub elements: Vec<String>,
+    pub holder: String,
+    pub ttl_seconds: i64,
+}
+
+pub async fn acquire_locks(
+    State(state): State<ApiState>,
+    Path(project): Path<String>,
+    Json(body): Json<AcquireLocks>,
+) -> Result<(StatusCode, Json<Vec<Lock>>), ApiError> {
+    validate_name("branch name", &body.branch)?;
+    if body.elements.is_empty() {
+        return Err(ApiError::bad_request("at least one element is required"));
+    }
+    for element in &body.elements {
+        validate_name("element name", element)?;
+    }
+    if !(30..=86400).contains(&body.ttl_seconds) {
+        return Err(ApiError::bad_request(
+            "ttlSeconds must be between 30 and 86400",
+        ));
+    }
+    if state
+        .store
+        .project(&project)
+        .map_err(map_store_error)?
+        .is_none()
+    {
+        return Err(ApiError::not_found(format!("project {}", project)));
+    }
+
+    let locks = state
+        .store
+        .acquire_locks(
+            &project,
+            &body.branch,
+            &body.elements,
+            &body.holder,
+            body.ttl_seconds,
+            now_seconds(),
+        )
+        .map_err(map_store_error)?;
+    Ok((StatusCode::CREATED, Json(locks)))
+}
+
+pub async fn list_locks(
+    State(state): State<ApiState>,
+    Path(project): Path<String>,
+) -> Result<Json<Vec<Lock>>, ApiError> {
+    if state
+        .store
+        .project(&project)
+        .map_err(map_store_error)?
+        .is_none()
+    {
+        return Err(ApiError::not_found(format!("project {}", project)));
+    }
+    let locks = state
+        .store
+        .locks(&project, now_seconds())
+        .map_err(map_store_error)?;
+    Ok(Json(locks))
+}
+
+#[derive(Deserialize)]
+pub struct ReleaseLocks {
+    pub holder: String,
+    pub ids: Vec<String>,
+}
+
+pub async fn release_locks(
+    State(state): State<ApiState>,
+    Path(project): Path<String>,
+    Json(body): Json<ReleaseLocks>,
+) -> Result<Json<Value>, ApiError> {
+    if state
+        .store
+        .project(&project)
+        .map_err(map_store_error)?
+        .is_none()
+    {
+        return Err(ApiError::not_found(format!("project {}", project)));
+    }
+    let released = state
+        .store
+        .release_locks(&project, &body.holder, &body.ids)
+        .map_err(map_store_error)?;
+    Ok(Json(json!({ "released": released })))
+}
diff --git a/server/src/store/mod.rs b/server/src/store/mod.rs
index b8892a2..04f1da2 100644
--- a/server/src/store/mod.rs
+++ b/server/src/store/mod.rs
@@ -1,11 +1,12 @@
 // SPDX-License-Identifier: AGPL-3.0-or-later
+use serde::Serialize;
 use sha2::{Digest, Sha256};
 
 pub mod sqlite;
 
 #[derive(Debug, Clone, PartialEq)]
 pub struct Project {
     pub name: String,
     pub created_at: String,
 }
 
@@ -25,20 +26,35 @@ pub struct Commit {
 pub struct GateRun {
     pub project: String,
     pub branch: String,
     pub reference_hash: String,
     pub candidate_hash: String,
     pub passed: bool,
     pub evidence: String,
     pub created_at: String,
 }
 
+/// A lease on one element. A lock always carries an expiry, so a crashed client cannot
+/// block an element forever. The `branch` records where the holder intends to edit, while
+/// the lock itself is keyed on the element: two branches cannot edit one element at once.
+#[derive(Debug, Clone, PartialEq, Serialize)]
+#[serde(rename_all = "camelCase")]
+pub struct Lock {
+    pub id: String,
+    pub project: String,
+    pub branch: String,
+    pub element: String,
+    pub holder: String,
+    pub acquired_at: i64,
+    pub expires_at: i64,
+}
+
 #[derive(Debug)]
 pub enum StoreError {
     NotFound(String),
     Conflict(String),
     Backend(String),
 }
 
 impl std::fmt::Display for StoreError {
     fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
         match self {
@@ -77,20 +93,30 @@ pub fn commit_hash(
         "branch": branch,
         "parents": sorted_parents,
         "okfHash": okf_hash,
         "author": author,
         "message": message
     });
     let bytes = serde_json::to_vec(&payload).expect("commit payload serializes");
     blob_hash(&bytes)
 }
 
+/// Deterministic identifier for a lock row: the project, branch, element and holder
+/// scoped by the acquisition time, so tests can predict the id without a random source.
+/// Truncated to 32 hex characters, ample for a lease measured in minutes.
+fn lock_id(project: &str, branch: &str, element: &str, holder: &str, now: i64) -> String {
+    let digest =
+        Sha256::digest(format!("{}|{}|{}|{}|{}", project, branch, element, holder, now).as_bytes());
+    let encoded = hex::encode(digest);
+    encoded[..32].to_string()
+}
+
 /// Seconds since the epoch, stored beside a commit and never inside its hash.
 pub fn now_epoch() -> String {
     match std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH) {
         Ok(d) => d.as_secs().to_string(),
         Err(_) => "0".to_string(),
     }
 }
 
 pub trait Store: Send + Sync {
     fn create_project(&self, name: &str) -> Result<Project, StoreError>;
@@ -130,11 +156,46 @@ pub trait Store: Send + Sync {
     fn branch_tip(&self, project: &str, branch: &str) -> Result<Option<String>, StoreError>;
     fn create_branch(&self, project: &str, name: &str, from: &str) -> Result<(), StoreError>;
 
     /// Remove a branch pointer. This never deletes commits: the objects a branch pointed
     /// at stay in the store, so a deleted branch can be recreated at the same hash and no
     /// history is ever lost.
     fn delete_branch(&self, project: &str, name: &str) -> Result<(), StoreError>;
     fn list_branches(&self, project: &str) -> Result<Vec<(String, String)>, StoreError>;
     fn record_gate_run(&self, run: &GateRun) -> Result<(), StoreError>;
     fn gate_runs(&self, project: &str) -> Result<Vec<GateRun>, StoreError>;
+
+    /// Acquire a lease on each of `elements`, all or nothing. If any element is held by a
+    /// live lease owned by a DIFFERENT holder, nothing is acquired and a Conflict is
+    /// returned naming the holder and the expiry. Re-acquiring an element the same holder
+    /// already holds extends the lease rather than failing.
+    fn acquire_locks(
+        &self,
+        project: &str,
+        branch: &str,
+        elements: &[String],
+        holder: &str,
+        ttl_seconds: i64,
+        now: i64,
+    ) -> Result<Vec<Lock>, StoreError>;
+
+    /// Release locks by id; only the listed holder may release them. Returns how many
+    /// rows were actually removed.
+    fn release_locks(
+        &self,
+        project: &str,
+        holder: &str,
+        ids: &[String],
+    ) -> Result<usize, StoreError>;
+
+    /// Live locks on a project: expired rows are reported as gone.
+    fn locks(&self, project: &str, now: i64) -> Result<Vec<Lock>, StoreError>;
+
+    /// The live locks covering any of the given elements, used by the commit path to see
+    /// who holds an element before changing it.
+    fn holders_of(
+        &self,
+        project: &str,
+        elements: &[String],
+        now: i64,
+    ) -> Result<Vec<Lock>, StoreError>;
 }
diff --git a/server/src/store/sqlite.rs b/server/src/store/sqlite.rs
index 3639387..cfe3ff6 100644
--- a/server/src/store/sqlite.rs
+++ b/server/src/store/sqlite.rs
@@ -1,16 +1,16 @@
 // SPDX-License-Identifier: AGPL-3.0-or-later
 use std::path::Path;
 
 use rusqlite::{params, Connection};
 
-use super::{now_epoch, Commit, GateRun, Project, Store, StoreError};
+use super::{now_epoch, Commit, GateRun, Lock, Project, Store, StoreError};
 
 const SCHEMA: &str = "
 CREATE TABLE IF NOT EXISTS projects (
     name TEXT PRIMARY KEY,
     created_at TEXT NOT NULL
 );
 CREATE TABLE IF NOT EXISTS blobs (
     hash TEXT PRIMARY KEY,
     bytes BLOB NOT NULL
 );
@@ -34,20 +34,30 @@ CREATE TABLE IF NOT EXISTS branches (
 CREATE TABLE IF NOT EXISTS gate_runs (
     id INTEGER PRIMARY KEY AUTOINCREMENT,
     project TEXT NOT NULL,
     branch TEXT NOT NULL,
     reference_hash TEXT NOT NULL,
     candidate_hash TEXT NOT NULL,
     passed INTEGER NOT NULL,
     evidence TEXT NOT NULL,
     created_at TEXT NOT NULL
 );
+CREATE TABLE IF NOT EXISTS locks (
+    id TEXT PRIMARY KEY,
+    project TEXT NOT NULL,
+    branch TEXT NOT NULL,
+    element TEXT NOT NULL,
+    holder TEXT NOT NULL,
+    acquired_at INTEGER NOT NULL,
+    expires_at INTEGER NOT NULL
+);
+CREATE INDEX IF NOT EXISTS locks_element ON locks(project, element);
 ";
 
 pub struct SqliteStore {
     connection: std::sync::Mutex<Connection>,
 }
 
 impl SqliteStore {
     pub fn open(path: &Path) -> anyhow::Result<Self> {
         let connection = Connection::open(path)?;
         connection.execute_batch(SCHEMA)?;
@@ -478,11 +488,218 @@ impl Store for SqliteStore {
                     reference_hash: row.get(2)?,
                     candidate_hash: row.get(3)?,
                     passed: row.get::<_, i64>(4)? != 0,
                     evidence: row.get(5)?,
                     created_at: row.get(6)?,
                 })
             })?;
             rows.collect()
         })
     }
+
+    fn acquire_locks(
+        &self,
+        project: &str,
+        branch: &str,
+        elements: &[String],
+        holder: &str,
+        ttl_seconds: i64,
+        now: i64,
+    ) -> Result<Vec<Lock>, StoreError> {
+        let guard = self
+            .connection
+            .lock()
+            .map_err(|_| StoreError::Backend("connection lock poisoned".to_string()))?;
+        let tx = guard
+            .unchecked_transaction()
+            .map_err(|e| StoreError::Backend(e.to_string()))?;
+
+        // Sweep dead leases first, so an expired lock never blocks a new holder.
+        tx.execute("DELETE FROM locks WHERE expires_at <= ?1", params![now])
+            .map_err(|e| StoreError::Backend(e.to_string()))?;
+
+        // All or nothing: refuse before writing anything if any requested element is
+        // held by a live lease owned by a different holder.
+        for element in elements {
+            let conflict: Option<(String, i64)> =
+                (|| -> rusqlite::Result<Option<(String, i64)>> {
+                    let mut stmt = tx.prepare(
+                        "SELECT holder, expires_at FROM locks WHERE project = ?1 AND element = ?2 AND holder != ?3",
+                    )?;
+                    let mut rows = stmt.query(params![project, element.as_str(), holder])?;
+                    match rows.next()? {
+                        Some(row) => Ok(Some((row.get(0)?, row.get(1)?))),
+                        None => Ok(None),
+                    }
+                })()
+                .map_err(|e| StoreError::Backend(e.to_string()))?;
+
+            if let Some((other, expires_at)) = conflict {
+                return Err(StoreError::Conflict(format!(
+                    "element {} is held by {} (expires at {})",
+                    element, other, expires_at
+                )));
+            }
+        }
+
+        // Upsert this holder's rows: extend an existing lease, insert a new one otherwise.
+        let mut locks = Vec::with_capacity(elements.len());
+        for element in elements {
+            let existing: Option<(String, String, i64)> =
+                (|| -> rusqlite::Result<Option<(String, String, i64)>> {
+                    let mut stmt = tx.prepare(
+                        "SELECT id, branch, acquired_at FROM locks WHERE project = ?1 AND element = ?2 AND holder = ?3",
+                    )?;
+                    let mut rows = stmt.query(params![project, element.as_str(), holder])?;
+                    match rows.next()? {
+                        Some(row) => Ok(Some((row.get(0)?, row.get(1)?, row.get(2)?))),
+                        None => Ok(None),
+                    }
+                })()
+                .map_err(|e| StoreError::Backend(e.to_string()))?;
+
+            let expires_at = now + ttl_seconds;
+            let (id, acquired_at) = match existing {
+                Some((id, _branch, acquired_at)) => {
+                    tx.execute(
+                        "UPDATE locks SET branch = ?1, expires_at = ?2 WHERE id = ?3",
+                        params![branch, expires_at, id],
+                    )
+                    .map_err(|e| StoreError::Backend(e.to_string()))?;
+                    (id, acquired_at)
+                }
+                None => {
+                    let id = super::lock_id(project, branch, element, holder, now);
+                    tx.execute(
+                        "INSERT INTO locks (id, project, branch, element, holder, acquired_at, expires_at) VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7)",
+                        params![id, project, branch, element.as_str(), holder, now, expires_at],
+                    )
+                    .map_err(|e| StoreError::Backend(e.to_string()))?;
+                    (id, now)
+                }
+            };
+
+            locks.push(Lock {
+                id,
+                project: project.to_string(),
+                branch: branch.to_string(),
+                element: element.clone(),
+                holder: holder.to_string(),
+                acquired_at,
+                expires_at,
+            });
+        }
+
+        tx.commit()
+            .map_err(|e| StoreError::Backend(e.to_string()))?;
+
+        Ok(locks)
+    }
+
+    fn release_locks(
+        &self,
+        project: &str,
+        holder: &str,
+        ids: &[String],
+    ) -> Result<usize, StoreError> {
+        let guard = self
+            .connection
+            .lock()
+            .map_err(|_| StoreError::Backend("connection lock poisoned".to_string()))?;
+        let tx = guard
+            .unchecked_transaction()
+            .map_err(|e| StoreError::Backend(e.to_string()))?;
+
+        // Only the listed holder may release, so holder and id are both pinned in the
+        // WHERE clause; any other holder's attempt deletes nothing.
+        let mut released = 0usize;
+        for id in ids {
+            released += tx
+                .execute(
+                    "DELETE FROM locks WHERE project = ?1 AND holder = ?2 AND id = ?3",
+                    params![project, holder, id],
+                )
+                .map_err(|e| StoreError::Backend(e.to_string()))?;
+        }
+
+        tx.commit()
+            .map_err(|e| StoreError::Backend(e.to_string()))?;
+        Ok(released)
+    }
+
+    fn locks(&self, project: &str, now: i64) -> Result<Vec<Lock>, StoreError> {
+        let guard = self
+            .connection
+            .lock()
+            .map_err(|_| StoreError::Backend("connection lock poisoned".to_string()))?;
+        let tx = guard
+            .unchecked_transaction()
+            .map_err(|e| StoreError::Backend(e.to_string()))?;
+
+        let locks: Vec<Lock> = (|| -> rusqlite::Result<Vec<Lock>> {
+            let mut stmt = tx.prepare(
+                "SELECT id, project, branch, element, holder, acquired_at, expires_at FROM locks WHERE project = ?1 AND expires_at > ?2 ORDER BY element",
+            )?;
+            let rows = stmt.query_map(params![project, now], |row| {
+                Ok(Lock {
+                    id: row.get(0)?,
+                    project: row.get(1)?,
+                    branch: row.get(2)?,
+                    element: row.get(3)?,
+                    holder: row.get(4)?,
+                    acquired_at: row.get(5)?,
+                    expires_at: row.get(6)?,
+                })
+            })?;
+            rows.collect()
+        })()
+        .map_err(|e| StoreError::Backend(e.to_string()))?;
+
+        tx.commit()
+            .map_err(|e| StoreError::Backend(e.to_string()))?;
+        Ok(locks)
+    }
+
+    fn holders_of(
+        &self,
+        project: &str,
+        elements: &[String],
+        now: i64,
+    ) -> Result<Vec<Lock>, StoreError> {
+        let guard = self
+            .connection
+            .lock()
+            .map_err(|_| StoreError::Backend("connection lock poisoned".to_string()))?;
+        let tx = guard
+            .unchecked_transaction()
+            .map_err(|e| StoreError::Backend(e.to_string()))?;
+
+        let locks: Vec<Lock> = (|| -> rusqlite::Result<Vec<Lock>> {
+            let mut locks = Vec::new();
+            for element in elements {
+                let mut stmt = tx.prepare(
+                    "SELECT id, project, branch, element, holder, acquired_at, expires_at FROM locks WHERE project = ?1 AND element = ?2 AND expires_at > ?3",
+                )?;
+                let rows = stmt.query_map(params![project, element.as_str(), now], |row| {
+                    Ok(Lock {
+                        id: row.get(0)?,
+                        project: row.get(1)?,
+                        branch: row.get(2)?,
+                        element: row.get(3)?,
+                        holder: row.get(4)?,
+                        acquired_at: row.get(5)?,
+                        expires_at: row.get(6)?,
+                    })
+                })?;
+                for row in rows {
+                    locks.push(row?);
+                }
+            }
+            Ok(locks)
+        })()
+        .map_err(|e| StoreError::Backend(e.to_string()))?;
+
+        tx.commit()
+            .map_err(|e| StoreError::Backend(e.to_string()))?;
+        Ok(locks)
+    }
 }
diff --git a/server/tests/locks.rs b/server/tests/locks.rs
new file mode 100644
index 0000000..5675ee3
--- /dev/null
+++ b/server/tests/locks.rs
@@ -0,0 +1,274 @@
+// SPDX-License-Identifier: AGPL-3.0-or-later
+use axum::body::Body;
+use axum::http::{Request, StatusCode};
+use http_body_util::BodyExt;
+use tower::ServiceExt;
+
+use server::store::{sqlite::SqliteStore, Store, StoreError};
+
+fn state(dir: &std::path::Path) -> server::AppState {
+    let store = SqliteStore::open(&dir.join("mw.db")).unwrap();
+    server::AppState {
+        store: std::sync::Arc::new(store),
+        evidence_dir: dir.to_path_buf(),
+    }
+}
+
+fn post(uri: &str, body: serde_json::Value) -> Request<Body> {
+    Request::builder()
+        .method("POST")
+        .uri(uri)
+        .header("content-type", "application/json")
+        .body(Body::from(body.to_string()))
+        .unwrap()
+}
+
+fn get(uri: &str) -> Request<Body> {
+    Request::builder().uri(uri).body(Body::empty()).unwrap()
+}
+
+async fn json_body(response: axum::response::Response) -> serde_json::Value {
+    let bytes = response.into_body().collect().await.unwrap().to_bytes();
+    serde_json::from_slice(&bytes).unwrap()
+}
+
+async fn seed_project(router: &axum::Router) {
+    let response = router
+        .clone()
+        .oneshot(post("/projects", serde_json::json!({ "name": "coffee" })))
+        .await
+        .unwrap();
+    assert_eq!(response.status(), StatusCode::CREATED);
+}
+
+#[tokio::test]
+async fn a_lock_can_be_acquired_listed_and_released() {
+    let dir = tempfile::tempdir().unwrap();
+    let router = server::app(state(dir.path()));
+    seed_project(&router).await;
+
+    let acquired = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/locks",
+            serde_json::json!({
+                "branch": "main",
+                "elements": ["b1", "b2"],
+                "holder": "alex",
+                "ttlSeconds": 300
+            }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(acquired.status(), StatusCode::CREATED);
+    let acquired = json_body(acquired).await;
+    let acquired = acquired.as_array().unwrap();
+    assert_eq!(acquired.len(), 2);
+    let ids: Vec<String> = acquired
+        .iter()
+        .map(|l| l["id"].as_str().unwrap().to_string())
+        .collect();
+
+    let listed = router
+        .clone()
+        .oneshot(get("/projects/coffee/locks"))
+        .await
+        .unwrap();
+    assert_eq!(listed.status(), StatusCode::OK);
+    let listed = json_body(listed).await;
+    let listed = listed.as_array().unwrap();
+    assert_eq!(listed.len(), 2);
+    let elements: Vec<&str> = listed
+        .iter()
+        .map(|l| l["element"].as_str().unwrap())
+        .collect();
+    assert!(elements.contains(&"b1"));
+    assert!(elements.contains(&"b2"));
+
+    let released = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/locks/release",
+            serde_json::json!({ "holder": "alex", "ids": ids }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(released.status(), StatusCode::OK);
+    let body = json_body(released).await;
+    assert_eq!(body["released"].as_i64(), Some(2));
+
+    let listed = router.oneshot(get("/projects/coffee/locks")).await.unwrap();
+    assert_eq!(json_body(listed).await.as_array().unwrap().len(), 0);
+}
+
+#[tokio::test]
+async fn a_second_holder_is_refused_and_nothing_is_acquired() {
+    let dir = tempfile::tempdir().unwrap();
+    let router = server::app(state(dir.path()));
+    seed_project(&router).await;
+
+    let a = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/locks",
+            serde_json::json!({
+                "branch": "main",
+                "elements": ["b1"],
+                "holder": "alex",
+                "ttlSeconds": 300
+            }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(a.status(), StatusCode::CREATED);
+
+    let refused = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/locks",
+            serde_json::json!({
+                "branch": "main",
+                "elements": ["b1", "b2"],
+                "holder": "bob",
+                "ttlSeconds": 300
+            }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(refused.status(), StatusCode::CONFLICT);
+    let error = json_body(refused).await;
+    assert!(error["error"].as_str().unwrap().contains("alex"));
+
+    // The refused request must leave NOTHING acquired: only A's b1 lock remains.
+    let listed = router.oneshot(get("/projects/coffee/locks")).await.unwrap();
+    let listed = json_body(listed).await;
+    let locks = listed.as_array().unwrap();
+    assert_eq!(
+        locks.len(),
+        1,
+        "the refused request must leave nothing acquired"
+    );
+    assert_eq!(locks[0]["element"], "b1");
+    assert_eq!(locks[0]["holder"], "alex");
+}
+
+#[tokio::test]
+async fn the_same_holder_can_extend_its_own_lease() {
+    let dir = tempfile::tempdir().unwrap();
+    let router = server::app(state(dir.path()));
+    seed_project(&router).await;
+
+    let first = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/locks",
+            serde_json::json!({
+                "branch": "main",
+                "elements": ["b1"],
+                "holder": "alex",
+                "ttlSeconds": 30
+            }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(first.status(), StatusCode::CREATED);
+    let first = json_body(first).await;
+    let first_expiry = first[0]["expiresAt"].as_i64().unwrap();
+
+    let second = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/locks",
+            serde_json::json!({
+                "branch": "main",
+                "elements": ["b1"],
+                "holder": "alex",
+                "ttlSeconds": 300
+            }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(second.status(), StatusCode::CREATED);
+    let second = json_body(second).await;
+    let second_expiry = second[0]["expiresAt"].as_i64().unwrap();
+    assert!(
+        second_expiry > first_expiry,
+        "re-acquiring must extend the lease"
+    );
+
+    let listed = router.oneshot(get("/projects/coffee/locks")).await.unwrap();
+    let locks = json_body(listed).await;
+    assert_eq!(
+        locks.as_array().unwrap().len(),
+        1,
+        "exactly one lock must exist for b1"
+    );
+}
+
+#[test]
+fn an_expired_lease_stops_blocking() {
+    // The HTTP layer always passes the real clock, so expiry is driven through the store
+    // directly with an injected clock: no sleeping, and the boundary is exact.
+    let dir = tempfile::tempdir().unwrap();
+    let store = SqliteStore::open(&dir.path().join("mw.db")).unwrap();
+
+    // A acquires b1 at now = 1000 with ttl 30, so the lease expires at 1030.
+    store
+        .acquire_locks("coffee", "main", &["b1".to_string()], "alex", 30, 1000)
+        .unwrap();
+
+    // Still inside the lease: a second holder is refused.
+    match store.acquire_locks("coffee", "main", &["b1".to_string()], "bob", 30, 1000) {
+        Err(StoreError::Conflict(_)) => {}
+        other => panic!("expected a conflict at now=1000, got {:?}", other),
+    }
+
+    // Past the lease (1030): the lease is dead and the second holder succeeds.
+    let acquired = store
+        .acquire_locks("coffee", "main", &["b1".to_string()], "bob", 30, 1031)
+        .unwrap();
+    assert_eq!(acquired.len(), 1);
+    assert_eq!(acquired[0].holder, "bob");
+}
+
+#[tokio::test]
+async fn only_the_holder_can_release() {
+    let dir = tempfile::tempdir().unwrap();
+    let router = server::app(state(dir.path()));
+    seed_project(&router).await;
+
+    let acquired = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/locks",
+            serde_json::json!({
+                "branch": "main",
+                "elements": ["b1"],
+                "holder": "alex",
+                "ttlSeconds": 300
+            }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(acquired.status(), StatusCode::CREATED);
+    let acquired = json_body(acquired).await;
+    let id = acquired[0]["id"].as_str().unwrap().to_string();
+
+    let released = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/locks/release",
+            serde_json::json!({ "holder": "bob", "ids": [id] }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(released.status(), StatusCode::OK);
+    let body = json_body(released).await;
+    assert_eq!(body["released"].as_i64(), Some(0));
+
+    let listed = router.oneshot(get("/projects/coffee/locks")).await.unwrap();
+    let locks = json_body(listed).await;
+    let locks = locks.as_array().unwrap();
+    assert_eq!(locks.len(), 1);
+    assert_eq!(locks[0]["holder"], "alex");
+}
