# Fix Round 1 Report: locks + audit (Slice 2 tranche 3)

## Status

DONE

## Commits

- `8a3d7a2` fix(server): enforce locks on all write paths and make audit writes atomic
  (closes I-1 and I-2; also closes M-1, M-2, M-5)

## Test summary

`cargo test --workspace --no-fail-fast`: 108 passed, 0 failed. Server (service) binaries:
api 11, audit 5, corpus 1, gate_api 3, http 2, locks 13, merge 15, merge_api 4, store 10
(= 64). Engine binaries: capi 4, gate 5, graph_stats 7, mcp 13, okf_diff 8,
okf_validation 7 (= 44).

`cargo fmt --all`: clean (exit 0). `cargo clippy --workspace --all-targets -- -D warnings`:
clean (exit 0).

## What was implemented

### I-1 — locks enforced by default, on every write path

- `create_commit` now always computes the touched set and always passes a `CommitGuard`.
  A request without a holder passes an empty holder, which the store's lock check refuses
  against any live lease (`holder != ?` with an empty holder matches every live lock).
- `reset_branch` computes `touched_elements(tip_model, target_model)` and passes a guard
  with an empty holder (reset has no holder field).
- `merge_branches` computes `touched_elements(ours, merged)` and passes a guard with an
  empty holder (merge has no holder field).
- `commit_merge` gained a `guard: Option<CommitGuard<'_>>` parameter and enforces it
  inside its transaction via a shared `enforce_guard` helper (the same helper commit_model
  now uses).
- The refusal is a 409 naming element, holder and expiry, plus the instruction that a caller
  who holds the lease must supply the holder field (`store::lock_refusal`).

### I-2 — audit rows written inside each mutation's own transaction

- `create_project`, `create_branch`, `delete_branch`, `record_gate_run`,
  `acquire_locks` and `release_locks` each gained an optional `Option<&AuditEntry>`
  parameter, written inside the same transaction as the mutation (via a `with_tx` helper
  that rolls back on any error). `release_locks` writes its row only when it actually
  removed a lock (released > 0), preserving the existing "no-op release is not a mutation"
  behaviour.
- Handlers pass the entry in, removing every "mutate in one transaction, append in a second"
  path.

### M-1 — refusals recorded

- `commit.refused` is recorded whenever commit/merge/reset is refused because an element is
  locked (`commit_refusal_guard` + `record_refusal`).
- `lock.denied` is recorded when an acquire is refused because another holder holds the
  lease.

### M-2 — append-only as a database property

- Added `BEFORE UPDATE` and `BEFORE DELETE` triggers on `audit` that `RAISE(ABORT)`.

### M-5 — holder and element-name validation

- `validate_holder` (non-empty, <= 128 characters) on lock acquire.
- `validate_element_name` (non-empty, no control characters, <= 256 bytes) replaces
  `validate_name` for lock-request elements, so element ids that OKF allows remain lockable.

## Concerns

- Merge and reset have no holder field, so they can never be the holder: a merge/reset that
  would change a locked element is always refused until the lease is released. This is the
  semantics the finding asks for ("a request that supplies no holder ... cannot be the
  holder"), but it means there is no merge-through-a-lock escape hatch.
- A lock refusal is distinguished from the branch-moved conflict by the canonical
  `"is locked by"` marker in the conflict message (`store::is_lock_refusal`). It is a
  string convention inside one crate, not a structured error type.
- `commit_merge`'s guard `expected_tip` is passed but its stale-tip protection is the
  pre-existing `parents[0] == current_tip` check (equivalent, since the handler sets
  `expected_tip` to `parents[0]`).

## Deviations

- Existing tests changed: `server/tests/store.rs` and `server/tests/locks.rs` call sites
  were updated mechanically for the new optional parameters (`create_project`,
  `create_branch`, `acquire_locks`, `commit_merge` gained an argument; passing `None`).
  No existing test EXPECTATION changed — none relied on locks being ignorable, so no test
  had to be rewritten for the enforce-by-default change.
- `lock.release`'s audit `detail` no longer carries the exact released count (it reads
  `"released lock(s)"`); the count was only knowable after the store ran, and the entry now
  rides the store's transaction. The subject still lists every released id.
