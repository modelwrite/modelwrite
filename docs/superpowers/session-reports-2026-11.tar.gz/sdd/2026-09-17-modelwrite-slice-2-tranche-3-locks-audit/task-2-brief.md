﻿## Global Constraints

- Rust stable; edition 2021; rust-version 1.75; no new dependencies.
- Every source file begins with: // SPDX-License-Identifier: AGPL-3.0-or-later
- Cargo is not on PATH in fresh shells: begin every shell command sequence with $env:Path = "$env:USERPROFILE\\.cargo\\bin;" + $env:Path
- Use --no-fail-fast when running a test suite.
- Stage and commit only the paths a task owns. Never amend or rewrite a commit.
- History stays append-only: no operation deletes or rewrites a commit row.
- THE AUDIT LOG IS APPEND-ONLY: the Store exposes an append and a read, never an update or a delete, and a test must prove that a second append cannot alter an earlier entry.
- A lock is a LEASE: it carries an expiry, and an expired lock is available to anyone. A crashed client must never be able to block an element forever.
- Time is passed IN to the store, never read inside it, so lock expiry and audit timestamps are testable without sleeping. The store takes a now: i64 parameter; the HTTP layer supplies the real clock.
- Every request path returns a structured error and never panics: 400 malformed, 404 missing, 409 held by someone else or conflict, 422 invalid model, 500 internal with a generic message.
- Names (project, branch) are validated by api::validate_name before use.
- Tests drive the router in process with tower oneshot; no port is bound.


## Task 2: A commit refuses to change an element someone else has locked

**Files:**
- Modify: server/src/api.rs (create_commit: optional lock assertion)
- Modify: server/src/store/mod.rs and sqlite.rs (commit_model gains an optional allowed-holder check)
- Test: server/tests/locks.rs (two more tests)

**Interfaces:**
- Consumes: Store::holders_of, okf::diff (to find which elements a commit touches).
- Produces:
  - `CreateCommit` gains `pub holder: Option<String>`.
  - When `holder` is supplied, create_commit computes the elements the commit CHANGES - the ids present in the diff between the branch tip's model and the incoming model, plus the ids of elements added or removed, plus the endpoints of changed edges - and refuses with 409 if any of them is locked by a different holder. When `holder` is absent the commit behaves exactly as today, so this is opt-in and nothing existing changes.

**Steps:**

- [ ] **Step 1: Compute the touched element ids.** Add a helper in api.rs:

The engine's real contract, which this helper must match: `okf::diff::diff(reference, candidate)`
returns a `DiffReport` with `equal`, `missing_elements`, `extra_elements`, `missing_edges`,
`extra_edges` and `changed_attributes`. The three ELEMENT fields hold section-scoped keys of
the form `<section>:<id>` (for example `structure:b1`, `graphnode:b1`, `state:s1`, `doc:project`,
`activity:0`). The two EDGE fields hold canonical JSON arrays `["source","target","kind","label"]`,
not section-scoped keys. There is no `changes` field and no per-change `key`.

```rust
/// The elements a commit changes: every diff entry that names an element, plus the
/// endpoints of changed edges. A lock protects an element from being CHANGED, so an
/// untouched element elsewhere in the document does not block the commit.
fn touched_elements(reference: &okf::types::OkfRoot, candidate: &okf::types::OkfRoot) -> Vec<String> {
    let report = okf::diff::diff(reference, candidate);
    let mut ids: std::collections::BTreeSet<String> = std::collections::BTreeSet::new();

    // Element entries are keyed "<section>:<id>". Two kinds of key are skipped on purpose:
    // "doc:" keys name document fields rather than elements, and the activity keys are list
    // indices rather than ids, so neither could be the subject of a lock.
    for key in report
        .missing_elements
        .iter()
        .chain(report.extra_elements.iter())
        .chain(report.changed_attributes.iter())
    {
        if let Some((section, id)) = key.split_once(':') {
            if section != "doc" && section != "activity" {
                ids.insert(id.to_string());
            }
        }
    }

    // An edge is a JSON array of source, target, kind and label, so changing one touches
    // both of its endpoints.
    for key in report.missing_edges.iter().chain(report.extra_edges.iter()) {
        if let Ok(parts) = serde_json::from_str::<Vec<String>>(key) {
            if let Some(source) = parts.first() {
                ids.insert(source.clone());
            }
            if let Some(target) = parts.get(1) {
                ids.insert(target.clone());
            }
        }
    }

    ids.into_iter().collect()
}
```

- [ ] **Step 2: Assert the locks** in create_commit, after validation and before put_blob:

```rust
    if let Some(holder) = body.holder.as_deref() {
        let tip_model = match state.store.branch_tip(&project, &body.branch).map_err(map_store_error)? {
            Some(tip) => load_model(&state, &project, &tip)?,
            None => incoming.clone(),
        };
        let touched = touched_elements(&tip_model, &incoming);
        let held = state
            .store
            .holders_of(&project, &touched, now_seconds())
            .map_err(map_store_error)?;
        let blocked: Vec<&Lock> = held.iter().filter(|l| l.holder != holder).collect();
        if !blocked.is_empty() {
            return Err(ApiError::conflict(format!(
                "{} is locked by {} until {}",
                blocked[0].element, blocked[0].holder, blocked[0].expires_at
            )));
        }
    }
```

- [ ] **Step 3: Tests** in server/tests/locks.rs:

6. `a_commit_is_refused_when_another_holder_locks_a_touched_element` - A locks b1 on main; B commits a model that RENAMES b1 with holder B and gets 409; the branch tip is unchanged. Then B commits a model that changes only an element nobody locked, with holder B, and succeeds.
7. `the_holder_may_commit_its_own_locked_element` - A locks b1 and commits the rename with holder A; 201.

- [ ] **Step 4: Run, lint and commit** as in Task 1, expected 49 service tests.

---


