# Task 3 Report: The append-only audit log

## Status

DONE

## Commits

- `c314b12` feat: add the append-only audit log (server/ only: src/store/mod.rs, src/store/sqlite.rs, src/api.rs, src/gate_api.rs, src/merge_api.rs, src/locks_api.rs, src/audit_api.rs, src/lib.rs, tests/audit.rs, tests/store.rs)

## Test summary

`cargo test -p mw-server --no-fail-fast`: 56 passed, 0 failed (audit: 5, api: 11, corpus: 1, gate_api: 3, http: 2, locks: 8, merge: 15, merge_api: 4, store: 7).

`cargo fmt --all`: clean. `cargo clippy -p mw-server --all-targets -- -D warnings`: clean (exit 0).

## What was implemented

- `audit` table (verbatim schema from the brief: AUTOINCREMENT id, project, at, actor, action,
  subject, detail) plus an `AuditEntry` type serialised camelCase in server/src/store/mod.rs.
- `Store::append_audit(&self, &AuditEntry) -> Result<i64, StoreError>` and
  `Store::audit(&self, project, limit) -> Result<Vec<AuditEntry>, StoreError>` (newest first,
  capped at 1000) in server/src/store/sqlite.rs, one transaction each. There is deliberately NO
  update, delete or truncate method anywhere in the trait or impl.
- `commit_model` and `commit_merge` gained an optional `Option<&AuditEntry>` parameter, and
  the audit row is inserted INSIDE their existing write transaction, so a commit (or reset, or
  clean merge) and its audit row succeed or fail together.
- Audit recording on every mutation path: `project.create`, `commit.create`,
  `branch.create`, `branch.delete`, `branch.reset`, `merge.clean`, `merge.conflict`,
  `lock.acquire`, `lock.release`, `gate.run` (including a FAILED gate).
- server/src/audit_api.rs with `GET /projects/:project/audit?limit=n`, wired in lib.rs.
- server/tests/audit.rs with the five required tests.

## Self-review

- Every mutation path records exactly one entry: create_commit and reset_branch pass their
  audit entry into commit_model (action `commit.create` / `branch.reset`), merge_branches
  passes `merge.clean` into commit_merge or appends `merge.conflict` on conflict; the other
  five paths append exactly one row immediately after the mutation. No path double-records.
- A failed gate is recorded: `a_failed_gate_is_recorded` gates the corrupted corpus model and
  asserts a `gate.run` entry whose detail contains `failed`.
- A conflicting merge is recorded: `a_conflicting_merge_is_recorded` asserts a
  `merge.conflict` entry whose detail names both branches.
- The rewrite test compares WHOLE entries, not presence: `entries_are_never_rewritten` captures
  the first read's entries and asserts `assert_eq!(&second[2..], &first[..])` after two more
  appends, plus explicit id-equality. Ids, timestamps, actors, subjects and details are all
  byte-identical, so appending never rewrites an earlier row.
- The read is newest first and capped: `audit` is `ORDER BY id DESC LIMIT ?` with the limit
  clamped to 1..=1000; `the_log_is_newest_first_and_capped` requests limit=2 and asserts
  exactly two entries with the higher id first.

## Concerns

- For the mutations that already own a transaction (commit_model, commit_merge) the audit row
  rides the same transaction, as the brief requires. For every OTHER path
  (project.create, branch.create, branch.delete, lock.acquire, lock.release, gate.run, and the
  conflict path) the audit row is appended in its own small transaction immediately after the
  mutation. If that append fails, the mutation persists without its audit row — a slightly
  weaker guarantee. This is stated rather than hidden: the brief only mandates the in-transaction
  audit for commit_model/commit_merge, and extending every store method's signature for
  single-row mutations would be more churn than the guarantee it buys at this stage.
- Actors are unverified by design: `project.create`, `branch.create`, `branch.delete` and
  `gate.run` carry no identity in their request today, so their actor is recorded as the
  literal `"unknown"`. Commit/reset/merge record the request's author and lock acquire/release
  record the holder, verbatim. Nothing here is an authenticated identity — that is the next
  tranche, and the log records what the request SAID, never what the server verified.

## Deviations

- The brief's Step 6 says "expected 54 service tests" and test 1 says "nine actions", but the
  action list has ten entries and the task instruction sets the target at 56 (51 prior + 5 new).
  I implemented exactly five tests and the suite is 56. I read "nine actions" as the nine
  success actions — all ten except `merge.conflict`, which only ever fails and is covered by
  its own test — which is the only reading under which "nine" is true.
- `lock.release` writes an entry only when it actually removed rows (released > 0). A release
  that removes nothing (a foreign holder, or already-released ids) is not a mutation and writes
  no entry; this is a small, deliberate judgment call.
- `commit_model`/commit_merge` now take 8 arguments, tripping clippy's
  `too_many_arguments` lint. I added a targeted `#[allow(clippy::too_many_arguments)]` on the
  trait declaration and the impl, because the brief explicitly requires the audit entry as an
  optional parameter to those two, and bundling the arguments into a struct would be a larger
  deviation than a scoped allow.
