﻿# Tranche 3 Task 2 review package (lock enforcement on commit)

## Commits under review

003d5ff fix: enforce locks inside the commit transaction, not before it
adfac47 feat: refuse a commit that changes a locked element

## Diff stat

 server/src/api.rs          |  77 ++++++++++++++++++++-
 server/src/store/mod.rs    |  15 ++++
 server/src/store/sqlite.rs |  33 ++++++++-
 server/tests/locks.rs      | 167 +++++++++++++++++++++++++++++++++++++++++++++
 server/tests/store.rs      |  97 ++++++++++++++++++++++++--
 5 files changed, 379 insertions(+), 10 deletions(-)

## Full diff (-U10)

diff --git a/server/src/api.rs b/server/src/api.rs
index 9689934..cd14fc6 100644
--- a/server/src/api.rs
+++ b/server/src/api.rs
@@ -1,21 +1,21 @@
 // SPDX-License-Identifier: AGPL-3.0-or-later
 use std::sync::Arc;
 
 use axum::extract::{Path, Query, State};
 use axum::http::StatusCode;
 use axum::Json;
 use serde::Deserialize;
 use serde_json::{json, Value};
 
 use crate::error::ApiError;
-use crate::store::{Commit, Store, StoreError};
+use crate::store::{now_epoch, Commit, CommitGuard, Store, StoreError};
 
 #[derive(Clone)]
 pub struct ApiState {
     pub store: Arc<dyn Store>,
     pub evidence_dir: std::path::PathBuf,
 }
 
 /// A name that is safe as a URL segment: letters, digits, dot, underscore and hyphen,
 /// at most 64 characters, and at least one letter or digit so that "." and ".." are
 /// rejected. The charset is deliberately narrow rather than merely path-safe, so names
@@ -84,20 +84,68 @@ pub fn load_model(
         .ok_or_else(|| {
             eprintln!("missing blob {}", commit.okf_hash);
             ApiError::internal("the stored model is missing")
         })?;
     serde_json::from_slice(&bytes).map_err(|e| {
         eprintln!("stored model is not readable: {}", e);
         ApiError::internal("the stored model could not be read")
     })
 }
 
+/// The real clock in seconds, as the store requires it. The store itself never reads the
+/// clock: time is passed in so lock expiry is testable without sleeping.
+fn now_seconds() -> i64 {
+    now_epoch().parse().unwrap_or(0)
+}
+
+/// The elements a commit changes: every diff entry that names an element, plus the
+/// endpoints of changed edges. A lock protects an element from being CHANGED, so an
+/// untouched element elsewhere in the document does not block the commit.
+fn touched_elements(
+    reference: &okf::types::OkfRoot,
+    candidate: &okf::types::OkfRoot,
+) -> Vec<String> {
+    let report = okf::diff::diff(reference, candidate);
+    let mut ids: std::collections::BTreeSet<String> = std::collections::BTreeSet::new();
+
+    // Element entries are keyed "<section>:<id>". Two kinds of key are skipped on purpose:
+    // "doc:" keys name document fields rather than elements, and the activity keys are list
+    // indices rather than ids, so neither could be the subject of a lock.
+    for key in report
+        .missing_elements
+        .iter()
+        .chain(report.extra_elements.iter())
+        .chain(report.changed_attributes.iter())
+    {
+        if let Some((section, id)) = key.split_once(':') {
+            if section != "doc" && section != "activity" {
+                ids.insert(id.to_string());
+            }
+        }
+    }
+
+    // An edge is a JSON array of source, target, kind and label, so changing one touches
+    // both of its endpoints.
+    for key in report.missing_edges.iter().chain(report.extra_edges.iter()) {
+        if let Ok(parts) = serde_json::from_str::<Vec<String>>(key) {
+            if let Some(source) = parts.first() {
+                ids.insert(source.clone());
+            }
+            if let Some(target) = parts.get(1) {
+                ids.insert(target.clone());
+            }
+        }
+    }
+
+    ids.into_iter().collect()
+}
+
 pub fn commit_json(commit: &Commit) -> Value {
     json!({
         "hash": commit.hash,
         "project": commit.project,
         "branch": commit.branch,
         "parents": commit.parents,
         "okfHash": commit.okf_hash,
         "author": commit.author,
         "message": commit.message,
         "createdAt": commit.created_at
@@ -132,20 +180,21 @@ pub async fn list_projects(State(state): State<ApiState>) -> Result<Json<Value>,
         .collect();
     Ok(Json(Value::Array(out)))
 }
 
 #[derive(Deserialize)]
 pub struct CreateCommit {
     pub branch: String,
     pub author: String,
     pub message: String,
     pub okf: Value,
+    pub holder: Option<String>,
 }
 
 pub async fn create_commit(
     State(state): State<ApiState>,
     Path(project): Path<String>,
     Json(body): Json<CreateCommit>,
 ) -> Result<(StatusCode, Json<Value>), ApiError> {
     if state
         .store
         .project(&project)
@@ -162,32 +211,57 @@ pub async fn create_commit(
     let root: okf::types::OkfRoot = serde_json::from_slice(&bytes)
         .map_err(|e| ApiError::bad_request(format!("not an OKF document: {}", e)))?;
     let report = okf::validate::validate(&root);
     if !report.valid {
         return Err(ApiError::unprocessable(
             "the model failed validation",
             report.errors,
         ));
     }
 
+    // A holder that asks the commit to respect locks: refuse to change any element held by
+    // someone else. Absent, the commit behaves exactly as before - locks are opt-in. The
+    // check itself happens INSIDE the store's commit transaction, so a lock taken between
+    // this point and the write cannot be bypassed.
+    let touched: Vec<String> = match body.holder.as_deref() {
+        Some(_) => {
+            let tip_model = match state
+                .store
+                .branch_tip(&project, &body.branch)
+                .map_err(map_store_error)?
+            {
+                Some(tip) => load_model(&state, &project, &tip)?,
+                None => root.clone(),
+            };
+            touched_elements(&tip_model, &root)
+        }
+        None => Vec::new(),
+    };
+    let guard = body.holder.as_deref().map(|holder| CommitGuard {
+        holder,
+        elements: &touched,
+        now: now_seconds(),
+    });
+
     let okf_hash = state.store.put_blob(&bytes).map_err(map_store_error)?;
     // One call, one transaction: the parents come from the tip the store reads inside the
     // same lock that writes the commit, so two concurrent commits to one branch chain
     // instead of forking the history.
     let commit = state
         .store
         .commit_model(
             &project,
             &body.branch,
             &okf_hash,
             &body.author,
             &body.message,
+            guard,
         )
         .map_err(map_store_error)?;
     Ok((StatusCode::CREATED, Json(commit_json(&commit))))
 }
 
 #[derive(Deserialize)]
 pub struct BranchQuery {
     pub branch: Option<String>,
 }
 
@@ -327,14 +401,15 @@ pub async fn reset_branch(
     // The target's model is already stored, so this reuses its blob rather than copying
     // the bytes: the restored content is byte-identical to the original by construction.
     let commit = state
         .store
         .commit_model(
             &project,
             &name,
             &target.okf_hash,
             &body.author,
             &body.message,
+            None,
         )
         .map_err(map_store_error)?;
     Ok((StatusCode::CREATED, Json(commit_json(&commit))))
 }
diff --git a/server/src/store/mod.rs b/server/src/store/mod.rs
index 04f1da2..b0fbfcf 100644
--- a/server/src/store/mod.rs
+++ b/server/src/store/mod.rs
@@ -111,39 +111,54 @@ fn lock_id(project: &str, branch: &str, element: &str, holder: &str, now: i64) -
 }
 
 /// Seconds since the epoch, stored beside a commit and never inside its hash.
 pub fn now_epoch() -> String {
     match std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH) {
         Ok(d) => d.as_secs().to_string(),
         Err(_) => "0".to_string(),
     }
 }
 
+/// What a guarded commit must not change. The holder is the one asking; any element in
+/// `elements` held by a DIFFERENT holder with a live lease refuses the commit.
+pub struct CommitGuard<'a> {
+    pub holder: &'a str,
+    pub elements: &'a [String],
+    pub now: i64,
+}
+
 pub trait Store: Send + Sync {
     fn create_project(&self, name: &str) -> Result<Project, StoreError>;
     fn project(&self, name: &str) -> Result<Option<Project>, StoreError>;
     fn list_projects(&self) -> Result<Vec<Project>, StoreError>;
     fn put_blob(&self, bytes: &[u8]) -> Result<String, StoreError>;
     fn blob(&self, hash: &str) -> Result<Option<Vec<u8>>, StoreError>;
 
     /// Commit a model onto a branch atomically: the tip is read, the parents and the
     /// commit hash are derived from it, and the commit row and the branch tip are written
     /// inside ONE lock and transaction. Resolving the parents a layer above would be a
     /// read-modify-write race: two concurrent commits would both read the same tip and
     /// fork the history, the later one orphaning the earlier while the branch lists both.
+    ///
+    /// An optional guard says "refuse this commit if any of these elements is locked by
+    /// somebody else". The check runs INSIDE the transaction, not before it: checking first
+    /// and writing afterwards leaves a window in which another holder acquires the lock and
+    /// the guarded commit lands anyway, which would make a lock advisory in the worst way -
+    /// it would look enforced and not be.
     fn commit_model(
         &self,
         project: &str,
         branch: &str,
         okf_hash: &str,
         author: &str,
         message: &str,
+        guard: Option<CommitGuard<'_>>,
     ) -> Result<Commit, StoreError>;
 
     /// Write a commit with EXPLICIT parents and move the branch tip, in one transaction.
     /// A merge commit has two parents, so the parent list cannot be derived from the tip.
     fn commit_merge(
         &self,
         project: &str,
         branch: &str,
         parents: &[String],
         okf_hash: &str,
diff --git a/server/src/store/sqlite.rs b/server/src/store/sqlite.rs
index cfe3ff6..5b4c11a 100644
--- a/server/src/store/sqlite.rs
+++ b/server/src/store/sqlite.rs
@@ -1,16 +1,16 @@
 // SPDX-License-Identifier: AGPL-3.0-or-later
 use std::path::Path;
 
 use rusqlite::{params, Connection};
 
-use super::{now_epoch, Commit, GateRun, Lock, Project, Store, StoreError};
+use super::{now_epoch, Commit, CommitGuard, GateRun, Lock, Project, Store, StoreError};
 
 const SCHEMA: &str = "
 CREATE TABLE IF NOT EXISTS projects (
     name TEXT PRIMARY KEY,
     created_at TEXT NOT NULL
 );
 CREATE TABLE IF NOT EXISTS blobs (
     hash TEXT PRIMARY KEY,
     bytes BLOB NOT NULL
 );
@@ -169,29 +169,56 @@ impl Store for SqliteStore {
         })
     }
 
     fn commit_model(
         &self,
         project: &str,
         branch: &str,
         okf_hash: &str,
         author: &str,
         message: &str,
+        guard: Option<CommitGuard<'_>>,
     ) -> Result<Commit, StoreError> {
-        let guard = self
+        let connection = self
             .connection
             .lock()
             .map_err(|_| StoreError::Backend("connection lock poisoned".to_string()))?;
-        let tx = guard
+        let tx = connection
             .unchecked_transaction()
             .map_err(|e| StoreError::Backend(e.to_string()))?;
 
+        // The lock check happens HERE, inside the transaction that writes the commit. A
+        // check performed by the caller before this call would leave a window in which
+        // another holder takes the lock and the guarded commit lands regardless.
+        if let Some(guard) = guard {
+            for element in guard.elements {
+                let held: Option<(String, i64)> = (|| -> rusqlite::Result<Option<(String, i64)>> {
+                    let mut stmt = tx.prepare(
+                        "SELECT holder, expires_at FROM locks WHERE project = ?1 AND element = ?2 AND expires_at > ?3 AND holder != ?4 LIMIT 1",
+                    )?;
+                    let mut rows =
+                        stmt.query(params![project, element, guard.now, guard.holder])?;
+                    match rows.next()? {
+                        Some(row) => Ok(Some((row.get(0)?, row.get(1)?))),
+                        None => Ok(None),
+                    }
+                })()
+                .map_err(|e| StoreError::Backend(e.to_string()))?;
+                if let Some((holder, expires_at)) = held {
+                    return Err(StoreError::Conflict(format!(
+                        "{} is locked by {} until {}",
+                        element, holder, expires_at
+                    )));
+                }
+            }
+        }
+
         // The tip is read inside the same lock and transaction that writes the commit, so
         // two concurrent commits to one branch chain rather than fork.
         let tip: Option<String> = (|| -> rusqlite::Result<Option<String>> {
             let mut stmt =
                 tx.prepare("SELECT tip FROM branches WHERE project = ?1 AND name = ?2")?;
             let mut rows = stmt.query(params![project, branch])?;
             match rows.next()? {
                 Some(row) => Ok(Some(row.get(0)?)),
                 None => Ok(None),
             }
diff --git a/server/tests/locks.rs b/server/tests/locks.rs
index ebeebbc..cca7878 100644
--- a/server/tests/locks.rs
+++ b/server/tests/locks.rs
@@ -316,10 +316,177 @@ async fn locks_can_be_released_with_delete_or_post() {
                 .unwrap(),
         )
         .await
         .unwrap();
     assert_eq!(released.status(), StatusCode::OK);
     assert_eq!(json_body(released).await["released"], 1);
 
     let listed = router.oneshot(get("/projects/coffee/locks")).await.unwrap();
     assert!(json_body(listed).await.as_array().unwrap().is_empty());
 }
+
+fn model_with_nodes(ids: &[&str]) -> serde_json::Value {
+    let nodes: Vec<serde_json::Value> = ids
+        .iter()
+        .map(|id| serde_json::json!({ "id": id, "kind": "block", "name": id.to_uppercase() }))
+        .collect();
+    serde_json::json!({
+        "project": "coffee",
+        "exportedAt": "2026-09-17T00:00:00Z",
+        "summary": {},
+        "stateMachine": { "name": "sm", "regions": [] },
+        "graph": { "nodes": nodes, "edges": [] }
+    })
+}
+
+#[tokio::test]
+async fn a_commit_is_refused_when_another_holder_locks_a_touched_element() {
+    let dir = tempfile::tempdir().unwrap();
+    let router = server::app(state(dir.path()));
+    seed_project(&router).await;
+
+    // Establish the branch tip with two elements, so a later commit can change one while
+    // leaving the other - and its lock - untouched.
+    let seeded = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/commits",
+            serde_json::json!({
+                "branch": "main",
+                "author": "alex",
+                "message": "seed",
+                "okf": model_with_nodes(&["b1", "b2"])
+            }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(seeded.status(), StatusCode::CREATED);
+    let tip = json_body(seeded).await["hash"]
+        .as_str()
+        .unwrap()
+        .to_string();
+
+    let locked = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/locks",
+            serde_json::json!({
+                "branch": "main",
+                "elements": ["b1"],
+                "holder": "alex",
+                "ttlSeconds": 300
+            }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(locked.status(), StatusCode::CREATED);
+
+    // B renames b1: the locked element is the one being CHANGED, so the commit is refused.
+    let refused = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/commits",
+            serde_json::json!({
+                "branch": "main",
+                "author": "bob",
+                "message": "rename b1",
+                "holder": "bob",
+                "okf": model_with_nodes(&["b1-renamed", "b2"])
+            }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(refused.status(), StatusCode::CONFLICT);
+    let error = json_body(refused).await;
+    let message = error["error"].as_str().unwrap();
+    assert!(
+        message.contains("b1"),
+        "the 409 must name the locked element"
+    );
+    assert!(message.contains("alex"), "the 409 must name the holder");
+
+    // The refused commit must write NOTHING: the branch tip is unchanged.
+    let branches = router
+        .clone()
+        .oneshot(get("/projects/coffee/branches"))
+        .await
+        .unwrap();
+    let branches = json_body(branches).await;
+    let main = branches
+        .as_array()
+        .unwrap()
+        .iter()
+        .find(|b| b["name"] == "main")
+        .unwrap();
+    assert_eq!(main["tip"].as_str().unwrap(), tip.as_str());
+
+    // A model that changes only b2 - an element nobody locked - succeeds even though the
+    // document still CONTAINS the locked b1: a lock guards change, not mere presence.
+    let ok = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/commits",
+            serde_json::json!({
+                "branch": "main",
+                "author": "bob",
+                "message": "rename b2",
+                "holder": "bob",
+                "okf": model_with_nodes(&["b1", "b2-renamed"])
+            }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(ok.status(), StatusCode::CREATED);
+}
+
+#[tokio::test]
+async fn the_holder_may_commit_its_own_locked_element() {
+    let dir = tempfile::tempdir().unwrap();
+    let router = server::app(state(dir.path()));
+    seed_project(&router).await;
+
+    let seeded = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/commits",
+            serde_json::json!({
+                "branch": "main",
+                "author": "alex",
+                "message": "seed",
+                "okf": model_with_nodes(&["b1"])
+            }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(seeded.status(), StatusCode::CREATED);
+
+    let locked = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/locks",
+            serde_json::json!({
+                "branch": "main",
+                "elements": ["b1"],
+                "holder": "alex",
+                "ttlSeconds": 300
+            }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(locked.status(), StatusCode::CREATED);
+
+    // The same holder that owns the lock may commit the change to that element.
+    let committed = router
+        .oneshot(post(
+            "/projects/coffee/commits",
+            serde_json::json!({
+                "branch": "main",
+                "author": "alex",
+                "message": "rename b1",
+                "holder": "alex",
+                "okf": model_with_nodes(&["b1-renamed"])
+            }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(committed.status(), StatusCode::CREATED);
+}
diff --git a/server/tests/store.rs b/server/tests/store.rs
index 3b1fefa..0b114d7 100644
--- a/server/tests/store.rs
+++ b/server/tests/store.rs
@@ -26,29 +26,29 @@ fn a_commit_hash_ignores_time_but_not_content() {
     let c = commit_hash("p", "main", &parents, "okf2", "alex", "m");
     assert_eq!(a, b);
     assert_ne!(a, c);
 }
 
 #[test]
 fn commits_land_on_a_branch_and_move_its_tip() {
     let (store, _dir) = store();
     store.create_project("coffee").unwrap();
     let first = store
-        .commit_model("coffee", "main", "okf1", "alex", "first commit")
+        .commit_model("coffee", "main", "okf1", "alex", "first commit", None)
         .unwrap();
     assert_eq!(
         store.branch_tip("coffee", "main").unwrap().unwrap(),
         first.hash
     );
 
     let second = store
-        .commit_model("coffee", "main", "okf2", "alex", "second commit")
+        .commit_model("coffee", "main", "okf2", "alex", "second commit", None)
         .unwrap();
     assert_eq!(
         store.branch_tip("coffee", "main").unwrap().unwrap(),
         second.hash
     );
     assert_eq!(store.commits_on("coffee", "main").unwrap().len(), 2);
     // The parent link is the point of a commit graph: without it, history is a pile of
     // unrelated snapshots that no merge could ever reason about.
     assert!(first.parents.is_empty(), "the first commit has no parent");
     assert_eq!(second.parents, vec![first.hash.clone()]);
@@ -56,21 +56,21 @@ fn commits_land_on_a_branch_and_move_its_tip() {
 
 #[test]
 fn duplicate_projects_and_branches_are_conflicts() {
     let (store, _dir) = store();
     store.create_project("coffee").unwrap();
     match store.create_project("coffee") {
         Err(StoreError::Conflict(_)) => {}
         other => panic!("expected a conflict, got {:?}", other),
     }
     let commit = store
-        .commit_model("coffee", "main", "okf1", "alex", "first commit")
+        .commit_model("coffee", "main", "okf1", "alex", "first commit", None)
         .unwrap();
     store
         .create_branch("coffee", "review", &commit.hash)
         .unwrap();
     match store.create_branch("coffee", "review", &commit.hash) {
         Err(StoreError::Conflict(_)) => {}
         other => panic!("expected a conflict, got {:?}", other),
     }
     match store.create_branch("coffee", "other", "missing-commit") {
         Err(StoreError::NotFound(_)) => {}
@@ -93,20 +93,21 @@ fn concurrent_commits_to_one_branch_form_a_linear_chain() {
     for i in 0..8 {
         let store = store.clone();
         handles.push(std::thread::spawn(move || {
             store
                 .commit_model(
                     "coffee",
                     "main",
                     &format!("okf-{}", i),
                     "alex",
                     "concurrent",
+                    None,
                 )
                 .expect("commit model");
         }));
     }
     for handle in handles {
         handle.join().expect("worker thread");
     }
 
     let history = store.commits_on("coffee", "main").unwrap();
     assert_eq!(history.len(), 8, "every commit must land");
@@ -156,32 +157,39 @@ fn concurrent_commits_to_one_branch_form_a_linear_chain() {
     );
 }
 #[test]
 fn a_merge_refuses_when_the_branch_moved_under_it() {
     // A merge is computed from tips read before the write. If a commit lands in between,
     // writing the merge would move the branch off that commit and orphan it: stored, but
     // unreachable from any branch. The store must refuse instead of losing it.
     let (store, _dir) = store();
     store.create_project("coffee").unwrap();
     let root = store
-        .commit_model("coffee", "main", "okf-root", "alex", "root")
+        .commit_model("coffee", "main", "okf-root", "alex", "root", None)
         .unwrap();
     store
         .create_branch("coffee", "feature", &root.hash)
         .unwrap();
     let their_side = store
-        .commit_model("coffee", "feature", "okf-feature", "alex", "feature")
+        .commit_model("coffee", "feature", "okf-feature", "alex", "feature", None)
         .unwrap();
 
     // The concurrent commit: main moves AFTER the merge read its tips.
     let concurrent = store
-        .commit_model("coffee", "main", "okf-concurrent", "alex", "concurrent")
+        .commit_model(
+            "coffee",
+            "main",
+            "okf-concurrent",
+            "alex",
+            "concurrent",
+            None,
+        )
         .unwrap();
 
     let refused = store.commit_merge(
         "coffee",
         "main",
         &[root.hash.clone(), their_side.hash.clone()],
         "okf-merged",
         "alex",
         "merge",
     );
@@ -196,10 +204,87 @@ fn a_merge_refuses_when_the_branch_moved_under_it() {
         concurrent.hash
     );
     let merges: Vec<_> = store
         .commits_on("coffee", "main")
         .unwrap()
         .into_iter()
         .filter(|c| c.parents.len() == 2)
         .collect();
     assert!(merges.is_empty(), "no merge commit may be written");
 }
+#[test]
+fn a_guarded_commit_is_refused_inside_the_transaction() {
+    // The guard has to be enforced by the store, not by the caller. A check performed
+    // before the write leaves a window in which another holder takes the lock and the
+    // guarded commit lands anyway - a lock that looks enforced and is not. This test drives
+    // the store directly, with no API layer to do the checking for it.
+    use server::store::CommitGuard;
+
+    let (store, _dir) = store();
+    store.create_project("coffee").unwrap();
+    store
+        .commit_model("coffee", "main", "okf-root", "alex", "root", None)
+        .unwrap();
+
+    // Alex holds b1.
+    store
+        .acquire_locks("coffee", "main", &["b1".to_string()], "alex", 600, 1000)
+        .unwrap();
+
+    // Sam's commit touches b1: the store must refuse it, with nothing written.
+    let touched = vec!["b1".to_string()];
+    let refused = store.commit_model(
+        "coffee",
+        "main",
+        "okf-sam",
+        "sam",
+        "sam edits a locked element",
+        Some(CommitGuard {
+            holder: "sam",
+            elements: &touched,
+            now: 1000,
+        }),
+    );
+    match refused {
+        Err(StoreError::Conflict(message)) => {
+            assert!(message.contains("b1"), "the refusal must name the element");
+            assert!(message.contains("alex"), "the refusal must name the holder");
+        }
+        other => panic!("expected a conflict, got {:?}", other.map(|c| c.hash)),
+    }
+    assert_eq!(store.commits_on("coffee", "main").unwrap().len(), 1);
+
+    // An expired lease is not a lock: the same commit succeeds once the lease lapses.
+    let allowed = store.commit_model(
+        "coffee",
+        "main",
+        "okf-sam",
+        "sam",
+        "sam edits after the lease lapsed",
+        Some(CommitGuard {
+            holder: "sam",
+            elements: &touched,
+            now: 2000,
+        }),
+    );
+    assert!(allowed.is_ok(), "an expired lease must not block a commit");
+
+    // A guard for an element nobody holds blocks nothing, even while a DIFFERENT element is
+    // locked: a lock protects the elements it names, not the document around them.
+    let elsewhere = vec!["b3".to_string()];
+    store
+        .acquire_locks("coffee", "main", &["b2".to_string()], "alex", 600, 1000)
+        .unwrap();
+    let unrelated = store.commit_model(
+        "coffee",
+        "main",
+        "okf-other",
+        "sam",
+        "sam edits something else",
+        Some(CommitGuard {
+            holder: "sam",
+            elements: &elsewhere,
+            now: 1000,
+        }),
+    );
+    assert!(unrelated.is_ok(), "only the guarded elements are protected");
+}
