# Modelwrite Workbench — UX Fixes Report

**Status:** DONE_WITH_CONCERNS
**Commit:** 47efbf1 (branch slice-2-repository)
**Files:** 14 changed — engine/graph (components fn), server/src/ui (health.rs, search.rs, import.rs, model.rs, layout.rs, app.js, assist.rs, mod.rs), server/src/lib.rs (routes), server/tests (ui.rs, ui_assist.rs), e2e/tests/diagram.spec.js.

## One-line test summary

`cargo test --workspace --no-fail-fast` all green (619 → 628, +9 tests, 0 failed); `cargo fmt --all --check` clean; `cargo clippy --workspace --all-targets -- -D warnings` clean; e2e `diagram.spec.js` readable-scale test passing.

## Old-vs-new click counts (the four affected jobs)

| Job | OLD | NEW | How it moved |
|---|---|---|---|
| 2 — "what is broken" | 7 clicks / 6 pages | **2 clicks / 1 page** | landing → open project → **Health**. One screen names orphaned nodes (0), isolated groups (0), dangling links (2), uncovered requirements (10) — verified on the corpus. |
| 3 — import loss acceptance | 252 checkboxes | **1 action** | "Accept all 252 losses and import" button + select-all + a visible selected count. Per-entry boxes stay. |
| 8 — open the 99-node diagram and read it | 2 + ~4 zoom/pan | **2** | Default camera opens at a readable label scale (≥11px effective); Fit stays as a button. |
| 6 — find "pump" | hidden tree filter (2 clicks + 1 field, absent from Changes and most pages) | **1 click + 1 field** | Header search box on every project page (incl. the Changes landing page) → matches → "in diagram" reveal. |

## Branch-bug verdict (re-proved, then fixed)

The audit claimed "edit/new-element links hardcode branch=main". **The literal claim is disproved** — a code grep found ZERO literal `branch=main`, and the links carry `commit.branch`. **But the bug is REAL in a subtler form, so it was fixed and tested.**

Evidence:
- `server/src/ui/model.rs` "Add element" / "edit" links and the assist panel used `commit.branch` — the branch the tip COMMIT was created on — not the branch being viewed.
- `create_branch` points a new version at an existing commit; that commit's stored `branch` field remains `"main"`. So on `overview?branch=feature` the links emitted `?branch=main`, silently writing edits to main.
- Fix: the links now carry `view_branch` (the branch in the address bar), which falls back to `commit.branch` only for a commit-scoped view.
- Proof: test `add_element_and_edit_links_carry_the_viewed_branch_not_main` (server/tests/ui.rs) creates a version from main's tip and asserts the add/edit links carry `?branch=feature` and never `?branch=main`.

## Concerns

1. **No visual verification possible.** Model deepseek-v4-pro has no image input (read_image rejected with "does not declare image input"), so every conclusion rests on DOM/HTML inspection, HTTP responses, and the e2e geometry measurement (scale ≥ 0.8, label ≥ 11px) — never a screenshot I actually looked at.
2. **Local 8080 trial server not restarted.** It still runs the pre-fix binary; I left it untouched to preserve its live-reasoner config (Assist works there per the audit). The re-walk ran against a fresh server (port 8095) seeded with the coffee corpus, plus the e2e server.
3. **Stray .gitignore line.** `.gitignore` has a corrupted entry (`e2e/*.png\ne2e/diag-*.js` with a literal `\n`), so the audit's `e2e/flow-*.png` are not actually ignored and remain untracked. Out of scope; not touched.
