# Crate re-release: report

## Status

DONE_WITH_CONCERNS

All twelve crates are published on crates.io at 0.2.0, in dependency order, each
dry-run-first and confirmed against the crates.io API. The install proof (cargo install
mw-cli from a clean directory, run offline, and a throwaway crate built against the
published mw-okf) passes. The published 0.2.0 fixes the original defect: mw-okf now
exposes OkfRoot.references.

## Commits

- `187ce08` — chore(crates): bump the crate layer to 0.2.0 and make server publish-ready
  (14 files: Cargo.lock, the twelve Cargo.toml manifests, server/README.md)
- `111f83e` — docs: reflect the 0.2.0 crates.io release and note the MSRV pins
  (README.md, docs/guide/cli.md, cli/README.md)

A third commit, `4a153b7` ("fix(import): configure and stream the request-body limit"),
landed on the branch concurrently by the body-limit task while I published; it is not mine
and was correctly excluded from the 0.2.0 snapshot.

## One-line test summary

cargo test --workspace --no-fail-fast: 556 passed, 0 failed, 24 ignored (PostgreSQL suite
skipped); cargo fmt --all clean; cargo clippy --workspace --all-targets -- -D warnings clean;
cargo +1.75.0 build on the ten engine crates: exit 0 (indexmap 2.11.4 and zeroize 1.8.2 held).

## Per-crate published table

| Crate | Version | Publish result |
|-------|---------|----------------|
| mw-test-support | 0.2.0 | published (API max_version 0.2.0) |
| mw-okf | 0.2.0 | published (API max_version 0.2.0) |
| mw-graph | 0.2.0 | published (API max_version 0.2.0) |
| mw-gate | 0.2.0 | published (API max_version 0.2.0) |
| mw-binding | 0.2.0 | published (API max_version 0.2.0) |
| mw-capi | 0.2.0 | published (API max_version 0.2.0) |
| mw-binding-xmi | 0.2.0 | published (API max_version 0.2.0) |
| mw-agent | 0.2.0 | published (API max_version 0.2.0) |
| mw-analytics | 0.2.0 | published (API max_version 0.2.0) |
| mw-mcp | 0.2.0 | published (API max_version 0.2.0) |
| mw-server | 0.2.0 | published (API max_version 0.2.0) |
| mw-cli | 0.2.0 | published (API max_version 0.2.0) |

Publish order (from the actual dependency edges, not the brief's list): mw-test-support
first because mw-okf dev-depends on it; then mw-okf, mw-graph, mw-gate, mw-binding,
mw-capi, mw-binding-xmi, mw-agent, mw-analytics, mw-mcp, mw-server, mw-cli. No 429s were hit.

## Verbatim install-and-build proof (clean directory C:\Users\alexk\mw-clean-verify)

cargo install mw-cli (from crates.io) compiled mw-okf/mw-graph/mw-gate/mw-binding/
mw-binding-xmi/mw-agent/mw-analytics/mw-server/mw-cli all v0.2.0 from the registry and:

```
  Installing C:\Users\alexk\.cargo\bin\mw.exe
   Installed package `mw-cli v0.2.0` (executable `mw.exe`)
```

```console
$ mw --help
usage: mw [--server <url> [--token <ENV_VAR>] | --db <path>] <command>

  --server <url>   talk to a running service over plain http://
  --token <VAR>    read the bearer token from the environment variable named VAR
  --db <path>      open a local SQLite store directly (offline, no server)

commands:
  project create <name>
  project list
  commit <project> --branch <branch> --message <msg> --file <path> [--holder <name>]
  log <project> --branch <branch>
  artifact <project> --hash <hash>
  branch list <project>
  branch create <project> --name <name> --from <commit>
  branch delete <project> --name <name>
  merge <project> --branch <branch> --other <branch> --message <msg> [--holder <name>]
  reset <project> --branch <branch> --to <commit> --message <msg> [--holder <name>]
  gate <project> --reference <commit> --candidate <commit>
  lock acquire <project> --branch <branch> --elements <a,b> --holder <name> --ttl <seconds>
  lock release <project> --holder <name> --ids <a,b>
  lock list <project>
  audit <project> [--limit <n>]
```

```console
$ mw --db throwaway.db project create coffee
{
  "createdAt": "1789901022",
  "name": "coffee"
}

$ mw --db throwaway.db commit coffee --branch main --message "first commit" --file model.json
{
  "author": "",
  "branch": "main",
  "createdAt": "1789901022",
  "hash": "e52a72fe125821df5e09453aae2f846724f894fcceed62b47251f0c60512662c",
  "message": "first commit",
  "okfHash": "aaf301fbe88ef571137d37556724447d7574aba9659cfaa169f5871b79be9981",
  "parents": [],
  "project": "coffee",
  "provenance": { "kind": "authored" }
}

$ mw --db throwaway.db log coffee --branch main
[ ... one commit, hash e52a72fe125821df5e09453aae2f846724f894fcceed62b47251f0c60512662c ... ]
```

(All four commands exited 0.)

Throwaway crate (`cargo add mw-okf` then `cargo run`) against the published 0.2.0,
exercising the exact field the defect claimed was missing:

```console
$ cargo run
OkfRoot.references present: 1 reference(s)
```

The code constructs `OkfRoot { references: vec![SubsystemReference { project, revision,
role, bounds }], .. }` — proof that the published mw-okf 0.2.0 exposes OkfRoot.references
(the compile would fail with E0560/E0609 otherwise, which is how the stale 0.1.0 failed).

## MSRV caveat

The workspace pins indexmap =2.11.4 and zeroize =1.8.2 are preserved and they propagate
into the published manifests (mw-graph depends on indexmap =2.11.4; mw-mcp depends on
zeroize =1.8.2), so the engine's 1.75 floor is expressed in crate metadata, not only in
the lockfile. Proven with cargo +1.75.0 build of all ten engine crates (exit 0; it compiled
indexmap v2.11.4 and zeroize v1.8.2). docs/guide/cli.md now states the pins.

Remaining caveat: cargo install mw-cli WITHOUT --locked resolves mw-cli's own transitive
tree fresh. This does not endanger the engine floor — mw-cli declares rust-version 1.88 and
the 1.75 floor only applies to the engine crates, whose pins live in their own manifests.
For a byte-reproducible mw-cli build, install with --locked.

## Tag (item 6)

Not created. A v0.2.0 tag fires the release workflow (ghcr image + five-platform mw/mw-mcp
binaries) and requires pushing my local commits and the tag to origin, so I am deferring it
rather than guessing. Recommendation if you want a release consistent with the published
crates: tag the bump commit itself, `187ce08` (not the tip, which now carries the
concurrent body-limit commit `4a153b7` that is not in 0.2.0):

    git push origin 187ce08:slice-2-repository
    git tag v0.2.0 187ce08
    git push origin v0.2.0

## Concerns

1. **Concurrent work landed after 0.2.0 was cut.** The body-limit task committed `4a153b7`
   after I published, and cross-model-edge work (engine/okf/src/types.rs `cross_model_edges`
   / `CrossModelEdge`, plus composition/impact sources) is still uncommitted in the working
   tree. Published 0.2.0 = commit `187ce08`, which is the committed HEAD at publish time and
   deliberately excludes both; the main branch has since moved on. A future 0.2.1 / 0.3.0 can
   pick up cross_model_edges once it is committed.
2. **Published mw-server 0.2.0 manifest carries two deps its 0.2.0 source does not use.**
   The concurrent body-limit task had added `axum` (multipart) and `tempfile` to
   server/Cargo.toml before my bump; my committed (and thus published) server manifest
   inherits those two lines, but the 0.2.0 server source (pre-body-limit) does not use them.
   Harmless (unused deps; the full build/clippy/test passed), but it is a slight
   manifest/source mismatch worth knowing about.
3. **My commits are local only.** `187ce08` and `111f83e` are on the local
   slice-2-repository branch, not yet pushed.
