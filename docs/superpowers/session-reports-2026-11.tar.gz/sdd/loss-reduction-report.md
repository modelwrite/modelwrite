# Loss-reduction report: MagicDraw XMI import

status: DONE_WITH_CONCERNS

## Commits

`0d1b2ab` — carry ports, associations and parts; reclassify diagram/file metadata (see below)

## One-line test summary

434 passed, 0 failed, 24 ignored (PostgreSQL suite); `cargo clippy --workspace --all-targets -- -D warnings` clean; `cargo fmt --all` clean.

## Before / after totals

- Content losses (Unmappable): **270 → 124** (−146, a 54% cut).
- Recognised declarations: **1 → 22**.
- Graph nodes / edges: **59/28 → 66/95**.
- Structure blocks: **34 → 41** (34 Block + 6 InterfaceBlock + 1 ConstraintBlock).

## By-construct before/after

| Construct | Before | After | What happened |
|---|---|---|---|
| uml:Property | 86 | 51 | 28 `association` back-refs consumed (associations now carried); 7 non-block properties carried via InterfaceBlock/ConstraintBlock blocks; 51 `visibility` remain named losses (no OKF slot) |
| uml:Association | 33 | 5 | 28 block↔block carried as `association` edges; 5 Actor/UseCase associations stay NAMED losses |
| PartProperty (other) | 28 | 0 | carried as `part` edges (owner → type) |
| DiagramInfo (other) | 11 | 0 | reclassified declaration (diagram author/date metadata) |
| ValueProperty (other) | 11 | 0 | consumed (carried as attribute) |
| uml:Class | 10 | 3 | 7 non-Block/Requirement classes (6 InterfaceBlock + 1 ConstraintBlock) carried as blocks; 3 `classifierBehavior` attributes remain named |
| uml:Signal | 9 | 9 | out of scope |
| Extension (other) | 8 | 0 | reclassified declaration (serialization/diagram metadata container) |
| InterfaceBlock (other) | 6 | 0 | consumed; classes carried as blocks |
| ProxyPort (other) | 6 | 0 | consumed (port carried) |
| uml:Port | 6 | 8 | carried as attribute + part edge, but 6 `visibility` + 2 `isConjugated` attributes remain named |
| uml:SignalEvent | 6 | 6 | out of scope |
| FlowProperty (other) | 5 | 5 | consumed, but the 5 `direction` attributes remain named (no OKF slot) |
| ReferenceProperty (other) | 5 | 0 | carried as `reference` edges (owner → type) |
| uml:Connector | 5 | 5 | out of scope |
| uml:UseCase | 5 | 5 | out of scope |
| useCase (other) | 5 | 5 | out of scope |
| ValueType (other) | 3 | 3 | out of scope (value types) |
| uml:Activity | 3 | 3 | out of scope |
| uml:DataType | 3 | 3 | out of scope (value types) |
| uml:TimeEvent | 3 | 3 | out of scope |
| uml:Actor | 2 | 2 | out of scope |
| uml:Operation | 2 | 2 | out of scope |
| ConstraintBlock (other) | 1 | 0 | consumed; class carried as block |
| Documentation (other) | 1 | 0 | reclassified declaration (exporter metadata) |
| auxiliaryResource (other) | 1 | 0 | reclassified declaration (auxiliary-file metadata) |
| client / supplier (other) | 2 | 2 | out of scope |
| uml:Comment / Constraint / Dependency / StateMachine | 4 | 4 | out of scope |

## Edge directions chosen, and the evidence

- **dependency (Satisfy/Allocate/Refine/Verify)** — unchanged: `source = client`, `target = supplier`.
  Evidence: `engine/graph`'s `requirement_coverage` counts a requirement as covered only when it is the **target** (`req_ids.contains(t)`), and the existing reader already emits `source: d.client, target: d.supplier`. The real model still yields 20 Satisfy / 3 Allocate / 4 Refine / 1 Verify.
- **association** — `source = type(memberEnd[0])`, `target = type(memberEnd[1])` (the ownedEnd).
  Evidence: the golden corpus `sample/corpus/coffee-machine/okf/expected/coffee_machine_model.json` has `Water System --association--> Coffee Machine` for the association whose `memberEnd[0]` is the `water System` part property (typed Water System) and whose `ownedEnd` is typed Coffee Machine. Verified on all 28 block↔block associations.
- **part (PartProperty and Port)** — `source = owning block`, `target = property type`.
  Evidence: golden corpus `Coffee Machine --part--> Water System` and `Coffee Machine --part--> Water Flow Port`. This is the OPPOSITE direction of the association edge for the same relationship.
- **reference (ReferenceProperty)** — `source = owning block`, `target = referenced type`.
  Evidence: golden corpus `Coffee Machine --reference--> Coffee Machine Production`.

All four directions are pinned by `real_magicdraw.rs` and by the new `ports_associations_and_parts_carry_with_the_golden_corpus_direction` fixture test in `xmi.rs`.

## What remains lost (all still NAMED, never dropped)

- 51 `uml:Property … attribute 'visibility'` — OKF `Attribute` has no visibility slot; the value is the UML default `public`.
- 8 `uml:Port` attributes (6 visibility + 2 `isConjugated`).
- 5 `FlowProperty … attribute 'direction'` (in/out) — no OKF slot.
- 5 `uml:Association` between Actor/UseCase (their endpoints are not carried blocks, so the edge would dangle).
- 3 `uml:Class … attribute 'classifierBehavior'`.
- The whole signal/activity/state-machine/connector/use-case surface (uml:Signal 9, SignalEvent 6, Connector 5, UseCase 5, useCase 5, Activity 3, TimeEvent 3, Actor 2, Operation 2, DataType 3, ValueType 3, Constraint 1, StateMachine 1, Dependency 1, Comment 1, client/supplier 2) — outside this task's scope.

## Concerns

1. **Export is now narrower than import.** The binding imports association/part/reference edges as a graph reduction, but `export` still refuses any edge whose `kind != "dependency"` (a clean `BindingError::Export`, consistent with "refuse rather than silently normalise", but the real model no longer round-trips through export). The graph reduction loses the property id/name needed to reconstruct a faithful `uml:Association` + `PartProperty` pair, so I did not attempt a lossy reconstruction.
2. **Item 1 was extended to `xmi:Extension` (8).** The task named DiagramInfo/auxiliaryResource/Documentation; `xmi:Extension` containers (plugins, resources, stereotypesHREFS, ownedDiagram geometry) are unambiguously the same category, so they are also reclassified declarations. Revert those 8 lines in the walk if the narrower scope is preferred.
3. **Actor/UseCase associations stay losses.** Carrying actors and use cases (and their 12 associated losses) is a separate piece of work, not asked for here.
4. **A pre-existing unrelated change in `server/src/lib.rs` was present in the working tree during my run** (a `/ → /ui` redirect). I did not author it and left it uncommitted; my commit touches only `engine/binding-xmi`.
