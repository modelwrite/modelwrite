# Workbench create — report

## Status

DONE

## Commits

- `02ab177` feat(workbench): let the workbench create projects, models, elements and branches

## One-line test summary

Full workspace suite green: 443 passed, 0 failed, 24 ignored (the PostgreSQL suite); `cargo fmt --all --check` and `cargo clippy --workspace --all-targets -- -D warnings` both clean.

## What was built

The workbench could VIEW, EDIT an existing element, IMPORT and MERGE, but had no way to
create anything — the trial user's complaint ("how do I create a new model?") had no answer
in the UI. Four creation paths now exist, each a client of the existing API through the
same shared cores the JSON endpoints use (no new store methods, no second sequence):

1. **Create a project** — a "New project" form on `/ui` (project list), guarded by
   Administer, POSTs `/ui` through `create_project_core` and redirects to the new project.
2. **Create a model** — an empty project's model page now says "This project has no model
   yet — start one or import a legacy model" with the action right there: "Start from
   empty" (a minimal valid OKF document) or "Create from pasted document" (pasted JSON).
   Both POST `/ui/projects/:project/model/new` through `commit_core` and land on the model.
3. **Add an element** — "Add element" on the model page opens
   `/ui/projects/:project/element/new`, which adds a block or a requirement (id, name,
   kind, and a requirement's reqId and text) through `commit_core` — the same validation,
   locking and audit entry as the JSON commit endpoint.
4. **Create a branch** — a "New branch" form on the project page POSTs
   `/ui/projects/:project/branch` through `create_branch_core`.

Every form resolves Identity, checks the permission the underlying endpoint requires, and
only then does work, in the same order as the handlers; a form is not offered to a caller
who cannot submit it, and a refusal re-renders the form with the reason rather than a bare
error page.

## End-to-end click path (nothing → model with a block and a requirement)

1. Open `/ui` → "No projects yet. Create one below." → type a project name → **Create project**.
2. On `/ui/projects/<name>` ("This project has no branches yet.") → **Start a model**.
3. On `/ui/projects/<name>/model` ("This project has no model yet…") → **Start from empty**
   (or paste JSON → **Create from pasted document**).
4. On the model page → **Add element** → kind=block, id, name, message → **Add element**.
5. **Add element** again → kind=requirement, id, name, reqId, text, message → **Add element**.
6. The model page now shows the block and the requirement; commits are `start the model`,
   `add the heater block`, `add the heat requirement`.
7. On `/ui/projects/<name>` → "New branch" → name + "Branch from" tip → **Create branch**.

## What remains missing

- **Proposal accept/refuse UI** (item 5, explicitly optional): the
  `POST .../proposals/:id/accept` and `.../refuse` routes are still API-only. Deferred;
  items 1–4 are complete and green.

## Concerns

- **Verification had to use a separate target dir.** The trial server runs
  `target/debug/mw-server.exe`, which Windows locks, so `cargo test`/clippy on the default
  target dir fails trying to relink that exe. I ran all checks with
  `CARGO_TARGET_DIR=target-tests` (now gitignored) so the running trial was never touched.
  Anyone verifying on this machine needs the same `CARGO_TARGET_DIR`, or must stop the trial.
- **"Start from empty" carries a phantom graph node** (`root`, kind `block`). The OKF
  validator requires a non-empty graph and a state machine, so a truly empty document cannot
  be literally empty; the node backs no element and is invisible on the model page, but it
  would render as a stray node in the diagram view. Not flagged by validation.
- **A requirement needs a reqId.** The task named "text" as the requirement field, but the
  validator refuses an empty reqId, so the form collects a reqId (and refuses with a clear
  message when it is empty) rather than silently inventing one.
