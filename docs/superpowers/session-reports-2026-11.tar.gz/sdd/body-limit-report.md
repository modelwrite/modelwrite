# Request-body limit: configure it and stream the artifact path

## Status

DONE_WITH_CONCERNS

## Commits

- `4a153b7` fix(import): configure and stream the request-body limit

## One-line test summary

`cargo test --workspace --no-fail-fast`, `cargo fmt --all`, and
`cargo clippy --workspace --all-targets -- -D warnings` all pass; the five new
body-limit/streaming tests and the ignored 36 MB TMT import test are green.

## The default and its justification

`MW_MAX_BODY_BYTES`, default **512 MiB** (536,870,912 bytes). Real MBSE models
run to hundreds of megabytes — the Open-MBEE Thirty Meter Telescope is a 36 MB
XMI and is SMALL by production standards — so axum's 2 MB default turns a routine
vendor export into a silent failure. 512 MiB accepts the models a migration
actually sees while staying under SQLite's 1 GB single-value ceiling with headroom,
and it bounds a single upload's on-disk staging so concurrent imports cannot
exhaust the host. Anything larger is a configuration decision (set the variable),
not a code change. The limit is applied as `DefaultBodyLimit` to every route and
stated on the import page.

## Streaming vs buffering

The artifact path now **streams**. On SQLite (the default and tested backend):

1. The multipart `artifact` file field is staged to a temporary file in 64 KiB
   chunks while the byte count is enforced (peak memory ~ a few chunks, never the
   model).
2. `Store::put_blob_file` hashes that file incrementally (64 KiB chunks) and
   writes it into the SQLite `blobs` column via `zeroblob(size)` +
   `blob_open` + positional `write_all_at` — no step holds the whole artifact
   in memory.
3. The XMI is read back into memory only to hand it to the binding parser
   (roxmltree needs the whole document), so peak memory during parse is ~1× the
   artifact, not the 2–3× that base64-in-JSON buffering used.

The PostgreSQL backend hashes incrementally but reads the staged file into memory
for its single `BYTEA` insert (one full-file buffer at insert time, not during
receipt). That asymmetry is documented in the code, not hidden.

## Verbatim TMT import outcome

```
=== TMT STREAMING IMPORT (Open-MBEE TMT.mdzip, 2022x, Apache-2.0) ===
source bytes         : 36158244
artifact hash        : 76e5c008df30906edeb337348ac1afb84b1468e688689759d28ca1feeaba5a3e
streamed+stored in   : 1.9474252s
imported in          : 5.5282564s
outcome              : Blocking (refused: 48553 blocking losses not accepted)
binding              : sysml-v1-xmi@2.4
```

The 36 MB model now reaches the importer through the streaming store. The migration
itself is refused as `Blocking` because the binding names 48,553 blocking losses
and none were accepted — that is the model's lossiness, not a transport failure. The
artifact is retained byte-for-byte under the hash above, before import, exactly as
the founding rule requires.

## Concerns

1. **The TMT migration cannot commit** — 48,553 blocking losses are unaccepted, so
   `import_core` returns `Blocking`, not `Committed`. The artifact is retained
   and parsed; the migration is refused pending loss acceptance.
2. **PostgreSQL buffers once at insert** — only SQLite streams into its blob column
   without a full-file buffer (see above).
3. **XMI parse still needs the whole document in memory** (roxmltree) — streaming
   eliminates the JSON/base64 double-buffer and the receipt-time buffer, not the
   parse buffer.
4. **Workbench acceptance re-uploads the file** — a streamed import with blocking
   losses shows the losses and asks the user to submit the file again with the
   accepted losses; the retained artifact is not yet re-read by hash for the
   acceptance round-trip.
