# Modelwrite Workbench — UX Flow Audit (click-count, journey-by-journey)

**Status:** DONE_WITH_CONCERNS
**Auditor:** delegated subagent (read-only; no product code touched)
**Servers audited:**
- **Public** https://trial.modelwrite.org — jobs 1, 2, 6, 7, 8, 10, and the Job 9 check.
- **Local** http://127.0.0.1:8080 — jobs 3 (import), 4 (assist), 5 (version), because the public trial has "No live reasoner configured" (Assist is dead there) and local is scratch with a live reasoner (mw-assist). Split stated per job.

## Evidence standard — READ FIRST

**My model (deepseek-v4-pro) has NO image input. I could NOT visually read any screenshot.** Every screenshot was still captured to e2e/flow-<n>-*.png (the record), but every claim was verified by DOM/HTML inspection (rendered text, element counts, attributes, hrefs, computed geometry) — never by a visual check I did not perform. Where a visual judgment was decisive (diagram legibility) I measured geometry (effective label font-size in px). Stated once here, assumed everywhere below.

---

## Click-count table (cold start at /ui, first-time visitor)

| # | Job (goal) | Clicks | Fields | Extra friction | Verdict |
|---|-----------|-------:|-------:|----------------|---------|
| 1a | Showcase → cafe-stand composition | 2 | 0 | not discoverable from landing | FRICTION |
| 1b | Showcase → compare main vs with-microduck | 4 | 0 | chooser detour; pre-filled path hidden in switcher | FRICTION |
| 2 | "What is broken" (full graph-gaps picture) | 7 | 0 | 6 pages; no single view | **BROKEN** |
| 3 | Import my model (file → loss report → accept → result) | 4 | 4 + 252 checkboxes | no bulk-accept | **BROKEN** |
| 4 | Ask assistant to change something (request → proposal → accept) | 4 | 2 | gate-before-accept works; silent no-commit on empty message | ACCEPTABLE |
| 5 | Make a version, change it, compare, make current | ~9 | ~8 | branch context dropped on edit links | FRICTION |
| 6 | Find one element by name ("where is the pump?") | 2 | 1 | tree filter only; absent on many pages; no reveal-in-diagram | FRICTION |
| 7 | See requirement coverage (covered/uncovered + what satisfies each) | 2 | 0 | — | ACCEPTABLE |
| 8 | Open the 99-node diagram and READ it | 2 + ~4 zoom | 0 | default fit-to-view ≈ 6 px labels | FRICTION |
| 9 | Register for a trial | — | — | NOT BUILT (404 both servers) | NOT BUILT |
| 10 | Export or download anything | — | — | nothing exists (routes 404, zero links) | **BROKEN** |

Counting: "clicks" = discrete pointer clicks; "fields" = typed/selected inputs (file picker = 1 field). Job 3's 252 checkboxes are separate because they are the story. Job 5's "~9/~8" is the full cycle (create → change → compare → make current); the change step alone is a 7-field form.

---

## Per-job findings

### 1. "Show me what this thing can do" — FRICTION

Goal A (composition): landing → click cafe-stand (1) → Composition (2) = 2 clicks. Result: 4 resolving subsystems, measured-vs-asserted boundary, 6-step process (flow-1-2-composition.png).

Goal B (compare): landing → cafe-stand (1) → Overview (2) → Compare (3) → pick with-microduck (4) = 4 clicks. Result: variant-impact panel + diff + gate verdict (floor-care floor-robot→microduck changed; "Verdict: failed … integration: 2 connected components").

Dead ends / confusions:
- The landing card opens the model at "Changes" (H1), NOT Overview. A stranger's first screen after Open is a commit/version dashboard, not "what this model is".
- Nothing flags cafe-stand as the platform showcase or the two-robot trade study. A stranger would not find either goal.
- Same job, two paths: the visible Compare button → /compare?from=main (a chooser); the switcher's "compare" link is pre-filled from=main&to=with-microduck.

### 2. "What is broken in my model?" — BROKEN (expected top finding, confirmed)

Complete picture requires 6 pages (7 clicks): Overview (coverage COUNT only 15/25), Structure (tree — orphans silently re-rooted, never labeled; no "orphan" text anywhere), Requirements (uncovered chips + the "Unresolved edges" list = 2 dangling Satisfy links), Traceability (per-requirement status), Diagram (2 dangling/unresolved nodes), Checks (gate runs only — "No gate runs yet" on public, so isolated nodes / connected-components are absent unless a gate run exists).

**No single view answers it.** Two signals are effectively invisible:
- Orphans: never labeled — renderer just re-roots unreached elements (model.rs), so a user cannot tell an orphan from a legitimate top-level block.
- Isolated groups: only inside a gate-run evidence block (gate.rs "Isolated nodes" / "N connected components"). Public trial has no gate runs → dead end there.

### 3. Import my model — BROKEN (worst flow measured)

Path: open (1) → Import (2) → branch + message + file (3 fields) → Import file (3) → "Import refused: blocking losses" → check each loss → "Accept the checked losses and import" (4) → "Import committed".

Measured against a real 193 KB MagicDraw SysML XMI (.superpowers/coffee.xmi):
- Loss report: 124 unmappable + 128 lossy = 252 blocking losses, each its own checkbox, NO select-all/accept-all (confirmed in import.rs — one accept_loss_<i> checkbox per loss, no bulk control).
- A non-expert must click 252 checkboxes by name before commit. Worst interaction in the workbench.
- Other lose-points: unexplained "Binding" term, bare "branch" field (empty default), a required "commit message" for an import, and two simultaneous forms (Upload a file vs Or paste a small artifact).

Good parts: nothing lossy commits before acceptance ("nothing was committed"), artifact retained byte-for-byte and content-addressed.

### 4. Ask the assistant to change something — ACCEPTABLE (the fix works)

Path: open (1) → Assist (2) → type request (1 field) → Submit (3) → read proposal → Accept (4).

**Gate consequences ARE shown before acceptance — confirmed.** The review page renders, in order: "Gate check of the candidate — Would fail the gate", the Isolated nodes list, "Connected components: 12", "Uncovered requirements: 10", then the proposed change, then the Accept form (flow-4-2-submitted.png). Exactly the gate-before-accept fix requested.

Concerns: (a) empty commit message on Accept re-rendered the review WITHOUT committing and WITHOUT an obvious error (heater-block never appeared); (b) Assist is dead on the public trial ("No live reasoner configured"), so the showcase cannot demo the headline flow.

### 5. Version control — FRICTION (branch context dropped)

Full cycle: open (1) → New version (2) → name (1 field) → Create version (3) → change it → Compare → Make current.

- Create: lands on the new branch; ctx-actions become "New version · Compare · Make current". 3 clicks + 1 field.
- **The change step is where the difference becomes unclear — and it is a real bug:** on overview?branch=audit-v2, every "Add element" and "edit" link hardcodes branch=main (/element/new?branch=main, /edit/<id>?branch=main). Editing "your" version writes to MAIN, with nothing on screen saying so. Verified identical hrefs for both branches.
- Compare from a branch also goes through the chooser (one more click).
- Make current: gate verdict correctly shown BEFORE the merge form (section order ["gate","merge"]; verdict "failed … 10 isolated nodes, 11 connected components"), then "Merge and make current".

### 6. Find "pump" — FRICTION (search exists, but is a hidden tree filter)

**The expected "there is NO UI search" is no longer true — partially denied.** A search input DOES exist on Overview / Structure / Requirements / Diagram / the /model page, placeholder "Filter name / id / stereotype". Typing "pump" narrows the tree to Coffee Machine System → Water Subsystem → Water Pump plus the Pump Pressure requirement (flow-6-3-search.png).

But it is not what the job asks for:
- It is a tree filter, not a global find. Absent from landing, the Changes default page, Composition, Checks, Traceability, Proposals, Import, Assist.
- No reveal-location action (no "show in diagram"/jump); the tree just collapses to the path.
- The diagram has a second box "Search name / id", but typing "pump" there flagged 0 nodes (filter-style or inert, not locate/reveal).
- Net: find-the-pump = open (lands on Changes, no search) → Overview → type = 2 clicks + 1 field, and only a tree path, not a location.

### 7. Requirement coverage — ACCEPTABLE

Landing → open (1) → Requirements (2) = 2 clicks. Table shows 15 covered / 10 uncovered with per-requirement "satisfied by" cells (25 cells) and per-link "unresolved link" markers. Overview also shows a counts-only summary in 2 clicks. Best-supported job; only miss is that the Overview summary is a count, not a list.

### 8. Open the 99-node diagram and READ it — FRICTION (default is wrong)

Landing → open (1) → Diagram (2) = 2 clicks to open. Then to read:
- Default is fit-to-view. Measured: SVG viewBox 2130×2080 rendered 1214×642 → scale ≈ 0.57 (fit-to-width) → ≈ 6 px effective label text (13 px font × 0.57). 99 nodes in a ~1214 px viewport. Illegible by construction (flow-8-2-diagram.png).
- Reading requires repeated + zoom (3–4 clicks) then pan, plus kind-filter chips to dim categories. Kind filter works.
- The diagram's own "Search name / id" does not highlight a match (0 nodes) — even search doesn't help you read it.

**The default is wrong** for a 99-node graph: open at a readable scale, not fit-to-view.

### 9. Register for a trial — NOT BUILT

/register, /ui/register, /trial, /signup, /ui/signup all return 404 on both servers. The running router hardcodes registered: None; there is no registered-trial UI route in either live binary. Nothing to walk — only the open showcase exists (/ui, "anonymous via open"). Note: during this audit the registered-trial source began landing on disk (server/src/registered.rs, server/src/ui/register.rs, server/src/store/trials.rs, server/src/trial/, server/tests/registered.rs are new untracked files) — the feature is being actively built by another task, but neither running server serves it yet.

### 10. Export or download anything — BROKEN

A visitor can take away NOTHING. Verified: no export/download link or button anywhere; /export, /download, /ui/projects/<p>/export, /ui/projects/<p>/download all 404; landing body contains zero occurrences of "export"/"download". Diagram has no PNG/SVG export; gate page references an "Evidence file" path (server-side) but offers no download. Only take-away is copy-paste or the browser's save-page. Exactly as expected: little or nothing.

---

## The three worst dead ends

1. **Import loss-acceptance.** A 193 KB SysML XMI import demands 252 individually-checked losses with no accept-all. Effectively unusable.
2. **"What is broken" has no home.** Six pages to assemble; orphans never labeled anywhere; isolated groups only inside a gate run (empty on public). The owner's headline analytic has no single screen.
3. **No export/download.** Write-mostly, take-nothing. A visitor who builds or imports cannot leave with a model, report, or image.

## The top five fixes (ranked by frequency × friction)

1. **Build the single "model health" (graph-gaps) view** — orphans, isolated groups, dangling/unresolved links, and uncovered requirements on one screen. Saves 6 page-visits → 1 on the highest-frequency, highest-stakes job. (Expected candidate — CONFIRMED as the top gap.)
2. **Add bulk-accept to the import loss report** — select-all + accept-all (retain per-item list for audit). Saves ~250 clicks per import.
3. **Fix the branch-drop bug** — Add element / edit links must carry the current branch, not hardcode branch=main. Silent write-to-wrong-version correctness bug, not just friction.
4. **Change the diagram default zoom** — open at a readable scale (or fit a focused subgraph), not fit-to-view. Saves ~4 zoom/pan interactions per open. (Expected candidate — CONFIRMED; ≈6 px labels at default.)
5. **Promote the tree filter to a global "find element" search** — reachable on every page (incl. landing and Changes), with a "reveal in diagram" action. Turns "where is the pump" from 2 clicks + guess into 1 search + 1 jump. (Expected candidate — PARTIALLY DENIED: a search box exists but only as a hidden tree filter; the gap is global reach + locate/reveal.)

Confirm/deny vs the owner's expected list: graph-gaps single view — CONFIRMED missing; UI search — DENIED as "no search", reframed as "search exists but hidden tree filter"; diagram default zoom — CONFIRMED wrong.

---

## Concerns

1. **Screenshots were not visually verified.** My model has no image input, so e2e/flow-*.png are the record but every conclusion rests on DOM/HTML inspection. A human or image-capable model should spot-check flow-3-3-afterupload.png, flow-4-2-submitted.png, flow-8-2-diagram.png, flow-5-6-make-current.png.
2. **Split-server audit.** Jobs 3/4/5 on local 8080 (public Assist unconfigured); jobs 1/2/6/7/8/10 on the public trial. Faithful split, but interactive flows measured on scratch data, not the exact public build.
3. **Assist accept behaviour unconfirmed at code level.** Empty commit message on Accept re-rendered the review without committing and without a visible error (heater-block never appeared; branch tips unchanged). Likely the message is required and the refusal under-surfaced.
4. **Public trial resets hourly.** Counts captured in one pass; a mid-run reset could shift seed metadata (coffee-machine/cafe-stand are the stable seeds).
5. **Diagram search appears inert for locate.** Typing "pump" in the diagram's "Search name / id" flagged 0 nodes — filter-style at best, not locate/reveal.

## Artifacts

- Report: .superpowers/sdd/ux-flow-audit.md (this file).
- Screenshots: e2e/flow-*.png (~60 files, gitignored), named flow-<job>-<step>.
- Throwaway project audit-flow on 127.0.0.1:8080 (scratch reset clears it; not on the public trial).
