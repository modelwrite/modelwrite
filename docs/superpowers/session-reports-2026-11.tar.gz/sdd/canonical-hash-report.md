# Canonical Hash Fix — Content-Addressing Consistency

## Status
DONE. The content-addressing inconsistency the STPA seeding exposed is fixed at the platform
level, not just in the fixture. A document's commit hash is now a function of its CONTENT alone
— the summary is re-derived and the serialisation order is fixed at ONE canonical point — so
the same document written through every path produces the same hash. Full workspace suite green,
fmt clean, clippy clean, CI-enforced evidence records regenerate byte-for-byte.

## Commits
- 6ea0913 — "fix(content-address): one canonical serialisation across every write path"

## One-line test summary
`cargo test --workspace --no-fail-fast` → 0 failed (635 → 636: +1 cross-path hash-equality
test), `cargo fmt --all` clean, `cargo clippy --workspace --all-targets -- -D warnings` clean.

## Serialisation-site inventory (file + symbol)

Every place that produces bytes a commit is hashed over, or hashes a document, as found BEFORE
the change:

| # | File | Symbol | What it did | Order |
|---|------|--------|-------------|-------|
| 1 | `engine/okf/src/hash.rs` | `canonical_hash` | sha256 of `serde_json::to_vec(root)` | struct (canonical), but did NOT re-derive summary |
| 2 | `server/src/store/mod.rs` | `derived_okf_hash` | re-serialised `to_vec(&root)` only when the summary changed; otherwise returned the caller's hash verbatim | struct (only on summary change) |
| 3 | `server/src/api.rs` | `create_commit` | `to_vec(&body.okf)` where `body.okf: Value` | **BTreeMap / alphabetical — the bug site** |
| 4 | `server/src/api.rs` | `commit_core` | `put_blob(input.bytes)` — stored the caller's bytes verbatim | caller-defined |
| 5 | `server/src/ui/edit.rs` | `perform_edit` | `to_vec(&candidate)` | struct |
| 6 | `server/src/ui/create.rs` | `create_model` / `create_element` | `to_vec(&root)` / `to_vec(&candidate)` | struct |
| 7 | `server/src/proposal_api.rs` | `accept_proposal` core | `to_vec(&candidate)` | struct |
| 8 | `server/src/binding_api.rs` | `import_core` | `to_vec(&root)` (fed to the round-trip harness, then committed) | struct |
| 9 | `server/src/merge_api.rs` | `merge_branches` core | `to_vec(&merged)` (no summary derivation) | struct |
| 10 | `cli/src/offline.rs` | `run` (Commit arm) | `put_blob(&bytes)` where `bytes` = **raw file bytes** | **file-defined — bug site** |
| 11 | `cli/src/offline.rs` | `merge` | `to_vec(&merged)` | struct |
| 12 | `engine/gate/src/lib.rs` | `run` | `canonical_hash(reference/candidate)` into evidence | (via #1) |
| 13 | `engine/analytics/src/compliance.rs` | `portfolio_report` | `canonical_hash(model)` | (via #1) |

(`server/src/store/mod.rs::commit_hash` hashes the commit METADATA payload — project, branch,
parents, okfHash, author, message — never the document bytes, so it is out of scope.)

## Canonical design
ONE serializer, `okf::hash::canonical_bytes(root) -> Vec<u8>`: it clones the typed
`OkfRoot`, re-derives the summary with `okf::summary::recompute`, and serialises with
`serde_json::to_vec`. Because `OkfRoot`/`Summary` are typed structs, the field order is
fixed by the type definitions (struct order), so the bytes are a pure function of content — the
summary is DERIVED, never trusted, and no caller's map/JSON order can influence them.
`canonical_hash` is sha256 over these bytes.

Every writer now produces its blob through this one function, at the convergence points:
- `commit_core` (server): stores `canonical_bytes(candidate)` — it no longer takes a
  caller-provided `bytes` field at all, so HTTP, edit, create, proposal and import all
  converge on canonical bytes.
- `store::derived_okf_hash` (store): now ALWAYS canonicalises (re-derive + struct order) and
  re-stores when the stored blob differs — not only when the summary changes — so a non-model
  blob is untouched, but any caller-ordered OKF blob is normalised at the final commit gate.
- `cli/src/offline.rs` commit + merge and `server/src/merge_api.rs`: use
  `canonical_bytes` directly.

This keeps the earlier write-path convergence intact (commit_model / commit_accepted /
commit_merge all still land in `derived_okf_hash`), the migration rules, the gate, and the
round-trip proofs untouched.

## Cross-path proof
Test: `cli/tests/cli.rs::the_same_document_commits_to_one_hash_through_every_path` — one
document committed through the store commit, the capture/replay HTTP path, the offline CLI, and
a lossless XMI binding round trip, asserting identical okf_hash.

- RED (before the fix): store commit and binding round trip produced the canonical
  `d8792b8639f79f4211f5d27143fa429fb2b937bd90c5bbb14b64dcae146d3201`, while the
  capture/replay HTTP path drifted to
  `99f5449a03a57ed65fc57afdf3c06629499e5a8d61ae607becba765f56215bbd` (BTreeMap order).
  The test failed on the HTTP assertion.
- GREEN (after the fix): all four paths produce
  `d8792b8639f79f4211f5d27143fa429fb2b937bd90c5bbb14b64dcae146d3201`.

## Changed hashes
- Expected corpus fixture `referenceHash`/`candidateHash`: UNCHANGED
  (`a86cc4faece3fd935120f2b51778e7f3611eca77cc673f69ceef0fc6444dcf7b`) — its summary was
  already correct, so re-derivation is a no-op.
- Corrupted corpus fixture `candidateHash` in
  `docs/evidence/2026-09-17-roundtrip-corrupted-fail.json`: changed
  `9c9bbac605691b059627c9b6309763328878f9dc174d11adf85dc3df8cc305c2` →
  `352ffaed1c6a7b5aa6e1be379ae69355c135fb1afe76195ffdabb61b755a7479`. Why: the corrupted
  fixture's summary is stale (claims 25 requirements / 165 edges, actually has 24 / 162), and
  `canonical_hash` now re-derives the summary — the hash is now a function of content alone,
  so the stale summary is caught rather than silently ignored.
- `gateVersion` in both regenerated evidence records: `0.1.0` → `0.2.0` — a PRE-EXISTING
  drift from the earlier crate rerelease, not caused by this change; the records were
  regenerated with the documented `mw-gate` command so CI's byte-for-byte check passes.

## Concerns
1. The trial seed's capture/replay manifest on the idc-1 host holds `expectedHash` values
   captured from the pre-fix (BTreeMap-order) HTTP path. After this fix, a re-capture will
   produce struct-order hashes, so that host manifest must be re-captured when idc-1 is next
   redeployed — the other task owns that deployment. The repo's `docs/deploy/seed-trial.mjs`
   does NOT hardcode hashes (it re-derives them), so it is unaffected.
2. `docs/evidence/server-*.json` records still carry `gateVersion: "0.1.0"` and pre-fix
   hashes; they are append-only and NOT CI-enforced (only the two roundtrip records are), so
   they were left untouched.
3. The GET commit route re-serialises the stored blob through a `serde_json::Value`, so its
   response is alphabetically ordered, not canonical. This does not affect content addressing
   (the hash is over the canonical blob at commit time) — it is a read-side byte-order only.
4. CONCURRENT-EDIT COLLISION: while this task ran, another task was editing
   `server/src/binding_api.rs` (SysMLv2 viewer-binding support) plus
   `binding_registry.rs`, `ui/import.rs`, `server/Cargo.toml`, `Cargo.lock` and new
   `sysmlv2` fixtures. My first `git add` of `binding_api.rs` swept their in-progress
   `Option<FidelityOutcome>` viewer-handling edits into commit 9bc54ef. I amended to 6ea0913
   so my commit contains ONLY my two `binding_api.rs` changes (the I3 comment and removing the
   now-dead `bytes` field), then force-pushed. Their EARLIER viewer-handling edits remain
   recoverable from 9bc54ef (reflog); a later ~23-line batch they made after my first commit
   was overwritten by the `git checkout` I used to reconstruct the file and is NOT in git —
   the other task should re-apply that tail from its editor buffer. Their other files
   (`binding_registry.rs`, `ui/import.rs`, `Cargo.toml`, `Cargo.lock`, fixtures, the
   `sysmlv2_import` test) are left untouched and still uncommitted in the working tree.
