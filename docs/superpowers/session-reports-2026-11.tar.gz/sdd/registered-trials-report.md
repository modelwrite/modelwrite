# Registered trials — report

Status: DONE

Commit: `94953fc` — Registered trials: identity, sessions, rolling lifecycle, registration, pluggable mailer.

## One-line test summary

`cargo test --workspace --no-fail-fast` green (619 passed, 0 failed, 24 PostgreSQL tests ignored); `cargo fmt --all` clean; `cargo clippy --workspace --all-targets -- -D warnings` clean.

## The cross-trial refusal proof

`server/tests/registered.rs::user_as_session_cannot_read_user_bs_project_even_holding_the_id`:
register A and B, have B create a project called `secret` via `POST /projects`, then have A —
holding B's project id in hand — `GET /projects/secret/branches`. A's session resolves to A's own
per-trial SQLite database, which contains no such project, so A gets **404**, while B's session
gets **200**. A's `GET /projects` returns `[]`. The trial identity comes from the SESSION, never
from the request; the project id is looked up in the session's own trial database.

## The time-travel proof

`server/src/trial/lifecycle.rs` and `server/src/trial/mod.rs` tests, all clock-injected (no sleep):
- 13 days idle → still ACTIVE (writes allowed); 14 days idle → READ-ONLY.
- `write_refusal_for` at 14 days idle returns a refusal naming the trial's archive moment and how to restart.
- activity on day 13 refreshes the window, so the trial is still writable on day 27 (`the_rolling_window_refuses_writes_after_fourteen_days_and_recovers`).
- 21 days idle → `reap` archives: DB copied to the archive root, SHA-256 checksum recorded, live copy removed, account kept, and the old session is dead (`the_reaper_archives_a_trial_after_twenty_one_days_idle`).

## What the mailer console transport prints

`[mailer:console] to=<recipient> subject="Your Modelwrite login code" body="Your Modelwrite login code is <6-digit-code>. It expires in 10 minutes."`

(The file transport writes the same one-line record, one line per email, to `MW_MAILER_FILE`.)

## The ingress line needed for app.modelwrite.org

```yaml
- hostname: app.modelwrite.org
  service: http://localhost:3103
```

Run the registered tier as a second instance of the same binary: `MW_REGISTERED=yes`
`MW_TRIAL_DATA_ROOT=/opt/modelwrite/registered` `MW_BIND=0.0.0.0` (in-container), exposed on the host
at `127.0.0.1:3103` — mirroring the `trial.modelwrite.org -> localhost:3102` entry in
`/etc/cloudflared/hatch-config.yml`. DNS is NOT changed.

## Concerns / what remains blocked on credentials

1. **Real SMTP delivery** is one credential away, by design. The `Mailer` trait is the transport
   interface; only the console and file transports are wired today. A real SMTP transport
   implements the same trait behind `MW_MAILER=smtp` + a credential — no flow change.
2. **app.modelwrite.org DNS** is out of scope (Cloudflare DNS untouched); only the ingress line and
   the parameterised second-instance deployment are prepared here.
3. **The gate-evidence directory is shared** across trials in registered mode (evidence files are
   content-addressed and deterministic, but not per-trial isolated). Per-trial evidence isolation
   was not in the brief; flagged for the next tranche.
4. The brief's test list said "13 days idle → writes refused"; the spec (authoritative) sets the
   read-only boundary at 14 days. I implemented 14 days, and the test proves the day-13 → day-27
   refresh and the 21-day archive.

