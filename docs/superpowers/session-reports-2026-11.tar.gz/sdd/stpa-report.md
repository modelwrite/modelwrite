# STPA / STAMP completeness check — T1-T3 report

## Status
COMPLETE. T1 (vocabulary pack + worked fixtures), T2 (control-structure view) and T3 (the five
checks on one screen) are shipped, tested and committed. Full workspace suite is green.

## Commits
- `0b369b5` — "STPA/STAMP completeness check (T1-T3): vocabulary pack, control-structure view, five engine checks and screen" (branch `slice-2-repository`, 13 files, +2312/-3).

## One-line test summary
`cargo test --workspace --no-fail-fast` → 635 passed, 0 failed (was 628; +7 new tests), and
`cargo clippy --workspace --all-targets -- -D warnings` is clean.

## The five checks on both fixtures

### fire-suppression-defective.json (each check fires)
1. **Unanalysed control actions: 1** — `ca-discharge` carries 2 of 4 UCA types
   (`not-provided`, `provided`), missing `wrong-timing-or-order` and
   `stopped-too-soon-or-applied-too-long`.
2. **Control loops with no feedback: 1** — `controller` issues `ca-discharge` and receives no
   feedback path.
3. **Hazards with no constraints: 1** (`haz-1`); **constraints reaching no element: 1**
   (`sc-1`).
4. **UCAs with no LossScenario: 1** (`uca-p`; `uca-np` is explained).
5. **Trend across baselines: 1** commit on `main` (the fixture alone). In the two-commit test
   (defective → correct) the trend shows 2 points, 5 findings → 0 findings.

### fire-suppression-correct.json (silent)
1. Unanalysed control actions: **0**.
2. Control loops with no feedback: **0**.
3. Hazards with no constraints: **0**; constraints reaching no element: **0**.
4. UCAs with no LossScenario: **0**.
5. Trend: 0 findings at the tip.

## Concerns / what could not be verified
- The completeness screen was verified through the in-process router tests (HTML assertions) and
  the engine unit tests, not by a rendered browser screenshot; the SVG control view was verified
  to render the controller/process/feedback names, not pixel-checked.
- Check 5 is computed directly over a branch's commits (via `Store::commits_on` + per-commit
  `stpa_report`); there is no cached trend path in the analytics crate, so the page says so
  rather than implying a cache. This is the honest fallback the slice spec allows.
- The vocabulary uses NO new OKF edge kind: control actions/feedback are `signal` nodes and the
  loop is `triggers` edges; hazards→constraints is `dependency`/Mitigate, UCA/scenario links
  are `reference`. T2 therefore needs no engine edge-kind change.
- Engine 1.75 floor and server 1.88 are unchanged (no dependency or edition changes).
