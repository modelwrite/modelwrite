# Docs consistency report

## Status

Complete. Job B (generator + CI drift check) is built and wired; Job A's four
stale claims are corrected, each verified against the repository first.

## Commits

- `28cd152` — the work: `website/generate-docs.mjs`, the CI drift-check job,
  the generated sections in `README.md` and `docs/guide/{limits,faq,mcp-agents}.md`,
  and the four claim corrections. (A follow-up commit carries this report.)

## Test summary (one line)

Node generator runs clean and is idempotent (second run changes 0 files);
`examples.html`'s generated block is byte-identical to `generate-examples.mjs`
output; `ci.yml` parses as valid YAML; no Rust changed, so no cargo build/test
was run (Node-script exception).

## Generator sources of truth

- **crate licences** — root `Cargo.toml` `[workspace.package] license` plus each
  workspace member's `Cargo.toml` (`[package] name` + `license`/`license.workspace`).
- **binding list** — `engine/binding-xmi` and `engine/binding-sysmlv2`
  `src/lib.rs` (`BINDING_ID`, `BINDING_VERSION`, `Direction`, `description`) plus
  the server's binding registry `server/src/binding_registry.rs` (the workbench's
  actual import surface).
- **MCP tool list** — `docs/agents/mcp-tools.json` (`tools[].name/summary/inputSchema.required`).
- **metric definitions** — `spec/analytics/metric_definitions.json` (count; referenced,
  never duplicated).

## Drift-check proof

1. Introduced drift: hand-edited the generated crate-licence line
   `mw-okf | AGPL-3.0-or-later` to `Apache-2.0` and committed it.
2. Ran `node website/generate-docs.mjs` (regenerated it back to AGPL), then
   `git diff --exit-code -- README.md docs/guide/` -> **exit 1 (FAIL)**; the diff
   showed the regenerated line.
3. `git reset --mixed HEAD~1`, regenerated again (0 changes), `git diff
   --exit-code -- README.md docs/guide/` -> **exit 0 (PASS)**.

## Corrections (before -> after)

1. **faq.md binding list** — "The only binding today is sysml-v1-xmi@2.4" ->
   generated binding list (two bindings: `sysml-v1-xmi@2.4` read/write and
   `sysml-v2-textual@1.0` viewer) plus the workbench-import-surface note.
2. **README limits summary** — "an activity's link to a subsystem element is a
   role name, not a cross-model edge" -> "typed cross-model edges resolve per
   edge, but the global system-of-systems graph property is asserted rather than
   computed".
3. **website "two doors"** — "not serving yet" / "rolling out" -> both doors live:
   the registered trial is live and session-authenticated; email delivery is the
   one pending SMTP credential.
4. **Loss numbers** — "45,725" (index.html) vs "48,553" (examples.html) -> one
   wording everywhere: "48,553 blocking losses (45,725 unmappable + 2,828 lossy)".

## Already correct (changed nothing)

- `docs/guide/limits.md`'s "The global system-of-systems graph property is
  asserted, not computed" section already stated the S2 truth (typed cross-model
  edges resolve; allocatedTo still names the role); only the README summary was
  stale. Its wording was left unchanged.
- Crate licences were verified: all 13 workspace crates are AGPL-3.0-or-later
  (no per-crate override); the historical "importers/exporters Apache-2.0" claim
  had already been corrected before this task, and is now locked by the generator.

## Concerns

- The server's binding registry (workbench import surface) contains **only**
  `sysml-v1-xmi@2.4`: `binding-sysmlv2` exists as an engine crate but is not
  registered in `server/src/binding_registry.rs` (and `server/Cargo.toml` does not
  depend on it). Adding it is server/ scope, which this task must not touch, so the
  generated list states both truths instead.
- The pre-existing print-based generators (`website/generate-analytics.mjs`,
  `website/generate-examples.mjs`) are not wired into the new drift check, so their
  committed blocks in `index.html`/`examples.html` can still drift; examples.html
  was kept in sync and verified this round.
- `docs/agents/mcp-agent.md` (docs/agents/, out of scope) still carries hand-written
  tool tables; only `docs/guide/mcp-agents.md` was regenerated.
- `docs/guide/mcp-agents.md` had two stale counts beyond the four claims
  ("Thirteen tools" -> 26; "seven read tools" -> 20), fixed and folded into the
  generated list.
