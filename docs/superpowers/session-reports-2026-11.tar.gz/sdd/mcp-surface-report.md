# MCP surface: eight read-only triage tools

Status: DONE

## Commits

- a97470ded1b46d665d434bcc68d5df2d2f1e9101 — "Add eight read-only MCP repository tools for agent triage" (7 files, +897 / -31)

## Test summary

cargo test --workspace --no-fail-fast (CARGO_TARGET_DIR=target-tests): 77 suites, 556 passed, 0 failed. cargo fmt --all and cargo clippy --workspace --all-targets -- -D warnings both clean. No dependency changes, so the engine 1.75 floor is untouched.

## Tools added (all read-only; repo.propose stays the single write-shaped action)

| Tool | Required args | What it returns |
|------|---------------|-----------------|
| repo.references | project, hash | Typed subsystem references; with resolve, each reference's resolve state via the same /references/resolve route the UI and API use |
| repo.coverage | project, hash | Requirement coverage from the engine's graph::requirement_coverage (covered count + named uncovered) |
| repo.element | project, hash, id | One element by id: attributes plus its graph edges |
| repo.find | project, hash, query | Elements matching a name/id/stereotype fragment: id, name, kind, section |
| repo.lossSummary | project, artifactHash | The loss report aggregated by construct and verdict, with paging over the full list |
| repo.proposals | project | The project's proposals with decisions and who made them |
| repo.analytics | project, requirements | The portfolio answer from the project analytics route |
| repo.artifact | project, artifactHash | The retained original bytes of a migrated artifact, verbatim |

## Live proof (against the running server on 127.0.0.1:8080)

### repo.coverage on coffee-machine

15 requirements covered, 10 uncovered, uncovered names below (the engine's own requirement_coverage):

    {
      "allocated": 0,
      "covered": 15,
      "refined": 3,
      "satisfied": 20,
      "total": 25,
      "uncovered": [
        "_2026x_1_12a70364_1789522470201_737876_5617",
        "_2026x_1_12a70364_1789522470246_238622_5652",
        "_2026x_1_12a70364_1789522470268_212057_5663",
        "_2026x_1_12a70364_1789522470269_5755_5665",
        "_2026x_1_12a70364_1789522470270_589609_5667",
        "_2026x_1_12a70364_1789522470271_475286_5670",
        "_2026x_1_12a70364_1789522470272_63721_5673",
        "_2026x_1_12a70364_1789522470273_392927_5676",
        "_2026x_1_12a70364_1789522470274_644308_5679",
        "_2026x_1_12a70364_1789522470275_767711_5681"
      ],
      "verified": 1
    }

### repo.references with resolve on cafe-stand

All four resolve:

    {
      "commit": "18d24bcc4bf6d8ae566a279cef0e0bdd393a83322e372b8381eae4fad7699ebf",
      "project": "cafe-stand",
      "references": [
        { "project": "purchasing-terminal", "reason": null, "resolves": true, "revision": "86a14a8128ee2a02085a56bf83a2504f12774e25a0a1d28005daf1fe1e9ee1ea", "role": "payment" },
        { "project": "coffee-machine",      "reason": null, "resolves": true, "revision": "d427e847bf4d875d06fc7f2a5b47bb0a3dc53855a61850195c4ec78e7d45fc36", "role": "beverage" },
        { "project": "sandwich-toaster",    "reason": null, "resolves": true, "revision": "6cc2b58d6f827363d032965ead2d7ecc33e95dfdab1089f9586423959b3bf9ac", "role": "food" },
        { "project": "floor-robot",         "reason": null, "resolves": true, "revision": "9dcccb6d13fb0fd67b46af70d08a730491e5a7d32ae52f3a2f4d42e843f0d712", "role": "floor-care" }
      ],
      "resolves": true
    }

### repo.lossSummary on the coffee-machine-xmi import

274 entries flattened into 30 construct classes. Biggest loss classes by count:

    byVerdict: Lossy 128, Unmappable 124, Exact 22

    byConstruct (biggest first):
      uml:Property    count 102  (lossy 51, unmappable 51)
      uml:Association count 33   (lossy 28, unmappable 5)
      uml:Abstraction count 28   (lossy 28)
      uml:Port        count 14   (lossy 6, unmappable 8)
      uml:Package     count 13   (lossy 13)
      ... 25 more constructs ...

    page: { offset: 0, limit: 0, total: 274, entries: [] }
    total: 274

### repo.find for a name fragment, then repo.element

    repo.find(query="pump"):
      matches: [ { id: "_2026x_1_12a70364_1789363591862_529655_3736", kind: "block", name: "Water Pump", section: "structure" } ]

    repo.element(id=_2026x_1_12a70364_1789363591862_529655_3736):
      element: { id: "_2026x_1_12a70364_1789363591862_529655_3736", name: "Water Pump", kind: "block", stereotypes: ["Block"], attributes: [], documentation: "" }
      edges: [
        { kind: "association", label: "", source: Water Pump, target: Water Subsystem },
        { kind: "dependency", label: "Satisfy", source: Water Pump, target: req 1.8 },
        { kind: "part", label: "water Pump", source: Water Subsystem, target: Water Pump }
      ]

## Concerns

- The spec's motivating number (45,725 losses) is the Open-MBEE TMT vendor model, which is NOT loaded in this trial server. The trial server's coffee-machine-xmi import carries 274 entries; repo.lossSummary aggregates it correctly (30 construct classes) and the same code aggregates 45k entries unchanged. The "thousands of entries" wording in the acceptance is therefore demonstrated at 274, not at the TMT scale.
- repo.coverage returns the engine's CoverageReport verbatim, per ruling 2: the uncovered requirements are NAMED (ids), while covered is reported as a count plus total, so the covered set is the complement. No second coverage implementation was added.
- The analyses tool named in the review's gap table is deliberately NOT added: it is the in-flight analyses slice and is not among the eight tools the spec's WHAT-TO-ADD section lists.

## Deliberately not added

- No write capability: repo.propose remains the only POST; the wire-level test still proves GET-only plus the single proposal POST, now across all 17 repository tools.
- No analyses tool (in-flight elsewhere; not in the eight).
- No new dependencies, so the engine 1.75 floor is unchanged.
