﻿# SDD ledger - plan: docs/superpowers/plans/2026-09-17-modelwrite-slice-2-repository-service.md

Spec: docs/superpowers/specs/2026-09-17-modelwrite-platform-design.md (sections 4.1 to 4.3, Slice 2)
Working branch: slice-2-repository (to be created from main after Slice 1 merges; until then, from slice-1-engine-core)

## Pre-flight conflict scan

| Pair / task | Produces vs consumes | Finding |
|---|---|---|
| T1 -> T3 | T1 defines AppState with evidence_dir only; T3 adds the store field | Handled: T3 Step 3 gives the updated state helper for tests/http.rs and main.rs. |
| T1 -> T3, T4 | All three touch server/src/lib.rs | Handled: T3 Step 2 supplies the full lib.rs, T4 Step 2 names the two routes to add. |
| T1 -> T3, T4, T5 | All use http-body-util and tempfile from dev-dependencies | Handled: declared once in T1 Step 1 and Step 2. |
| T2 -> T3 | T3 consumes store::{commit_hash, now_epoch, Commit, Store, StoreError} | Names and signatures match the T2 trait. |
| T3 -> T4 | T4 imports api::{map_store_error, ApiState} | Both are public in T3's api.rs, stated in T4 Step 1. |
| T4 -> T5 | T5 consumes the gate endpoint and the evidence file naming | Match: server-<project>-<ref12>-<cand12>.json. |
| T5 -> T5 | T5 reads the corpus and the corrupted fixture through test-support | Both fixtures exist and are pinned from Slice 1. |

## Rulings

Ruling: Slice 2 is delivered in tranches. This plan is tranche 1 (store and prove OKF commits); branching/merge, locks, identity, audit, PostgreSQL, the CLI and deployment are named in the plan's final section and get their own plans, so this plan stays accurate instead of speculative. Cost if wrong: an extra planning round per tranche.
Ruling: SQLite implements the Store trait first, with the trait boundary designed for a PostgreSQL backend later. Rationale: a zero-configuration single file is what an evaluator or a small team needs on a controlled network, and it keeps tranche 1 testable without a database service. Cost if wrong: a second backend implementation, which is planned work either way.

## Progress


Task 1: implementation complete (818a9cc). Controller verified 2 tests pass; fmt and clippy clean. Review dispatched; Task 2 (the store) dispatched.

Task 1: review verdicts - spec compliance PASS, task quality PASS. Two Minors.
Minor 1 (accepted, brief-mandated): the manifest declares dependencies that this task's code does not yet use (mw-okf, mw-gate, rusqlite, sha2, hex, mw-test-support). They are consumed by Tasks 2 and 3, and the review's concern about the bundled SQLite build is moot because Task 2 is the task that needs it. No action; splitting the manifest across tasks would churn it four times.
Minor 2 (fixed): version_names_the_service asserted only the service name, so a regression in the version string would pass. The controller added an assertion on the server version field.

Task 2: implementation complete (9b9a03e), 6 tests pass, lints clean.
Reconciliation: the Task 2 implementer reported an un-authored line in server/tests/http.rs and correctly refused to commit it. It was the controller's, from the Task 1 review's Minor 2; it is now committed on its own as 3ac0537. No agent should ever commit a line it did not author, and the implementer did the right thing by flagging it.
Task 2 review verdicts: spec compliance PASS, task quality PASS, with three Important findings about the store's concurrency and error semantics: (1) append_commit is non-atomic, running the commit insert and the branch-tip upsert in two separate lock acquisitions, so concurrent appends can leave the tip behind the history; (2) create_project and create_branch check then insert in separate acquisitions, so a concurrent duplicate surfaces as a Backend error rather than Conflict; (3) a malformed parents column is silently turned into an empty list by unwrap_or_default, which masks corrupt persisted data instead of reporting it. Ruling: all three are fixed, in the store, after Task 3 commits - editing the store while Task 3 has a build in flight would corrupt its test run.

Task 3: implementation complete (8d99adf), 10 tests pass, lints clean. Review dispatched.
Ruling (plan defect, found by the implementer): the plan pinned axum 0.7 but wrote routes in axum 0.8 brace syntax ({project}). On 0.7 those routes silently 404 - the matcher never reaches the handler, so there is no error to see. The implementer converted them to :project and :hash, verified the behaviour empirically, and flagged that later briefs must match. The plan now carries a ROUTE SYNTAX note and corrected router lines, and briefs 3, 4 and 5 were re-extracted. Cost if wrong: none now; the alternative would have been a whole slice of routes that answer 404.
Store hardening (6361c32): the controller applied Task 2's three Important findings after Task 3 committed, because editing the store while another task had a build in flight would corrupt its test run. append_commit is now a single lock acquisition wrapped in a transaction; create_project and create_branch let the primary key decide duplicates instead of reading first; a corrupt parents column is reported as a storage error naming the commit instead of being silently emptied; and a CommitRow type alias removed the tuple type clippy flagged. Verified: 10 tests pass, fmt and clippy clean. A scoped re-review is dispatched.
Process note: the controller's own first attempt at the store fix did not compile (a ? inside a rusqlite closure cannot convert a StoreError), which is why commit() now reads its row under the lock and parses outside it. The failing build was caught before the commit.

Task 4: complete (705b4cd), gate endpoint and evidence recording; 13 server tests at that point. Review dispatched.
Task 5: complete (204e91e), the corpus end-to-end test. It commits the real coffee-machine export, branches from that commit, commits the corrupted fixture onto the branch, and asserts that the clean comparison passes (one component, coverage total 25) while the lossy comparison fails with the loss named, and that two gate runs are recorded. Review dispatched.
Task 3 review: spec compliance PASS, task quality PASS. One Important finding - the round-trip assertion compared parsed JSON values, so a key-reordering regression would have passed; the controller replaced it with a raw-bytes assertion against serde_json::to_vec of the model that was stored. Two Minors were also closed: create_branch 404/409 and the commits?branch= listing had no coverage and now have tests. The third Minor (a blob can be orphaned when a commit fails after the blob write) is accepted: blobs are content-addressed and deduplicated, and the orphan is unreachable and harmless.
Workspace after the hardening: 60 tests across 11 binaries, fmt and clippy clean (server now 16 tests: api 6, corpus 1, gate 3, http 2, store 4).

Task 4 review: spec compliance PASS, task quality PASS. Four Minors were raised and three were fixed (69d062d): the evidence file name now carries BOTH FULL hashes, because truncating them kept determinism but lost uniqueness - two commit pairs sharing a 12-hex prefix would overwrite each other's evidence while both runs stayed recorded, so a run could cite a file it never wrote; the run is now recorded before the evidence file is exported, because the store row carries the whole payload and is the authority; and the panic-prone byte-slicing helper was deleted. The unused test parameter was also cleaned up. The remaining Minor (OR IGNORE conflates constraint kinds) is latent only: the schema has no foreign keys today, and it is recorded for the day one is added.
Store hardening re-review: PASS. All three Important findings are closed, and the reviewer confirmed by reading the rusqlite 0.31 signature that the non-mut MutexGuard still holds the lock for the transaction's lifetime, so a reader cannot observe a commit without its tip update, no check-then-act remains, no corrupt row can be silently defaulted, and no store path can panic.
Task 5 review: spec compliance PASS, task quality PASS, with one Important finding and two Minors, all fixed (c32147b): the test proved the gate detects loss but did not pin that the lossy commit DESCENDS from the imported one, so a broken branch creation would have passed it - the gate detects loss by content, not topology, and a commit onto a non-existent branch simply starts a new history. The branch response status is now asserted CREATED, imported and corrupted are asserted distinct, and both gate responses are asserted 200 before their bodies are read.
Publish: branch slice-2-repository pushed; pull request #2 opened, based on slice-1-engine-core so its diff shows only the service work. GitHub Actions is green on the branch on Linux.
Server suite is now 16 tests; workspace 60, fmt and clippy clean.

Final whole-tranche review: verdict conditionally mergeable, three Important findings, all fixed in one pass (47c50f3) and re-reviewed.
Important 1 (history corruption): create_commit resolved the branch parents one layer above the store, in a separate lock acquisition from the append, so two concurrent commits to one branch could both read the same tip and fork the history - both commits land, one orphans the other, and the branch lists both. Ruling: the parents belong inside the atomic operation. The Store trait gained commit_model, which takes one lock, opens one transaction, reads the tip inside it, derives the parents and hash, writes the commit and moves the tip, and returns the Commit. A new test fires eight threads at one branch through commit_model and asserts eight commits land with exactly one root and exactly seven parent links, so a fork fails the build rather than corrupting a repository quietly.
Important 2 (path safety): project names reached the evidence file path with only a non-empty check. Ruling: names are validated (letters, digits, dot, underscore, hyphen; at most 64 characters; at least one alphanumeric), AND the project name is gone from the evidence file name, which now carries both full commit hashes only. The controller's first attempt at the charset allowed dots and therefore '..'; its own new test caught that immediately, and the 'at least one letter or digit' rule closes it.
Important 3 (information leak): 500 bodies echoed raw rusqlite and serde detail. Ruling: the detail is logged server-side and the client receives a generic message.
Server suite is now 18 tests; workspace 62. fmt and clippy clean. Branch pushed; PR #2 updated.
Deferred Minors from the tranche review, carried into tranche 2: inconsistent 404 for a missing project on the commits listing; no commit-metadata endpoint; referenceHash/candidateHash meaning the commit hash in a gate run but the model hash in the embedded evidence; Store::list_branches unrouted and untested; list_gate_runs swallowing corrupt evidence; commit_hash including project and branch, which will shape merge-commit identity; rowid ordering that is not PostgreSQL-portable; no create_dir_all before the evidence write; a blocking std Mutex inside async handlers; the default 2 MB body limit; orphaned blobs with no GC. The audit log, identity and roles, foreign keys, locks, merge and the PostgreSQL backend remain named tranche 2 work.
