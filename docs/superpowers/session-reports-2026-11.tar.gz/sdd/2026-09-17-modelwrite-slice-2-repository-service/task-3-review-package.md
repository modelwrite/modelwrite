﻿# Slice 2 Task 3 review package

## Commit

8d99adf feat: add the project and commit API

## Diff stat

 server/src/api.rs    | 199 +++++++++++++++++++++++++++++++++++++++++++++++++++
 server/src/lib.rs    |  34 +++++++--
 server/src/main.rs   |  15 +++-
 server/tests/api.rs  | 162 +++++++++++++++++++++++++++++++++++++++++
 server/tests/http.rs |   2 +
 5 files changed, 403 insertions(+), 9 deletions(-)

## Full diff (-U10)

diff --git a/server/src/api.rs b/server/src/api.rs
new file mode 100644
index 0000000..d424535
--- /dev/null
+++ b/server/src/api.rs
@@ -0,0 +1,199 @@
+// SPDX-License-Identifier: AGPL-3.0-or-later
+use std::sync::Arc;
+
+use axum::extract::{Path, Query, State};
+use axum::http::StatusCode;
+use axum::Json;
+use serde::Deserialize;
+use serde_json::{json, Value};
+
+use crate::error::ApiError;
+use crate::store::{commit_hash, now_epoch, Commit, Store, StoreError};
+
+#[derive(Clone)]
+pub struct ApiState {
+    pub store: Arc<dyn Store>,
+    pub evidence_dir: std::path::PathBuf,
+}
+
+pub fn map_store_error(e: StoreError) -> ApiError {
+    match e {
+        StoreError::NotFound(m) => ApiError::not_found(m),
+        StoreError::Conflict(m) => ApiError::conflict(m),
+        StoreError::Backend(m) => ApiError::internal(m),
+    }
+}
+
+fn commit_json(commit: &Commit) -> Value {
+    json!({
+        "hash": commit.hash,
+        "project": commit.project,
+        "branch": commit.branch,
+        "parents": commit.parents,
+        "okfHash": commit.okf_hash,
+        "author": commit.author,
+        "message": commit.message,
+        "createdAt": commit.created_at
+    })
+}
+
+#[derive(Deserialize)]
+pub struct CreateProject {
+    pub name: String,
+}
+
+pub async fn create_project(
+    State(state): State<ApiState>,
+    Json(body): Json<CreateProject>,
+) -> Result<(StatusCode, Json<Value>), ApiError> {
+    if body.name.trim().is_empty() {
+        return Err(ApiError::bad_request("project name must not be empty"));
+    }
+    let project = state
+        .store
+        .create_project(&body.name)
+        .map_err(map_store_error)?;
+    Ok((
+        StatusCode::CREATED,
+        Json(json!({ "name": project.name, "createdAt": project.created_at })),
+    ))
+}
+
+pub async fn list_projects(State(state): State<ApiState>) -> Result<Json<Value>, ApiError> {
+    let projects = state.store.list_projects().map_err(map_store_error)?;
+    let out: Vec<Value> = projects
+        .iter()
+        .map(|p| json!({ "name": p.name, "createdAt": p.created_at }))
+        .collect();
+    Ok(Json(Value::Array(out)))
+}
+
+#[derive(Deserialize)]
+pub struct CreateCommit {
+    pub branch: String,
+    pub author: String,
+    pub message: String,
+    pub okf: Value,
+}
+
+pub async fn create_commit(
+    State(state): State<ApiState>,
+    Path(project): Path<String>,
+    Json(body): Json<CreateCommit>,
+) -> Result<(StatusCode, Json<Value>), ApiError> {
+    if state
+        .store
+        .project(&project)
+        .map_err(map_store_error)?
+        .is_none()
+    {
+        return Err(ApiError::not_found(format!("project {}", project)));
+    }
+    if body.branch.trim().is_empty() {
+        return Err(ApiError::bad_request("branch must not be empty"));
+    }
+
+    // The document must be a valid OKF model before it is stored: a repository that
+    // accepts invalid models cannot be gated meaningfully.
+    let bytes = serde_json::to_vec(&body.okf).map_err(|e| ApiError::bad_request(e.to_string()))?;
+    let root: okf::types::OkfRoot = serde_json::from_slice(&bytes)
+        .map_err(|e| ApiError::bad_request(format!("not an OKF document: {}", e)))?;
+    let report = okf::validate::validate(&root);
+    if !report.valid {
+        return Err(ApiError::unprocessable(
+            "the model failed validation",
+            report.errors,
+        ));
+    }
+
+    let okf_hash = state.store.put_blob(&bytes).map_err(map_store_error)?;
+    let parents: Vec<String> = state
+        .store
+        .branch_tip(&project, &body.branch)
+        .map_err(map_store_error)?
+        .into_iter()
+        .collect();
+    let hash = commit_hash(
+        &project,
+        &body.branch,
+        &parents,
+        &okf_hash,
+        &body.author,
+        &body.message,
+    );
+    let commit = Commit {
+        hash: hash.clone(),
+        project: project.clone(),
+        branch: body.branch.clone(),
+        parents: parents.clone(),
+        okf_hash,
+        author: body.author,
+        message: body.message,
+        created_at: now_epoch(),
+    };
+    state
+        .store
+        .append_commit(&commit)
+        .map_err(map_store_error)?;
+    Ok((StatusCode::CREATED, Json(commit_json(&commit))))
+}
+
+#[derive(Deserialize)]
+pub struct BranchQuery {
+    pub branch: Option<String>,
+}
+
+pub async fn list_commits(
+    State(state): State<ApiState>,
+    Path(project): Path<String>,
+    Query(query): Query<BranchQuery>,
+) -> Result<Json<Value>, ApiError> {
+    let branch = query.branch.unwrap_or_else(|| "main".to_string());
+    let commits = state
+        .store
+        .commits_on(&project, &branch)
+        .map_err(map_store_error)?;
+    Ok(Json(Value::Array(
+        commits.iter().map(commit_json).collect(),
+    )))
+}
+
+pub async fn get_commit(
+    State(state): State<ApiState>,
+    Path((project, hash)): Path<(String, String)>,
+) -> Result<Json<Value>, ApiError> {
+    let commit = state
+        .store
+        .commit(&project, &hash)
+        .map_err(map_store_error)?
+        .ok_or_else(|| ApiError::not_found(format!("commit {}", hash)))?;
+    let bytes = state
+        .store
+        .blob(&commit.okf_hash)
+        .map_err(map_store_error)?
+        .ok_or_else(|| ApiError::internal(format!("missing blob {}", commit.okf_hash)))?;
+    let value: Value =
+        serde_json::from_slice(&bytes).map_err(|e| ApiError::internal(e.to_string()))?;
+    Ok(Json(value))
+}
+
+#[derive(Deserialize)]
+pub struct CreateBranch {
+    pub name: String,
+    pub from: String,
+}
+
+pub async fn create_branch(
+    State(state): State<ApiState>,
+    Path(project): Path<String>,
+    Json(body): Json<CreateBranch>,
+) -> Result<(StatusCode, Json<Value>), ApiError> {
+    state
+        .store
+        .create_branch(&project, &body.name, &body.from)
+        .map_err(map_store_error)?;
+    Ok((
+        StatusCode::CREATED,
+        Json(json!({ "name": body.name, "tip": body.from })),
+    ))
+}
diff --git a/server/src/lib.rs b/server/src/lib.rs
index ea8b28b..9a05879 100644
--- a/server/src/lib.rs
+++ b/server/src/lib.rs
@@ -1,34 +1,54 @@
 // SPDX-License-Identifier: AGPL-3.0-or-later
+pub mod api;
 pub mod error;
 pub mod store;
 
-use std::path::PathBuf;
+pub use error::ApiError;
+
 use std::sync::Arc;
 
-use axum::routing::get;
+use axum::routing::{get, post};
 use axum::{Json, Router};
 use serde_json::json;
 
-pub use error::ApiError;
-
 #[derive(Clone)]
 pub struct AppState {
-    pub evidence_dir: PathBuf,
+    pub store: Arc<dyn store::Store>,
+    pub evidence_dir: std::path::PathBuf,
+}
+
+impl AppState {
+    fn api(&self) -> api::ApiState {
+        api::ApiState {
+            store: self.store.clone(),
+            evidence_dir: self.evidence_dir.clone(),
+        }
+    }
 }
 
-/// The whole HTTP surface as a router, so tests drive it in-process and never bind a port.
 pub fn app(state: AppState) -> Router {
+    let api_state = state.api();
     Router::new()
         .route("/health", get(health))
         .route("/version", get(version))
-        .with_state(Arc::new(state))
+        .route(
+            "/projects",
+            post(api::create_project).get(api::list_projects),
+        )
+        .route(
+            "/projects/:project/commits",
+            post(api::create_commit).get(api::list_commits),
+        )
+        .route("/projects/:project/commits/:hash", get(api::get_commit))
+        .route("/projects/:project/branches", post(api::create_branch))
+        .with_state(api_state)
 }
 
 async fn health() -> Json<serde_json::Value> {
     Json(json!({ "status": "ok" }))
 }
 
 async fn version() -> Json<serde_json::Value> {
     Json(json!({
         "server": env!("CARGO_PKG_VERSION"),
         "service": "mw-server"
diff --git a/server/src/main.rs b/server/src/main.rs
index f4a6d17..facc9f4 100644
--- a/server/src/main.rs
+++ b/server/src/main.rs
@@ -1,22 +1,33 @@
 // SPDX-License-Identifier: AGPL-3.0-or-later
 use std::net::SocketAddr;
 use std::path::PathBuf;
+use std::sync::Arc;
 
+use server::store::sqlite::SqliteStore;
 use server::{app, AppState};
 
 #[tokio::main]
 async fn main() -> anyhow::Result<()> {
     let port: u16 = std::env::var("MW_PORT")
         .ok()
         .and_then(|p| p.parse().ok())
         .unwrap_or(8080);
+    let db_path = std::env::var("MW_DB").unwrap_or_else(|_| "modelwrite.db".to_string());
     let evidence_dir = std::env::var("MW_EVIDENCE_DIR")
         .map(PathBuf::from)
         .unwrap_or_else(|_| PathBuf::from("docs/evidence"));
 
+    let store = Arc::new(SqliteStore::open(std::path::Path::new(&db_path))?);
     let addr = SocketAddr::from(([127, 0, 0, 1], port));
     let listener = tokio::net::TcpListener::bind(addr).await?;
-    println!("mw-server listening on http://{}", addr);
-    axum::serve(listener, app(AppState { evidence_dir })).await?;
+    println!("mw-server listening on http://{} (db {})", addr, db_path);
+    axum::serve(
+        listener,
+        app(AppState {
+            store,
+            evidence_dir,
+        }),
+    )
+    .await?;
     Ok(())
 }
diff --git a/server/tests/api.rs b/server/tests/api.rs
new file mode 100644
index 0000000..d659a4c
--- /dev/null
+++ b/server/tests/api.rs
@@ -0,0 +1,162 @@
+// SPDX-License-Identifier: AGPL-3.0-or-later
+use axum::body::Body;
+use axum::http::{Request, StatusCode};
+use http_body_util::BodyExt;
+use tower::ServiceExt;
+
+fn state(dir: &std::path::Path) -> server::AppState {
+    let store = server::store::sqlite::SqliteStore::open(&dir.join("mw.db")).unwrap();
+    server::AppState {
+        store: std::sync::Arc::new(store),
+        evidence_dir: dir.to_path_buf(),
+    }
+}
+
+fn post(uri: &str, body: serde_json::Value) -> Request<Body> {
+    Request::builder()
+        .method("POST")
+        .uri(uri)
+        .header("content-type", "application/json")
+        .body(Body::from(body.to_string()))
+        .unwrap()
+}
+
+async fn json_body(response: axum::response::Response) -> serde_json::Value {
+    let bytes = response.into_body().collect().await.unwrap().to_bytes();
+    serde_json::from_slice(&bytes).unwrap()
+}
+
+fn tiny_okf() -> serde_json::Value {
+    serde_json::json!({
+        "project": "tiny",
+        "exportedAt": "2026-09-17T00:00:00Z",
+        "summary": {},
+        "stateMachine": { "name": "tiny sm", "regions": [] },
+        "graph": { "nodes": [{ "id": "b1", "kind": "block", "name": "B1" }], "edges": [] }
+    })
+}
+
+#[tokio::test]
+async fn a_project_can_be_created_listed_and_is_not_duplicated() {
+    let dir = tempfile::tempdir().unwrap();
+    let router = server::app(state(dir.path()));
+
+    let created = router
+        .clone()
+        .oneshot(post("/projects", serde_json::json!({ "name": "coffee" })))
+        .await
+        .unwrap();
+    assert_eq!(created.status(), StatusCode::CREATED);
+
+    let duplicate = router
+        .clone()
+        .oneshot(post("/projects", serde_json::json!({ "name": "coffee" })))
+        .await
+        .unwrap();
+    assert_eq!(duplicate.status(), StatusCode::CONFLICT);
+
+    let listed = router
+        .oneshot(
+            Request::builder()
+                .uri("/projects")
+                .body(Body::empty())
+                .unwrap(),
+        )
+        .await
+        .unwrap();
+    let value = json_body(listed).await;
+    assert_eq!(value[0]["name"], "coffee");
+}
+
+#[tokio::test]
+async fn a_commit_stores_the_model_and_moves_the_branch() {
+    let dir = tempfile::tempdir().unwrap();
+    let router = server::app(state(dir.path()));
+    router
+        .clone()
+        .oneshot(post("/projects", serde_json::json!({ "name": "coffee" })))
+        .await
+        .unwrap();
+
+    let committed = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/commits",
+            serde_json::json!({
+                "branch": "main",
+                "author": "alex",
+                "message": "import the model",
+                "okf": tiny_okf()
+            }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(committed.status(), StatusCode::CREATED);
+    let commit = json_body(committed).await;
+    assert!(commit["hash"].as_str().unwrap().len() == 64);
+    assert!(commit["parents"].as_array().unwrap().is_empty());
+
+    let hash = commit["hash"].as_str().unwrap().to_string();
+    let fetched = router
+        .oneshot(
+            Request::builder()
+                .uri(format!("/projects/coffee/commits/{}", hash))
+                .body(Body::empty())
+                .unwrap(),
+        )
+        .await
+        .unwrap();
+    assert_eq!(fetched.status(), StatusCode::OK);
+    assert_eq!(json_body(fetched).await, tiny_okf());
+}
+
+#[tokio::test]
+async fn an_invalid_model_is_rejected_with_its_errors() {
+    let dir = tempfile::tempdir().unwrap();
+    let router = server::app(state(dir.path()));
+    router
+        .clone()
+        .oneshot(post("/projects", serde_json::json!({ "name": "coffee" })))
+        .await
+        .unwrap();
+
+    let mut okf = tiny_okf();
+    okf["graph"] = serde_json::Value::Null;
+    let rejected = router
+        .oneshot(post(
+            "/projects/coffee/commits",
+            serde_json::json!({
+                "branch": "main",
+                "author": "alex",
+                "message": "broken",
+                "okf": okf
+            }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(rejected.status(), StatusCode::UNPROCESSABLE_ENTITY);
+    let body = json_body(rejected).await;
+    assert!(body["error"]
+        .as_str()
+        .unwrap()
+        .contains("graph section is missing"));
+}
+
+#[tokio::test]
+async fn committing_an_unknown_project_is_not_found() {
+    let dir = tempfile::tempdir().unwrap();
+    let router = server::app(state(dir.path()));
+    let response = router
+        .oneshot(post(
+            "/projects/missing/commits",
+            serde_json::json!({
+                "branch": "main",
+                "author": "alex",
+                "message": "nothing",
+                "okf": tiny_okf()
+            }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(response.status(), StatusCode::NOT_FOUND);
+}
diff --git a/server/tests/http.rs b/server/tests/http.rs
index d3ebfd1..4e697e4 100644
--- a/server/tests/http.rs
+++ b/server/tests/http.rs
@@ -1,18 +1,20 @@
 // SPDX-License-Identifier: AGPL-3.0-or-later
 use axum::body::Body;
 use axum::http::{Request, StatusCode};
 use http_body_util::BodyExt;
 use tower::ServiceExt;
 
 fn state(dir: &std::path::Path) -> server::AppState {
+    let store = server::store::sqlite::SqliteStore::open(&dir.join("mw.db")).unwrap();
     server::AppState {
+        store: std::sync::Arc::new(store),
         evidence_dir: dir.to_path_buf(),
     }
 }
 
 #[tokio::test]
 async fn health_answers_ok() {
     let dir = tempfile::tempdir().unwrap();
     let router = server::app(state(dir.path()));
     let response = router
         .oneshot(
