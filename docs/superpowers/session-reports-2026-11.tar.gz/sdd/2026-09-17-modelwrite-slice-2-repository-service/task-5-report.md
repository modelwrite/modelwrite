# Task 5 Report: The corpus end-to-end test

## Status

DONE

## Commits

- 204e91eb288e7d9be24752f36913b4013e76d7a8 — test: prove the corpus can be committed, branched and gated through the service

## Test summary

cargo test --workspace --no-fail-fast: 58 passed, 0 failed
(okf 15 — diff 8, validation 7; gate 5; graph 7; mcp 13; capi 4; server 14 — api 4, corpus 1, gate_api 3, http 2, store 4).
The engine's 44 all still pass; the server's 14 all pass, including the new corpus test.

## Concerns

None.

## Deviations

None. server/tests/corpus.rs is the brief's listing verbatim; it passes as written, confirming the corpus
behaves exactly as predicted. The clean comparison passes with integration.componentCount == 1 and
coverage.total == 25, the lossy comparison fails with "missing elements" and "isolated" in the failures list,
and two gate runs are recorded.

## Verification

- SPDX header present at the top of server/tests/corpus.rs.
- The test drives the real coffee-machine corpus via test_support::{load_okf_expected, load_okf_broken},
  not a hand-built model: the expected fixture commits on main, the corrupted fixture commits on a new
  "corrupted" branch, and both are gated.
- Asserts BOTH the clean pass (passed == true, componentCount == 1, coverage.total == 25) and the lossy
  failure (passed == false, failures containing "missing elements" and "isolated").
- Asserts the recorded runs: GET /projects/coffee/gate-runs returns exactly 2 runs.
- The corrupted fixture is a valid OKF document that has LOST content, so it commits successfully and fails
  the GATE, not validation — the lossy-migration distinction the task specifies.
- cargo test -p mw-server --no-fail-fast: 14 passed, 0 failed.
- cargo test --workspace --no-fail-fast: 58 passed, 0 failed.
- cargo fmt --all: clean. cargo clippy --workspace --all-targets -- -D warnings: clean (exit 0).
- Staged only server/tests/corpus.rs; Cargo.toml and Cargo.lock were unchanged, and .superpowers/ was left
  untracked.
