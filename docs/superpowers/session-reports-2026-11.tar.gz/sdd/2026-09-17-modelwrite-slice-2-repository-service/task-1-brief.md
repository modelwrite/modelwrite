﻿### Task 1: The service skeleton

**Files:**
- Create: server/Cargo.toml
- Create: server/src/lib.rs
- Create: server/src/main.rs
- Create: server/src/error.rs
- Test: server/tests/http.rs
- Modify: Cargo.toml (workspace members and shared dependencies)

**Interfaces:**
- Consumes: nothing.
- Produces:
  - server::app(state: AppState) -> axum::Router - the whole HTTP surface as a router, so tests can drive it in-process.
  - server::AppState { pub store: std::sync::Arc<dyn Store>, pub evidence_dir: std::path::PathBuf } (Store arrives in Task 2; in this task AppState carries only evidence_dir and the router serves the two static routes).
  - server::error::ApiError with ApiError::bad_request(msg) -> (StatusCode, Json<Value>) style responses.
  - Binary mw-server, listening on 127.0.0.1:8080 by default, overridable with MW_PORT.

- [ ] **Step 1: Add the workspace dependencies and member**

In the root Cargo.toml, extend members with "server", and add to [workspace.dependencies]:

```toml
axum = "0.7"
tokio = { version = "1", features = ["rt-multi-thread", "macros", "net"] }
rusqlite = { version = "0.31", features = ["bundled"] }
tower = { version = "0.4", features = ["util"] }
http-body-util = "0.1"
tempfile = "3"
```

- [ ] **Step 2: Write server/Cargo.toml**

```toml
[package]
name = "mw-server"
version = "0.1.0"
edition.workspace = true
rust-version.workspace = true
license.workspace = true
publish = false

[lib]
name = "server"

[[bin]]
name = "mw-server"
path = "src/main.rs"

[dependencies]
mw-okf = { path = "../engine/okf" }
mw-gate = { path = "../engine/gate" }
axum.workspace = true
tokio.workspace = true
rusqlite.workspace = true
serde.workspace = true
serde_json.workspace = true
sha2.workspace = true
hex.workspace = true
anyhow.workspace = true

[dev-dependencies]
mw-test-support = { path = "../engine/test-support" }
tower.workspace = true
http-body-util.workspace = true
tempfile.workspace = true
serde_json.workspace = true
```

- [ ] **Step 3: Write server/src/error.rs**

```rust
// SPDX-License-Identifier: AGPL-3.0-or-later
use axum::http::StatusCode;
use axum::response::{IntoResponse, Response};
use axum::Json;
use serde_json::json;

/// Every failure path returns this: a status code and a JSON body, never a panic.
#[derive(Debug)]
pub struct ApiError {
    pub status: StatusCode,
    pub message: String,
}

impl ApiError {
    pub fn bad_request(message: impl Into<String>) -> Self {
        Self {
            status: StatusCode::BAD_REQUEST,
            message: message.into(),
        }
    }

    pub fn not_found(message: impl Into<String>) -> Self {
        Self {
            status: StatusCode::NOT_FOUND,
            message: message.into(),
        }
    }

    pub fn conflict(message: impl Into<String>) -> Self {
        Self {
            status: StatusCode::CONFLICT,
            message: message.into(),
        }
    }

    /// A well-formed OKF document that fails validation: the model is the problem,
    /// not the request, so the code is 422 and the report travels with it.
    pub fn unprocessable(message: impl Into<String>, errors: Vec<String>) -> Self {
        Self {
            status: StatusCode::UNPROCESSABLE_ENTITY,
            message: format!("{}: {}", message.into(), errors.join("; ")),
        }
    }

    pub fn internal(message: impl Into<String>) -> Self {
        Self {
            status: StatusCode::INTERNAL_SERVER_ERROR,
            message: message.into(),
        }
    }
}

impl IntoResponse for ApiError {
    fn into_response(self) -> Response {
        (self.status, Json(json!({ "error": self.message }))).into_response()
    }
}
```

- [ ] **Step 4: Write server/src/lib.rs**

```rust
// SPDX-License-Identifier: AGPL-3.0-or-later
pub mod error;

use std::path::PathBuf;
use std::sync::Arc;

use axum::routing::get;
use axum::{Json, Router};
use serde_json::json;

pub use error::ApiError;

#[derive(Clone)]
pub struct AppState {
    pub evidence_dir: PathBuf,
}

/// The whole HTTP surface as a router, so tests drive it in-process and never bind a port.
pub fn app(state: AppState) -> Router {
    Router::new()
        .route("/health", get(health))
        .route("/version", get(version))
        .with_state(Arc::new(state))
}

async fn health() -> Json<serde_json::Value> {
    Json(json!({ "status": "ok" }))
}

async fn version() -> Json<serde_json::Value> {
    Json(json!({
        "server": env!("CARGO_PKG_VERSION"),
        "service": "mw-server"
    }))
}
```

- [ ] **Step 5: Write server/src/main.rs**

```rust
// SPDX-License-Identifier: AGPL-3.0-or-later
use std::net::SocketAddr;
use std::path::PathBuf;

use server::{app, AppState};

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    let port: u16 = std::env::var("MW_PORT")
        .ok()
        .and_then(|p| p.parse().ok())
        .unwrap_or(8080);
    let evidence_dir = std::env::var("MW_EVIDENCE_DIR")
        .map(PathBuf::from)
        .unwrap_or_else(|_| PathBuf::from("docs/evidence"));

    let addr = SocketAddr::from(([127, 0, 0, 1], port));
    let listener = tokio::net::TcpListener::bind(addr).await?;
    println!("mw-server listening on http://{}", addr);
    axum::serve(listener, app(AppState { evidence_dir })).await?;
    Ok(())
}
```

- [ ] **Step 6: Write server/tests/http.rs**

```rust
// SPDX-License-Identifier: AGPL-3.0-or-later
use axum::body::Body;
use axum::http::{Request, StatusCode};
use http_body_util::BodyExt;
use tower::ServiceExt;

fn state(dir: &std::path::Path) -> server::AppState {
    server::AppState {
        evidence_dir: dir.to_path_buf(),
    }
}

#[tokio::test]
async fn health_answers_ok() {
    let dir = tempfile::tempdir().unwrap();
    let router = server::app(state(dir.path()));
    let response = router
        .oneshot(Request::builder().uri("/health").body(Body::empty()).unwrap())
        .await
        .unwrap();
    assert_eq!(response.status(), StatusCode::OK);
    let bytes = response.into_body().collect().await.unwrap().to_bytes();
    let value: serde_json::Value = serde_json::from_slice(&bytes).unwrap();
    assert_eq!(value["status"], "ok");
}

#[tokio::test]
async fn version_names_the_service() {
    let dir = tempfile::tempdir().unwrap();
    let router = server::app(state(dir.path()));
    let response = router
        .oneshot(Request::builder().uri("/version").body(Body::empty()).unwrap())
        .await
        .unwrap();
    assert_eq!(response.status(), StatusCode::OK);
    let bytes = response.into_body().collect().await.unwrap().to_bytes();
    let value: serde_json::Value = serde_json::from_slice(&bytes).unwrap();
    assert_eq!(value["service"], "mw-server");
}
```

http-body-util supplies BodyExt, which the tests use to read response bodies; it is declared in Step 1 as a workspace dependency and in the manifest above.

- [ ] **Step 7: Run the tests**

Run: cargo test -p mw-server --no-fail-fast
Expected: 2 tests pass.

- [ ] **Step 8: Format, lint and commit**

```powershell
cargo fmt --all
cargo clippy -p mw-server --all-targets -- -D warnings
git add Cargo.toml Cargo.lock server
git commit -m "feat: add the repository service skeleton"
```

---

