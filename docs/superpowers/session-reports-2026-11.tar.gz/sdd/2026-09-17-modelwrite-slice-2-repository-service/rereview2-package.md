﻿# Re-review round 2 package

## Commit

dbecb8c test: prove branch linearity by child counts and a tip walk, and drop the dead append path

## Full diff (-U10) of this fix

diff --git a/server/src/api.rs b/server/src/api.rs
index f3c997e..8cc8d4f 100644
--- a/server/src/api.rs
+++ b/server/src/api.rs
@@ -9,23 +9,25 @@ use serde_json::{json, Value};
 
 use crate::error::ApiError;
 use crate::store::{Commit, Store, StoreError};
 
 #[derive(Clone)]
 pub struct ApiState {
     pub store: Arc<dyn Store>,
     pub evidence_dir: std::path::PathBuf,
 }
 
-/// A name that is safe as a URL segment and as a file name component. Project and
-/// branch names end up in the evidence file path, so an unrestricted name could contain
-/// a separator and write outside the evidence directory.
+/// A name that is safe as a URL segment: letters, digits, dot, underscore and hyphen,
+/// at most 64 characters, and at least one letter or digit so that "." and ".." are
+/// rejected. The charset is deliberately narrow rather than merely path-safe, so names
+/// stay predictable in URLs and logs; it does mean a Git-style slashed branch name is
+/// not accepted, which is a deliberate restriction, not an oversight.
 pub fn validate_name(kind: &str, name: &str) -> Result<(), ApiError> {
     if name.is_empty() {
         return Err(ApiError::bad_request(format!("{} must not be empty", kind)));
     }
     if name.len() > 64 {
         return Err(ApiError::bad_request(format!(
             "{} must be 64 characters or fewer",
             kind
         )));
     }
diff --git a/server/src/gate_api.rs b/server/src/gate_api.rs
index 77f8081..88b994f 100644
--- a/server/src/gate_api.rs
+++ b/server/src/gate_api.rs
@@ -64,22 +64,24 @@ pub async fn run_gate(
     state.store.record_gate_run(&run).map_err(map_store_error)?;
 
     // The name carries both FULL hashes. Truncating them would keep determinism but lose
     // uniqueness: two commit pairs sharing a prefix would overwrite each other's evidence
     // while both runs stayed recorded, so a run would cite a file it never wrote.
     // The name carries both FULL hashes and no project name: the hashes are globally
     // unique, and keeping an unvalidated string out of a filesystem path removes any
     // chance of a separator escaping the evidence directory.
     let file_name = format!("server-{}-{}.json", body.reference, body.candidate);
     let path = state.evidence_dir.join(file_name);
-    gate::write_evidence(&path, &outcome.evidence)
-        .map_err(|e| ApiError::internal(e.to_string()))?;
+    gate::write_evidence(&path, &outcome.evidence).map_err(|e| {
+        eprintln!("could not write evidence to {}: {}", path.display(), e);
+        ApiError::internal("the evidence record could not be exported")
+    })?;
 
     Ok(Json(outcome.evidence))
 }
 
 pub async fn list_gate_runs(
     State(state): State<ApiState>,
     Path(project): Path<String>,
 ) -> Result<Json<Value>, ApiError> {
     let runs = state.store.gate_runs(&project).map_err(map_store_error)?;
     let out: Vec<Value> = runs
diff --git a/server/src/store/mod.rs b/server/src/store/mod.rs
index 80375fc..848c2f6 100644
--- a/server/src/store/mod.rs
+++ b/server/src/store/mod.rs
@@ -91,21 +91,20 @@ pub fn now_epoch() -> String {
         Err(_) => "0".to_string(),
     }
 }
 
 pub trait Store: Send + Sync {
     fn create_project(&self, name: &str) -> Result<Project, StoreError>;
     fn project(&self, name: &str) -> Result<Option<Project>, StoreError>;
     fn list_projects(&self) -> Result<Vec<Project>, StoreError>;
     fn put_blob(&self, bytes: &[u8]) -> Result<String, StoreError>;
     fn blob(&self, hash: &str) -> Result<Option<Vec<u8>>, StoreError>;
-    fn append_commit(&self, commit: &Commit) -> Result<(), StoreError>;
 
     /// Commit a model onto a branch atomically: the tip is read, the parents and the
     /// commit hash are derived from it, and the commit row and the branch tip are written
     /// inside ONE lock and transaction. Resolving the parents a layer above would be a
     /// read-modify-write race: two concurrent commits would both read the same tip and
     /// fork the history, the later one orphaning the earlier while the branch lists both.
     fn commit_model(
         &self,
         project: &str,
         branch: &str,
diff --git a/server/src/store/sqlite.rs b/server/src/store/sqlite.rs
index 8a51a1b..8f582b3 100644
--- a/server/src/store/sqlite.rs
+++ b/server/src/store/sqlite.rs
@@ -152,48 +152,20 @@ impl Store for SqliteStore {
         self.with(|c| {
             let mut stmt = c.prepare("SELECT bytes FROM blobs WHERE hash = ?1")?;
             let mut rows = stmt.query(params![hash])?;
             match rows.next()? {
                 Some(row) => Ok(Some(row.get(0)?)),
                 None => Ok(None),
             }
         })
     }
 
-    fn append_commit(&self, commit: &Commit) -> Result<(), StoreError> {
-        let parents = serde_json::to_string(&commit.parents)
-            .map_err(|e| StoreError::Backend(e.to_string()))?;
-        // The commit row and the branch tip must move together. Two separate lock
-        // acquisitions would let two concurrent appends interleave, leaving the tip
-        // pointing at the earlier commit while the history lists both.
-        let guard = self
-            .connection
-            .lock()
-            .map_err(|_| StoreError::Backend("connection lock poisoned".to_string()))?;
-        let tx = guard
-            .unchecked_transaction()
-            .map_err(|e| StoreError::Backend(e.to_string()))?;
-        tx.execute(
-            "INSERT OR IGNORE INTO commits (hash, project, branch, parents, okf_hash, author, message, created_at) VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8)",
-            params![commit.hash, commit.project, commit.branch, parents, commit.okf_hash, commit.author, commit.message, commit.created_at],
-        )
-        .map_err(|e| StoreError::Backend(e.to_string()))?;
-        tx.execute(
-            "INSERT INTO branches (project, name, tip) VALUES (?1, ?2, ?3) ON CONFLICT(project, name) DO UPDATE SET tip = ?3",
-            params![commit.project, commit.branch, commit.hash],
-        )
-        .map_err(|e| StoreError::Backend(e.to_string()))?;
-        tx.commit()
-            .map_err(|e| StoreError::Backend(e.to_string()))?;
-        Ok(())
-    }
-
     fn commit_model(
         &self,
         project: &str,
         branch: &str,
         okf_hash: &str,
         author: &str,
         message: &str,
     ) -> Result<Commit, StoreError> {
         let guard = self
             .connection
@@ -214,22 +186,24 @@ impl Store for SqliteStore {
                 None => Ok(None),
             }
         })()
         .map_err(|e| StoreError::Backend(e.to_string()))?;
         let parents: Vec<String> = tip.into_iter().collect();
         let created_at = now_epoch();
         let hash = super::commit_hash(project, branch, &parents, okf_hash, author, message);
         let parents_json =
             serde_json::to_string(&parents).map_err(|e| StoreError::Backend(e.to_string()))?;
 
+        // Plain INSERT, not OR IGNORE: a constraint failure must abort this transaction
+        // rather than move a branch tip to a hash that has no commit row.
         tx.execute(
-            "INSERT OR IGNORE INTO commits (hash, project, branch, parents, okf_hash, author, message, created_at) VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8)",
+            "INSERT INTO commits (hash, project, branch, parents, okf_hash, author, message, created_at) VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8)",
             params![hash, project, branch, parents_json, okf_hash, author, message, created_at],
         )
         .map_err(|e| StoreError::Backend(e.to_string()))?;
         tx.execute(
             "INSERT INTO branches (project, name, tip) VALUES (?1, ?2, ?3) ON CONFLICT(project, name) DO UPDATE SET tip = ?3",
             params![project, branch, hash],
         )
         .map_err(|e| StoreError::Backend(e.to_string()))?;
         tx.commit()
             .map_err(|e| StoreError::Backend(e.to_string()))?;
diff --git a/server/tests/store.rs b/server/tests/store.rs
index 6dabcc3..63d1af9 100644
--- a/server/tests/store.rs
+++ b/server/tests/store.rs
@@ -1,34 +1,19 @@
 // SPDX-License-Identifier: AGPL-3.0-or-later
-use server::store::{commit_hash, sqlite::SqliteStore, Commit, Store, StoreError};
+use server::store::{commit_hash, sqlite::SqliteStore, Store, StoreError};
 
 fn store() -> (SqliteStore, tempfile::TempDir) {
     let dir = tempfile::tempdir().unwrap();
     let store = SqliteStore::open(&dir.path().join("mw.db")).unwrap();
     (store, dir)
 }
 
-fn commit_for(project: &str, branch: &str, okf_hash: &str) -> Commit {
-    let parents: Vec<String> = vec![];
-    let hash = commit_hash(project, branch, &parents, okf_hash, "alex", "first commit");
-    Commit {
-        hash,
-        project: project.to_string(),
-        branch: branch.to_string(),
-        parents,
-        okf_hash: okf_hash.to_string(),
-        author: "alex".to_string(),
-        message: "first commit".to_string(),
-        created_at: "0".to_string(),
-    }
-}
-
 #[test]
 fn blobs_are_content_addressed() {
     let (store, _dir) = store();
     let a = store.put_blob(b"{\"model\":1}").unwrap();
     let b = store.put_blob(b"{\"model\":1}").unwrap();
     let c = store.put_blob(b"{\"model\":2}").unwrap();
     assert_eq!(a, b, "identical bytes must share an address");
     assert_ne!(a, c);
     assert_eq!(store.blob(&a).unwrap().unwrap(), b"{\"model\":1}");
 }
@@ -40,64 +25,73 @@ fn a_commit_hash_ignores_time_but_not_content() {
     let b = commit_hash("p", "main", &parents, "okf1", "alex", "m");
     let c = commit_hash("p", "main", &parents, "okf2", "alex", "m");
     assert_eq!(a, b);
     assert_ne!(a, c);
 }
 
 #[test]
 fn commits_land_on_a_branch_and_move_its_tip() {
     let (store, _dir) = store();
     store.create_project("coffee").unwrap();
-    let first = commit_for("coffee", "main", "okf1");
-    store.append_commit(&first).unwrap();
+    let first = store
+        .commit_model("coffee", "main", "okf1", "alex", "first commit")
+        .unwrap();
     assert_eq!(
         store.branch_tip("coffee", "main").unwrap().unwrap(),
         first.hash
     );
 
-    let second = commit_for("coffee", "main", "okf2");
-    store.append_commit(&second).unwrap();
+    let second = store
+        .commit_model("coffee", "main", "okf2", "alex", "second commit")
+        .unwrap();
     assert_eq!(
         store.branch_tip("coffee", "main").unwrap().unwrap(),
         second.hash
     );
     assert_eq!(store.commits_on("coffee", "main").unwrap().len(), 2);
+    // The parent link is the point of a commit graph: without it, history is a pile of
+    // unrelated snapshots that no merge could ever reason about.
+    assert!(first.parents.is_empty(), "the first commit has no parent");
+    assert_eq!(second.parents, vec![first.hash.clone()]);
 }
 
 #[test]
 fn duplicate_projects_and_branches_are_conflicts() {
     let (store, _dir) = store();
     store.create_project("coffee").unwrap();
     match store.create_project("coffee") {
         Err(StoreError::Conflict(_)) => {}
         other => panic!("expected a conflict, got {:?}", other),
     }
-    let commit = commit_for("coffee", "main", "okf1");
-    store.append_commit(&commit).unwrap();
+    let commit = store
+        .commit_model("coffee", "main", "okf1", "alex", "first commit")
+        .unwrap();
     store
         .create_branch("coffee", "review", &commit.hash)
         .unwrap();
     match store.create_branch("coffee", "review", &commit.hash) {
         Err(StoreError::Conflict(_)) => {}
         other => panic!("expected a conflict, got {:?}", other),
     }
     match store.create_branch("coffee", "other", "missing-commit") {
         Err(StoreError::NotFound(_)) => {}
         other => panic!("expected not found, got {:?}", other),
     }
 }
 #[test]
 fn concurrent_commits_to_one_branch_form_a_linear_chain() {
     // The store resolves the parents, hashes and appends inside one lock and transaction.
-    // If that atomicity were lost, two concurrent commits would both read the same tip
-    // and fork the history: both commits would land, but one would orphan the other and
-    // the chain would have two roots. This test fails loudly in that case.
+    // If that atomicity were lost, two concurrent commits would read the same tip and
+    // become SIBLINGS: both land, one orphans the other. Counting roots would not see
+    // that - a sibling fork still has one root - so linearity is checked the only way
+    // that catches it: by counting each commit's children and by walking the parents
+    // from the tip back to the root.
     let (store, _dir) = store();
     store.create_project("coffee").unwrap();
     let store = std::sync::Arc::new(store);
 
     let mut handles = Vec::new();
     for i in 0..8 {
         let store = store.clone();
         handles.push(std::thread::spawn(move || {
             store
                 .commit_model(
@@ -109,21 +103,55 @@ fn concurrent_commits_to_one_branch_form_a_linear_chain() {
                 )
                 .expect("commit model");
         }));
     }
     for handle in handles {
         handle.join().expect("worker thread");
     }
 
     let history = store.commits_on("coffee", "main").unwrap();
     assert_eq!(history.len(), 8, "every commit must land");
-    let roots = history.iter().filter(|c| c.parents.is_empty()).count();
-    assert_eq!(roots, 1, "exactly one commit may be rootless");
+
+    // A parent with two children is a fork, and this is the assertion that catches it.
+    let mut children: std::collections::HashMap<String, Vec<String>> =
+        std::collections::HashMap::new();
     for commit in &history {
+        for parent in &commit.parents {
+            children
+                .entry(parent.clone())
+                .or_default()
+                .push(commit.hash.clone());
+        }
+    }
+    for (parent, kids) in &children {
+        assert_eq!(
+            kids.len(),
+            1,
+            "commit {} is the parent of {} commits, so the history forked",
+            parent,
+            kids.len()
+        );
+    }
+
+    // Walking the parents from the branch tip must reach every commit exactly once.
+    let tip = store.branch_tip("coffee", "main").unwrap().unwrap();
+    let mut seen: Vec<String> = Vec::new();
+    let mut cursor = Some(tip);
+    while let Some(hash) = cursor {
         assert!(
-            commit.parents.len() <= 1,
-            "no commit may have two parents in this scenario"
+            !seen.contains(&hash),
+            "the chain revisits {}, so it is not a chain",
+            hash
         );
+        let commit = history
+            .iter()
+            .find(|c| c.hash == hash)
+            .expect("the tip and its ancestors must all be in the history");
+        cursor = commit.parents.first().cloned();
+        seen.push(hash);
     }
-    let links: usize = history.iter().map(|c| c.parents.len()).sum();
-    assert_eq!(links, 7, "seven commits must link to their predecessor");
+    assert_eq!(
+        seen.len(),
+        8,
+        "walking back from the tip must reach all eight commits"
+    );
 }
