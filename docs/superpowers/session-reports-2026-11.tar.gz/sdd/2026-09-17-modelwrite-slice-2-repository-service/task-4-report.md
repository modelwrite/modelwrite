# Task 4 Report: The gate endpoint and server-side evidence

## Status

DONE

## Commits

- 705b4cde45066e72bef81e98a182b93b071a99c3 — feat: add the server-side gate endpoint and evidence recording

## Test summary

cargo test -p mw-server --no-fail-fast: 13 passed, 0 failed (http 2, store 4, api 4, gate 3).

## Concerns

None.

## Deviations

None. The brief already carried both corrections applied here: the routes use axum 0.7 `:param` syntax
(`/projects/:project/gate`, `/projects/:project/gate-runs`) and the changed-model test asserts roundtrip
inequality as `assert!(!evidence["roundtrip"]["equal"].as_bool().unwrap());`. No braces were present in any
route touched, so nothing further was converted.

## Verification

- SPDX header present at the top of every new/modified source file.
- No handler panic paths: load_model, write_evidence and record_gate_run all map failures to ApiError;
  short() clamps to the hash length so the slice cannot panic.
- Evidence is written to the evidence directory under `server-{project}-{ref12}-{cand12}.json`, derived from
  both commit hashes, so the same two commits always produce the same file (verified by the first gate test).
- A failed gate returns HTTP 200 with `passed: false` and is still recorded (verified by the second test).
- The recorded run appears in GET /projects/coffee/gate-runs (verified by the second test).
- cargo fmt --all: clean. cargo clippy -p mw-server --all-targets -- -D warnings: clean (exit 0).
- Staged only server/src/gate_api.rs, server/src/lib.rs, server/tests/gate_api.rs; Cargo.toml and Cargo.lock
  were unchanged, and .superpowers/ was left untracked.
