# Task 3 Report: The project and commit API

## Status

DONE_WITH_CONCERNS

## Commits

- `8d99adf` feat: add the project and commit API

## Test summary

`cargo test -p mw-server --no-fail-fast`: 10 passed, 0 failed (lib 0, bin 0, integration tests/api.rs 4, integration tests/http.rs 2, integration tests/store.rs 4, doc-tests 0).

## Verification

- `cargo test -p mw-server --no-fail-fast` — 10 tests pass; cargo exit code 0.
- `cargo fmt --all` — clean (exit 0).
- `cargo clippy -p mw-server --all-targets -- -D warnings` — clean (exit 0).
- Commit `8d99adf` touches exactly 5 files, all under `server/`: `src/api.rs` (new), `src/lib.rs` (AppState gains `store`; router gains the six routes), `src/main.rs` (opens the store), `tests/api.rs` (new, 4 tests), `tests/http.rs` (state() helper only). `Cargo.toml`/`Cargo.lock` are unchanged (no new dependencies; mw-okf/axum/tower/http-body-util/tempfile were already declared). `engine/`, `judge/`, `sample/`, `docs/`, `collateral/` are untouched.

## Self-review

- SPDX header present on all three new/changed source files (`src/api.rs`, `src/lib.rs`, `src/main.rs`) and on `tests/api.rs`.
- No handler unwraps a request field: request bodies are extracted via `Json<T>`/`Path<T>`/`Query<T>` and every fallible step is `map_err(...)?` — no `.unwrap()`/`.expect()` on anything from the request. (The only `.expect` in the crate remains Task 2's `commit_hash`, over a `json!` value of strings/arrays, which cannot fail.)
- The validation gate runs before storage: `create_commit` deserializes and `okf::validate::validate`s the document and returns 422 before `put_blob` or `append_commit` is ever called.
- Every route in the brief is registered: POST `/projects`, GET `/projects`, POST `/projects/:project/commits`, GET `/projects/:project/commits`, GET `/projects/:project/commits/:hash`, POST `/projects/:project/branches` (all six, on the same URLs as the brief).
- The controller's extra version assertion in `tests/http.rs` survives: `assert_eq!(value["server"], env!("CARGO_PKG_VERSION"));` is untouched (the file's diff is +2 lines, confined to the `state()` helper), and the `version_names_the_service` test still passes.
- 422 path asserted end-to-end: `an_invalid_model_is_rejected_with_its_errors` proves a null `graph` section is rejected with status 422 and `"graph section is missing"` in the `error` body; `a_commit_stores_the_model_and_moves_the_branch` proves the stored document is returned byte-for-byte equal to `tiny_okf()`.

## Deviation from brief

1. **Route param syntax `{param}` -> `:param` (required).** The brief's `lib.rs` registers `/projects/{project}/commits`, `/projects/{project}/commits/{hash}`, `/projects/{project}/branches`. The workspace pins `axum = "0.7"` (resolved 0.7.9 / matchit 0.7.3), which uses colon syntax `:param`; braces `{param}` are axum 0.8 syntax. With the brief's literal strings the routes silently fail to match — I confirmed empirically that POST `/projects/coffee/commits` returned an empty-body 404 (axum's default not-found, not the handler's `ApiError`). I changed only the param markers (`{project}` -> `:project`, `{hash}` -> `:hash`); the URLs and all six routes are unchanged.
2. **Removed the unused `use okf::types::OkfRoot;` import from `api.rs`.** The body refers to the type via the fully-qualified `okf::types::OkfRoot`, so the import is redundant and would fail `clippy -D warnings` (unused import). Everything else in `api.rs` is verbatim from the brief.

## Concerns

- The brief's route strings use axum 0.8 `{param}` syntax while the workspace pins axum 0.7. Tasks 4/5 (the gate API) are likely to introduce more route parameters; whoever writes those briefs should use `:param` for this workspace, or the workspace should be upgraded to axum 0.8 deliberately (which has additional API changes beyond routing and is out of scope for this task).
