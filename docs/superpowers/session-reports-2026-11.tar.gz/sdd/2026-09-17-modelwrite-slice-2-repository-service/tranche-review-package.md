﻿# Slice 2 tranche 1 - final whole-tranche review package

## Commits on this branch since the plan commit

69d062d fix: name evidence files by full hashes and record the run before exporting it
b9a8a8e test: pin the byte-for-byte round trip and the branch route semantics
204e91e test: prove the corpus can be committed, branched and gated through the service
705b4cd feat: add the server-side gate endpoint and evidence recording
6361c32 fix: make store writes atomic, report corrupt rows, and correct the route syntax
8d99adf feat: add the project and commit API
3ac0537 test: assert the served version, not only the service name
9b9a03e feat: add the content-addressed model store
818a9cc feat: add the repository service skeleton

## Diff stat

 Cargo.lock                                         | 666 ++++++++++++++++++++-
 Cargo.toml                                         |   8 +-
 ...-09-17-modelwrite-slice-2-repository-service.md |  12 +-
 server/Cargo.toml                                  |  33 +
 server/src/api.rs                                  | 199 ++++++
 server/src/error.rs                                |  57 ++
 server/src/gate_api.rs                             | 100 ++++
 server/src/lib.rs                                  |  62 ++
 server/src/main.rs                                 |  33 +
 server/src/store/mod.rs                            | 109 ++++
 server/src/store/sqlite.rs                         | 339 +++++++++++
 server/tests/api.rs                                | 262 ++++++++
 server/tests/corpus.rs                             | 119 ++++
 server/tests/gate_api.rs                           | 168 ++++++
 server/tests/http.rs                               |  52 ++
 server/tests/store.rs                              |  87 +++
 16 files changed, 2298 insertions(+), 8 deletions(-)

## Verification observed by the controller

```
cargo test --workspace --no-fail-fast   -> 60 tests pass, 11 binaries, 0 failures
cargo fmt --all -- --check              -> exit 0
cargo clippy --workspace --all-targets -- -D warnings -> exit 0
```

## Full diff (-U10)

diff --git a/Cargo.toml b/Cargo.toml
index c923385..770ed12 100644
--- a/Cargo.toml
+++ b/Cargo.toml
@@ -1,17 +1,23 @@
 [workspace]
 resolver = "2"
-members = ["engine/okf", "engine/test-support", "engine/graph", "engine/gate", "engine/capi", "engine/mcp"]
+members = ["engine/okf", "engine/test-support", "engine/graph", "engine/gate", "engine/capi", "engine/mcp", "server"]
 
 [workspace.package]
 edition = "2021"
 rust-version = "1.75"
 license = "AGPL-3.0-or-later"
 repository = "https://github.com/modelwrite/modelwrite"
 
 [workspace.dependencies]
 anyhow = "1.0"
 hex = "0.4"
 petgraph = "0.6"
 serde = { version = "1.0", features = ["derive"] }
 serde_json = "1.0"
 sha2 = "0.10"
+axum = "0.7"
+tokio = { version = "1", features = ["rt-multi-thread", "macros", "net"] }
+rusqlite = { version = "0.31", features = ["bundled"] }
+tower = { version = "0.4", features = ["util"] }
+http-body-util = "0.1"
+tempfile = "3"
diff --git a/server/Cargo.toml b/server/Cargo.toml
new file mode 100644
index 0000000..e84db54
--- /dev/null
+++ b/server/Cargo.toml
@@ -0,0 +1,33 @@
+[package]
+name = "mw-server"
+version = "0.1.0"
+edition.workspace = true
+rust-version.workspace = true
+license.workspace = true
+publish = false
+
+[lib]
+name = "server"
+
+[[bin]]
+name = "mw-server"
+path = "src/main.rs"
+
+[dependencies]
+mw-okf = { path = "../engine/okf" }
+mw-gate = { path = "../engine/gate" }
+axum.workspace = true
+tokio.workspace = true
+rusqlite.workspace = true
+serde.workspace = true
+serde_json.workspace = true
+sha2.workspace = true
+hex.workspace = true
+anyhow.workspace = true
+
+[dev-dependencies]
+mw-test-support = { path = "../engine/test-support" }
+tower.workspace = true
+http-body-util.workspace = true
+tempfile.workspace = true
+serde_json.workspace = true
diff --git a/server/src/api.rs b/server/src/api.rs
new file mode 100644
index 0000000..d424535
--- /dev/null
+++ b/server/src/api.rs
@@ -0,0 +1,199 @@
+// SPDX-License-Identifier: AGPL-3.0-or-later
+use std::sync::Arc;
+
+use axum::extract::{Path, Query, State};
+use axum::http::StatusCode;
+use axum::Json;
+use serde::Deserialize;
+use serde_json::{json, Value};
+
+use crate::error::ApiError;
+use crate::store::{commit_hash, now_epoch, Commit, Store, StoreError};
+
+#[derive(Clone)]
+pub struct ApiState {
+    pub store: Arc<dyn Store>,
+    pub evidence_dir: std::path::PathBuf,
+}
+
+pub fn map_store_error(e: StoreError) -> ApiError {
+    match e {
+        StoreError::NotFound(m) => ApiError::not_found(m),
+        StoreError::Conflict(m) => ApiError::conflict(m),
+        StoreError::Backend(m) => ApiError::internal(m),
+    }
+}
+
+fn commit_json(commit: &Commit) -> Value {
+    json!({
+        "hash": commit.hash,
+        "project": commit.project,
+        "branch": commit.branch,
+        "parents": commit.parents,
+        "okfHash": commit.okf_hash,
+        "author": commit.author,
+        "message": commit.message,
+        "createdAt": commit.created_at
+    })
+}
+
+#[derive(Deserialize)]
+pub struct CreateProject {
+    pub name: String,
+}
+
+pub async fn create_project(
+    State(state): State<ApiState>,
+    Json(body): Json<CreateProject>,
+) -> Result<(StatusCode, Json<Value>), ApiError> {
+    if body.name.trim().is_empty() {
+        return Err(ApiError::bad_request("project name must not be empty"));
+    }
+    let project = state
+        .store
+        .create_project(&body.name)
+        .map_err(map_store_error)?;
+    Ok((
+        StatusCode::CREATED,
+        Json(json!({ "name": project.name, "createdAt": project.created_at })),
+    ))
+}
+
+pub async fn list_projects(State(state): State<ApiState>) -> Result<Json<Value>, ApiError> {
+    let projects = state.store.list_projects().map_err(map_store_error)?;
+    let out: Vec<Value> = projects
+        .iter()
+        .map(|p| json!({ "name": p.name, "createdAt": p.created_at }))
+        .collect();
+    Ok(Json(Value::Array(out)))
+}
+
+#[derive(Deserialize)]
+pub struct CreateCommit {
+    pub branch: String,
+    pub author: String,
+    pub message: String,
+    pub okf: Value,
+}
+
+pub async fn create_commit(
+    State(state): State<ApiState>,
+    Path(project): Path<String>,
+    Json(body): Json<CreateCommit>,
+) -> Result<(StatusCode, Json<Value>), ApiError> {
+    if state
+        .store
+        .project(&project)
+        .map_err(map_store_error)?
+        .is_none()
+    {
+        return Err(ApiError::not_found(format!("project {}", project)));
+    }
+    if body.branch.trim().is_empty() {
+        return Err(ApiError::bad_request("branch must not be empty"));
+    }
+
+    // The document must be a valid OKF model before it is stored: a repository that
+    // accepts invalid models cannot be gated meaningfully.
+    let bytes = serde_json::to_vec(&body.okf).map_err(|e| ApiError::bad_request(e.to_string()))?;
+    let root: okf::types::OkfRoot = serde_json::from_slice(&bytes)
+        .map_err(|e| ApiError::bad_request(format!("not an OKF document: {}", e)))?;
+    let report = okf::validate::validate(&root);
+    if !report.valid {
+        return Err(ApiError::unprocessable(
+            "the model failed validation",
+            report.errors,
+        ));
+    }
+
+    let okf_hash = state.store.put_blob(&bytes).map_err(map_store_error)?;
+    let parents: Vec<String> = state
+        .store
+        .branch_tip(&project, &body.branch)
+        .map_err(map_store_error)?
+        .into_iter()
+        .collect();
+    let hash = commit_hash(
+        &project,
+        &body.branch,
+        &parents,
+        &okf_hash,
+        &body.author,
+        &body.message,
+    );
+    let commit = Commit {
+        hash: hash.clone(),
+        project: project.clone(),
+        branch: body.branch.clone(),
+        parents: parents.clone(),
+        okf_hash,
+        author: body.author,
+        message: body.message,
+        created_at: now_epoch(),
+    };
+    state
+        .store
+        .append_commit(&commit)
+        .map_err(map_store_error)?;
+    Ok((StatusCode::CREATED, Json(commit_json(&commit))))
+}
+
+#[derive(Deserialize)]
+pub struct BranchQuery {
+    pub branch: Option<String>,
+}
+
+pub async fn list_commits(
+    State(state): State<ApiState>,
+    Path(project): Path<String>,
+    Query(query): Query<BranchQuery>,
+) -> Result<Json<Value>, ApiError> {
+    let branch = query.branch.unwrap_or_else(|| "main".to_string());
+    let commits = state
+        .store
+        .commits_on(&project, &branch)
+        .map_err(map_store_error)?;
+    Ok(Json(Value::Array(
+        commits.iter().map(commit_json).collect(),
+    )))
+}
+
+pub async fn get_commit(
+    State(state): State<ApiState>,
+    Path((project, hash)): Path<(String, String)>,
+) -> Result<Json<Value>, ApiError> {
+    let commit = state
+        .store
+        .commit(&project, &hash)
+        .map_err(map_store_error)?
+        .ok_or_else(|| ApiError::not_found(format!("commit {}", hash)))?;
+    let bytes = state
+        .store
+        .blob(&commit.okf_hash)
+        .map_err(map_store_error)?
+        .ok_or_else(|| ApiError::internal(format!("missing blob {}", commit.okf_hash)))?;
+    let value: Value =
+        serde_json::from_slice(&bytes).map_err(|e| ApiError::internal(e.to_string()))?;
+    Ok(Json(value))
+}
+
+#[derive(Deserialize)]
+pub struct CreateBranch {
+    pub name: String,
+    pub from: String,
+}
+
+pub async fn create_branch(
+    State(state): State<ApiState>,
+    Path(project): Path<String>,
+    Json(body): Json<CreateBranch>,
+) -> Result<(StatusCode, Json<Value>), ApiError> {
+    state
+        .store
+        .create_branch(&project, &body.name, &body.from)
+        .map_err(map_store_error)?;
+    Ok((
+        StatusCode::CREATED,
+        Json(json!({ "name": body.name, "tip": body.from })),
+    ))
+}
diff --git a/server/src/error.rs b/server/src/error.rs
new file mode 100644
index 0000000..0507b1a
--- /dev/null
+++ b/server/src/error.rs
@@ -0,0 +1,57 @@
+// SPDX-License-Identifier: AGPL-3.0-or-later
+use axum::http::StatusCode;
+use axum::response::{IntoResponse, Response};
+use axum::Json;
+use serde_json::json;
+
+/// Every failure path returns this: a status code and a JSON body, never a panic.
+#[derive(Debug)]
+pub struct ApiError {
+    pub status: StatusCode,
+    pub message: String,
+}
+
+impl ApiError {
+    pub fn bad_request(message: impl Into<String>) -> Self {
+        Self {
+            status: StatusCode::BAD_REQUEST,
+            message: message.into(),
+        }
+    }
+
+    pub fn not_found(message: impl Into<String>) -> Self {
+        Self {
+            status: StatusCode::NOT_FOUND,
+            message: message.into(),
+        }
+    }
+
+    pub fn conflict(message: impl Into<String>) -> Self {
+        Self {
+            status: StatusCode::CONFLICT,
+            message: message.into(),
+        }
+    }
+
+    /// A well-formed OKF document that fails validation: the model is the problem,
+    /// not the request, so the code is 422 and the report travels with it.
+    pub fn unprocessable(message: impl Into<String>, errors: Vec<String>) -> Self {
+        Self {
+            status: StatusCode::UNPROCESSABLE_ENTITY,
+            message: format!("{}: {}", message.into(), errors.join("; ")),
+        }
+    }
+
+    pub fn internal(message: impl Into<String>) -> Self {
+        Self {
+            status: StatusCode::INTERNAL_SERVER_ERROR,
+            message: message.into(),
+        }
+    }
+}
+
+impl IntoResponse for ApiError {
+    fn into_response(self) -> Response {
+        (self.status, Json(json!({ "error": self.message }))).into_response()
+    }
+}
diff --git a/server/src/gate_api.rs b/server/src/gate_api.rs
new file mode 100644
index 0000000..c86db27
--- /dev/null
+++ b/server/src/gate_api.rs
@@ -0,0 +1,100 @@
+// SPDX-License-Identifier: AGPL-3.0-or-later
+use axum::extract::{Path, State};
+use axum::Json;
+use serde::Deserialize;
+use serde_json::{json, Value};
+
+use crate::api::{map_store_error, ApiState};
+use crate::error::ApiError;
+use crate::store::{now_epoch, GateRun};
+
+/// Load the OKF document behind a commit hash.
+fn load_model(
+    state: &ApiState,
+    project: &str,
+    hash: &str,
+) -> Result<okf::types::OkfRoot, ApiError> {
+    let commit = state
+        .store
+        .commit(project, hash)
+        .map_err(map_store_error)?
+        .ok_or_else(|| ApiError::not_found(format!("commit {}", hash)))?;
+    let bytes = state
+        .store
+        .blob(&commit.okf_hash)
+        .map_err(map_store_error)?
+        .ok_or_else(|| ApiError::internal(format!("missing blob {}", commit.okf_hash)))?;
+    serde_json::from_slice(&bytes).map_err(|e| ApiError::internal(e.to_string()))
+}
+
+#[derive(Deserialize)]
+pub struct GateRequest {
+    pub reference: String,
+    pub candidate: String,
+}
+
+pub async fn run_gate(
+    State(state): State<ApiState>,
+    Path(project): Path<String>,
+    Json(body): Json<GateRequest>,
+) -> Result<Json<Value>, ApiError> {
+    let reference = load_model(&state, &project, &body.reference)?;
+    let candidate = load_model(&state, &project, &body.candidate)?;
+
+    let outcome = gate::run(&reference, &candidate, false);
+    let branch = state
+        .store
+        .commit(&project, &body.candidate)
+        .map_err(map_store_error)?
+        .map(|c| c.branch)
+        .unwrap_or_else(|| "main".to_string());
+
+    // The run is recorded first: the store carries the whole evidence payload, so it is
+    // the authority, and the file written below is an export of it. Writing first would
+    // let a failed insert leave an evidence file no recorded run cites.
+    let run = GateRun {
+        project: project.clone(),
+        branch,
+        reference_hash: body.reference.clone(),
+        candidate_hash: body.candidate.clone(),
+        passed: outcome.passed,
+        evidence: outcome.evidence.to_string(),
+        created_at: now_epoch(),
+    };
+    state.store.record_gate_run(&run).map_err(map_store_error)?;
+
+    // The name carries both FULL hashes. Truncating them would keep determinism but lose
+    // uniqueness: two commit pairs sharing a prefix would overwrite each other's evidence
+    // while both runs stayed recorded, so a run would cite a file it never wrote.
+    let file_name = format!(
+        "server-{}-{}-{}.json",
+        project, body.reference, body.candidate
+    );
+    let path = state.evidence_dir.join(file_name);
+    gate::write_evidence(&path, &outcome.evidence)
+        .map_err(|e| ApiError::internal(e.to_string()))?;
+
+    Ok(Json(outcome.evidence))
+}
+
+pub async fn list_gate_runs(
+    State(state): State<ApiState>,
+    Path(project): Path<String>,
+) -> Result<Json<Value>, ApiError> {
+    let runs = state.store.gate_runs(&project).map_err(map_store_error)?;
+    let out: Vec<Value> = runs
+        .iter()
+        .map(|r| {
+            json!({
+                "project": r.project,
+                "branch": r.branch,
+                "referenceHash": r.reference_hash,
+                "candidateHash": r.candidate_hash,
+                "passed": r.passed,
+                "evidence": serde_json::from_str::<Value>(&r.evidence).unwrap_or(Value::Null),
+                "createdAt": r.created_at
+            })
+        })
+        .collect();
+    Ok(Json(Value::Array(out)))
+}
diff --git a/server/src/lib.rs b/server/src/lib.rs
new file mode 100644
index 0000000..68d5d63
--- /dev/null
+++ b/server/src/lib.rs
@@ -0,0 +1,62 @@
+// SPDX-License-Identifier: AGPL-3.0-or-later
+pub mod api;
+pub mod error;
+pub mod gate_api;
+pub mod store;
+
+pub use error::ApiError;
+
+use std::sync::Arc;
+
+use axum::routing::{get, post};
+use axum::{Json, Router};
+use serde_json::json;
+
+#[derive(Clone)]
+pub struct AppState {
+    pub store: Arc<dyn store::Store>,
+    pub evidence_dir: std::path::PathBuf,
+}
+
+impl AppState {
+    fn api(&self) -> api::ApiState {
+        api::ApiState {
+            store: self.store.clone(),
+            evidence_dir: self.evidence_dir.clone(),
+        }
+    }
+}
+
+pub fn app(state: AppState) -> Router {
+    let api_state = state.api();
+    Router::new()
+        .route("/health", get(health))
+        .route("/version", get(version))
+        .route(
+            "/projects",
+            post(api::create_project).get(api::list_projects),
+        )
+        .route(
+            "/projects/:project/commits",
+            post(api::create_commit).get(api::list_commits),
+        )
+        .route("/projects/:project/commits/:hash", get(api::get_commit))
+        .route("/projects/:project/branches", post(api::create_branch))
+        .route("/projects/:project/gate", post(gate_api::run_gate))
+        .route(
+            "/projects/:project/gate-runs",
+            get(gate_api::list_gate_runs),
+        )
+        .with_state(api_state)
+}
+
+async fn health() -> Json<serde_json::Value> {
+    Json(json!({ "status": "ok" }))
+}
+
+async fn version() -> Json<serde_json::Value> {
+    Json(json!({
+        "server": env!("CARGO_PKG_VERSION"),
+        "service": "mw-server"
+    }))
+}
diff --git a/server/src/main.rs b/server/src/main.rs
new file mode 100644
index 0000000..facc9f4
--- /dev/null
+++ b/server/src/main.rs
@@ -0,0 +1,33 @@
+// SPDX-License-Identifier: AGPL-3.0-or-later
+use std::net::SocketAddr;
+use std::path::PathBuf;
+use std::sync::Arc;
+
+use server::store::sqlite::SqliteStore;
+use server::{app, AppState};
+
+#[tokio::main]
+async fn main() -> anyhow::Result<()> {
+    let port: u16 = std::env::var("MW_PORT")
+        .ok()
+        .and_then(|p| p.parse().ok())
+        .unwrap_or(8080);
+    let db_path = std::env::var("MW_DB").unwrap_or_else(|_| "modelwrite.db".to_string());
+    let evidence_dir = std::env::var("MW_EVIDENCE_DIR")
+        .map(PathBuf::from)
+        .unwrap_or_else(|_| PathBuf::from("docs/evidence"));
+
+    let store = Arc::new(SqliteStore::open(std::path::Path::new(&db_path))?);
+    let addr = SocketAddr::from(([127, 0, 0, 1], port));
+    let listener = tokio::net::TcpListener::bind(addr).await?;
+    println!("mw-server listening on http://{} (db {})", addr, db_path);
+    axum::serve(
+        listener,
+        app(AppState {
+            store,
+            evidence_dir,
+        }),
+    )
+    .await?;
+    Ok(())
+}
diff --git a/server/src/store/mod.rs b/server/src/store/mod.rs
new file mode 100644
index 0000000..d31150b
--- /dev/null
+++ b/server/src/store/mod.rs
@@ -0,0 +1,109 @@
+// SPDX-License-Identifier: AGPL-3.0-or-later
+use sha2::{Digest, Sha256};
+
+pub mod sqlite;
+
+#[derive(Debug, Clone, PartialEq)]
+pub struct Project {
+    pub name: String,
+    pub created_at: String,
+}
+
+#[derive(Debug, Clone, PartialEq)]
+pub struct Commit {
+    pub hash: String,
+    pub project: String,
+    pub branch: String,
+    pub parents: Vec<String>,
+    pub okf_hash: String,
+    pub author: String,
+    pub message: String,
+    pub created_at: String,
+}
+
+#[derive(Debug, Clone, PartialEq)]
+pub struct GateRun {
+    pub project: String,
+    pub branch: String,
+    pub reference_hash: String,
+    pub candidate_hash: String,
+    pub passed: bool,
+    pub evidence: String,
+    pub created_at: String,
+}
+
+#[derive(Debug)]
+pub enum StoreError {
+    NotFound(String),
+    Conflict(String),
+    Backend(String),
+}
+
+impl std::fmt::Display for StoreError {
+    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
+        match self {
+            StoreError::NotFound(m) => write!(f, "not found: {}", m),
+            StoreError::Conflict(m) => write!(f, "conflict: {}", m),
+            StoreError::Backend(m) => write!(f, "storage error: {}", m),
+        }
+    }
+}
+
+impl std::error::Error for StoreError {}
+
+/// Content address of a model: sha256 over the exact bytes stored. The same document
+/// always has the same address, so a re-export that changed nothing is a no-op.
+pub fn blob_hash(bytes: &[u8]) -> String {
+    let mut hasher = Sha256::new();
+    hasher.update(bytes);
+    hex::encode(hasher.finalize())
+}
+
+/// Content address of a commit: sha256 over a canonical JSON payload of everything
+/// that defines it except time. Two identical commits made at different moments hash
+/// the same, which is what makes a commit reproducible and its evidence citable.
+pub fn commit_hash(
+    project: &str,
+    branch: &str,
+    parents: &[String],
+    okf_hash: &str,
+    author: &str,
+    message: &str,
+) -> String {
+    let mut sorted_parents: Vec<&str> = parents.iter().map(|p| p.as_str()).collect();
+    sorted_parents.sort_unstable();
+    let payload = serde_json::json!({
+        "project": project,
+        "branch": branch,
+        "parents": sorted_parents,
+        "okfHash": okf_hash,
+        "author": author,
+        "message": message
+    });
+    let bytes = serde_json::to_vec(&payload).expect("commit payload serializes");
+    blob_hash(&bytes)
+}
+
+/// Seconds since the epoch, stored beside a commit and never inside its hash.
+pub fn now_epoch() -> String {
+    match std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH) {
+        Ok(d) => d.as_secs().to_string(),
+        Err(_) => "0".to_string(),
+    }
+}
+
+pub trait Store: Send + Sync {
+    fn create_project(&self, name: &str) -> Result<Project, StoreError>;
+    fn project(&self, name: &str) -> Result<Option<Project>, StoreError>;
+    fn list_projects(&self) -> Result<Vec<Project>, StoreError>;
+    fn put_blob(&self, bytes: &[u8]) -> Result<String, StoreError>;
+    fn blob(&self, hash: &str) -> Result<Option<Vec<u8>>, StoreError>;
+    fn append_commit(&self, commit: &Commit) -> Result<(), StoreError>;
+    fn commit(&self, project: &str, hash: &str) -> Result<Option<Commit>, StoreError>;
+    fn commits_on(&self, project: &str, branch: &str) -> Result<Vec<Commit>, StoreError>;
+    fn branch_tip(&self, project: &str, branch: &str) -> Result<Option<String>, StoreError>;
+    fn create_branch(&self, project: &str, name: &str, from: &str) -> Result<(), StoreError>;
+    fn list_branches(&self, project: &str) -> Result<Vec<(String, String)>, StoreError>;
+    fn record_gate_run(&self, run: &GateRun) -> Result<(), StoreError>;
+    fn gate_runs(&self, project: &str) -> Result<Vec<GateRun>, StoreError>;
+}
diff --git a/server/src/store/sqlite.rs b/server/src/store/sqlite.rs
new file mode 100644
index 0000000..f09f4e9
--- /dev/null
+++ b/server/src/store/sqlite.rs
@@ -0,0 +1,339 @@
+// SPDX-License-Identifier: AGPL-3.0-or-later
+use std::path::Path;
+
+use rusqlite::{params, Connection};
+
+use super::{now_epoch, Commit, GateRun, Project, Store, StoreError};
+
+const SCHEMA: &str = "
+CREATE TABLE IF NOT EXISTS projects (
+    name TEXT PRIMARY KEY,
+    created_at TEXT NOT NULL
+);
+CREATE TABLE IF NOT EXISTS blobs (
+    hash TEXT PRIMARY KEY,
+    bytes BLOB NOT NULL
+);
+CREATE TABLE IF NOT EXISTS commits (
+    hash TEXT PRIMARY KEY,
+    project TEXT NOT NULL,
+    branch TEXT NOT NULL,
+    parents TEXT NOT NULL,
+    okf_hash TEXT NOT NULL,
+    author TEXT NOT NULL,
+    message TEXT NOT NULL,
+    created_at TEXT NOT NULL
+);
+CREATE INDEX IF NOT EXISTS commits_by_project_branch ON commits (project, branch);
+CREATE TABLE IF NOT EXISTS branches (
+    project TEXT NOT NULL,
+    name TEXT NOT NULL,
+    tip TEXT NOT NULL,
+    PRIMARY KEY (project, name)
+);
+CREATE TABLE IF NOT EXISTS gate_runs (
+    id INTEGER PRIMARY KEY AUTOINCREMENT,
+    project TEXT NOT NULL,
+    branch TEXT NOT NULL,
+    reference_hash TEXT NOT NULL,
+    candidate_hash TEXT NOT NULL,
+    passed INTEGER NOT NULL,
+    evidence TEXT NOT NULL,
+    created_at TEXT NOT NULL
+);
+";
+
+pub struct SqliteStore {
+    connection: std::sync::Mutex<Connection>,
+}
+
+impl SqliteStore {
+    pub fn open(path: &Path) -> anyhow::Result<Self> {
+        let connection = Connection::open(path)?;
+        connection.execute_batch(SCHEMA)?;
+        Ok(Self {
+            connection: std::sync::Mutex::new(connection),
+        })
+    }
+
+    fn with<T>(&self, f: impl FnOnce(&Connection) -> rusqlite::Result<T>) -> Result<T, StoreError> {
+        let guard = self
+            .connection
+            .lock()
+            .map_err(|_| StoreError::Backend("connection lock poisoned".to_string()))?;
+        f(&guard).map_err(|e| StoreError::Backend(e.to_string()))
+    }
+}
+
+/// One commit row exactly as stored: hash, project, branch, parents, okf_hash, author,
+/// message, created_at. Named so the query helpers stay readable and clippy-clean.
+type CommitRow = (
+    String,
+    String,
+    String,
+    String,
+    String,
+    String,
+    String,
+    String,
+);
+
+/// Parse the parents column, reporting corruption rather than hiding it: an empty list
+/// silently substituted here would change what commit_hash covers.
+fn parse_parents(hash: &str, raw: &str) -> Result<Vec<String>, StoreError> {
+    serde_json::from_str(raw).map_err(|e| {
+        StoreError::Backend(format!("corrupt parents column for commit {}: {}", hash, e))
+    })
+}
+
+impl Store for SqliteStore {
+    fn create_project(&self, name: &str) -> Result<Project, StoreError> {
+        // Check-then-insert would be a time-of-check window: two concurrent callers could
+        // both pass the check. The primary key settles it instead, and an insert that
+        // changed nothing is reported as the conflict it is.
+        let created_at = now_epoch();
+        let inserted = self.with(|c| {
+            c.execute(
+                "INSERT OR IGNORE INTO projects (name, created_at) VALUES (?1, ?2)",
+                params![name, created_at],
+            )
+        })?;
+        if inserted == 0 {
+            return Err(StoreError::Conflict(format!(
+                "project {} already exists",
+                name
+            )));
+        }
+        Ok(Project {
+            name: name.to_string(),
+            created_at,
+        })
+    }
+
+    fn project(&self, name: &str) -> Result<Option<Project>, StoreError> {
+        self.with(|c| {
+            let mut stmt = c.prepare("SELECT name, created_at FROM projects WHERE name = ?1")?;
+            let mut rows = stmt.query(params![name])?;
+            match rows.next()? {
+                Some(row) => Ok(Some(Project {
+                    name: row.get(0)?,
+                    created_at: row.get(1)?,
+                })),
+                None => Ok(None),
+            }
+        })
+    }
+
+    fn list_projects(&self) -> Result<Vec<Project>, StoreError> {
+        self.with(|c| {
+            let mut stmt = c.prepare("SELECT name, created_at FROM projects ORDER BY name")?;
+            let rows = stmt.query_map([], |row| {
+                Ok(Project {
+                    name: row.get(0)?,
+                    created_at: row.get(1)?,
+                })
+            })?;
+            rows.collect()
+        })
+    }
+
+    fn put_blob(&self, bytes: &[u8]) -> Result<String, StoreError> {
+        let hash = super::blob_hash(bytes);
+        self.with(|c| {
+            c.execute(
+                "INSERT OR IGNORE INTO blobs (hash, bytes) VALUES (?1, ?2)",
+                params![hash, bytes],
+            )
+        })?;
+        Ok(hash)
+    }
+
+    fn blob(&self, hash: &str) -> Result<Option<Vec<u8>>, StoreError> {
+        self.with(|c| {
+            let mut stmt = c.prepare("SELECT bytes FROM blobs WHERE hash = ?1")?;
+            let mut rows = stmt.query(params![hash])?;
+            match rows.next()? {
+                Some(row) => Ok(Some(row.get(0)?)),
+                None => Ok(None),
+            }
+        })
+    }
+
+    fn append_commit(&self, commit: &Commit) -> Result<(), StoreError> {
+        let parents = serde_json::to_string(&commit.parents)
+            .map_err(|e| StoreError::Backend(e.to_string()))?;
+        // The commit row and the branch tip must move together. Two separate lock
+        // acquisitions would let two concurrent appends interleave, leaving the tip
+        // pointing at the earlier commit while the history lists both.
+        let guard = self
+            .connection
+            .lock()
+            .map_err(|_| StoreError::Backend("connection lock poisoned".to_string()))?;
+        let tx = guard
+            .unchecked_transaction()
+            .map_err(|e| StoreError::Backend(e.to_string()))?;
+        tx.execute(
+            "INSERT OR IGNORE INTO commits (hash, project, branch, parents, okf_hash, author, message, created_at) VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8)",
+            params![commit.hash, commit.project, commit.branch, parents, commit.okf_hash, commit.author, commit.message, commit.created_at],
+        )
+        .map_err(|e| StoreError::Backend(e.to_string()))?;
+        tx.execute(
+            "INSERT INTO branches (project, name, tip) VALUES (?1, ?2, ?3) ON CONFLICT(project, name) DO UPDATE SET tip = ?3",
+            params![commit.project, commit.branch, commit.hash],
+        )
+        .map_err(|e| StoreError::Backend(e.to_string()))?;
+        tx.commit()
+            .map_err(|e| StoreError::Backend(e.to_string()))?;
+        Ok(())
+    }
+
+    fn commit(&self, project: &str, hash: &str) -> Result<Option<Commit>, StoreError> {
+        // The row is read inside the lock and the parents column is parsed outside it, so
+        // that corruption can surface as a storage error rather than a query error.
+        let row: Option<CommitRow> = self.with(|c| {
+                let mut stmt = c.prepare(
+                    "SELECT hash, project, branch, parents, okf_hash, author, message, created_at FROM commits WHERE project = ?1 AND hash = ?2",
+                )?;
+                let mut rows = stmt.query(params![project, hash])?;
+                match rows.next()? {
+                    Some(row) => Ok(Some((
+                        row.get(0)?,
+                        row.get(1)?,
+                        row.get(2)?,
+                        row.get(3)?,
+                        row.get(4)?,
+                        row.get(5)?,
+                        row.get(6)?,
+                        row.get(7)?,
+                    ))),
+                    None => Ok(None),
+                }
+            })?;
+
+        match row {
+            None => Ok(None),
+            Some((hash, project, branch, parents, okf_hash, author, message, created_at)) => {
+                Ok(Some(Commit {
+                    parents: parse_parents(&hash, &parents)?,
+                    hash,
+                    project,
+                    branch,
+                    okf_hash,
+                    author,
+                    message,
+                    created_at,
+                }))
+            }
+        }
+    }
+
+    fn commits_on(&self, project: &str, branch: &str) -> Result<Vec<Commit>, StoreError> {
+        // Rows are collected first and the parents column is parsed afterwards, because a
+        // parse failure inside the query closure could only be reported as a rusqlite
+        // error; corruption must surface as a storage error instead.
+        let rows: Vec<CommitRow> = self.with(|c| {
+            let mut stmt = c.prepare(
+                "SELECT hash, project, branch, parents, okf_hash, author, message, created_at FROM commits WHERE project = ?1 AND branch = ?2 ORDER BY rowid",
+            )?;
+            let rows = stmt.query_map(params![project, branch], |row| {
+                Ok((
+                    row.get(0)?,
+                    row.get(1)?,
+                    row.get(2)?,
+                    row.get(3)?,
+                    row.get(4)?,
+                    row.get(5)?,
+                    row.get(6)?,
+                    row.get(7)?,
+                ))
+            })?;
+            rows.collect()
+        })?;
+
+        let mut commits = Vec::with_capacity(rows.len());
+        for (hash, project, branch, parents, okf_hash, author, message, created_at) in rows {
+            commits.push(Commit {
+                parents: parse_parents(&hash, &parents)?,
+                hash,
+                project,
+                branch,
+                okf_hash,
+                author,
+                message,
+                created_at,
+            });
+        }
+        Ok(commits)
+    }
+
+    fn branch_tip(&self, project: &str, branch: &str) -> Result<Option<String>, StoreError> {
+        self.with(|c| {
+            let mut stmt =
+                c.prepare("SELECT tip FROM branches WHERE project = ?1 AND name = ?2")?;
+            let mut rows = stmt.query(params![project, branch])?;
+            match rows.next()? {
+                Some(row) => Ok(Some(row.get(0)?)),
+                None => Ok(None),
+            }
+        })
+    }
+
+    fn create_branch(&self, project: &str, name: &str, from: &str) -> Result<(), StoreError> {
+        if self.commit(project, from)?.is_none() {
+            return Err(StoreError::NotFound(format!("commit {}", from)));
+        }
+        // The composite primary key decides a duplicate branch, not a prior read.
+        let inserted = self.with(|c| {
+            c.execute(
+                "INSERT OR IGNORE INTO branches (project, name, tip) VALUES (?1, ?2, ?3)",
+                params![project, name, from],
+            )
+        })?;
+        if inserted == 0 {
+            return Err(StoreError::Conflict(format!(
+                "branch {} already exists",
+                name
+            )));
+        }
+        Ok(())
+    }
+
+    fn list_branches(&self, project: &str) -> Result<Vec<(String, String)>, StoreError> {
+        self.with(|c| {
+            let mut stmt =
+                c.prepare("SELECT name, tip FROM branches WHERE project = ?1 ORDER BY name")?;
+            let rows = stmt.query_map(params![project], |row| Ok((row.get(0)?, row.get(1)?)))?;
+            rows.collect()
+        })
+    }
+
+    fn record_gate_run(&self, run: &GateRun) -> Result<(), StoreError> {
+        self.with(|c| {
+            c.execute(
+                "INSERT INTO gate_runs (project, branch, reference_hash, candidate_hash, passed, evidence, created_at) VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7)",
+                params![run.project, run.branch, run.reference_hash, run.candidate_hash, run.passed as i64, run.evidence, run.created_at],
+            )
+        })?;
+        Ok(())
+    }
+
+    fn gate_runs(&self, project: &str) -> Result<Vec<GateRun>, StoreError> {
+        self.with(|c| {
+            let mut stmt = c.prepare(
+                "SELECT project, branch, reference_hash, candidate_hash, passed, evidence, created_at FROM gate_runs WHERE project = ?1 ORDER BY id",
+            )?;
+            let rows = stmt.query_map(params![project], |row| {
+                Ok(GateRun {
+                    project: row.get(0)?,
+                    branch: row.get(1)?,
+                    reference_hash: row.get(2)?,
+                    candidate_hash: row.get(3)?,
+                    passed: row.get::<_, i64>(4)? != 0,
+                    evidence: row.get(5)?,
+                    created_at: row.get(6)?,
+                })
+            })?;
+            rows.collect()
+        })
+    }
+}
diff --git a/server/tests/api.rs b/server/tests/api.rs
new file mode 100644
index 0000000..8c9ec92
--- /dev/null
+++ b/server/tests/api.rs
@@ -0,0 +1,262 @@
+// SPDX-License-Identifier: AGPL-3.0-or-later
+use axum::body::Body;
+use axum::http::{Request, StatusCode};
+use http_body_util::BodyExt;
+use tower::ServiceExt;
+
+fn state(dir: &std::path::Path) -> server::AppState {
+    let store = server::store::sqlite::SqliteStore::open(&dir.join("mw.db")).unwrap();
+    server::AppState {
+        store: std::sync::Arc::new(store),
+        evidence_dir: dir.to_path_buf(),
+    }
+}
+
+fn post(uri: &str, body: serde_json::Value) -> Request<Body> {
+    Request::builder()
+        .method("POST")
+        .uri(uri)
+        .header("content-type", "application/json")
+        .body(Body::from(body.to_string()))
+        .unwrap()
+}
+
+async fn json_body(response: axum::response::Response) -> serde_json::Value {
+    let bytes = response.into_body().collect().await.unwrap().to_bytes();
+    serde_json::from_slice(&bytes).unwrap()
+}
+
+fn tiny_okf() -> serde_json::Value {
+    serde_json::json!({
+        "project": "tiny",
+        "exportedAt": "2026-09-17T00:00:00Z",
+        "summary": {},
+        "stateMachine": { "name": "tiny sm", "regions": [] },
+        "graph": { "nodes": [{ "id": "b1", "kind": "block", "name": "B1" }], "edges": [] }
+    })
+}
+
+#[tokio::test]
+async fn a_project_can_be_created_listed_and_is_not_duplicated() {
+    let dir = tempfile::tempdir().unwrap();
+    let router = server::app(state(dir.path()));
+
+    let created = router
+        .clone()
+        .oneshot(post("/projects", serde_json::json!({ "name": "coffee" })))
+        .await
+        .unwrap();
+    assert_eq!(created.status(), StatusCode::CREATED);
+
+    let duplicate = router
+        .clone()
+        .oneshot(post("/projects", serde_json::json!({ "name": "coffee" })))
+        .await
+        .unwrap();
+    assert_eq!(duplicate.status(), StatusCode::CONFLICT);
+
+    let listed = router
+        .oneshot(
+            Request::builder()
+                .uri("/projects")
+                .body(Body::empty())
+                .unwrap(),
+        )
+        .await
+        .unwrap();
+    let value = json_body(listed).await;
+    assert_eq!(value[0]["name"], "coffee");
+}
+
+#[tokio::test]
+async fn a_commit_stores_the_model_and_moves_the_branch() {
+    let dir = tempfile::tempdir().unwrap();
+    let router = server::app(state(dir.path()));
+    router
+        .clone()
+        .oneshot(post("/projects", serde_json::json!({ "name": "coffee" })))
+        .await
+        .unwrap();
+
+    let committed = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/commits",
+            serde_json::json!({
+                "branch": "main",
+                "author": "alex",
+                "message": "import the model",
+                "okf": tiny_okf()
+            }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(committed.status(), StatusCode::CREATED);
+    let commit = json_body(committed).await;
+    assert!(commit["hash"].as_str().unwrap().len() == 64);
+    assert!(commit["parents"].as_array().unwrap().is_empty());
+
+    let hash = commit["hash"].as_str().unwrap().to_string();
+    let fetched = router
+        .oneshot(
+            Request::builder()
+                .uri(format!("/projects/coffee/commits/{}", hash))
+                .body(Body::empty())
+                .unwrap(),
+        )
+        .await
+        .unwrap();
+    assert_eq!(fetched.status(), StatusCode::OK);
+    // Byte for byte, not structurally: comparing two parsed values would let a
+    // key-reordering or reformatting regression pass unnoticed.
+    let bytes = fetched.into_body().collect().await.unwrap().to_bytes();
+    assert_eq!(
+        bytes.as_ref(),
+        serde_json::to_vec(&tiny_okf()).unwrap().as_slice(),
+        "the stored model must come back byte for byte"
+    );
+}
+
+#[tokio::test]
+async fn an_invalid_model_is_rejected_with_its_errors() {
+    let dir = tempfile::tempdir().unwrap();
+    let router = server::app(state(dir.path()));
+    router
+        .clone()
+        .oneshot(post("/projects", serde_json::json!({ "name": "coffee" })))
+        .await
+        .unwrap();
+
+    let mut okf = tiny_okf();
+    okf["graph"] = serde_json::Value::Null;
+    let rejected = router
+        .oneshot(post(
+            "/projects/coffee/commits",
+            serde_json::json!({
+                "branch": "main",
+                "author": "alex",
+                "message": "broken",
+                "okf": okf
+            }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(rejected.status(), StatusCode::UNPROCESSABLE_ENTITY);
+    let body = json_body(rejected).await;
+    assert!(body["error"]
+        .as_str()
+        .unwrap()
+        .contains("graph section is missing"));
+}
+
+#[tokio::test]
+async fn committing_an_unknown_project_is_not_found() {
+    let dir = tempfile::tempdir().unwrap();
+    let router = server::app(state(dir.path()));
+    let response = router
+        .oneshot(post(
+            "/projects/missing/commits",
+            serde_json::json!({
+                "branch": "main",
+                "author": "alex",
+                "message": "nothing",
+                "okf": tiny_okf()
+            }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(response.status(), StatusCode::NOT_FOUND);
+}
+#[tokio::test]
+async fn branch_creation_reports_unknown_commits_and_duplicates() {
+    let dir = tempfile::tempdir().unwrap();
+    let router = server::app(state(dir.path()));
+    router
+        .clone()
+        .oneshot(post("/projects", serde_json::json!({ "name": "coffee" })))
+        .await
+        .unwrap();
+    let committed = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/commits",
+            serde_json::json!({ "branch": "main", "author": "alex", "message": "m", "okf": tiny_okf() }),
+        ))
+        .await
+        .unwrap();
+    let hash = json_body(committed).await["hash"]
+        .as_str()
+        .unwrap()
+        .to_string();
+
+    let unknown = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/branches",
+            serde_json::json!({ "name": "review", "from": "not-a-commit" }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(unknown.status(), StatusCode::NOT_FOUND);
+
+    let created = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/branches",
+            serde_json::json!({ "name": "review", "from": hash }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(created.status(), StatusCode::CREATED);
+
+    let duplicate = router
+        .oneshot(post(
+            "/projects/coffee/branches",
+            serde_json::json!({ "name": "review", "from": hash }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(duplicate.status(), StatusCode::CONFLICT);
+}
+
+#[tokio::test]
+async fn commits_can_be_listed_per_branch() {
+    let dir = tempfile::tempdir().unwrap();
+    let router = server::app(state(dir.path()));
+    router
+        .clone()
+        .oneshot(post("/projects", serde_json::json!({ "name": "coffee" })))
+        .await
+        .unwrap();
+    router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/commits",
+            serde_json::json!({ "branch": "main", "author": "alex", "message": "m", "okf": tiny_okf() }),
+        ))
+        .await
+        .unwrap();
+
+    let main = router
+        .clone()
+        .oneshot(
+            Request::builder()
+                .uri("/projects/coffee/commits?branch=main")
+                .body(Body::empty())
+                .unwrap(),
+        )
+        .await
+        .unwrap();
+    assert_eq!(json_body(main).await.as_array().unwrap().len(), 1);
+
+    let other = router
+        .oneshot(
+            Request::builder()
+                .uri("/projects/coffee/commits?branch=nothing-here")
+                .body(Body::empty())
+                .unwrap(),
+        )
+        .await
+        .unwrap();
+    assert!(json_body(other).await.as_array().unwrap().is_empty());
+}
diff --git a/server/tests/corpus.rs b/server/tests/corpus.rs
new file mode 100644
index 0000000..8948261
--- /dev/null
+++ b/server/tests/corpus.rs
@@ -0,0 +1,119 @@
+// SPDX-License-Identifier: AGPL-3.0-or-later
+use axum::body::Body;
+use axum::http::{Request, StatusCode};
+use http_body_util::BodyExt;
+use tower::ServiceExt;
+
+fn state(dir: &std::path::Path) -> server::AppState {
+    let store = server::store::sqlite::SqliteStore::open(&dir.join("mw.db")).unwrap();
+    server::AppState {
+        store: std::sync::Arc::new(store),
+        evidence_dir: dir.to_path_buf(),
+    }
+}
+
+fn post(uri: &str, body: serde_json::Value) -> Request<Body> {
+    Request::builder()
+        .method("POST")
+        .uri(uri)
+        .header("content-type", "application/json")
+        .body(Body::from(body.to_string()))
+        .unwrap()
+}
+
+async fn json_body(response: axum::response::Response) -> serde_json::Value {
+    let bytes = response.into_body().collect().await.unwrap().to_bytes();
+    serde_json::from_slice(&bytes).unwrap()
+}
+
+async fn commit(
+    router: &axum::Router,
+    branch: &str,
+    message: &str,
+    okf: serde_json::Value,
+) -> String {
+    let response = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/commits",
+            serde_json::json!({ "branch": branch, "author": "alex", "message": message, "okf": okf }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(response.status(), StatusCode::CREATED);
+    json_body(response).await["hash"]
+        .as_str()
+        .unwrap()
+        .to_string()
+}
+
+#[tokio::test]
+async fn the_corpus_can_be_committed_branched_and_gated() {
+    let dir = tempfile::tempdir().unwrap();
+    let router = server::app(state(dir.path()));
+
+    router
+        .clone()
+        .oneshot(post("/projects", serde_json::json!({ "name": "coffee" })))
+        .await
+        .unwrap();
+
+    let expected: serde_json::Value =
+        serde_json::from_str(&test_support::load_okf_expected()).unwrap();
+    let broken: serde_json::Value = serde_json::from_str(&test_support::load_okf_broken()).unwrap();
+
+    let imported = commit(&router, "main", "import the exported model", expected).await;
+    router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/branches",
+            serde_json::json!({ "name": "corrupted", "from": imported }),
+        ))
+        .await
+        .unwrap();
+    let corrupted = commit(&router, "corrupted", "drop a requirement", broken).await;
+
+    let clean = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/gate",
+            serde_json::json!({ "reference": imported, "candidate": imported }),
+        ))
+        .await
+        .unwrap();
+    let clean = json_body(clean).await;
+    assert_eq!(clean["passed"], true);
+    assert_eq!(clean["integration"]["componentCount"], 1);
+    assert_eq!(clean["coverage"]["total"], 25);
+
+    let lossy = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/gate",
+            serde_json::json!({ "reference": imported, "candidate": corrupted }),
+        ))
+        .await
+        .unwrap();
+    let lossy = json_body(lossy).await;
+    assert_eq!(lossy["passed"], false);
+    let failures: Vec<String> = lossy["failures"]
+        .as_array()
+        .unwrap()
+        .iter()
+        .map(|f| f.as_str().unwrap().to_string())
+        .collect();
+    assert!(failures.iter().any(|f| f.contains("missing elements")));
+    assert!(failures.iter().any(|f| f.contains("isolated")));
+
+    let runs = router
+        .oneshot(
+            Request::builder()
+                .uri("/projects/coffee/gate-runs")
+                .body(Body::empty())
+                .unwrap(),
+        )
+        .await
+        .unwrap();
+    let runs = json_body(runs).await;
+    assert_eq!(runs.as_array().unwrap().len(), 2);
+}
diff --git a/server/tests/gate_api.rs b/server/tests/gate_api.rs
new file mode 100644
index 0000000..360d260
--- /dev/null
+++ b/server/tests/gate_api.rs
@@ -0,0 +1,168 @@
+﻿// SPDX-License-Identifier: AGPL-3.0-or-later
+use axum::body::Body;
+use axum::http::{Request, StatusCode};
+use http_body_util::BodyExt;
+use tower::ServiceExt;
+
+fn state(dir: &std::path::Path) -> server::AppState {
+    let store = server::store::sqlite::SqliteStore::open(&dir.join("mw.db")).unwrap();
+    server::AppState {
+        store: std::sync::Arc::new(store),
+        evidence_dir: dir.to_path_buf(),
+    }
+}
+
+fn post(uri: &str, body: serde_json::Value) -> Request<Body> {
+    Request::builder()
+        .method("POST")
+        .uri(uri)
+        .header("content-type", "application/json")
+        .body(Body::from(body.to_string()))
+        .unwrap()
+}
+
+fn get(uri: &str) -> Request<Body> {
+    Request::builder().uri(uri).body(Body::empty()).unwrap()
+}
+
+async fn json_body(response: axum::response::Response) -> serde_json::Value {
+    let bytes = response.into_body().collect().await.unwrap().to_bytes();
+    serde_json::from_slice(&bytes).unwrap()
+}
+
+fn model(name: &str) -> serde_json::Value {
+    serde_json::json!({
+        "project": name,
+        "exportedAt": "2026-09-17T00:00:00Z",
+        "summary": {},
+        "stateMachine": { "name": "sm", "regions": [] },
+        "graph": {
+            "nodes": [
+                { "id": "b1", "kind": "block", "name": "Block" },
+                { "id": "r1", "kind": "requirement", "name": "Req" }
+            ],
+            "edges": [
+                { "source": "b1", "target": "r1", "kind": "dependency", "label": "Satisfy" }
+            ]
+        },
+        "requirements": [
+            { "id": "r1", "name": "Req", "kind": "requirement", "stereotypes": ["Requirement"], "attributes": [], "documentation": "", "reqId": "1.1", "reqText": "shall satisfy" }
+        ]
+    })
+}
+
+async fn seed_project(router: &axum::Router) -> (String, String) {
+    router
+        .clone()
+        .oneshot(post("/projects", serde_json::json!({ "name": "coffee" })))
+        .await
+        .unwrap();
+
+    let first = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/commits",
+            serde_json::json!({ "branch": "main", "author": "alex", "message": "model", "okf": model("coffee") }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(first.status(), StatusCode::CREATED);
+    let first = json_body(first).await;
+    let reference = first["hash"].as_str().unwrap().to_string();
+
+    let mut changed = model("coffee");
+    changed["project"] = serde_json::json!("coffee v2");
+    let second = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/commits",
+            serde_json::json!({ "branch": "main", "author": "alex", "message": "changed", "okf": changed }),
+        ))
+        .await
+        .unwrap();
+    let second = json_body(second).await;
+    let candidate = second["hash"].as_str().unwrap().to_string();
+
+    (reference, candidate)
+}
+
+#[tokio::test]
+async fn gating_a_commit_against_itself_passes_and_records_evidence() {
+    let dir = tempfile::tempdir().unwrap();
+    let router = server::app(state(dir.path()));
+    let (reference, _candidate) = seed_project(&router).await;
+
+    let response = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/gate",
+            serde_json::json!({ "reference": reference, "candidate": reference }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(response.status(), StatusCode::OK);
+    let evidence = json_body(response).await;
+    assert_eq!(evidence["passed"], true);
+    assert_eq!(evidence["roundtrip"]["equal"], true);
+
+    let files: Vec<_> = std::fs::read_dir(dir.path())
+        .unwrap()
+        .filter_map(|e| e.ok())
+        .map(|e| e.file_name().to_string_lossy().to_string())
+        .filter(|n| n.starts_with("server-"))
+        .collect();
+    assert_eq!(
+        files.len(),
+        1,
+        "expected one evidence file, got {:?}",
+        files
+    );
+}
+
+#[tokio::test]
+async fn gating_a_changed_model_fails_and_is_still_a_successful_run() {
+    let dir = tempfile::tempdir().unwrap();
+    let router = server::app(state(dir.path()));
+    let (reference, candidate) = seed_project(&router).await;
+
+    let response = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/gate",
+            serde_json::json!({ "reference": reference, "candidate": candidate }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(response.status(), StatusCode::OK);
+    let evidence = json_body(response).await;
+    assert_eq!(evidence["passed"], false);
+    assert!(!evidence["roundtrip"]["equal"].as_bool().unwrap());
+    assert!(evidence["failures"]
+        .as_array()
+        .unwrap()
+        .iter()
+        .any(|f| f.as_str().unwrap().contains("roundtrip")));
+
+    let runs = router
+        .oneshot(get("/projects/coffee/gate-runs"))
+        .await
+        .unwrap();
+    let recorded = json_body(runs).await;
+    assert_eq!(recorded.as_array().unwrap().len(), 1);
+    assert_eq!(recorded[0]["passed"], false);
+}
+
+#[tokio::test]
+async fn gating_an_unknown_commit_is_not_found() {
+    let dir = tempfile::tempdir().unwrap();
+    let router = server::app(state(dir.path()));
+    let (reference, _candidate) = seed_project(&router).await;
+    let response = router
+        .oneshot(post(
+            "/projects/coffee/gate",
+            serde_json::json!({ "reference": reference, "candidate": "missing" }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(response.status(), StatusCode::NOT_FOUND);
+}
diff --git a/server/tests/http.rs b/server/tests/http.rs
new file mode 100644
index 0000000..4e697e4
--- /dev/null
+++ b/server/tests/http.rs
@@ -0,0 +1,52 @@
+// SPDX-License-Identifier: AGPL-3.0-or-later
+use axum::body::Body;
+use axum::http::{Request, StatusCode};
+use http_body_util::BodyExt;
+use tower::ServiceExt;
+
+fn state(dir: &std::path::Path) -> server::AppState {
+    let store = server::store::sqlite::SqliteStore::open(&dir.join("mw.db")).unwrap();
+    server::AppState {
+        store: std::sync::Arc::new(store),
+        evidence_dir: dir.to_path_buf(),
+    }
+}
+
+#[tokio::test]
+async fn health_answers_ok() {
+    let dir = tempfile::tempdir().unwrap();
+    let router = server::app(state(dir.path()));
+    let response = router
+        .oneshot(
+            Request::builder()
+                .uri("/health")
+                .body(Body::empty())
+                .unwrap(),
+        )
+        .await
+        .unwrap();
+    assert_eq!(response.status(), StatusCode::OK);
+    let bytes = response.into_body().collect().await.unwrap().to_bytes();
+    let value: serde_json::Value = serde_json::from_slice(&bytes).unwrap();
+    assert_eq!(value["status"], "ok");
+}
+
+#[tokio::test]
+async fn version_names_the_service() {
+    let dir = tempfile::tempdir().unwrap();
+    let router = server::app(state(dir.path()));
+    let response = router
+        .oneshot(
+            Request::builder()
+                .uri("/version")
+                .body(Body::empty())
+                .unwrap(),
+        )
+        .await
+        .unwrap();
+    assert_eq!(response.status(), StatusCode::OK);
+    let bytes = response.into_body().collect().await.unwrap().to_bytes();
+    let value: serde_json::Value = serde_json::from_slice(&bytes).unwrap();
+    assert_eq!(value["service"], "mw-server");
+    assert_eq!(value["server"], env!("CARGO_PKG_VERSION"));
+}
diff --git a/server/tests/store.rs b/server/tests/store.rs
new file mode 100644
index 0000000..4e0ae8f
--- /dev/null
+++ b/server/tests/store.rs
@@ -0,0 +1,87 @@
+// SPDX-License-Identifier: AGPL-3.0-or-later
+use server::store::{commit_hash, sqlite::SqliteStore, Commit, Store, StoreError};
+
+fn store() -> (SqliteStore, tempfile::TempDir) {
+    let dir = tempfile::tempdir().unwrap();
+    let store = SqliteStore::open(&dir.path().join("mw.db")).unwrap();
+    (store, dir)
+}
+
+fn commit_for(project: &str, branch: &str, okf_hash: &str) -> Commit {
+    let parents: Vec<String> = vec![];
+    let hash = commit_hash(project, branch, &parents, okf_hash, "alex", "first commit");
+    Commit {
+        hash,
+        project: project.to_string(),
+        branch: branch.to_string(),
+        parents,
+        okf_hash: okf_hash.to_string(),
+        author: "alex".to_string(),
+        message: "first commit".to_string(),
+        created_at: "0".to_string(),
+    }
+}
+
+#[test]
+fn blobs_are_content_addressed() {
+    let (store, _dir) = store();
+    let a = store.put_blob(b"{\"model\":1}").unwrap();
+    let b = store.put_blob(b"{\"model\":1}").unwrap();
+    let c = store.put_blob(b"{\"model\":2}").unwrap();
+    assert_eq!(a, b, "identical bytes must share an address");
+    assert_ne!(a, c);
+    assert_eq!(store.blob(&a).unwrap().unwrap(), b"{\"model\":1}");
+}
+
+#[test]
+fn a_commit_hash_ignores_time_but_not_content() {
+    let parents = vec!["p1".to_string()];
+    let a = commit_hash("p", "main", &parents, "okf1", "alex", "m");
+    let b = commit_hash("p", "main", &parents, "okf1", "alex", "m");
+    let c = commit_hash("p", "main", &parents, "okf2", "alex", "m");
+    assert_eq!(a, b);
+    assert_ne!(a, c);
+}
+
+#[test]
+fn commits_land_on_a_branch_and_move_its_tip() {
+    let (store, _dir) = store();
+    store.create_project("coffee").unwrap();
+    let first = commit_for("coffee", "main", "okf1");
+    store.append_commit(&first).unwrap();
+    assert_eq!(
+        store.branch_tip("coffee", "main").unwrap().unwrap(),
+        first.hash
+    );
+
+    let second = commit_for("coffee", "main", "okf2");
+    store.append_commit(&second).unwrap();
+    assert_eq!(
+        store.branch_tip("coffee", "main").unwrap().unwrap(),
+        second.hash
+    );
+    assert_eq!(store.commits_on("coffee", "main").unwrap().len(), 2);
+}
+
+#[test]
+fn duplicate_projects_and_branches_are_conflicts() {
+    let (store, _dir) = store();
+    store.create_project("coffee").unwrap();
+    match store.create_project("coffee") {
+        Err(StoreError::Conflict(_)) => {}
+        other => panic!("expected a conflict, got {:?}", other),
+    }
+    let commit = commit_for("coffee", "main", "okf1");
+    store.append_commit(&commit).unwrap();
+    store
+        .create_branch("coffee", "review", &commit.hash)
+        .unwrap();
+    match store.create_branch("coffee", "review", &commit.hash) {
+        Err(StoreError::Conflict(_)) => {}
+        other => panic!("expected a conflict, got {:?}", other),
+    }
+    match store.create_branch("coffee", "other", "missing-commit") {
+        Err(StoreError::NotFound(_)) => {}
+        other => panic!("expected not found, got {:?}", other),
+    }
+}
