# Task 1 Report: The service skeleton

## Status

DONE

## Commits

- `818a9cc` feat: add the repository service skeleton

## Test summary

`cargo test -p mw-server --no-fail-fast`: 2 passed, 0 failed (lib 0, bin 0, integration tests/http.rs 2, doc-tests 0).

## Verification

- `cargo test -p mw-server --no-fail-fast` — 2 tests pass (health_answers_ok, version_names_the_service).
- `cargo fmt --all` — clean (exit 0).
- `cargo clippy -p mw-server --all-targets -- -D warnings` — clean (exit 0).
- Crate builds as both a lib (`server`) and a binary (`mw-server`); both targets compiled in the test run.
- Tests drive the router in-process via `tower::ServiceExt::oneshot` against `server::app(...)`; no port is bound in tests.
- `git status` after commit shows only the untracked `.superpowers/` directory (intentionally not staged); no other stray files.
- Commit touches exactly `Cargo.toml`, `Cargo.lock`, and `server/` (5 files: Cargo.toml, src/error.rs, src/lib.rs, src/main.rs, tests/http.rs). `engine/`, `judge/`, `sample/`, `docs/`, and `collateral/` are untouched.

## Files

- `Cargo.toml` (modified) — added `"server"` to members; added axum, tokio, rusqlite, tower, http-body-util, tempfile to `[workspace.dependencies]`.
- `Cargo.lock` (modified) — 68 packages added (resolved).
- `server/Cargo.toml` — package `mw-server` 0.1.0, edition/rust-version/license inherited from workspace, publish = false; lib `server`, bin `mw-server`.
- `server/src/error.rs` — `ApiError` with bad_request/not_found/conflict/unprocessable/internal and `IntoResponse` returning `(StatusCode, Json({"error": ...}))`.
- `server/src/lib.rs` — `AppState { evidence_dir }`, `app(state) -> Router` with `/health` and `/version` routes.
- `server/src/main.rs` — `mw-server` binary on 127.0.0.1:8080 (MW_PORT overridable), evidence dir from MW_EVIDENCE_DIR (default docs/evidence).
- `server/tests/http.rs` — two in-process tests.

All source files carry the `// SPDX-License-Identifier: AGPL-3.0-or-later` header.

## Dependencies

All brief-specified dependency versions resolved without manual intervention: axum 0.7.9, tokio 1.53.1, rusqlite 0.31.0 (bundled), tower 0.4.13, http-body-util 0.1.5, tempfile 3.27.0.

## Deviations from brief

None.

## Concerns

None.
