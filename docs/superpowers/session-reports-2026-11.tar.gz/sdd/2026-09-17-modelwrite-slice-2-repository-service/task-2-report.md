# Task 2 Report: The model store (trait plus SQLite backend)

## Status

DONE_WITH_CONCERNS

## Commits

- `9b9a03e` feat: add the content-addressed model store

## Test summary

`cargo test -p mw-server --no-fail-fast`: 6 passed, 0 failed (lib 0, bin 0, integration tests/http.rs 2, integration tests/store.rs 4, doc-tests 0).

## Verification

- `cargo test -p mw-server --no-fail-fast` — 6 tests pass (2 from Task 1, 4 store tests); cargo exit code 0.
- `cargo fmt --all -- --check` — clean (exit 0) across the whole workspace.
- `cargo clippy -p mw-server --all-targets -- -D warnings` — clean (exit 0).
- Commit `9b9a03e` touches exactly 4 files under `server/`: `src/lib.rs` (+1: `pub mod store;`), `src/store/mod.rs`, `src/store/sqlite.rs`, `tests/store.rs`. `Cargo.toml`/`Cargo.lock` are unchanged (rusqlite/sha2/hex/serde_json/anyhow/tempfile were already declared in Task 1). `engine/`, `judge/`, `sample/`, `docs/`, `collateral/` are untouched.

## Self-review

- SPDX header present on all three new files and on the modified `src/lib.rs`.
- `SCHEMA` creates every table the trait touches — `projects`, `blobs`, `commits`, `branches`, `gate_runs` — plus the `commits_by_project_branch` index.
- `Store` is `Send + Sync`; `SqliteStore` wraps `rusqlite::Connection` (Send, not Sync) in a `std::sync::Mutex`.
- No panic path in the store: `with` maps a poisoned lock to `StoreError::Backend` (never `.unwrap()`); the only `expect` is `serde_json::to_vec` on a `json!` value of strings/arrays, which cannot fail.
- Content addressing is asserted by tests: `blobs_are_content_addressed` (identical bytes share an address, different bytes differ, blob round-trips) and `a_commit_hash_ignores_time_but_not_content` (hash stable across calls, changes with content).
- No test weakened: the four store tests are verbatim from the brief.

## Deviation from brief

- Staged the four Task 2 files explicitly (`git add Cargo.toml Cargo.lock server/src/lib.rs server/src/store server/tests/store.rs`) rather than the brief's `git add ... server`. Reason: an unaccounted modification to `server/tests/http.rs` appeared in the working tree during the session (see Concerns). To keep this commit scoped to Task 2 and avoid capturing work I did not author, `server/tests/http.rs` was left uncommitted.

## Concerns

- `server/tests/http.rs` gained one line during the session — `assert_eq!(value["server"], env!("CARGO_PKG_VERSION"));` — that I did not author. It is absent from every slice-2 task brief (Task 1's brief and its committed version assert only `value["service"] == "mw-server"`), and the working tree was clean at session start (`git status` showed only `.superpowers/`). This indicates concurrent modification of the shared working tree by another agent or process. I left it uncommitted (the tree still shows ` M server/tests/http.rs`). The line is a harmless test strengthening and all 6 tests pass with it present, but its provenance is unknown and should be reconciled by the orchestrator.
