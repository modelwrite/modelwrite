﻿# Slice 2 Task 2 review package

## Commit

9b9a03e feat: add the content-addressed model store

## Diff stat

 server/src/lib.rs          |   1 +
 server/src/store/mod.rs    | 109 ++++++++++++++++++
 server/src/store/sqlite.rs | 272 +++++++++++++++++++++++++++++++++++++++++++++
 server/tests/store.rs      |  87 +++++++++++++++
 4 files changed, 469 insertions(+)

## Full diff (-U10)

diff --git a/server/src/lib.rs b/server/src/lib.rs
index 8f57321..ea8b28b 100644
--- a/server/src/lib.rs
+++ b/server/src/lib.rs
@@ -1,12 +1,13 @@
 // SPDX-License-Identifier: AGPL-3.0-or-later
 pub mod error;
+pub mod store;
 
 use std::path::PathBuf;
 use std::sync::Arc;
 
 use axum::routing::get;
 use axum::{Json, Router};
 use serde_json::json;
 
 pub use error::ApiError;
 
diff --git a/server/src/store/mod.rs b/server/src/store/mod.rs
new file mode 100644
index 0000000..d31150b
--- /dev/null
+++ b/server/src/store/mod.rs
@@ -0,0 +1,109 @@
+// SPDX-License-Identifier: AGPL-3.0-or-later
+use sha2::{Digest, Sha256};
+
+pub mod sqlite;
+
+#[derive(Debug, Clone, PartialEq)]
+pub struct Project {
+    pub name: String,
+    pub created_at: String,
+}
+
+#[derive(Debug, Clone, PartialEq)]
+pub struct Commit {
+    pub hash: String,
+    pub project: String,
+    pub branch: String,
+    pub parents: Vec<String>,
+    pub okf_hash: String,
+    pub author: String,
+    pub message: String,
+    pub created_at: String,
+}
+
+#[derive(Debug, Clone, PartialEq)]
+pub struct GateRun {
+    pub project: String,
+    pub branch: String,
+    pub reference_hash: String,
+    pub candidate_hash: String,
+    pub passed: bool,
+    pub evidence: String,
+    pub created_at: String,
+}
+
+#[derive(Debug)]
+pub enum StoreError {
+    NotFound(String),
+    Conflict(String),
+    Backend(String),
+}
+
+impl std::fmt::Display for StoreError {
+    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
+        match self {
+            StoreError::NotFound(m) => write!(f, "not found: {}", m),
+            StoreError::Conflict(m) => write!(f, "conflict: {}", m),
+            StoreError::Backend(m) => write!(f, "storage error: {}", m),
+        }
+    }
+}
+
+impl std::error::Error for StoreError {}
+
+/// Content address of a model: sha256 over the exact bytes stored. The same document
+/// always has the same address, so a re-export that changed nothing is a no-op.
+pub fn blob_hash(bytes: &[u8]) -> String {
+    let mut hasher = Sha256::new();
+    hasher.update(bytes);
+    hex::encode(hasher.finalize())
+}
+
+/// Content address of a commit: sha256 over a canonical JSON payload of everything
+/// that defines it except time. Two identical commits made at different moments hash
+/// the same, which is what makes a commit reproducible and its evidence citable.
+pub fn commit_hash(
+    project: &str,
+    branch: &str,
+    parents: &[String],
+    okf_hash: &str,
+    author: &str,
+    message: &str,
+) -> String {
+    let mut sorted_parents: Vec<&str> = parents.iter().map(|p| p.as_str()).collect();
+    sorted_parents.sort_unstable();
+    let payload = serde_json::json!({
+        "project": project,
+        "branch": branch,
+        "parents": sorted_parents,
+        "okfHash": okf_hash,
+        "author": author,
+        "message": message
+    });
+    let bytes = serde_json::to_vec(&payload).expect("commit payload serializes");
+    blob_hash(&bytes)
+}
+
+/// Seconds since the epoch, stored beside a commit and never inside its hash.
+pub fn now_epoch() -> String {
+    match std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH) {
+        Ok(d) => d.as_secs().to_string(),
+        Err(_) => "0".to_string(),
+    }
+}
+
+pub trait Store: Send + Sync {
+    fn create_project(&self, name: &str) -> Result<Project, StoreError>;
+    fn project(&self, name: &str) -> Result<Option<Project>, StoreError>;
+    fn list_projects(&self) -> Result<Vec<Project>, StoreError>;
+    fn put_blob(&self, bytes: &[u8]) -> Result<String, StoreError>;
+    fn blob(&self, hash: &str) -> Result<Option<Vec<u8>>, StoreError>;
+    fn append_commit(&self, commit: &Commit) -> Result<(), StoreError>;
+    fn commit(&self, project: &str, hash: &str) -> Result<Option<Commit>, StoreError>;
+    fn commits_on(&self, project: &str, branch: &str) -> Result<Vec<Commit>, StoreError>;
+    fn branch_tip(&self, project: &str, branch: &str) -> Result<Option<String>, StoreError>;
+    fn create_branch(&self, project: &str, name: &str, from: &str) -> Result<(), StoreError>;
+    fn list_branches(&self, project: &str) -> Result<Vec<(String, String)>, StoreError>;
+    fn record_gate_run(&self, run: &GateRun) -> Result<(), StoreError>;
+    fn gate_runs(&self, project: &str) -> Result<Vec<GateRun>, StoreError>;
+}
diff --git a/server/src/store/sqlite.rs b/server/src/store/sqlite.rs
new file mode 100644
index 0000000..9ae192a
--- /dev/null
+++ b/server/src/store/sqlite.rs
@@ -0,0 +1,272 @@
+// SPDX-License-Identifier: AGPL-3.0-or-later
+use std::path::Path;
+
+use rusqlite::{params, Connection};
+
+use super::{now_epoch, Commit, GateRun, Project, Store, StoreError};
+
+const SCHEMA: &str = "
+CREATE TABLE IF NOT EXISTS projects (
+    name TEXT PRIMARY KEY,
+    created_at TEXT NOT NULL
+);
+CREATE TABLE IF NOT EXISTS blobs (
+    hash TEXT PRIMARY KEY,
+    bytes BLOB NOT NULL
+);
+CREATE TABLE IF NOT EXISTS commits (
+    hash TEXT PRIMARY KEY,
+    project TEXT NOT NULL,
+    branch TEXT NOT NULL,
+    parents TEXT NOT NULL,
+    okf_hash TEXT NOT NULL,
+    author TEXT NOT NULL,
+    message TEXT NOT NULL,
+    created_at TEXT NOT NULL
+);
+CREATE INDEX IF NOT EXISTS commits_by_project_branch ON commits (project, branch);
+CREATE TABLE IF NOT EXISTS branches (
+    project TEXT NOT NULL,
+    name TEXT NOT NULL,
+    tip TEXT NOT NULL,
+    PRIMARY KEY (project, name)
+);
+CREATE TABLE IF NOT EXISTS gate_runs (
+    id INTEGER PRIMARY KEY AUTOINCREMENT,
+    project TEXT NOT NULL,
+    branch TEXT NOT NULL,
+    reference_hash TEXT NOT NULL,
+    candidate_hash TEXT NOT NULL,
+    passed INTEGER NOT NULL,
+    evidence TEXT NOT NULL,
+    created_at TEXT NOT NULL
+);
+";
+
+pub struct SqliteStore {
+    connection: std::sync::Mutex<Connection>,
+}
+
+impl SqliteStore {
+    pub fn open(path: &Path) -> anyhow::Result<Self> {
+        let connection = Connection::open(path)?;
+        connection.execute_batch(SCHEMA)?;
+        Ok(Self {
+            connection: std::sync::Mutex::new(connection),
+        })
+    }
+
+    fn with<T>(&self, f: impl FnOnce(&Connection) -> rusqlite::Result<T>) -> Result<T, StoreError> {
+        let guard = self
+            .connection
+            .lock()
+            .map_err(|_| StoreError::Backend("connection lock poisoned".to_string()))?;
+        f(&guard).map_err(|e| StoreError::Backend(e.to_string()))
+    }
+}
+
+impl Store for SqliteStore {
+    fn create_project(&self, name: &str) -> Result<Project, StoreError> {
+        if self.project(name)?.is_some() {
+            return Err(StoreError::Conflict(format!(
+                "project {} already exists",
+                name
+            )));
+        }
+        let created_at = now_epoch();
+        self.with(|c| {
+            c.execute(
+                "INSERT INTO projects (name, created_at) VALUES (?1, ?2)",
+                params![name, created_at],
+            )
+        })?;
+        Ok(Project {
+            name: name.to_string(),
+            created_at,
+        })
+    }
+
+    fn project(&self, name: &str) -> Result<Option<Project>, StoreError> {
+        self.with(|c| {
+            let mut stmt = c.prepare("SELECT name, created_at FROM projects WHERE name = ?1")?;
+            let mut rows = stmt.query(params![name])?;
+            match rows.next()? {
+                Some(row) => Ok(Some(Project {
+                    name: row.get(0)?,
+                    created_at: row.get(1)?,
+                })),
+                None => Ok(None),
+            }
+        })
+    }
+
+    fn list_projects(&self) -> Result<Vec<Project>, StoreError> {
+        self.with(|c| {
+            let mut stmt = c.prepare("SELECT name, created_at FROM projects ORDER BY name")?;
+            let rows = stmt.query_map([], |row| {
+                Ok(Project {
+                    name: row.get(0)?,
+                    created_at: row.get(1)?,
+                })
+            })?;
+            rows.collect()
+        })
+    }
+
+    fn put_blob(&self, bytes: &[u8]) -> Result<String, StoreError> {
+        let hash = super::blob_hash(bytes);
+        self.with(|c| {
+            c.execute(
+                "INSERT OR IGNORE INTO blobs (hash, bytes) VALUES (?1, ?2)",
+                params![hash, bytes],
+            )
+        })?;
+        Ok(hash)
+    }
+
+    fn blob(&self, hash: &str) -> Result<Option<Vec<u8>>, StoreError> {
+        self.with(|c| {
+            let mut stmt = c.prepare("SELECT bytes FROM blobs WHERE hash = ?1")?;
+            let mut rows = stmt.query(params![hash])?;
+            match rows.next()? {
+                Some(row) => Ok(Some(row.get(0)?)),
+                None => Ok(None),
+            }
+        })
+    }
+
+    fn append_commit(&self, commit: &Commit) -> Result<(), StoreError> {
+        let parents = serde_json::to_string(&commit.parents)
+            .map_err(|e| StoreError::Backend(e.to_string()))?;
+        self.with(|c| {
+            c.execute(
+                "INSERT OR IGNORE INTO commits (hash, project, branch, parents, okf_hash, author, message, created_at) VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8)",
+                params![commit.hash, commit.project, commit.branch, parents, commit.okf_hash, commit.author, commit.message, commit.created_at],
+            )
+        })?;
+        self.with(|c| {
+            c.execute(
+                "INSERT INTO branches (project, name, tip) VALUES (?1, ?2, ?3) ON CONFLICT(project, name) DO UPDATE SET tip = ?3",
+                params![commit.project, commit.branch, commit.hash],
+            )
+        })?;
+        Ok(())
+    }
+
+    fn commit(&self, project: &str, hash: &str) -> Result<Option<Commit>, StoreError> {
+        self.with(|c| {
+            let mut stmt = c.prepare(
+                "SELECT hash, project, branch, parents, okf_hash, author, message, created_at FROM commits WHERE project = ?1 AND hash = ?2",
+            )?;
+            let mut rows = stmt.query(params![project, hash])?;
+            match rows.next()? {
+                Some(row) => {
+                    let parents: String = row.get(3)?;
+                    Ok(Some(Commit {
+                        hash: row.get(0)?,
+                        project: row.get(1)?,
+                        branch: row.get(2)?,
+                        parents: serde_json::from_str(&parents).unwrap_or_default(),
+                        okf_hash: row.get(4)?,
+                        author: row.get(5)?,
+                        message: row.get(6)?,
+                        created_at: row.get(7)?,
+                    }))
+                }
+                None => Ok(None),
+            }
+        })
+    }
+
+    fn commits_on(&self, project: &str, branch: &str) -> Result<Vec<Commit>, StoreError> {
+        self.with(|c| {
+            let mut stmt = c.prepare(
+                "SELECT hash, project, branch, parents, okf_hash, author, message, created_at FROM commits WHERE project = ?1 AND branch = ?2 ORDER BY rowid",
+            )?;
+            let rows = stmt.query_map(params![project, branch], |row| {
+                let parents: String = row.get(3)?;
+                Ok(Commit {
+                    hash: row.get(0)?,
+                    project: row.get(1)?,
+                    branch: row.get(2)?,
+                    parents: serde_json::from_str(&parents).unwrap_or_default(),
+                    okf_hash: row.get(4)?,
+                    author: row.get(5)?,
+                    message: row.get(6)?,
+                    created_at: row.get(7)?,
+                })
+            })?;
+            rows.collect()
+        })
+    }
+
+    fn branch_tip(&self, project: &str, branch: &str) -> Result<Option<String>, StoreError> {
+        self.with(|c| {
+            let mut stmt =
+                c.prepare("SELECT tip FROM branches WHERE project = ?1 AND name = ?2")?;
+            let mut rows = stmt.query(params![project, branch])?;
+            match rows.next()? {
+                Some(row) => Ok(Some(row.get(0)?)),
+                None => Ok(None),
+            }
+        })
+    }
+
+    fn create_branch(&self, project: &str, name: &str, from: &str) -> Result<(), StoreError> {
+        if self.branch_tip(project, name)?.is_some() {
+            return Err(StoreError::Conflict(format!(
+                "branch {} already exists",
+                name
+            )));
+        }
+        if self.commit(project, from)?.is_none() {
+            return Err(StoreError::NotFound(format!("commit {}", from)));
+        }
+        self.with(|c| {
+            c.execute(
+                "INSERT INTO branches (project, name, tip) VALUES (?1, ?2, ?3)",
+                params![project, name, from],
+            )
+        })?;
+        Ok(())
+    }
+
+    fn list_branches(&self, project: &str) -> Result<Vec<(String, String)>, StoreError> {
+        self.with(|c| {
+            let mut stmt =
+                c.prepare("SELECT name, tip FROM branches WHERE project = ?1 ORDER BY name")?;
+            let rows = stmt.query_map(params![project], |row| Ok((row.get(0)?, row.get(1)?)))?;
+            rows.collect()
+        })
+    }
+
+    fn record_gate_run(&self, run: &GateRun) -> Result<(), StoreError> {
+        self.with(|c| {
+            c.execute(
+                "INSERT INTO gate_runs (project, branch, reference_hash, candidate_hash, passed, evidence, created_at) VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7)",
+                params![run.project, run.branch, run.reference_hash, run.candidate_hash, run.passed as i64, run.evidence, run.created_at],
+            )
+        })?;
+        Ok(())
+    }
+
+    fn gate_runs(&self, project: &str) -> Result<Vec<GateRun>, StoreError> {
+        self.with(|c| {
+            let mut stmt = c.prepare(
+                "SELECT project, branch, reference_hash, candidate_hash, passed, evidence, created_at FROM gate_runs WHERE project = ?1 ORDER BY id",
+            )?;
+            let rows = stmt.query_map(params![project], |row| {
+                Ok(GateRun {
+                    project: row.get(0)?,
+                    branch: row.get(1)?,
+                    reference_hash: row.get(2)?,
+                    candidate_hash: row.get(3)?,
+                    passed: row.get::<_, i64>(4)? != 0,
+                    evidence: row.get(5)?,
+                    created_at: row.get(6)?,
+                })
+            })?;
+            rows.collect()
+        })
+    }
+}
diff --git a/server/tests/store.rs b/server/tests/store.rs
new file mode 100644
index 0000000..4e0ae8f
--- /dev/null
+++ b/server/tests/store.rs
@@ -0,0 +1,87 @@
+// SPDX-License-Identifier: AGPL-3.0-or-later
+use server::store::{commit_hash, sqlite::SqliteStore, Commit, Store, StoreError};
+
+fn store() -> (SqliteStore, tempfile::TempDir) {
+    let dir = tempfile::tempdir().unwrap();
+    let store = SqliteStore::open(&dir.path().join("mw.db")).unwrap();
+    (store, dir)
+}
+
+fn commit_for(project: &str, branch: &str, okf_hash: &str) -> Commit {
+    let parents: Vec<String> = vec![];
+    let hash = commit_hash(project, branch, &parents, okf_hash, "alex", "first commit");
+    Commit {
+        hash,
+        project: project.to_string(),
+        branch: branch.to_string(),
+        parents,
+        okf_hash: okf_hash.to_string(),
+        author: "alex".to_string(),
+        message: "first commit".to_string(),
+        created_at: "0".to_string(),
+    }
+}
+
+#[test]
+fn blobs_are_content_addressed() {
+    let (store, _dir) = store();
+    let a = store.put_blob(b"{\"model\":1}").unwrap();
+    let b = store.put_blob(b"{\"model\":1}").unwrap();
+    let c = store.put_blob(b"{\"model\":2}").unwrap();
+    assert_eq!(a, b, "identical bytes must share an address");
+    assert_ne!(a, c);
+    assert_eq!(store.blob(&a).unwrap().unwrap(), b"{\"model\":1}");
+}
+
+#[test]
+fn a_commit_hash_ignores_time_but_not_content() {
+    let parents = vec!["p1".to_string()];
+    let a = commit_hash("p", "main", &parents, "okf1", "alex", "m");
+    let b = commit_hash("p", "main", &parents, "okf1", "alex", "m");
+    let c = commit_hash("p", "main", &parents, "okf2", "alex", "m");
+    assert_eq!(a, b);
+    assert_ne!(a, c);
+}
+
+#[test]
+fn commits_land_on_a_branch_and_move_its_tip() {
+    let (store, _dir) = store();
+    store.create_project("coffee").unwrap();
+    let first = commit_for("coffee", "main", "okf1");
+    store.append_commit(&first).unwrap();
+    assert_eq!(
+        store.branch_tip("coffee", "main").unwrap().unwrap(),
+        first.hash
+    );
+
+    let second = commit_for("coffee", "main", "okf2");
+    store.append_commit(&second).unwrap();
+    assert_eq!(
+        store.branch_tip("coffee", "main").unwrap().unwrap(),
+        second.hash
+    );
+    assert_eq!(store.commits_on("coffee", "main").unwrap().len(), 2);
+}
+
+#[test]
+fn duplicate_projects_and_branches_are_conflicts() {
+    let (store, _dir) = store();
+    store.create_project("coffee").unwrap();
+    match store.create_project("coffee") {
+        Err(StoreError::Conflict(_)) => {}
+        other => panic!("expected a conflict, got {:?}", other),
+    }
+    let commit = commit_for("coffee", "main", "okf1");
+    store.append_commit(&commit).unwrap();
+    store
+        .create_branch("coffee", "review", &commit.hash)
+        .unwrap();
+    match store.create_branch("coffee", "review", &commit.hash) {
+        Err(StoreError::Conflict(_)) => {}
+        other => panic!("expected a conflict, got {:?}", other),
+    }
+    match store.create_branch("coffee", "other", "missing-commit") {
+        Err(StoreError::NotFound(_)) => {}
+        other => panic!("expected not found, got {:?}", other),
+    }
+}
