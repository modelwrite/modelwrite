﻿# Tranche review re-review package (the three Important fixes)

## Commits

47c50f3 fix: commit atomically, validate names, and stop leaking internals in 500s

## Diff stat

 server/src/api.rs          | 101 ++++++++++++++++++++++++++++-----------------
 server/src/gate_api.rs     |   8 ++--
 server/src/store/mod.rs    |  15 +++++++
 server/src/store/sqlite.rs |  59 ++++++++++++++++++++++++++
 server/tests/api.rs        |  29 +++++++++++++
 server/tests/store.rs      |  42 +++++++++++++++++++
 6 files changed, 213 insertions(+), 41 deletions(-)

## Full diff (-U10)

diff --git a/server/src/api.rs b/server/src/api.rs
index d424535..f3c997e 100644
--- a/server/src/api.rs
+++ b/server/src/api.rs
@@ -1,33 +1,73 @@
 // SPDX-License-Identifier: AGPL-3.0-or-later
 use std::sync::Arc;
 
 use axum::extract::{Path, Query, State};
 use axum::http::StatusCode;
 use axum::Json;
 use serde::Deserialize;
 use serde_json::{json, Value};
 
 use crate::error::ApiError;
-use crate::store::{commit_hash, now_epoch, Commit, Store, StoreError};
+use crate::store::{Commit, Store, StoreError};
 
 #[derive(Clone)]
 pub struct ApiState {
     pub store: Arc<dyn Store>,
     pub evidence_dir: std::path::PathBuf,
 }
 
+/// A name that is safe as a URL segment and as a file name component. Project and
+/// branch names end up in the evidence file path, so an unrestricted name could contain
+/// a separator and write outside the evidence directory.
+pub fn validate_name(kind: &str, name: &str) -> Result<(), ApiError> {
+    if name.is_empty() {
+        return Err(ApiError::bad_request(format!("{} must not be empty", kind)));
+    }
+    if name.len() > 64 {
+        return Err(ApiError::bad_request(format!(
+            "{} must be 64 characters or fewer",
+            kind
+        )));
+    }
+    if !name
+        .chars()
+        .all(|c| c.is_ascii_alphanumeric() || matches!(c, '.' | '_' | '-'))
+    {
+        return Err(ApiError::bad_request(format!(
+            "{} may contain only letters, digits, dot, underscore and hyphen",
+            kind
+        )));
+    }
+    // Dots are allowed (coffee-machine.v2), which means ".." and "." pass the charset
+    // check while being the very thing a path must never contain. Requiring one letter or
+    // digit excludes them without narrowing the usable names.
+    if !name.chars().any(|c| c.is_ascii_alphanumeric()) {
+        return Err(ApiError::bad_request(format!(
+            "{} must contain at least one letter or digit",
+            kind
+        )));
+    }
+    Ok(())
+}
+
+/// Storage failures are logged with their detail and reported to the caller as a generic
+/// internal error: the detail names schema objects and hashes, which is not the client's
+/// business once this stops binding to localhost.
 pub fn map_store_error(e: StoreError) -> ApiError {
     match e {
         StoreError::NotFound(m) => ApiError::not_found(m),
         StoreError::Conflict(m) => ApiError::conflict(m),
-        StoreError::Backend(m) => ApiError::internal(m),
+        StoreError::Backend(m) => {
+            eprintln!("storage error: {}", m);
+            ApiError::internal("internal storage error")
+        }
     }
 }
 
 fn commit_json(commit: &Commit) -> Value {
     json!({
         "hash": commit.hash,
         "project": commit.project,
         "branch": commit.branch,
         "parents": commit.parents,
         "okfHash": commit.okf_hash,
@@ -39,23 +79,21 @@ fn commit_json(commit: &Commit) -> Value {
 
 #[derive(Deserialize)]
 pub struct CreateProject {
     pub name: String,
 }
 
 pub async fn create_project(
     State(state): State<ApiState>,
     Json(body): Json<CreateProject>,
 ) -> Result<(StatusCode, Json<Value>), ApiError> {
-    if body.name.trim().is_empty() {
-        return Err(ApiError::bad_request("project name must not be empty"));
-    }
+    validate_name("project name", &body.name)?;
     let project = state
         .store
         .create_project(&body.name)
         .map_err(map_store_error)?;
     Ok((
         StatusCode::CREATED,
         Json(json!({ "name": project.name, "createdAt": project.created_at })),
     ))
 }
 
@@ -82,65 +120,48 @@ pub async fn create_commit(
     Json(body): Json<CreateCommit>,
 ) -> Result<(StatusCode, Json<Value>), ApiError> {
     if state
         .store
         .project(&project)
         .map_err(map_store_error)?
         .is_none()
     {
         return Err(ApiError::not_found(format!("project {}", project)));
     }
-    if body.branch.trim().is_empty() {
-        return Err(ApiError::bad_request("branch must not be empty"));
-    }
+    validate_name("branch name", &body.branch)?;
 
     // The document must be a valid OKF model before it is stored: a repository that
     // accepts invalid models cannot be gated meaningfully.
     let bytes = serde_json::to_vec(&body.okf).map_err(|e| ApiError::bad_request(e.to_string()))?;
     let root: okf::types::OkfRoot = serde_json::from_slice(&bytes)
         .map_err(|e| ApiError::bad_request(format!("not an OKF document: {}", e)))?;
     let report = okf::validate::validate(&root);
     if !report.valid {
         return Err(ApiError::unprocessable(
             "the model failed validation",
             report.errors,
         ));
     }
 
     let okf_hash = state.store.put_blob(&bytes).map_err(map_store_error)?;
-    let parents: Vec<String> = state
-        .store
-        .branch_tip(&project, &body.branch)
-        .map_err(map_store_error)?
-        .into_iter()
-        .collect();
-    let hash = commit_hash(
-        &project,
-        &body.branch,
-        &parents,
-        &okf_hash,
-        &body.author,
-        &body.message,
-    );
-    let commit = Commit {
-        hash: hash.clone(),
-        project: project.clone(),
-        branch: body.branch.clone(),
-        parents: parents.clone(),
-        okf_hash,
-        author: body.author,
-        message: body.message,
-        created_at: now_epoch(),
-    };
-    state
+    // One call, one transaction: the parents come from the tip the store reads inside the
+    // same lock that writes the commit, so two concurrent commits to one branch chain
+    // instead of forking the history.
+    let commit = state
         .store
-        .append_commit(&commit)
+        .commit_model(
+            &project,
+            &body.branch,
+            &okf_hash,
+            &body.author,
+            &body.message,
+        )
         .map_err(map_store_error)?;
     Ok((StatusCode::CREATED, Json(commit_json(&commit))))
 }
 
 #[derive(Deserialize)]
 pub struct BranchQuery {
     pub branch: Option<String>,
 }
 
 pub async fn list_commits(
@@ -164,36 +185,42 @@ pub async fn get_commit(
 ) -> Result<Json<Value>, ApiError> {
     let commit = state
         .store
         .commit(&project, &hash)
         .map_err(map_store_error)?
         .ok_or_else(|| ApiError::not_found(format!("commit {}", hash)))?;
     let bytes = state
         .store
         .blob(&commit.okf_hash)
         .map_err(map_store_error)?
-        .ok_or_else(|| ApiError::internal(format!("missing blob {}", commit.okf_hash)))?;
-    let value: Value =
-        serde_json::from_slice(&bytes).map_err(|e| ApiError::internal(e.to_string()))?;
+        .ok_or_else(|| {
+            eprintln!("missing blob {}", commit.okf_hash);
+            ApiError::internal("stored model is missing")
+        })?;
+    let value: Value = serde_json::from_slice(&bytes).map_err(|e| {
+        eprintln!("stored model is not valid JSON: {}", e);
+        ApiError::internal("stored model could not be read")
+    })?;
     Ok(Json(value))
 }
 
 #[derive(Deserialize)]
 pub struct CreateBranch {
     pub name: String,
     pub from: String,
 }
 
 pub async fn create_branch(
     State(state): State<ApiState>,
     Path(project): Path<String>,
     Json(body): Json<CreateBranch>,
 ) -> Result<(StatusCode, Json<Value>), ApiError> {
+    validate_name("branch name", &body.name)?;
     state
         .store
         .create_branch(&project, &body.name, &body.from)
         .map_err(map_store_error)?;
     Ok((
         StatusCode::CREATED,
         Json(json!({ "name": body.name, "tip": body.from })),
     ))
 }
diff --git a/server/src/gate_api.rs b/server/src/gate_api.rs
index c86db27..77f8081 100644
--- a/server/src/gate_api.rs
+++ b/server/src/gate_api.rs
@@ -59,24 +59,24 @@ pub async fn run_gate(
         candidate_hash: body.candidate.clone(),
         passed: outcome.passed,
         evidence: outcome.evidence.to_string(),
         created_at: now_epoch(),
     };
     state.store.record_gate_run(&run).map_err(map_store_error)?;
 
     // The name carries both FULL hashes. Truncating them would keep determinism but lose
     // uniqueness: two commit pairs sharing a prefix would overwrite each other's evidence
     // while both runs stayed recorded, so a run would cite a file it never wrote.
-    let file_name = format!(
-        "server-{}-{}-{}.json",
-        project, body.reference, body.candidate
-    );
+    // The name carries both FULL hashes and no project name: the hashes are globally
+    // unique, and keeping an unvalidated string out of a filesystem path removes any
+    // chance of a separator escaping the evidence directory.
+    let file_name = format!("server-{}-{}.json", body.reference, body.candidate);
     let path = state.evidence_dir.join(file_name);
     gate::write_evidence(&path, &outcome.evidence)
         .map_err(|e| ApiError::internal(e.to_string()))?;
 
     Ok(Json(outcome.evidence))
 }
 
 pub async fn list_gate_runs(
     State(state): State<ApiState>,
     Path(project): Path<String>,
diff --git a/server/src/store/mod.rs b/server/src/store/mod.rs
index d31150b..80375fc 100644
--- a/server/src/store/mod.rs
+++ b/server/src/store/mod.rs
@@ -92,18 +92,33 @@ pub fn now_epoch() -> String {
     }
 }
 
 pub trait Store: Send + Sync {
     fn create_project(&self, name: &str) -> Result<Project, StoreError>;
     fn project(&self, name: &str) -> Result<Option<Project>, StoreError>;
     fn list_projects(&self) -> Result<Vec<Project>, StoreError>;
     fn put_blob(&self, bytes: &[u8]) -> Result<String, StoreError>;
     fn blob(&self, hash: &str) -> Result<Option<Vec<u8>>, StoreError>;
     fn append_commit(&self, commit: &Commit) -> Result<(), StoreError>;
+
+    /// Commit a model onto a branch atomically: the tip is read, the parents and the
+    /// commit hash are derived from it, and the commit row and the branch tip are written
+    /// inside ONE lock and transaction. Resolving the parents a layer above would be a
+    /// read-modify-write race: two concurrent commits would both read the same tip and
+    /// fork the history, the later one orphaning the earlier while the branch lists both.
+    fn commit_model(
+        &self,
+        project: &str,
+        branch: &str,
+        okf_hash: &str,
+        author: &str,
+        message: &str,
+    ) -> Result<Commit, StoreError>;
+
     fn commit(&self, project: &str, hash: &str) -> Result<Option<Commit>, StoreError>;
     fn commits_on(&self, project: &str, branch: &str) -> Result<Vec<Commit>, StoreError>;
     fn branch_tip(&self, project: &str, branch: &str) -> Result<Option<String>, StoreError>;
     fn create_branch(&self, project: &str, name: &str, from: &str) -> Result<(), StoreError>;
     fn list_branches(&self, project: &str) -> Result<Vec<(String, String)>, StoreError>;
     fn record_gate_run(&self, run: &GateRun) -> Result<(), StoreError>;
     fn gate_runs(&self, project: &str) -> Result<Vec<GateRun>, StoreError>;
 }
diff --git a/server/src/store/sqlite.rs b/server/src/store/sqlite.rs
index f09f4e9..8a51a1b 100644
--- a/server/src/store/sqlite.rs
+++ b/server/src/store/sqlite.rs
@@ -180,20 +180,79 @@ impl Store for SqliteStore {
         tx.execute(
             "INSERT INTO branches (project, name, tip) VALUES (?1, ?2, ?3) ON CONFLICT(project, name) DO UPDATE SET tip = ?3",
             params![commit.project, commit.branch, commit.hash],
         )
         .map_err(|e| StoreError::Backend(e.to_string()))?;
         tx.commit()
             .map_err(|e| StoreError::Backend(e.to_string()))?;
         Ok(())
     }
 
+    fn commit_model(
+        &self,
+        project: &str,
+        branch: &str,
+        okf_hash: &str,
+        author: &str,
+        message: &str,
+    ) -> Result<Commit, StoreError> {
+        let guard = self
+            .connection
+            .lock()
+            .map_err(|_| StoreError::Backend("connection lock poisoned".to_string()))?;
+        let tx = guard
+            .unchecked_transaction()
+            .map_err(|e| StoreError::Backend(e.to_string()))?;
+
+        // The tip is read inside the same lock and transaction that writes the commit, so
+        // two concurrent commits to one branch chain rather than fork.
+        let tip: Option<String> = (|| -> rusqlite::Result<Option<String>> {
+            let mut stmt =
+                tx.prepare("SELECT tip FROM branches WHERE project = ?1 AND name = ?2")?;
+            let mut rows = stmt.query(params![project, branch])?;
+            match rows.next()? {
+                Some(row) => Ok(Some(row.get(0)?)),
+                None => Ok(None),
+            }
+        })()
+        .map_err(|e| StoreError::Backend(e.to_string()))?;
+        let parents: Vec<String> = tip.into_iter().collect();
+        let created_at = now_epoch();
+        let hash = super::commit_hash(project, branch, &parents, okf_hash, author, message);
+        let parents_json =
+            serde_json::to_string(&parents).map_err(|e| StoreError::Backend(e.to_string()))?;
+
+        tx.execute(
+            "INSERT OR IGNORE INTO commits (hash, project, branch, parents, okf_hash, author, message, created_at) VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8)",
+            params![hash, project, branch, parents_json, okf_hash, author, message, created_at],
+        )
+        .map_err(|e| StoreError::Backend(e.to_string()))?;
+        tx.execute(
+            "INSERT INTO branches (project, name, tip) VALUES (?1, ?2, ?3) ON CONFLICT(project, name) DO UPDATE SET tip = ?3",
+            params![project, branch, hash],
+        )
+        .map_err(|e| StoreError::Backend(e.to_string()))?;
+        tx.commit()
+            .map_err(|e| StoreError::Backend(e.to_string()))?;
+
+        Ok(Commit {
+            hash,
+            project: project.to_string(),
+            branch: branch.to_string(),
+            parents,
+            okf_hash: okf_hash.to_string(),
+            author: author.to_string(),
+            message: message.to_string(),
+            created_at,
+        })
+    }
+
     fn commit(&self, project: &str, hash: &str) -> Result<Option<Commit>, StoreError> {
         // The row is read inside the lock and the parents column is parsed outside it, so
         // that corruption can surface as a storage error rather than a query error.
         let row: Option<CommitRow> = self.with(|c| {
                 let mut stmt = c.prepare(
                     "SELECT hash, project, branch, parents, okf_hash, author, message, created_at FROM commits WHERE project = ?1 AND hash = ?2",
                 )?;
                 let mut rows = stmt.query(params![project, hash])?;
                 match rows.next()? {
                     Some(row) => Ok(Some((
diff --git a/server/tests/api.rs b/server/tests/api.rs
index 8c9ec92..7ad9440 100644
--- a/server/tests/api.rs
+++ b/server/tests/api.rs
@@ -253,10 +253,39 @@ async fn commits_can_be_listed_per_branch() {
         .oneshot(
             Request::builder()
                 .uri("/projects/coffee/commits?branch=nothing-here")
                 .body(Body::empty())
                 .unwrap(),
         )
         .await
         .unwrap();
     assert!(json_body(other).await.as_array().unwrap().is_empty());
 }
+#[tokio::test]
+async fn names_that_could_escape_a_path_are_rejected() {
+    // Project names reach the evidence file path, so the charset is closed rather than
+    // trusted: a separator or a drive letter must never be accepted.
+    let dir = tempfile::tempdir().unwrap();
+    let router = server::app(state(dir.path()));
+    for name in ["..", "a/b", "a\\b", "has space", "colon:name", ""] {
+        let response = router
+            .clone()
+            .oneshot(post("/projects", serde_json::json!({ "name": name })))
+            .await
+            .unwrap();
+        assert_eq!(
+            response.status(),
+            StatusCode::BAD_REQUEST,
+            "name {:?} must be rejected",
+            name
+        );
+    }
+
+    let accepted = router
+        .oneshot(post(
+            "/projects",
+            serde_json::json!({ "name": "coffee-machine.v2" }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(accepted.status(), StatusCode::CREATED);
+}
diff --git a/server/tests/store.rs b/server/tests/store.rs
index 4e0ae8f..6dabcc3 100644
--- a/server/tests/store.rs
+++ b/server/tests/store.rs
@@ -78,10 +78,52 @@ fn duplicate_projects_and_branches_are_conflicts() {
         .unwrap();
     match store.create_branch("coffee", "review", &commit.hash) {
         Err(StoreError::Conflict(_)) => {}
         other => panic!("expected a conflict, got {:?}", other),
     }
     match store.create_branch("coffee", "other", "missing-commit") {
         Err(StoreError::NotFound(_)) => {}
         other => panic!("expected not found, got {:?}", other),
     }
 }
+#[test]
+fn concurrent_commits_to_one_branch_form_a_linear_chain() {
+    // The store resolves the parents, hashes and appends inside one lock and transaction.
+    // If that atomicity were lost, two concurrent commits would both read the same tip
+    // and fork the history: both commits would land, but one would orphan the other and
+    // the chain would have two roots. This test fails loudly in that case.
+    let (store, _dir) = store();
+    store.create_project("coffee").unwrap();
+    let store = std::sync::Arc::new(store);
+
+    let mut handles = Vec::new();
+    for i in 0..8 {
+        let store = store.clone();
+        handles.push(std::thread::spawn(move || {
+            store
+                .commit_model(
+                    "coffee",
+                    "main",
+                    &format!("okf-{}", i),
+                    "alex",
+                    "concurrent",
+                )
+                .expect("commit model");
+        }));
+    }
+    for handle in handles {
+        handle.join().expect("worker thread");
+    }
+
+    let history = store.commits_on("coffee", "main").unwrap();
+    assert_eq!(history.len(), 8, "every commit must land");
+    let roots = history.iter().filter(|c| c.parents.is_empty()).count();
+    assert_eq!(roots, 1, "exactly one commit may be rootless");
+    for commit in &history {
+        assert!(
+            commit.parents.len() <= 1,
+            "no commit may have two parents in this scenario"
+        );
+    }
+    let links: usize = history.iter().map(|c| c.parents.len()).sum();
+    assert_eq!(links, 7, "seven commits must link to their predecessor");
+}
