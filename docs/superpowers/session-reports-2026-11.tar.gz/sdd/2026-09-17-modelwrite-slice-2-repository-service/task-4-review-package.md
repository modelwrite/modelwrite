﻿# Slice 2 Task 4 review package

## Commit

705b4cd feat: add the server-side gate endpoint and evidence recording

## Diff stat

 server/src/gate_api.rs   | 103 +++++++++++++++++++++++++++++
 server/src/lib.rs        |   6 ++
 server/tests/gate_api.rs | 169 +++++++++++++++++++++++++++++++++++++++++++++++
 3 files changed, 278 insertions(+)

## Full diff (-U10)

diff --git a/server/src/gate_api.rs b/server/src/gate_api.rs
new file mode 100644
index 0000000..a4bbd7d
--- /dev/null
+++ b/server/src/gate_api.rs
@@ -0,0 +1,103 @@
+// SPDX-License-Identifier: AGPL-3.0-or-later
+use axum::extract::{Path, State};
+use axum::Json;
+use serde::Deserialize;
+use serde_json::{json, Value};
+
+use crate::api::{map_store_error, ApiState};
+use crate::error::ApiError;
+use crate::store::{now_epoch, GateRun};
+
+/// Load the OKF document behind a commit hash.
+fn load_model(
+    state: &ApiState,
+    project: &str,
+    hash: &str,
+) -> Result<okf::types::OkfRoot, ApiError> {
+    let commit = state
+        .store
+        .commit(project, hash)
+        .map_err(map_store_error)?
+        .ok_or_else(|| ApiError::not_found(format!("commit {}", hash)))?;
+    let bytes = state
+        .store
+        .blob(&commit.okf_hash)
+        .map_err(map_store_error)?
+        .ok_or_else(|| ApiError::internal(format!("missing blob {}", commit.okf_hash)))?;
+    serde_json::from_slice(&bytes).map_err(|e| ApiError::internal(e.to_string()))
+}
+
+fn short(hash: &str) -> &str {
+    let end = 12.min(hash.len());
+    &hash[..end]
+}
+
+#[derive(Deserialize)]
+pub struct GateRequest {
+    pub reference: String,
+    pub candidate: String,
+}
+
+pub async fn run_gate(
+    State(state): State<ApiState>,
+    Path(project): Path<String>,
+    Json(body): Json<GateRequest>,
+) -> Result<Json<Value>, ApiError> {
+    let reference = load_model(&state, &project, &body.reference)?;
+    let candidate = load_model(&state, &project, &body.candidate)?;
+
+    let outcome = gate::run(&reference, &candidate, false);
+    let branch = state
+        .store
+        .commit(&project, &body.candidate)
+        .map_err(map_store_error)?
+        .map(|c| c.branch)
+        .unwrap_or_else(|| "main".to_string());
+
+    // Evidence lands beside the engine's records under a deterministic name: the same
+    // two commits always produce the same file, so a run is reproducible and citable.
+    let file_name = format!(
+        "server-{}-{}-{}.json",
+        project,
+        short(&body.reference),
+        short(&body.candidate)
+    );
+    let path = state.evidence_dir.join(file_name);
+    gate::write_evidence(&path, &outcome.evidence)
+        .map_err(|e| ApiError::internal(e.to_string()))?;
+
+    let run = GateRun {
+        project: project.clone(),
+        branch,
+        reference_hash: body.reference.clone(),
+        candidate_hash: body.candidate.clone(),
+        passed: outcome.passed,
+        evidence: outcome.evidence.to_string(),
+        created_at: now_epoch(),
+    };
+    state.store.record_gate_run(&run).map_err(map_store_error)?;
+
+    Ok(Json(outcome.evidence))
+}
+
+pub async fn list_gate_runs(
+    State(state): State<ApiState>,
+    Path(project): Path<String>,
+) -> Result<Json<Value>, ApiError> {
+    let runs = state.store.gate_runs(&project).map_err(map_store_error)?;
+    let out: Vec<Value> = runs
+        .iter()
+        .map(|r| {
+            json!({
+                "project": r.project,
+                "branch": r.branch,
+                "referenceHash": r.reference_hash,
+                "candidateHash": r.candidate_hash,
+                "passed": r.passed,
+                "evidence": serde_json::from_str::<Value>(&r.evidence).unwrap_or(Value::Null),
+                "createdAt": r.created_at
+            })
+        })
+        .collect();
+    Ok(Json(Value::Array(out)))
+}
diff --git a/server/src/lib.rs b/server/src/lib.rs
index 9a05879..68d5d63 100644
--- a/server/src/lib.rs
+++ b/server/src/lib.rs
@@ -1,13 +1,14 @@
 // SPDX-License-Identifier: AGPL-3.0-or-later
 pub mod api;
 pub mod error;
+pub mod gate_api;
 pub mod store;
 
 pub use error::ApiError;
 
 use std::sync::Arc;
 
 use axum::routing::{get, post};
 use axum::{Json, Router};
 use serde_json::json;
 
@@ -34,20 +35,25 @@ pub fn app(state: AppState) -> Router {
         .route(
             "/projects",
             post(api::create_project).get(api::list_projects),
         )
         .route(
             "/projects/:project/commits",
             post(api::create_commit).get(api::list_commits),
         )
         .route("/projects/:project/commits/:hash", get(api::get_commit))
         .route("/projects/:project/branches", post(api::create_branch))
+        .route("/projects/:project/gate", post(gate_api::run_gate))
+        .route(
+            "/projects/:project/gate-runs",
+            get(gate_api::list_gate_runs),
+        )
         .with_state(api_state)
 }
 
 async fn health() -> Json<serde_json::Value> {
     Json(json!({ "status": "ok" }))
 }
 
 async fn version() -> Json<serde_json::Value> {
     Json(json!({
         "server": env!("CARGO_PKG_VERSION"),
diff --git a/server/tests/gate_api.rs b/server/tests/gate_api.rs
new file mode 100644
index 0000000..e0749fa
--- /dev/null
+++ b/server/tests/gate_api.rs
@@ -0,0 +1,169 @@
+// SPDX-License-Identifier: AGPL-3.0-or-later
+use axum::body::Body;
+use axum::http::{Request, StatusCode};
+use http_body_util::BodyExt;
+use tower::ServiceExt;
+
+fn state(dir: &std::path::Path) -> server::AppState {
+    let store = server::store::sqlite::SqliteStore::open(&dir.join("mw.db")).unwrap();
+    server::AppState {
+        store: std::sync::Arc::new(store),
+        evidence_dir: dir.to_path_buf(),
+    }
+}
+
+fn post(uri: &str, body: serde_json::Value) -> Request<Body> {
+    Request::builder()
+        .method("POST")
+        .uri(uri)
+        .header("content-type", "application/json")
+        .body(Body::from(body.to_string()))
+        .unwrap()
+}
+
+fn get(uri: &str) -> Request<Body> {
+    Request::builder().uri(uri).body(Body::empty()).unwrap()
+}
+
+async fn json_body(response: axum::response::Response) -> serde_json::Value {
+    let bytes = response.into_body().collect().await.unwrap().to_bytes();
+    serde_json::from_slice(&bytes).unwrap()
+}
+
+fn model(name: &str) -> serde_json::Value {
+    serde_json::json!({
+        "project": name,
+        "exportedAt": "2026-09-17T00:00:00Z",
+        "summary": {},
+        "stateMachine": { "name": "sm", "regions": [] },
+        "graph": {
+            "nodes": [
+                { "id": "b1", "kind": "block", "name": "Block" },
+                { "id": "r1", "kind": "requirement", "name": "Req" }
+            ],
+            "edges": [
+                { "source": "b1", "target": "r1", "kind": "dependency", "label": "Satisfy" }
+            ]
+        },
+        "requirements": [
+            { "id": "r1", "name": "Req", "kind": "requirement", "stereotypes": ["Requirement"], "attributes": [], "documentation": "", "reqId": "1.1", "reqText": "shall satisfy" }
+        ]
+    })
+}
+
+async fn seed_project(router: &axum::Router, dir: &std::path::Path) -> (String, String) {
+    router
+        .clone()
+        .oneshot(post("/projects", serde_json::json!({ "name": "coffee" })))
+        .await
+        .unwrap();
+
+    let first = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/commits",
+            serde_json::json!({ "branch": "main", "author": "alex", "message": "model", "okf": model("coffee") }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(first.status(), StatusCode::CREATED);
+    let first = json_body(first).await;
+    let reference = first["hash"].as_str().unwrap().to_string();
+
+    let mut changed = model("coffee");
+    changed["project"] = serde_json::json!("coffee v2");
+    let second = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/commits",
+            serde_json::json!({ "branch": "main", "author": "alex", "message": "changed", "okf": changed }),
+        ))
+        .await
+        .unwrap();
+    let second = json_body(second).await;
+    let candidate = second["hash"].as_str().unwrap().to_string();
+
+    let _ = dir;
+    (reference, candidate)
+}
+
+#[tokio::test]
+async fn gating_a_commit_against_itself_passes_and_records_evidence() {
+    let dir = tempfile::tempdir().unwrap();
+    let router = server::app(state(dir.path()));
+    let (reference, _candidate) = seed_project(&router, dir.path()).await;
+
+    let response = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/gate",
+            serde_json::json!({ "reference": reference, "candidate": reference }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(response.status(), StatusCode::OK);
+    let evidence = json_body(response).await;
+    assert_eq!(evidence["passed"], true);
+    assert_eq!(evidence["roundtrip"]["equal"], true);
+
+    let files: Vec<_> = std::fs::read_dir(dir.path())
+        .unwrap()
+        .filter_map(|e| e.ok())
+        .map(|e| e.file_name().to_string_lossy().to_string())
+        .filter(|n| n.starts_with("server-"))
+        .collect();
+    assert_eq!(
+        files.len(),
+        1,
+        "expected one evidence file, got {:?}",
+        files
+    );
+}
+
+#[tokio::test]
+async fn gating_a_changed_model_fails_and_is_still_a_successful_run() {
+    let dir = tempfile::tempdir().unwrap();
+    let router = server::app(state(dir.path()));
+    let (reference, candidate) = seed_project(&router, dir.path()).await;
+
+    let response = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/gate",
+            serde_json::json!({ "reference": reference, "candidate": candidate }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(response.status(), StatusCode::OK);
+    let evidence = json_body(response).await;
+    assert_eq!(evidence["passed"], false);
+    assert!(!evidence["roundtrip"]["equal"].as_bool().unwrap());
+    assert!(evidence["failures"]
+        .as_array()
+        .unwrap()
+        .iter()
+        .any(|f| f.as_str().unwrap().contains("roundtrip")));
+
+    let runs = router
+        .oneshot(get("/projects/coffee/gate-runs"))
+        .await
+        .unwrap();
+    let recorded = json_body(runs).await;
+    assert_eq!(recorded.as_array().unwrap().len(), 1);
+    assert_eq!(recorded[0]["passed"], false);
+}
+
+#[tokio::test]
+async fn gating_an_unknown_commit_is_not_found() {
+    let dir = tempfile::tempdir().unwrap();
+    let router = server::app(state(dir.path()));
+    let (reference, _candidate) = seed_project(&router, dir.path()).await;
+    let response = router
+        .oneshot(post(
+            "/projects/coffee/gate",
+            serde_json::json!({ "reference": reference, "candidate": "missing" }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(response.status(), StatusCode::NOT_FOUND);
+}
