# UI design report — modelwrite workbench visual design

**Status:** DONE_WITH_CONCERNS

**Commit:** `3b695e9` — "workbench: a real visual design system (type, colour, chrome, dense tree, form controls)"

**One-line test summary:** `cargo test --workspace --no-fail-fast` green (exit 0), `cargo fmt --all` clean, `cargo clippy --workspace --all-targets -- -D warnings` clean (exit 0), and the Playwright browser suite green (7/7, ~5.6s) — all built under `CARGO_TARGET_DIR=target-tests` so the locked trial server was never touched.

## What changed visually

The workbench now reads as a tool rather than unstyled HTML. All of it is hand-written CSS in `server/src/ui/layout.rs` and hand-written JS/markup in `server/src/ui/app.js` — no framework, no CDN, nothing fetched at load.

1. **Type system** — a system-UI stack for all text (no serif), a monospace stack for ids/hashes/code, and a real scale: 20px page title / 15px section title / 14px body / 12px meta, with distinct weights. Numbers and ids are monospace.
2. **Colour system** — CSS custom properties at the top of the stylesheet, each family commented: a single accent (blue) used sparingly; a neutral grey scale for chrome; semantic PASS/FAIL/UNKNOWN/WARN tints; and one colour per element kind.
3. **Panel chrome** — a sticky top bar with the product name, a small graph brand mark, a project pill and the identity; three distinct panes with headers ("Structure" / content / "Properties"), borders and subtle background differentiation (page surface is grey, panels are white).
4. **Dense professional tree** — 27px rows, hover and selected states, a coloured dot per element kind plus a muted kind badge (no more blue link soup), indentation guides, and the tree scrolls on its own while its header and search stay fixed.
5. **Real form controls** — styled inputs/textarea/select/buttons with padding, radius and hover/active/disabled states; focus-visible outlines on every control. The assist panel is a first-class feature (accent left border, header, proper textarea and button) instead of a bare form.
6. **Role distinction** — the side tree is NAVIGATION (dense, name + kind only); the page body is READING (comfortable spacing, documentation visible, kind chips, edit links).
7. **Empty/unknown states** — the empty properties pane shows a "select an element to see its properties" placeholder, never blank space; covered / uncovered / not-reported render as bordered chips rather than plain text; the empty-model state is a dashed panel.
8. **Diagram** — the SVG palette was moved onto the new accent/greys (requirement-node amber left at the team's pinned `#fff3cd` so the structural test still passes).

The no-JS contract is unchanged: with JavaScript disabled the server-rendered sections are byte-for-byte the same, and every `data-mw-*` hook, the tree structure, ids, search, keyboard and deep-link behaviour are intact (asserted green by `e2e/tests/ide.spec.js`).

## Concerns

1. **Visual self-verification was not possible.** The session model (`deepseek-v4-pro`) does not declare image input, so `read_image` fails with "does not declare image input". I could not perform the "read the screenshot / verify with a picture" acceptance step myself. I verified structurally instead — all Rust tests, clippy, and the full browser suite pass, and I reviewed the CSS/markup directly. I generated fresh screenshots `e2e/ui-model-after.png` and `e2e/ui-model-after-full.png` against a freshly-seeded throwaway server for a human to review (the "before" images remain at `e2e/ui-model.png` / `e2e/ui-model-full.png`). A human eye should confirm the rendered result before this is considered fully accepted.
2. **The trial server still serves the old design.** I built/tested with `CARGO_TARGET_DIR=target-tests` and did NOT stop or restart the trial server on port 8080; that process still runs the pre-change binary, so its URL will not show the new design until it is rebuilt/restarted.
3. **One diagram colour is pinned by a test outside my ownership scope.** `server/tests/ui.rs` asserts requirement nodes carry `fill='#fff3cd'`; I kept that exact value rather than modifying a test file I do not own.
