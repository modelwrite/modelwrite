# Task 4 Report: Signed tokens (JWT) from an identity provider

## Status

DONE_WITH_CONCERNS

## Commits

- e0ab956 feat: accept signed tokens from an identity provider

## Test summary

153 tests passed, 0 failed across the whole workspace (server 109: lib 12, api 11, audit 10, auth 25, corpus 1, gate_api 3, http 2, locks 15, merge 15, merge_api 4, store 11; engine 44: capi 4, gate 5, graph 7, mcp 13, okf_diff 8, okf_validation 7).

## Dependency added

- jsonwebtoken 9.3.1 (resolved via ring 0.17.14), in server/Cargo.toml. Reason: verifying an RSA signature correctly is not work to hand-roll, and jsonwebtoken is the de-facto standard for this in Rust. It uses ring for RSA verification, which is a self-contained Rust-based crypto stack with no OpenSSL linkage, so the container image stays slim. This is the ONE dependency this tranche declares; a cargo-deny / advisory check is a later governance task.

## What changed

- server/Cargo.toml: added jsonwebtoken = "9.3.1".
- server/src/auth.rs: the Jwt variant is now real. AuthConfig::Jwt carries the JWKS keys keyed by kid, an optional issuer, an optional audience, and the two configurable claim names. New: parse_jwks (JWKS -> HashMap<String, DecodingKey>, RSA keys only, keyed by kid), parse_identity_from_jwt (decode_header -> reject non-RSA alg -> select key by kid -> decode with expiry/issuer/audience validation -> read sub/roles/projects), AuthConfig::jwt / jwt_with_claims / from_jwks_file / from_jwks_url, and from_env now returns Result and reads MW_AUTH_JWKS (file, primary) then MW_AUTH_JWKS_URL (url, secondary). Claim names default to "roles"/"projects" via MW_AUTH_ROLES_CLAIM / MW_AUTH_PROJECTS_CLAIM; issuer/audience via MW_AUTH_ISSUER / MW_AUTH_AUDIENCE. The redacted Debug shows the key count, not the keys.
- server/src/main.rs: from_env() now returns a Result, so a malformed JWKS is a startup error rather than a silent fall back to open mode.
- server/tests/auth.rs: 11 new integration tests covering accept, expiry, wrong key, wrong/missing issuer, wrong audience, alg:none, malformed expiry type, clock skew within/beyond the 60s window, missing-roles denial, and from_jwks_file.
- server/tests/fixtures/: a committed RSA-2048 test key pair (private keys + public JWKS) so the tests need no network and no identity provider.

## Self-review

- An expired token is refused (jwt_mode_rejects_an_expired_token_without_echoing_it).
- A token signed by the wrong key is refused (jwt_mode_rejects_a_token_signed_by_the_wrong_key).
- alg:none is refused outright (jwt_mode_rejects_alg_none); the header alg is additionally constrained to RS256/RS384/RS512, so an HMAC downgrade is also refused.
- A missing roles claim yields no roles and therefore cannot write (jwt_mode_without_a_roles_claim_cannot_write, plus the string_list_claim unit test proves array / single-string / wrong-type / absent).
- Clock skew is tolerated within 60 seconds and refused beyond it (jwt_mode_tolerates_clock_skew_within_the_window_but_not_beyond).
- No token appears in any response body (the expiry-rejection test asserts the body does not contain the token; the error messages are the generic "missing/invalid bearer token").
- Open mode and the static-token path are unchanged (all 25 auth integration tests and the existing suite pass).

## Concerns

- jsonwebtoken 9.3.1 is flagged by CVE-2026-25537 (type confusion in claim validation: a malformed exp/nbf of the wrong JSON type is treated as "not present", so a check enabled but not marked required can be skipped). This is the latest 9.x line and the only line that satisfies the declared rust-version 1.75 and edition 2021; the patched lines (10.3.0+) require rust-version 1.85+, edition 2024, and switch to aws-lc-rs (an OpenSSL/BoringSSL-derived stack), contradicting the tranche's MSRV and "prefer pure-Rust / no OpenSSL" constraints. The vulnerability is fully mitigated in this code: exp is required by default, and issuer/audience are added to required_spec_claims whenever they are configured, so a missing OR malformed claim is a hard failure rather than a skipped check; a dedicated test (jwt_mode_rejects_a_malformed_expiry_type) proves the malformed-expiry case. nbf is deliberately not validated (outside the brief's signature/expiry/issuer/audience scope). The advisory/cargo-deny check remains a later governance task, as the brief anticipates.
- The URL source (MW_AUTH_JWKS_URL) is fetched at startup by shelling out to curl. This is the only way to reach an HTTPS URL without adding a second dependency (an HTTP/TLS stack), which the one-dependency constraint forbids. The file path (MW_AUTH_JWKS) is the primary and is fully pure-Rust; curl is only required for the networked URL path, and a missing curl is a clear startup error.

## Deviations

- AuthConfig::Jwt carries two fields beyond the three named in the brief (keys, issuer, audience): role_claim and project_claim. This is required by the brief's own "roles/projects come from configurable claims" clause, which needs somewhere to store the configured names; they default to "roles" and "projects".
- The test key pair is committed rather than generated in the test. Generating an RSA key pair inside a test would need the rsa crate (a second, undeclared dependency), which the brief anticipates as the reason to use a committed pair. The committed pair is an RSA-2048 generated once for this task; the JWKS carries only the public half, and a second private key is committed solely to prove wrong-key rejection.

## Working tree note

After my commit (e0ab956), the working tree showed an uncommitted modification to server/tests/audit.rs (a new task-3-style test, every_path_records_the_identity_rather_than_the_claimed_name) that I did not author and did not stage. It appeared during this session from a concurrent process (a task-3 follow-up / re-review); I left it untouched. My commit contains only the eight files this task owns (Cargo.lock, server/Cargo.toml, server/src/auth.rs, server/src/main.rs, server/tests/auth.rs, and the three fixtures).

## Verification

- cargo test --workspace --no-fail-fast: exit 0 (153 passed, 0 failed).
- cargo fmt --all --check: exit 0 (clean).
- cargo clippy --workspace --all-targets -- -D warnings: exit 0 (clean).
