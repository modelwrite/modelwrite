## Global Constraints

- Rust stable; edition 2021; rust-version 1.75. NO new dependency before Task 4, which declares exactly one and says why.
- Every source file begins with: // SPDX-License-Identifier: AGPL-3.0-or-later
- Cargo is not on PATH in fresh shells: begin every shell command sequence with $env:Path = "$env:USERPROFILE\\.cargo\\bin;" + $env:Path
- Use --no-fail-fast when running a test suite.
- Stage and commit only the paths a task owns. Never amend or rewrite a commit.
- AUTHENTICATION MUST BE OPT-IN so the existing 57 tests keep working: when no auth configuration is present (no MW_AUTH_TOKEN, no MW_AUTH_JWKS), the service runs in OPEN mode, every request is accepted, and the identity is `Identity::open()` with role admin and subject "anonymous". A test asserts open mode still works, and the startup path logs a loud warning that the service is unauthenticated.
- A VERIFIED ACTOR REPLACES A CLAIMED ONE: once auth is configured, the audit actor is the identity's subject and the request body's author or holder is IGNORED for attribution. If the body names a different actor, the request is refused with 403 rather than quietly recorded under the wrong name.
- Comparison of secrets is CONSTANT TIME. A token comparison that returns early on the first differing byte is a timing oracle.
- Never log a token, and never put one in an error body.
- Roles are `admin`, `author`, `reviewer`, `viewer`. Permissions: viewer reads; author adds commits, branches, resets, merges and locks; reviewer adds reading gate runs and evidence; admin adds project creation, branch deletion and lock breaking.
- Every request path returns a structured error and never panics: 401 for a missing or invalid token, 403 for an authenticated caller without the permission, and 500 with a generic message and no internal detail.

## Task 4: Signed tokens (JWT) against a JWKS

**Files:**
- Modify: server/Cargo.toml (ONE new dependency, and only here)
- Modify: server/src/auth.rs (the Jwt variant)
- Test: server/tests/auth.rs

**Interfaces:**
- Produces: `AuthConfig::Jwt { keys: HashMap<String, DecodingKey>, issuer: Option<String>, audience: Option<String> }`, built at startup from a JWKS file path in `MW_AUTH_JWKS` (a mounted secret, which is what an air-gapped install has) or fetched from `MW_AUTH_JWKS_URL` once at startup. Roles come from a configurable claim, default `roles`; projects from a claim, default `projects`. A token that fails signature, expiry, issuer or audience verification is a 401.

**Steps:**

- [ ] **Step 1: Declare the dependency.** `jsonwebtoken` is the one addition, and the plan says why: verifying an RSA signature correctly is not something to hand-roll, and the crate is the de-facto standard for this in Rust. Record the version chosen and that a cargo-deny or advisory check is a later governance task.

- [ ] **Step 2: Implement the Jwt variant** including clock skew tolerance of 60 seconds and a rejection of `alg: none`.

- [ ] **Step 3: Tests** with a key pair generated in the test itself: a valid token is accepted; an expired token is rejected; a token signed by the wrong key is rejected; a token with a different issuer or audience is rejected; a token whose roles claim is absent gets no roles and therefore cannot write. If generating a key pair in a test proves unreasonable, use a committed test key pair and say so in the report.

- [ ] **Step 4: Run, lint and commit** with `feat: accept signed tokens from an identity provider`.

---

