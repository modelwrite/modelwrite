﻿# Tranche 4 Task 2 review package (role and scope enforcement)

## Commits under review

4e8f5f5 fix: filter project listings by scope and redact the auth configuration
98561bf feat: enforce roles and project scope on every route

## Diff stat

 server/src/api.rs       |  70 ++++++++++-
 server/src/audit_api.rs |   8 ++
 server/src/auth.rs      |  37 +++++-
 server/src/gate_api.rs  |  15 +++
 server/src/lib.rs       |   5 +
 server/src/locks_api.rs |  22 ++++
 server/src/merge_api.rs |   8 ++
 server/tests/auth.rs    | 312 +++++++++++++++++++++++++++++++++++++++++++++++-
 8 files changed, 471 insertions(+), 6 deletions(-)

## Every changed file, in full

## FILE: server/src/api.rs

diff --git a/server/src/api.rs b/server/src/api.rs
index 8aeaf8a..659efab 100644
--- a/server/src/api.rs
+++ b/server/src/api.rs
@@ -4,13 +4,13 @@ use std::sync::Arc;
 use axum::extract::{Path, Query, State};
 use axum::http::StatusCode;
 use axum::Json;
 use serde::Deserialize;
 use serde_json::{json, Value};
 
-use crate::auth::AuthConfig;
+use crate::auth::{AuthConfig, Identity, Permission};
 use crate::error::ApiError;
 use crate::store::{
     is_lock_refusal, now_epoch, AuditEntry, Commit, CommitGuard, Store, StoreError,
 };
 
 #[derive(Clone)]
@@ -264,15 +264,22 @@ pub fn commit_json(commit: &Commit) -> Value {
 #[derive(Deserialize)]
 pub struct CreateProject {
     pub name: String,
 }
 
 pub async fn create_project(
+    identity: Identity,
     State(state): State<ApiState>,
     Json(body): Json<CreateProject>,
 ) -> Result<(StatusCode, Json<Value>), ApiError> {
+    if !identity.may(Permission::Administer) {
+        return Err(ApiError::forbidden("admin permission required"));
+    }
+    if !identity.may_reach(&body.name) {
+        return Err(ApiError::forbidden("project not in scope"));
+    }
     validate_name("project name", &body.name)?;
     let audit = AuditEntry {
         id: 0,
         project: body.name.clone(),
         at: now_seconds(),
         actor: "unknown".to_string(),
@@ -287,16 +294,26 @@ pub async fn create_project(
     Ok((
         StatusCode::CREATED,
         Json(json!({ "name": project.name, "createdAt": project.created_at })),
     ))
 }
 
-pub async fn list_projects(State(state): State<ApiState>) -> Result<Json<Value>, ApiError> {
+pub async fn list_projects(
+    identity: Identity,
+    State(state): State<ApiState>,
+) -> Result<Json<Value>, ApiError> {
+    if !identity.may(Permission::Read) {
+        return Err(ApiError::forbidden("read permission required"));
+    }
     let projects = state.store.list_projects().map_err(map_store_error)?;
+    // A caller scoped to particular projects must not learn the names of the others. The
+    // listing is filtered rather than refused: an identity that reaches nothing gets an
+    // empty list, which is the truthful answer to "what may I see".
     let out: Vec<Value> = projects
         .iter()
+        .filter(|p| identity.may_reach(&p.name))
         .map(|p| json!({ "name": p.name, "createdAt": p.created_at }))
         .collect();
     Ok(Json(Value::Array(out)))
 }
 
 #[derive(Deserialize)]
@@ -306,16 +323,23 @@ pub struct CreateCommit {
     pub message: String,
     pub okf: Value,
     pub holder: Option<String>,
 }
 
 pub async fn create_commit(
+    identity: Identity,
     State(state): State<ApiState>,
     Path(project): Path<String>,
     Json(body): Json<CreateCommit>,
 ) -> Result<(StatusCode, Json<Value>), ApiError> {
+    if !identity.may(Permission::Write) {
+        return Err(ApiError::forbidden("write permission required"));
+    }
+    if !identity.may_reach(&project) {
+        return Err(ApiError::forbidden("project not in scope"));
+    }
     if state
         .store
         .project(&project)
         .map_err(map_store_error)?
         .is_none()
     {
@@ -411,30 +435,44 @@ pub async fn create_commit(
 #[derive(Deserialize)]
 pub struct BranchQuery {
     pub branch: Option<String>,
 }
 
 pub async fn list_commits(
+    identity: Identity,
     State(state): State<ApiState>,
     Path(project): Path<String>,
     Query(query): Query<BranchQuery>,
 ) -> Result<Json<Value>, ApiError> {
+    if !identity.may(Permission::Read) {
+        return Err(ApiError::forbidden("read permission required"));
+    }
+    if !identity.may_reach(&project) {
+        return Err(ApiError::forbidden("project not in scope"));
+    }
     let branch = query.branch.unwrap_or_else(|| "main".to_string());
     let commits = state
         .store
         .commits_on(&project, &branch)
         .map_err(map_store_error)?;
     Ok(Json(Value::Array(
         commits.iter().map(commit_json).collect(),
     )))
 }
 
 pub async fn get_commit(
+    identity: Identity,
     State(state): State<ApiState>,
     Path((project, hash)): Path<(String, String)>,
 ) -> Result<Json<Value>, ApiError> {
+    if !identity.may(Permission::Read) {
+        return Err(ApiError::forbidden("read permission required"));
+    }
+    if !identity.may_reach(&project) {
+        return Err(ApiError::forbidden("project not in scope"));
+    }
     let commit = state
         .store
         .commit(&project, &hash)
         .map_err(map_store_error)?
         .ok_or_else(|| ApiError::not_found(format!("commit {}", hash)))?;
     let bytes = state
@@ -456,16 +494,23 @@ pub async fn get_commit(
 pub struct CreateBranch {
     pub name: String,
     pub from: String,
 }
 
 pub async fn create_branch(
+    identity: Identity,
     State(state): State<ApiState>,
     Path(project): Path<String>,
     Json(body): Json<CreateBranch>,
 ) -> Result<(StatusCode, Json<Value>), ApiError> {
+    if !identity.may(Permission::Write) {
+        return Err(ApiError::forbidden("write permission required"));
+    }
+    if !identity.may_reach(&project) {
+        return Err(ApiError::forbidden("project not in scope"));
+    }
     validate_name("branch name", &body.name)?;
     let audit = AuditEntry {
         id: 0,
         project: project.clone(),
         at: now_seconds(),
         actor: "unknown".to_string(),
@@ -481,15 +526,22 @@ pub async fn create_branch(
         StatusCode::CREATED,
         Json(json!({ "name": body.name, "tip": body.from })),
     ))
 }
 
 pub async fn list_branches(
+    identity: Identity,
     State(state): State<ApiState>,
     Path(project): Path<String>,
 ) -> Result<Json<Value>, ApiError> {
+    if !identity.may(Permission::Read) {
+        return Err(ApiError::forbidden("read permission required"));
+    }
+    if !identity.may_reach(&project) {
+        return Err(ApiError::forbidden("project not in scope"));
+    }
     if state
         .store
         .project(&project)
         .map_err(map_store_error)?
         .is_none()
     {
@@ -504,15 +556,22 @@ pub async fn list_branches(
         .map(|(name, tip)| json!({ "name": name, "tip": tip }))
         .collect();
     Ok(Json(Value::Array(out)))
 }
 
 pub async fn delete_branch(
+    identity: Identity,
     State(state): State<ApiState>,
     Path((project, name)): Path<(String, String)>,
 ) -> Result<StatusCode, ApiError> {
+    if !identity.may(Permission::Administer) {
+        return Err(ApiError::forbidden("admin permission required"));
+    }
+    if !identity.may_reach(&project) {
+        return Err(ApiError::forbidden("project not in scope"));
+    }
     validate_name("branch name", &name)?;
     let audit = AuditEntry {
         id: 0,
         project: project.clone(),
         at: now_seconds(),
         actor: "unknown".to_string(),
@@ -538,16 +597,23 @@ pub struct ResetBranch {
 }
 
 /// Restore a branch to the CONTENT of an earlier commit by appending a new commit. The
 /// history is never rewritten: the old tip stays reachable, and the revert is itself a
 /// commit with an author and a message.
 pub async fn reset_branch(
+    identity: Identity,
     State(state): State<ApiState>,
     Path((project, name)): Path<(String, String)>,
     Json(body): Json<ResetBranch>,
 ) -> Result<(StatusCode, Json<Value>), ApiError> {
+    if !identity.may(Permission::Write) {
+        return Err(ApiError::forbidden("write permission required"));
+    }
+    if !identity.may_reach(&project) {
+        return Err(ApiError::forbidden("project not in scope"));
+    }
     validate_name("branch name", &name)?;
     if state
         .store
         .project(&project)
         .map_err(map_store_error)?
         .is_none()

## FILE: server/src/audit_api.rs

diff --git a/server/src/audit_api.rs b/server/src/audit_api.rs
index f202717..ac4b5f6 100644
--- a/server/src/audit_api.rs
+++ b/server/src/audit_api.rs
@@ -1,28 +1,36 @@
 // SPDX-License-Identifier: AGPL-3.0-or-later
 use axum::extract::{Path, Query, State};
 use axum::Json;
 use serde::Deserialize;
 
 use crate::api::{map_store_error, ApiState};
+use crate::auth::{Identity, Permission};
 use crate::error::ApiError;
 use crate::store::AuditEntry;
 
 #[derive(Deserialize)]
 pub struct AuditQuery {
     pub limit: Option<i64>,
 }
 
 /// The append-only audit log for a project, newest first. The log records what was
 /// attempted as well as what succeeded, and can never be edited: the store exposes only
 /// an append and this read, never an update or a delete.
 pub async fn list_audit(
+    identity: Identity,
     State(state): State<ApiState>,
     Path(project): Path<String>,
     Query(query): Query<AuditQuery>,
 ) -> Result<Json<Vec<AuditEntry>>, ApiError> {
+    if !identity.may(Permission::Read) {
+        return Err(ApiError::forbidden("read permission required"));
+    }
+    if !identity.may_reach(&project) {
+        return Err(ApiError::forbidden("project not in scope"));
+    }
     if state
         .store
         .project(&project)
         .map_err(map_store_error)?
         .is_none()
     {

## FILE: server/src/auth.rs

diff --git a/server/src/auth.rs b/server/src/auth.rs
index ba21772..d3c15d3 100644
--- a/server/src/auth.rs
+++ b/server/src/auth.rs
@@ -77,13 +77,13 @@ impl Permission {
     }
 }
 
 /// How the service decides who a request is. Authentication is opt-in: the `Open` variant
 /// is the default, and the only non-open variant Task 1's startup path constructs is
 /// `Static`.
-#[derive(Debug, Clone)]
+#[derive(Clone)]
 pub enum AuthConfig {
     Open,
     /// A single shared bearer token, stored as its SHA-256 hex digest so the secret itself
     /// is never held and comparison is over a fixed-width digest.
     Static {
         token_hash: String,
@@ -91,12 +91,38 @@ pub enum AuthConfig {
     /// Signed JWTs verified against a JWKS. Task 4 implements this variant; until then it
     /// is present only so the configuration is complete and matches stay exhaustive about
     /// the not-yet-implemented path.
     Jwt {
         jwks_source: String,
     },
+    /// Every request resolves to this exact identity. Only tests construct this: it lets
+    /// the permission and project-scope decisions be exercised with a specific role or
+    /// scope before Task 4 wires a real per-claim authority. `from_env` never produces it.
+    Fixed(Identity),
+}
+
+/// Redacted on purpose: a derived Debug would print the token digest, and a configuration
+/// that can be printed into a log is a configuration that eventually will be. The digest is
+/// not the secret, but it is the thing compared to the secret, so it stays out of logs.
+impl std::fmt::Debug for AuthConfig {
+    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
+        match self {
+            AuthConfig::Open => write!(f, "AuthConfig::Open"),
+            AuthConfig::Static { .. } => {
+                write!(f, "AuthConfig::Static {{ token_hash: <redacted> }}")
+            }
+            AuthConfig::Jwt { jwks_source } => f
+                .debug_struct("AuthConfig::Jwt")
+                .field("jwks_source", jwks_source)
+                .finish(),
+            AuthConfig::Fixed(identity) => f
+                .debug_struct("AuthConfig::Fixed")
+                .field("subject", &identity.subject)
+                .finish(),
+        }
+    }
 }
 
 impl AuthConfig {
     /// Read the configuration from the environment. Task 1 wires the static token only;
     /// Task 4 wires the JWKS. With no `MW_AUTH_TOKEN` the service runs OPEN.
     pub fn from_env() -> AuthConfig {
@@ -110,12 +136,20 @@ impl AuthConfig {
     /// comparison is over a fixed-width digest and no token length is leaked.
     pub fn static_token(token: &str) -> AuthConfig {
         AuthConfig::Static {
             token_hash: hash_token(token),
         }
     }
+
+    /// Pin every request to one identity. This is a test hook: `from_env` never produces
+    /// it, and it exists so the role and project-scope decisions on every route can be
+    /// exercised with a viewer, an author or a single-project scope before Task 4 adds a
+    /// real token authority that can express those claims.
+    pub fn fixed(identity: Identity) -> AuthConfig {
+        AuthConfig::Fixed(identity)
+    }
 }
 
 /// SHA-256 of a token as lowercase hex. The configured token is hashed once at startup so
 /// the stored secret is a fixed-width digest, never the token itself.
 pub fn hash_token(token: &str) -> String {
     hex::encode(Sha256::digest(token.as_bytes()))
@@ -177,12 +211,13 @@ fn bearer_token(headers: &HeaderMap) -> Option<&str> {
 /// Resolve the request's identity against the configured authentication. In open mode every
 /// request is the anonymous admin; in static mode the bearer token must match, or the call
 /// is refused with 401. This is the extraction layer Task 2 threads through every route.
 pub async fn identity(state: &ApiState, headers: &HeaderMap) -> Result<Identity, ApiError> {
     match &state.auth {
         AuthConfig::Open => Ok(Identity::open()),
+        AuthConfig::Fixed(identity) => Ok(identity.clone()),
         AuthConfig::Static { .. } => {
             let token = bearer_token(headers)
                 .ok_or_else(|| ApiError::unauthorized("missing bearer token"))?;
             parse_identity_from_static(token, &state.auth)
                 .ok_or_else(|| ApiError::unauthorized("invalid bearer token"))
         }

## FILE: server/src/gate_api.rs

diff --git a/server/src/gate_api.rs b/server/src/gate_api.rs
index ab3f02b..27575ea 100644
--- a/server/src/gate_api.rs
+++ b/server/src/gate_api.rs
@@ -2,26 +2,34 @@
 use axum::extract::{Path, State};
 use axum::Json;
 use serde::Deserialize;
 use serde_json::{json, Value};
 
 use crate::api::{load_model, map_store_error, ApiState};
+use crate::auth::{Identity, Permission};
 use crate::error::ApiError;
 use crate::store::{now_epoch, now_seconds, AuditEntry, GateRun};
 
 #[derive(Deserialize)]
 pub struct GateRequest {
     pub reference: String,
     pub candidate: String,
 }
 
 pub async fn run_gate(
+    identity: Identity,
     State(state): State<ApiState>,
     Path(project): Path<String>,
     Json(body): Json<GateRequest>,
 ) -> Result<Json<Value>, ApiError> {
+    if !identity.may(Permission::Write) {
+        return Err(ApiError::forbidden("write permission required"));
+    }
+    if !identity.may_reach(&project) {
+        return Err(ApiError::forbidden("project not in scope"));
+    }
     let reference = load_model(&state, &project, &body.reference)?;
     let candidate = load_model(&state, &project, &body.candidate)?;
 
     let outcome = gate::run(&reference, &candidate, false);
     let branch = state
         .store
@@ -78,15 +86,22 @@ pub async fn run_gate(
     })?;
 
     Ok(Json(outcome.evidence))
 }
 
 pub async fn list_gate_runs(
+    identity: Identity,
     State(state): State<ApiState>,
     Path(project): Path<String>,
 ) -> Result<Json<Value>, ApiError> {
+    if !identity.may(Permission::Review) {
+        return Err(ApiError::forbidden("review permission required"));
+    }
+    if !identity.may_reach(&project) {
+        return Err(ApiError::forbidden("project not in scope"));
+    }
     let runs = state.store.gate_runs(&project).map_err(map_store_error)?;
     let out: Vec<Value> = runs
         .iter()
         .map(|r| {
             json!({
                 "project": r.project,

## FILE: server/src/lib.rs

diff --git a/server/src/lib.rs b/server/src/lib.rs
index 4618eb5..1a0b8c1 100644
--- a/server/src/lib.rs
+++ b/server/src/lib.rs
@@ -31,12 +31,17 @@ impl AppState {
             evidence_dir: self.evidence_dir.clone(),
             auth: self.auth.clone(),
         }
     }
 }
 
+/// The complete route table. `/health` and `/version` are public liveness/information
+/// endpoints and take no identity. Every other route takes `Identity` as its first
+/// extractor and enforces the required permission — and project reachability, where a
+/// project is named — before touching the store, so an unauthenticated caller gets 401 and
+/// an under-privileged one gets 403 rather than reaching project data.
 pub fn app(state: AppState) -> Router {
     let api_state = state.api();
     Router::new()
         .route("/health", get(health))
         .route("/version", get(version))
         .route(

## FILE: server/src/locks_api.rs

diff --git a/server/src/locks_api.rs b/server/src/locks_api.rs
index 66775b2..58198db 100644
--- a/server/src/locks_api.rs
+++ b/server/src/locks_api.rs
@@ -3,12 +3,13 @@ use axum::extract::{Path, State};
 use axum::http::StatusCode;
 use axum::Json;
 use serde::Deserialize;
 use serde_json::{json, Value};
 
 use crate::api::{map_store_error, record_refusal, validate_element_name, validate_name, ApiState};
+use crate::auth::{Identity, Permission};
 use crate::error::ApiError;
 use crate::store::{now_epoch, AuditEntry, Lock};
 
 /// The real clock in seconds, as the store requires it. The store itself never reads the
 /// clock: time is passed in so lock expiry is testable without sleeping.
 fn now_seconds() -> i64 {
@@ -37,16 +38,23 @@ pub struct AcquireLocks {
     pub elements: Vec<String>,
     pub holder: String,
     pub ttl_seconds: i64,
 }
 
 pub async fn acquire_locks(
+    identity: Identity,
     State(state): State<ApiState>,
     Path(project): Path<String>,
     Json(body): Json<AcquireLocks>,
 ) -> Result<(StatusCode, Json<Vec<Lock>>), ApiError> {
+    if !identity.may(Permission::Write) {
+        return Err(ApiError::forbidden("write permission required"));
+    }
+    if !identity.may_reach(&project) {
+        return Err(ApiError::forbidden("project not in scope"));
+    }
     validate_name("branch name", &body.branch)?;
     validate_holder(&body.holder)?;
     if body.elements.is_empty() {
         return Err(ApiError::bad_request("at least one element is required"));
     }
     for element in &body.elements {
@@ -122,15 +130,22 @@ pub async fn acquire_locks(
         }
     };
     Ok((StatusCode::CREATED, Json(locks)))
 }
 
 pub async fn list_locks(
+    identity: Identity,
     State(state): State<ApiState>,
     Path(project): Path<String>,
 ) -> Result<Json<Vec<Lock>>, ApiError> {
+    if !identity.may(Permission::Read) {
+        return Err(ApiError::forbidden("read permission required"));
+    }
+    if !identity.may_reach(&project) {
+        return Err(ApiError::forbidden("project not in scope"));
+    }
     if state
         .store
         .project(&project)
         .map_err(map_store_error)?
         .is_none()
     {
@@ -147,16 +162,23 @@ pub async fn list_locks(
 pub struct ReleaseLocks {
     pub holder: String,
     pub ids: Vec<String>,
 }
 
 pub async fn release_locks(
+    identity: Identity,
     State(state): State<ApiState>,
     Path(project): Path<String>,
     Json(body): Json<ReleaseLocks>,
 ) -> Result<Json<Value>, ApiError> {
+    if !identity.may(Permission::Write) {
+        return Err(ApiError::forbidden("write permission required"));
+    }
+    if !identity.may_reach(&project) {
+        return Err(ApiError::forbidden("project not in scope"));
+    }
     if state
         .store
         .project(&project)
         .map_err(map_store_error)?
         .is_none()
     {

## FILE: server/src/merge_api.rs

diff --git a/server/src/merge_api.rs b/server/src/merge_api.rs
index 2059eba..7108f73 100644
--- a/server/src/merge_api.rs
+++ b/server/src/merge_api.rs
@@ -6,12 +6,13 @@ use serde::Deserialize;
 use serde_json::{json, Value};
 
 use crate::api::{
     commit_json, commit_refusal_guard, load_model, map_store_error, touched_elements,
     validate_name, ApiState,
 };
+use crate::auth::{Identity, Permission};
 use crate::error::ApiError;
 use crate::merge::merge;
 use crate::store::{now_seconds, AuditEntry, CommitGuard};
 
 #[derive(Deserialize)]
 pub struct MergeRequest {
@@ -110,16 +111,23 @@ fn common_ancestor(
             "the branches have more than one possible merge base, so the merge cannot be computed automatically",
         )),
     }
 }
 
 pub async fn merge_branches(
+    identity: Identity,
     State(state): State<ApiState>,
     Path(project): Path<String>,
     Json(body): Json<MergeRequest>,
 ) -> Result<(StatusCode, Json<Value>), ApiError> {
+    if !identity.may(Permission::Write) {
+        return Err(ApiError::forbidden("write permission required"));
+    }
+    if !identity.may_reach(&project) {
+        return Err(ApiError::forbidden("project not in scope"));
+    }
     validate_name("branch name", &body.branch)?;
     validate_name("branch name", &body.other)?;
     if state
         .store
         .project(&project)
         .map_err(map_store_error)?

## FILE: server/tests/auth.rs

diff --git a/server/tests/auth.rs b/server/tests/auth.rs
index b604471..6e7026e 100644
--- a/server/tests/auth.rs
+++ b/server/tests/auth.rs
@@ -1,22 +1,28 @@
 // SPDX-License-Identifier: AGPL-3.0-or-later
 //! End-to-end tests for the opt-in authentication layer: open mode admits every request,
 //! static mode demands a matching bearer token, and no token is ever echoed in a response.
+//!
+//! Task 2 adds the denial half: with a `Fixed` identity the full route table must refuse an
+//! under-privileged caller with 403 BEFORE touching the store, so a route added without a
+//! permission decision cannot pass unnoticed.
 
 use std::sync::Arc;
 
 use axum::body::Body;
 use axum::http::{Request, StatusCode};
-use axum::routing::get;
+use axum::routing::get as axum_get;
 use axum::{Json, Router};
 use http_body_util::BodyExt;
 use serde_json::{json, Value};
 use tower::ServiceExt;
 
 use server::api::ApiState;
 use server::auth::{AuthConfig, Identity};
+use server::store::{sqlite::SqliteStore, Store};
+use server::{app, AppState};
 
 /// A route that exercises the Identity extractor and returns what it resolved. The rest of
 /// the service threads Identity through its real routes in Task 2; this is the minimal
 /// surface the extraction layer needs to be proven against.
 async fn whoami(identity: Identity) -> Json<Value> {
     Json(json!({
@@ -25,15 +31,15 @@ async fn whoami(identity: Identity) -> Json<Value> {
         "projects": identity.projects,
     }))
 }
 
 fn router(auth: AuthConfig) -> Router {
     let dir = tempfile::tempdir().unwrap();
-    let store = server::store::sqlite::SqliteStore::open(&dir.path().join("mw.db")).unwrap();
+    let store = SqliteStore::open(&dir.path().join("mw.db")).unwrap();
     Router::new()
-        .route("/whoami", get(whoami))
+        .route("/whoami", axum_get(whoami))
         .with_state(ApiState {
             store: Arc::new(store),
             evidence_dir: dir.path().to_path_buf(),
             auth,
         })
 }
@@ -138,6 +144,306 @@ async fn static_mode_accepts_the_right_token() {
     assert_eq!(response.status(), StatusCode::OK);
     let body = json_body(response).await;
     assert_eq!(body["subject"], "admin");
     assert_eq!(body["roles"][0], "admin");
     assert_eq!(body["projects"][0], "*");
 }
+
+// ---------------------------------------------------------------------------
+// Task 2: the denial tests. A `Fixed` identity pins every request to a specific
+// subject/role/scope, so the permission and project-scope checks on each route can be
+// exercised before Task 4 wires a real per-claim authority.
+// ---------------------------------------------------------------------------
+
+fn identity(subject: &str, roles: &[&str], projects: &[&str]) -> Identity {
+    Identity {
+        subject: subject.to_string(),
+        roles: roles.iter().map(|s| s.to_string()).collect(),
+        projects: projects.iter().map(|s| s.to_string()).collect(),
+    }
+}
+
+fn viewer() -> Identity {
+    identity("viewer", &["viewer"], &["*"])
+}
+
+fn author() -> Identity {
+    identity("author", &["author"], &["*"])
+}
+
+/// No roles at all: cannot even Read, so it is the denial identity for a route whose only
+/// requirement is Read and which has no project to scope (list projects).
+fn nobody() -> Identity {
+    identity("nobody", &[], &["*"])
+}
+
+/// An author scoped to one project: may write, but not reach any other project.
+fn scoped_coffee() -> Identity {
+    identity("scoped", &["author"], &["coffee"])
+}
+
+fn post(uri: &str, body: Value) -> Request<Body> {
+    Request::builder()
+        .method("POST")
+        .uri(uri)
+        .header("content-type", "application/json")
+        .body(Body::from(body.to_string()))
+        .unwrap()
+}
+
+fn get(uri: &str) -> Request<Body> {
+    Request::builder().uri(uri).body(Body::empty()).unwrap()
+}
+
+fn delete(uri: &str) -> Request<Body> {
+    Request::builder()
+        .method("DELETE")
+        .uri(uri)
+        .body(Body::empty())
+        .unwrap()
+}
+
+fn delete_json(uri: &str, body: Value) -> Request<Body> {
+    Request::builder()
+        .method("DELETE")
+        .uri(uri)
+        .header("content-type", "application/json")
+        .body(Body::from(body.to_string()))
+        .unwrap()
+}
+
+/// Build the full application router pinned to one identity, returning a handle to the
+/// store so a test can prove the denied request touched nothing. The tempdir is returned so
+/// it stays alive for as long as the router (and its open SQLite connection) is used.
+fn app_with_identity(identity: Identity) -> (Router, Arc<SqliteStore>, tempfile::TempDir) {
+    let dir = tempfile::tempdir().unwrap();
+    let store = Arc::new(SqliteStore::open(&dir.path().join("mw.db")).unwrap());
+    let state = AppState {
+        store: store.clone(),
+        evidence_dir: dir.path().to_path_buf(),
+        auth: AuthConfig::fixed(identity),
+    };
+    (app(state), store, dir)
+}
+
+#[tokio::test]
+async fn static_mode_requires_a_token_on_a_real_route() {
+    // A real route (not /whoami) must refuse a missing token with 401 BEFORE consulting the
+    // store: with the token absent and no "coffee" project, reaching the store would 404.
+    let dir = tempfile::tempdir().unwrap();
+    let store = Arc::new(SqliteStore::open(&dir.path().join("mw.db")).unwrap());
+    let state = AppState {
+        store: store.clone(),
+        evidence_dir: dir.path().to_path_buf(),
+        auth: AuthConfig::static_token("the-token"),
+    };
+    let router = app(state);
+    let response = router
+        .oneshot(get("/projects/coffee/commits"))
+        .await
+        .unwrap();
+    assert_eq!(
+        response.status(),
+        StatusCode::UNAUTHORIZED,
+        "a missing token must be refused before the store is consulted (which would 404)"
+    );
+    assert!(
+        store.list_projects().unwrap().is_empty(),
+        "a refused request must touch nothing"
+    );
+}
+
+#[tokio::test]
+async fn viewer_is_refused_a_commit_without_touching_the_store() {
+    let (router, store, _dir) = app_with_identity(viewer());
+    // Seed the target so a denied commit is observable as "nothing changed".
+    store.create_project("coffee", None).unwrap();
+
+    let response = router
+        .oneshot(post(
+            "/projects/coffee/commits",
+            json!({ "branch": "main", "author": "alex", "message": "m", "okf": {} }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(response.status(), StatusCode::FORBIDDEN);
+
+    assert!(
+        store.commits_on("coffee", "main").unwrap().is_empty(),
+        "a refused commit must write no commit"
+    );
+    assert!(
+        store.list_branches("coffee").unwrap().is_empty(),
+        "a refused commit must not move a branch"
+    );
+    assert!(
+        store.audit("coffee", 1000).unwrap().is_empty(),
+        "a refused commit must write no audit entry"
+    );
+}
+
+#[tokio::test]
+async fn author_is_refused_project_creation() {
+    let (router, store, _dir) = app_with_identity(author());
+    let response = router
+        .oneshot(post("/projects", json!({ "name": "tea" })))
+        .await
+        .unwrap();
+    assert_eq!(response.status(), StatusCode::FORBIDDEN);
+    assert!(
+        store.list_projects().unwrap().is_empty(),
+        "a refused project creation must create nothing"
+    );
+}
+
+#[tokio::test]
+async fn a_token_scoped_to_one_project_is_refused_on_another() {
+    let (router, store, _dir) = app_with_identity(scoped_coffee());
+    // The scoped author may WRITE, so the only thing standing between it and a commit on
+    // "tea" is project scope: may_reach must refuse it before any store access.
+    let response = router
+        .oneshot(post(
+            "/projects/tea/commits",
+            json!({ "branch": "main", "author": "alex", "message": "m", "okf": {} }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(response.status(), StatusCode::FORBIDDEN);
+    assert!(
+        store.list_projects().unwrap().is_empty(),
+        "an out-of-scope request must touch nothing"
+    );
+}
+
+/// The complete route table, one entry per (method, path) pair in lib.rs except the public
+/// /health and /version liveness endpoints. Each entry names an identity that must be
+/// refused with 403: a viewer or author for routes whose permission it lacks, a no-role
+/// identity for list-projects (Read with no project to scope), and a coffee-scoped author
+/// on the "tea" project for every Read route, which only project scope can deny. A new
+/// route that does not appear here, or that is not refused, is a permission bug.
+#[tokio::test]
+async fn every_route_denies_a_caller_without_permission_or_scope() {
+    let commit = || json!({ "branch": "main", "author": "alex", "message": "m", "okf": {} });
+    let branch = || json!({ "name": "review", "from": "abc" });
+    let reset = || json!({ "to": "abc", "author": "alex", "message": "m" });
+    let merge =
+        || json!({ "branch": "main", "other": "feature", "author": "alex", "message": "m" });
+    let gate = || json!({ "reference": "a", "candidate": "b" });
+    let locks =
+        || json!({ "branch": "main", "elements": ["b1"], "holder": "alex", "ttlSeconds": 300 });
+    let release = || json!({ "holder": "alex", "ids": ["x"] });
+
+    let cases: Vec<(&str, Identity, Request<Body>)> = vec![
+        (
+            "create_project",
+            author(),
+            post("/projects", json!({ "name": "tea" })),
+        ),
+        ("list_projects", nobody(), get("/projects")),
+        (
+            "create_commit",
+            viewer(),
+            post("/projects/coffee/commits", commit()),
+        ),
+        (
+            "list_commits",
+            scoped_coffee(),
+            get("/projects/tea/commits"),
+        ),
+        (
+            "get_commit",
+            scoped_coffee(),
+            get("/projects/tea/commits/abc"),
+        ),
+        (
+            "create_branch",
+            viewer(),
+            post("/projects/coffee/branches", branch()),
+        ),
+        (
+            "list_branches",
+            scoped_coffee(),
+            get("/projects/tea/branches"),
+        ),
+        (
+            "delete_branch",
+            author(),
+            delete("/projects/coffee/branches/main"),
+        ),
+        (
+            "reset_branch",
+            viewer(),
+            post("/projects/coffee/branches/main/reset", reset()),
+        ),
+        ("run_gate", viewer(), post("/projects/coffee/gate", gate())),
+        (
+            "merge_branches",
+            viewer(),
+            post("/projects/coffee/merge", merge()),
+        ),
+        (
+            "list_gate_runs",
+            author(),
+            get("/projects/coffee/gate-runs"),
+        ),
+        ("list_audit", scoped_coffee(), get("/projects/tea/audit")),
+        (
+            "acquire_locks",
+            viewer(),
+            post("/projects/coffee/locks", locks()),
+        ),
+        ("list_locks", scoped_coffee(), get("/projects/tea/locks")),
+        (
+            "release_locks_delete",
+            viewer(),
+            delete_json("/projects/coffee/locks", release()),
+        ),
+        (
+            "release_locks_post",
+            viewer(),
+            post("/projects/coffee/locks/release", release()),
+        ),
+    ];
+
+    for (name, identity, request) in cases {
+        let (router, store, _dir) = app_with_identity(identity);
+        let response = router.oneshot(request).await.unwrap();
+        assert_eq!(
+            response.status(),
+            StatusCode::FORBIDDEN,
+            "{} must be refused with 403",
+            name
+        );
+        assert!(
+            store.list_projects().unwrap().is_empty(),
+            "{} must be refused before the store is touched",
+            name
+        );
+    }
+}
+#[tokio::test]
+async fn a_scoped_identity_only_sees_the_projects_it_may_reach() {
+    // A refusal is not the only way to leak: a listing that returns every project name
+    // tells a caller scoped to one project about all the others. The listing is filtered,
+    // so the answer to "what may I see" is the truth rather than an error.
+    let (router, store, _dir) = app_with_identity(Identity {
+        subject: "alex".to_string(),
+        roles: vec!["viewer".to_string()],
+        projects: vec!["coffee".to_string()],
+    });
+    store.create_project("coffee", None).unwrap();
+    store.create_project("tea", None).unwrap();
+
+    let response = router
+        .oneshot(Request::builder().uri("/projects").body(Body::empty()).unwrap())
+        .await
+        .unwrap();
+    assert_eq!(response.status(), StatusCode::OK);
+    let body = json_body(response).await;
+    let names: Vec<String> = body
+        .as_array()
+        .unwrap()
+        .iter()
+        .map(|p| p["name"].as_str().unwrap().to_string())
+        .collect();
+    assert_eq!(names, vec!["coffee"], "tea must not be disclosed");
+}
