## Global Constraints

- Rust stable; edition 2021; rust-version 1.75. NO new dependency before Task 4, which declares exactly one and says why.
- Every source file begins with: // SPDX-License-Identifier: AGPL-3.0-or-later
- Cargo is not on PATH in fresh shells: begin every shell command sequence with $env:Path = "$env:USERPROFILE\\.cargo\\bin;" + $env:Path
- Use --no-fail-fast when running a test suite.
- Stage and commit only the paths a task owns. Never amend or rewrite a commit.
- AUTHENTICATION MUST BE OPT-IN so the existing 57 tests keep working: when no auth configuration is present (no MW_AUTH_TOKEN, no MW_AUTH_JWKS), the service runs in OPEN mode, every request is accepted, and the identity is `Identity::open()` with role admin and subject "anonymous". A test asserts open mode still works, and the startup path logs a loud warning that the service is unauthenticated.
- A VERIFIED ACTOR REPLACES A CLAIMED ONE: once auth is configured, the audit actor is the identity's subject and the request body's author or holder is IGNORED for attribution. If the body names a different actor, the request is refused with 403 rather than quietly recorded under the wrong name.
- Comparison of secrets is CONSTANT TIME. A token comparison that returns early on the first differing byte is a timing oracle.
- Never log a token, and never put one in an error body.
- Roles are `admin`, `author`, `reviewer`, `viewer`. Permissions: viewer reads; author adds commits, branches, resets, merges and locks; reviewer adds reading gate runs and evidence; admin adds project creation, branch deletion and lock breaking.
- Every request path returns a structured error and never panics: 401 for a missing or invalid token, 403 for an authenticated caller without the permission, and 500 with a generic message and no internal detail.

## Task 1: Identity, the permission model and open mode

**Files:**
- Create: server/src/auth.rs
- Modify: server/src/lib.rs (module, AppState gains auth configuration)
- Test: server/tests/auth.rs

**Interfaces:**
- Produces:
  - `pub struct Identity { pub subject: String, pub roles: Vec<String>, pub projects: Vec<String> }` with `Identity::open()`.
  - `Identity::has_role(&self, role: &str) -> bool`, `Identity::may(&self, permission: Permission) -> bool`, `Identity::may_reach(&self, project: &str) -> bool` (a projects entry of "*" reaches every project).
  - `pub enum Permission { Read, Write, Review, Administer }` and a mapping from permission to the roles that grant it.
  - `pub enum AuthConfig { Open, Static { token_hash: String }, Jwt { .. } }` - Task 1 implements Open and Static only; Jwt arrives in Task 4.
  - `pub fn parse_identity_from_static(token: &str, config: &AuthConfig) -> Option<Identity>` comparing SHA-256 of the presented token against the configured hash in constant time.

**Steps:**

- [ ] **Step 1: Write server/src/auth.rs** with the types above plus unit tests in the file for the role mapping and constant-time comparison. Hash the configured token once at startup so comparison is over fixed-width digests and no length is leaked.

- [ ] **Step 2: AppState gains the configuration.** `pub struct AppState { pub store: Arc<dyn Store>, pub evidence_dir: PathBuf, pub auth: AuthConfig }`. Update every existing test that constructs AppState to pass `AuthConfig::Open`; they are the proof that open mode is unchanged.

- [ ] **Step 3: An extraction layer.** Add `pub async fn identity(...)` as an axum extractor that reads `Authorization: Bearer <token>`, resolves it against the configuration, and returns `Result<Identity, ApiError>` - 401 for a missing or bad token. In open mode it returns `Identity::open()`.

- [ ] **Step 4: Tests** in server/tests/auth.rs: open mode accepts an unauthenticated request; static mode rejects a missing token with 401 and a wrong token with 401; static mode accepts the right token; unit tests in auth.rs cover the role mapping, including that viewer cannot write and author cannot administer.

- [ ] **Step 5: Run, lint and commit** with `feat: add identity, roles and an opt-in authentication mode`. Expected: 57 service tests plus the new ones.

---

