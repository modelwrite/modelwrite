## Global Constraints

- Rust stable; edition 2021; rust-version 1.75. NO new dependency before Task 4, which declares exactly one and says why.
- Every source file begins with: // SPDX-License-Identifier: AGPL-3.0-or-later
- Cargo is not on PATH in fresh shells: begin every shell command sequence with $env:Path = "$env:USERPROFILE\\.cargo\\bin;" + $env:Path
- Use --no-fail-fast when running a test suite.
- Stage and commit only the paths a task owns. Never amend or rewrite a commit.
- AUTHENTICATION MUST BE OPT-IN so the existing 57 tests keep working: when no auth configuration is present (no MW_AUTH_TOKEN, no MW_AUTH_JWKS), the service runs in OPEN mode, every request is accepted, and the identity is `Identity::open()` with role admin and subject "anonymous". A test asserts open mode still works, and the startup path logs a loud warning that the service is unauthenticated.
- A VERIFIED ACTOR REPLACES A CLAIMED ONE: once auth is configured, the audit actor is the identity's subject and the request body's author or holder is IGNORED for attribution. If the body names a different actor, the request is refused with 403 rather than quietly recorded under the wrong name.
- Comparison of secrets is CONSTANT TIME. A token comparison that returns early on the first differing byte is a timing oracle.
- Never log a token, and never put one in an error body.
- Roles are `admin`, `author`, `reviewer`, `viewer`. Permissions: viewer reads; author adds commits, branches, resets, merges and locks; reviewer adds reading gate runs and evidence; admin adds project creation, branch deletion and lock breaking.
- Every request path returns a structured error and never panics: 401 for a missing or invalid token, 403 for an authenticated caller without the permission, and 500 with a generic message and no internal detail.

## Task 3: The audit actor becomes the verified identity

**Files:**
- Modify: server/src/api.rs, merge_api.rs, locks_api.rs, gate_api.rs (audit entries take the subject from the Identity)
- Modify: server/src/store/mod.rs (AuditEntry documented as carrying a verified subject)
- Test: server/tests/audit.rs

**Interfaces:**
- Produces: the audit actor is `identity.subject` on every path, including the four that currently record `"unknown"`. In open mode the subject is `"anonymous"`, which is honest: nobody was authenticated. A request body that names an actor different from the identity is refused with 403, so a caller can never write another person's name into the record.

**Steps:**

- [ ] **Step 1: Replace every claimed actor** with the identity's subject, and add the 403 when a body's author or holder disagrees with the identity.

- [ ] **Step 2: Tests** in server/tests/audit.rs: with auth configured, a commit by identity "alex" records actor "alex" even though the body says "someone-else" (which is refused with 403, so the test asserts the refusal AND that nothing was recorded); project creation records the identity rather than "unknown"; open mode records "anonymous", which is a truthful statement that nobody was authenticated.

- [ ] **Step 3: Run, lint and commit** with `feat: record verified actors in the audit log`.

---

