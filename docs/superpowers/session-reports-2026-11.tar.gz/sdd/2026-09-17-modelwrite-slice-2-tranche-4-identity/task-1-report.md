# Task 1 report — identity, roles and opt-in authentication

## Status

DONE

## Commits

- `baeda9d` feat: add identity, roles and an opt-in authentication mode (13 files, server/ only)

## Test summary

`cargo test --workspace --no-fail-fast`: 122 passed, 0 failed.
Engine (44): capi 4, gate 5, graph 7, mcp 13, okf 15 (diff 8 + validation 7).
Service (78): auth-unit 8, api 11, audit 5, auth 5, corpus 1, gate_api 3, http 2, locks 14, merge 15, merge_api 4, store 10.
Baseline was 109 (engine 44 + service 65); this task adds 13 (8 auth.rs unit tests + 5 tests/auth.rs integration tests).

## Verification

- `cargo fmt --all -- --check` clean.
- `cargo clippy --workspace --all-targets -- -D warnings` clean.

## Concerns

1. The `Jwt` variant is a placeholder (`Jwt { jwks_source: String }`): `Jwt { .. }` is not valid enum syntax, and the real fields (`keys: HashMap<String, DecodingKey>, issuer, audience`) belong to Task 4, which declares `jsonwebtoken`. The extractor's Jwt arm is unreachable in Task 1 (main.rs reads only MW_AUTH_TOKEN) and returns 401 rather than panicking.
2. `cargo fmt --all` stripped a stray UTF-8 BOM from the first line of `server/tests/gate_api.rs` (the single 1-line deletion in the diff). Benign, within server/.
3. A correct static token maps to a fixed admin identity (subject "admin", roles ["admin"], projects ["*"]): a single shared secret carries no per-user claims. Per-user subjects arrive with JWT in Task 4.
4. The brief's "pub async fn identity(...) as an axum extractor" is realized as `pub async fn identity(&ApiState, &HeaderMap) -> Result<Identity, ApiError>` plus `impl FromRequestParts<ApiState> for Identity` (annotated `#[axum::async_trait]`, which axum re-exports — no new dependency), so handlers take `identity: Identity`.

## Deviations

- main.rs was modified in addition to the brief's explicit file list: AppState's new `auth` field requires it to compile, and the global constraints require the config to be read and the loud open-mode warning logged at startup. This is implied by "hash the configured token once at startup" and "the startup path logs a loud warning".

## Self-review

- Open mode provably unchanged: all 65 pre-existing service tests still pass unchanged (each test `state()` now passes `AuthConfig::Open`), plus a new integration test asserting an unauthenticated request is accepted as anonymous admin.
- Constant-time comparison: `constant_time_eq` has no early return on a differing byte (XOR-accumulate); the only early return is a fixed-width length check that never fires for digests and never observes a token's length.
- No token is logged or echoed: the 401 body is a generic structured error, and the wrong-token test asserts the token does not appear in the response.
- Role mapping is unit tested including denials: `viewer_cannot_write_and_author_cannot_administer` plus a full permission-to-role mapping test.
