﻿# Tranche 4 fix rounds - re-review package

## Commits under review

26cbb37 fix: require a non-empty JWT subject and record the auth mechanism in the audit log
98b52ce fix: enforce nbf, drop curl JWKS fetch, upgrade jsonwebtoken

## Diff stat

 Cargo.lock                      | 525 ++++++++++++++++++++++++++++++++--------
 server/Cargo.toml               |   4 +-
 server/src/api.rs               |  65 +++--
 server/src/auth.rs              | 164 ++++++++-----
 server/src/gate_api.rs          |   7 +-
 server/src/lib.rs               |  13 +-
 server/src/locks_api.rs         |   3 +
 server/src/main.rs              |   3 +-
 server/src/merge_api.rs         |  11 +-
 server/src/store/mod.rs         |   6 +-
 server/src/store/sqlite.rs      |  18 +-
 server/tests/audit.rs           |  30 +++
 server/tests/auth.rs            | 216 ++++++++++++++++-
 server/tests/fixtures/README.md |  16 ++
 server/tests/http.rs            |  49 +++-
 server/tests/store.rs           |   3 +
 16 files changed, 917 insertions(+), 216 deletions(-)

## Every changed file, in full

## FILE: Cargo.lock

diff --git a/Cargo.lock b/Cargo.lock
index 8337c1e..d316edf 100644
--- a/Cargo.lock
+++ b/Cargo.lock
@@ -95,18 +95,30 @@ dependencies = [
  "sync_wrapper",
  "tower-layer",
  "tower-service",
  "tracing",
 ]
 
+[[package]]
+name = "base16ct"
+version = "0.2.0"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "4c7f02d4ea65f2c1853089ffd8d2787bdbc63de2f0d29dedbcf8ccdfa0ccd4cf"
+
 [[package]]
 name = "base64"
 version = "0.22.1"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "72b3254f16251a8381aa12e40e3c4d2f0199f8c6508fbecb9d91f575e0fbb8c6"
 
+[[package]]
+name = "base64ct"
+version = "1.8.3"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "2af50177e190e07a26ab74f8b1efbfe2ef87da2116221318cb1c2e82baf7de06"
+
 [[package]]
 name = "bitflags"
 version = "2.13.2"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "3ded4057c258ba199e2d26386d3af3780957ecaee6c4ef4041c6b4b8b97c0b06"
 
@@ -144,31 +156,87 @@ dependencies = [
 [[package]]
 name = "cfg-if"
 version = "1.0.5"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "4e7648175b45a9a48536d676f68d918270699102aa8dab5496df06904c914600"
 
+[[package]]
+name = "const-oid"
+version = "0.9.6"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "c2459377285ad874054d797f3ccebf984978aa39129f6eafde5cdc8315b612f8"
+
 [[package]]
 name = "cpufeatures"
 version = "0.2.17"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "59ed5838eebb26a2bb2e58f6d5b5316989ae9d08bab10e0e6d103e656d1b0280"
 dependencies = [
  "libc",
 ]
 
+[[package]]
+name = "crypto-bigint"
+version = "0.5.5"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "0dc92fb57ca44df6db8059111ab3af99a63d5d0f8375d9972e319a379c6bab76"
+dependencies = [
+ "generic-array",
+ "rand_core",
+ "subtle",
+ "zeroize",
+]
+
 [[package]]
 name = "crypto-common"
 version = "0.1.7"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "78c8292055d1c1df0cce5d180393dc8cce0abec0a7102adb6c7b1eef6016d60a"
 dependencies = [
  "generic-array",
  "typenum",
 ]
 
+[[package]]
+name = "curve25519-dalek"
+version = "4.1.3"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "97fb8b7c4503de7d6ae7b42ab72a5a59857b4c937ec27a3d4539dba95b5ab2be"
+dependencies = [
+ "cfg-if",
+ "cpufeatures",
+ "curve25519-dalek-derive",
+ "digest",
+ "fiat-crypto",
+ "rustc_version",
+ "subtle",
+ "zeroize",
+]
+
+[[package]]
+name = "curve25519-dalek-derive"
+version = "0.1.1"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "f46882e17999c6cc590af592290432be3bce0428cb0d5f8b6715e4dc7b383eb3"
+dependencies = [
+ "proc-macro2",
+ "quote",
+ "syn 2.0.119",
+]
+
+[[package]]
+name = "der"
+version = "0.7.10"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "e7c1832837b905bbfb5101e07cc24c8deddf52f93225eee6ead5f4d63d53ddcb"
+dependencies = [
+ "const-oid",
+ "pem-rfc7468",
+ "zeroize",
+]
+
 [[package]]
 name = "deranged"
 version = "0.5.8"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "7cd812cc2bc1d69d4764bd80df88b4317eaef9e773c75226407d9bc0876b211c"
 
@@ -176,13 +244,74 @@ checksum = "7cd812cc2bc1d69d4764bd80df88b4317eaef9e773c75226407d9bc0876b211c"
 name = "digest"
 version = "0.10.7"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "9ed9a281f7bc9b7576e61468ba615a66a5c8cfdff42420a70aa82701a3b1e292"
 dependencies = [
  "block-buffer",
+ "const-oid",
  "crypto-common",
+ "subtle",
+]
+
+[[package]]
+name = "ecdsa"
+version = "0.16.9"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "ee27f32b5c5292967d2d4a9d7f1e0b0aed2c15daded5a60300e4abb9d8020bca"
+dependencies = [
+ "der",
+ "digest",
+ "elliptic-curve",
+ "rfc6979",
+ "signature",
+ "spki",
+]
+
+[[package]]
+name = "ed25519"
+version = "2.2.3"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "115531babc129696a58c64a4fef0a8bf9e9698629fb97e9e40767d235cfbcd53"
+dependencies = [
+ "pkcs8",
+ "signature",
+]
+
+[[package]]
+name = "ed25519-dalek"
+version = "2.2.0"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "70e796c081cee67dc755e1a36a0a172b897fab85fc3f6bc48307991f64e4eca9"
+dependencies = [
+ "curve25519-dalek",
+ "ed25519",
+ "serde",
+ "sha2",
+ "subtle",
+ "zeroize",
+]
+
+[[package]]
+name = "elliptic-curve"
+version = "0.13.8"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "b5e6043086bf7973472e0c7dff2142ea0b680d30e18d9cc40f267efbf222bd47"
+dependencies = [
+ "base16ct",
+ "crypto-bigint",
+ "digest",
+ "ff",
+ "generic-array",
+ "group",
+ "hkdf",
+ "pem-rfc7468",
+ "pkcs8",
+ "rand_core",
+ "sec1",
+ "subtle",
+ "zeroize",
 ]
 
 [[package]]
 name = "equivalent"
 version = "1.0.2"
 source = "registry+https://github.com/rust-lang/crates.io-index"
@@ -192,13 +321,13 @@ checksum = "877a4ace8713b0bcf2a4e7eec82529c029f1d0619886d18145fea96c3ffe5c0f"
 name = "errno"
 version = "0.3.14"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "39cab71617ae0d63f51a36d69f866391735b51691dbda63cf6f96d042b63efeb"
 dependencies = [
  "libc",
- "windows-sys 0.61.2",
+ "windows-sys",
 ]
 
 [[package]]
 name = "fallible-iterator"
 version = "0.3.0"
 source = "registry+https://github.com/rust-lang/crates.io-index"
@@ -213,12 +342,28 @@ checksum = "7360491ce676a36bf9bb3c56c1aa791658183a54d2744120f27285738d90465a"
 [[package]]
 name = "fastrand"
 version = "2.5.0"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "da7c62ceae207dd37ea5b845da6a0696c799f85e97da1ab5b7910be3c1c80223"
 
+[[package]]
+name = "ff"
+version = "0.13.1"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "c0b50bfb653653f9ca9095b427bed08ab8d75a137839d9ad64eb11810d5b6393"
+dependencies = [
+ "rand_core",
+ "subtle",
+]
+
+[[package]]
+name = "fiat-crypto"
+version = "0.2.9"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "28dea519a9695b9977216879a3ebfddf92f1c08c05d984f8996aecd6ecdc811d"
+
 [[package]]
 name = "find-msvc-tools"
 version = "0.1.12"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "3e0f1c7c3a72c66fd80abe965175f7523475c0489a87d3ff9d6e8c87d87a9d2d"
 
@@ -275,25 +420,24 @@ name = "generic-array"
 version = "0.14.7"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "85649ca51fd72272d7821adaf274ad91c288277713d9c18820d8499a7ff69e9a"
 dependencies = [
  "typenum",
  "version_check",
+ "zeroize",
 ]
 
 [[package]]
 name = "getrandom"
 version = "0.2.17"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "ff2abc00be7fca6ebc474524697ae276ad847ad0a6b3faa4bcb027e9a4614ad0"
 dependencies = [
  "cfg-if",
- "js-sys",
  "libc",
  "wasi",
- "wasm-bindgen",
 ]
 
 [[package]]
 name = "getrandom"
 version = "0.4.3"
 source = "registry+https://github.com/rust-lang/crates.io-index"
@@ -301,12 +445,23 @@ checksum = "300e883d756b2e4ec94e02791f39b04b522276138852cfc41d9fb7e904106099"
 dependencies = [
  "cfg-if",
  "libc",
  "r-efi",
 ]
 
+[[package]]
+name = "group"
+version = "0.13.0"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "f0f9ef7462f7c099f518d754361858f86d8a07af53ba9af0fe635bbccb151a63"
+dependencies = [
+ "ff",
+ "rand_core",
+ "subtle",
+]
+
 [[package]]
 name = "hashbrown"
 version = "0.14.5"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "e5274423e17b7c9fc20b6e7e208532f9b19825d82dfd615708b70edd83df41f1"
 dependencies = [
@@ -331,12 +486,30 @@ dependencies = [
 [[package]]
 name = "hex"
 version = "0.4.3"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "7f24254aa9a54b5c858eaee2f5bccdb46aaf0e486a595ed5fd8f86ba55232a70"
 
+[[package]]
+name = "hkdf"
+version = "0.12.4"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "7b5f8eb2ad728638ea2c7d47a21db23b7b58a72ed6a38256b8a1849f15fbbdf7"
+dependencies = [
+ "hmac",
+]
+
+[[package]]
+name = "hmac"
+version = "0.12.1"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "6c49c37c09c17a53d937dfbb742eb3a961d65a994e6bcdcf37e7399d0cc8ab5e"
+dependencies = [
+ "digest",
+]
+
 [[package]]
 name = "http"
 version = "1.5.0"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "918d3568bebf352712bc2ef3d46a8bcf1a75b373be6539de198e9105cbbf9ce0"
 dependencies = [
@@ -440,31 +613,54 @@ dependencies = [
  "futures-util",
  "wasm-bindgen",
 ]
 
 [[package]]
 name = "jsonwebtoken"
-version = "9.3.1"
+version = "10.3.0"
 source = "registry+https://github.com/rust-lang/crates.io-index"
-checksum = "5a87cc7a48537badeae96744432de36f4be2b4a34a05a5ef32e9dd8a1c169dde"
+checksum = "0529410abe238729a60b108898784df8984c87f6054c9c4fcacc47e4803c1ce1"
 dependencies = [
  "base64",
+ "ed25519-dalek",
+ "getrandom 0.2.17",
+ "hmac",
  "js-sys",
+ "p256",
+ "p384",
  "pem",
- "ring",
+ "rand",
+ "rsa",
  "serde",
  "serde_json",
+ "sha2",
+ "signature",
  "simple_asn1",
 ]
 
+[[package]]
+name = "lazy_static"
+version = "1.5.0"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "bbd2bcb4c963f2ddae06a2efc7e9f3591312473c50c6685e1f298068316e66fe"
+dependencies = [
+ "spin",
+]
+
 [[package]]
 name = "libc"
 version = "0.2.189"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "3eaf3ede3fee6db1a4c2ee091bf8a8b4dccdc6d17f656fb07896ee72867612f2"
 
+[[package]]
+name = "libm"
+version = "0.2.16"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "b6d2cec3eae94f9f509c767b45932f1ada8350c4bdb85af2fcab4a3c14807981"
+
 [[package]]
 name = "libsqlite3-sys"
 version = "0.28.0"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "0c10584274047cb335c23d3e61bcef8e323adae7c5c8c760540f73610177fc3f"
 dependencies = [
@@ -508,13 +704,13 @@ name = "mio"
 version = "1.2.3"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "4b18443e9c262bfe8fa82f51666e2642c53393f7e5c27b3e1aeab922cff5b9d8"
 dependencies = [
  "libc",
  "wasi",
- "windows-sys 0.61.2",
+ "windows-sys",
 ]
 
 [[package]]
 name = "mw-capi"
 version = "0.1.0"
 dependencies = [
@@ -600,12 +796,28 @@ source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "c89e69e7e0f03bea5ef08013795c25018e101932225a656383bd384495ecc367"
 dependencies = [
  "num-integer",
  "num-traits",
 ]
 
+[[package]]
+name = "num-bigint-dig"
+version = "0.8.6"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "e661dda6640fad38e827a6d4a310ff4763082116fe217f279885c97f511bb0b7"
+dependencies = [
+ "lazy_static",
+ "libm",
+ "num-integer",
+ "num-iter",
+ "num-traits",
+ "rand",
+ "smallvec",
+ "zeroize",
+]
+
 [[package]]
 name = "num-conv"
 version = "0.2.2"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "521739c6d2bac4aa25192232afe6841231376b2b26d4d9fae5ecf8ca5772e441"
 
@@ -615,37 +827,81 @@ version = "0.1.47"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "7ce2d95d4b3734dc35aa2f45e1aa22cd416814592a4f9d9205e11affd5b8e10b"
 dependencies = [
  "num-traits",
 ]
 
+[[package]]
+name = "num-iter"
+version = "0.1.46"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "c92800bd69a1eac91786bcfe9da64a897eb72911b8dc3095decbd07429e8048b"
+dependencies = [
+ "num-integer",
+ "num-traits",
+]
+
 [[package]]
 name = "num-traits"
 version = "0.2.19"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "071dfc062690e90b734c0b2273ce72ad0ffa95f0c74596bc250dcfd960262841"
 dependencies = [
  "autocfg",
+ "libm",
 ]
 
 [[package]]
 name = "once_cell"
 version = "1.21.4"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "9f7c3e4beb33f85d45ae3e3a1792185706c8e16d043238c593331cc7cd313b50"
 
+[[package]]
+name = "p256"
+version = "0.13.2"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "c9863ad85fa8f4460f9c48cb909d38a0d689dba1f6f6988a5e3e0d31071bcd4b"
+dependencies = [
+ "ecdsa",
+ "elliptic-curve",
+ "primeorder",
+ "sha2",
+]
+
+[[package]]
+name = "p384"
+version = "0.13.1"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "fe42f1670a52a47d448f14b6a5c61dd78fce51856e68edaa38f7ae3a46b8d6b6"
+dependencies = [
+ "ecdsa",
+ "elliptic-curve",
+ "primeorder",
+ "sha2",
+]
+
 [[package]]
 name = "pem"
 version = "3.0.6"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "1d30c53c26bc5b31a98cd02d20f25a7c8567146caf63ed593a9d87b2775291be"
 dependencies = [
  "base64",
  "serde_core",
 ]
 
+[[package]]
+name = "pem-rfc7468"
+version = "0.7.0"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "88b39c9bfcfc231068454382784bb460aae594343fb030d46e9f50a645418412"
+dependencies = [
+ "base64ct",
+]
+
 [[package]]
 name = "percent-encoding"
 version = "2.3.2"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "9b4f627cb1b25917193a259e49bdad08f671f8d9708acfd5fe0a8c1455d87220"
 
@@ -682,24 +938,63 @@ dependencies = [
 [[package]]
 name = "pin-project-lite"
 version = "0.2.17"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "a89322df9ebe1c1578d689c92318e070967d1042b512afbe49518723f4e6d5cd"
 
+[[package]]
+name = "pkcs1"
+version = "0.7.5"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "c8ffb9f10fa047879315e6625af03c164b16962a5368d724ed16323b68ace47f"
+dependencies = [
+ "der",
+ "pkcs8",
+ "spki",
+]
+
+[[package]]
+name = "pkcs8"
+version = "0.10.2"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "f950b2377845cebe5cf8b5165cb3cc1a5e0fa5cfa3e1f7f55707d8fd82e0a7b7"
+dependencies = [
+ "der",
+ "spki",
+]
+
 [[package]]
 name = "pkg-config"
 version = "0.3.34"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "f6b464fbc74e149a392436b17d523f769e057cb6877f6a5c4618bc6f11800548"
 
 [[package]]
 name = "powerfmt"
 version = "0.2.0"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "439ee305def115ba05938db6eb1644ff94165c5ab5e9420d1c1bcedbba909391"
 
+[[package]]
+name = "ppv-lite86"
+version = "0.2.21"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "85eae3c4ed2f50dcfe72643da4befc30deadb458a9b590d720cde2f2b1e97da9"
+dependencies = [
+ "zerocopy",
+]
+
+[[package]]
+name = "primeorder"
+version = "0.13.6"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "353e1ca18966c16d9deb1c69278edbc5f194139612772bd9537af60ac231e1e6"
+dependencies = [
+ "elliptic-curve",
+]
+
 [[package]]
 name = "proc-macro2"
 version = "1.0.107"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "985e7ec9bb745e6ce6535b544d84d6cd6f7ad8bd711c398938ae983b91a766d9"
 dependencies = [
@@ -719,23 +1014,69 @@ dependencies = [
 name = "r-efi"
 version = "6.0.0"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "f8dcc9c7d52a811697d2151c701e0d08956f92b0e24136cf4cf27b57a6a0d9bf"
 
 [[package]]
-name = "ring"
-version = "0.17.14"
+name = "rand"
+version = "0.8.8"
 source = "registry+https://github.com/rust-lang/crates.io-index"
-checksum = "a4689e6c2294d81e88dc6261c768b63bc4fcdb852be6d1352498b114f61383b7"
+checksum = "e058c7de0b26af77780c769414d6257830bb240f3c38477dbc2c16e5f54d6d4c"
 dependencies = [
- "cc",
- "cfg-if",
- "getrandom 0.2.17",
  "libc",
- "untrusted",
- "windows-sys 0.52.0",
+ "rand_chacha",
+ "rand_core",
+]
+
+[[package]]
+name = "rand_chacha"
+version = "0.3.1"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "e6c10a63a0fa32252be49d21e7709d4d4baf8d231c2dbce1eaa8141b9b127d88"
+dependencies = [
+ "ppv-lite86",
+ "rand_core",
+]
+
+[[package]]
+name = "rand_core"
+version = "0.6.4"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "ec0be4795e2f6a28069bec0b5ff3e2ac9bafc99e6a9a7dc3547996c5c816922c"
+dependencies = [
+ "getrandom 0.2.17",
+]
+
+[[package]]
+name = "rfc6979"
+version = "0.4.0"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "f8dd2a808d456c4a54e300a23e9f5a67e122c3024119acbfd73e3bf664491cb2"
+dependencies = [
+ "hmac",
+ "subtle",
+]
+
+[[package]]
+name = "rsa"
+version = "0.9.10"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "b8573f03f5883dcaebdfcf4725caa1ecb9c15b2ef50c43a07b816e06799bb12d"
+dependencies = [
+ "const-oid",
+ "digest",
+ "num-bigint-dig",
+ "num-integer",
+ "num-traits",
+ "pkcs1",
+ "pkcs8",
+ "rand_core",
+ "signature",
+ "spki",
+ "subtle",
+ "zeroize",
 ]
 
 [[package]]
 name = "rusqlite"
 version = "0.31.0"
 source = "registry+https://github.com/rust-lang/crates.io-index"
@@ -746,23 +1087,32 @@ dependencies = [
  "fallible-streaming-iterator",
  "hashlink",
  "libsqlite3-sys",
  "smallvec",
 ]
 
+[[package]]
+name = "rustc_version"
+version = "0.4.1"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "cfcb3a22ef46e85b45de6ee7e79d063319ebb6594faafcf1c225ea92ab6e9b92"
+dependencies = [
+ "semver",
+]
+
 [[package]]
 name = "rustix"
 version = "1.1.5"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "891efababe418670775f199f0d233d84843c227a0949a883ce15b37c78d6629d"
 dependencies = [
  "bitflags",
  "errno",
  "libc",
  "linux-raw-sys",
- "windows-sys 0.61.2",
+ "windows-sys",
 ]
 
 [[package]]
 name = "rustversion"
 version = "1.0.23"
 source = "registry+https://github.com/rust-lang/crates.io-index"
@@ -771,12 +1121,32 @@ checksum = "cf54715a573b99ac80df0bc206da022bcd442c974952c7b9720069370852e21f"
 [[package]]
 name = "ryu"
 version = "1.0.23"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "9774ba4a74de5f7b1c1451ed6cd5285a32eddb5cccb8cc655a4e50009e06477f"
 
+[[package]]
+name = "sec1"
+version = "0.7.3"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "d3e97a565f76233a6003f9f5c54be1d9c5bdfa3eccfb189469f11ec4901c47dc"
+dependencies = [
+ "base16ct",
+ "der",
+ "generic-array",
+ "pkcs8",
+ "subtle",
+ "zeroize",
+]
+
+[[package]]
+name = "semver"
+version = "1.0.28"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "8a7852d02fc848982e0c167ef163aaff9cd91dc640ba85e263cb1ce46fae51cd"
+
 [[package]]
 name = "serde"
 version = "1.0.229"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "4148590afebada386688f18773da617792bf2ef03ffc1e4cbd2b1d45b023e0ba"
 dependencies = [
@@ -854,12 +1224,22 @@ dependencies = [
 [[package]]
 name = "shlex"
 version = "2.0.1"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "f8fadd59c855ef2080decdef8ff161eb6661b86933c9d82e5ba29dc602a55aba"
 
+[[package]]
+name = "signature"
+version = "2.2.0"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "77549399552de45a898a580c1b41d445bf730df867cc44e6c0233bbc4b8329de"
+dependencies = [
+ "digest",
+ "rand_core",
+]
+
 [[package]]
 name = "simple_asn1"
 version = "0.6.4"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "0d585997b0ac10be3c5ee635f1bab02d512760d14b7c468801ac8a01d9ae5f1d"
 dependencies = [
@@ -885,15 +1265,37 @@ checksum = "ba467056f1b547ed52077911161fc86985becbc60e8e1857c8a144dab0def891"
 name = "socket2"
 version = "0.6.5"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "c3d1e2c7f27f8d4cb10542a02c49005dbd6e93095799d6f3be745fae9f8fedd4"
 dependencies = [
  "libc",
- "windows-sys 0.61.2",
+ "windows-sys",
+]
+
+[[package]]
+name = "spin"
+version = "0.9.9"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "3763264f6b73151db08c50ff20d7d8a0b8796e021cdea7ceedad07b80155fa0e"
+
+[[package]]
+name = "spki"
+version = "0.7.3"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "d91ed6c858b01f942cd56b37a94b3e0a1798290327d1236e4d9cf4eaca44d29d"
+dependencies = [
+ "base64ct",
+ "der",
 ]
 
+[[package]]
+name = "subtle"
+version = "2.6.1"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "13c2bddecc57b384dee18652358fb23172facb8a2c51ccc10d74c157bdea3292"
+
 [[package]]
 name = "syn"
 version = "2.0.119"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "872831b642d1a07999a962a351ed35b955ea2cfc8f3862091e2a240a84f17297"
 dependencies = [
@@ -926,13 +1328,13 @@ source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "32497e9a4c7b38532efcdebeef879707aa9f794296a4f0244f6f69e9bc8574bd"
 dependencies = [
  "fastrand",
  "getrandom 0.4.3",
  "once_cell",
  "rustix",
- "windows-sys 0.61.2",
+ "windows-sys",
 ]
 
 [[package]]
 name = "thiserror"
 version = "2.0.20"
 source = "registry+https://github.com/rust-lang/crates.io-index"
@@ -990,13 +1392,13 @@ checksum = "202caea871b69668250d242070849eb495be178ed697a3e98aebce5bc81a0bed"
 dependencies = [
  "libc",
  "mio",
  "pin-project-lite",
  "socket2",
  "tokio-macros",
- "windows-sys 0.61.2",
+ "windows-sys",
 ]
 
 [[package]]
 name = "tokio-macros"
 version = "2.7.2"
 source = "registry+https://github.com/rust-lang/crates.io-index"
@@ -1079,18 +1481,12 @@ checksum = "b6f5e870be6c3b371b77fe0ee0bafb859fa4964b4404c27de1d380043c4dda20"
 [[package]]
 name = "unicode-ident"
 version = "1.0.26"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "d245f478577f809a851594d02313b640fb437e0bb33866753cff937863096954"
 
-[[package]]
-name = "untrusted"
-version = "0.9.0"
-source = "registry+https://github.com/rust-lang/crates.io-index"
-checksum = "8ecb6da28b8a351d773b68d5825ac39017e680750f980f3a1a85cd8dd28a47c1"
-
 [[package]]
 name = "vcpkg"
 version = "0.2.15"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "accd4ea62f7bb7a82fe23066fb0957d48ef677f6eeb8215f372f52e48bb32426"
 
@@ -1154,94 +1550,21 @@ dependencies = [
 [[package]]
 name = "windows-link"
 version = "0.2.1"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "f0805222e57f7521d6a62e36fa9163bc891acd422f971defe97d64e70d0a4fe5"
 
-[[package]]
-name = "windows-sys"
-version = "0.52.0"
-source = "registry+https://github.com/rust-lang/crates.io-index"
-checksum = "282be5f36a8ce781fad8c8ae18fa3f9beff57ec1b52cb3de0789201425d9a33d"
-dependencies = [
- "windows-targets",
-]
-
 [[package]]
 name = "windows-sys"
 version = "0.61.2"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "ae137229bcbd6cdf0f7b80a31df61766145077ddf49416a728b02cb3921ff3fc"
 dependencies = [
  "windows-link",
 ]
 
-[[package]]
-name = "windows-targets"
-version = "0.52.6"
-source = "registry+https://github.com/rust-lang/crates.io-index"
-checksum = "9b724f72796e036ab90c1021d4780d4d3d648aca59e491e6b98e725b84e99973"
-dependencies = [
- "windows_aarch64_gnullvm",
- "windows_aarch64_msvc",
- "windows_i686_gnu",
- "windows_i686_gnullvm",
- "windows_i686_msvc",
- "windows_x86_64_gnu",
- "windows_x86_64_gnullvm",
- "windows_x86_64_msvc",
-]
-
-[[package]]
-name = "windows_aarch64_gnullvm"
-version = "0.52.6"
-source = "registry+https://github.com/rust-lang/crates.io-index"
-checksum = "32a4622180e7a0ec044bb555404c800bc9fd9ec262ec147edd5989ccd0c02cd3"
-
-[[package]]
-name = "windows_aarch64_msvc"
-version = "0.52.6"
-source = "registry+https://github.com/rust-lang/crates.io-index"
-checksum = "09ec2a7bb152e2252b53fa7803150007879548bc709c039df7627cabbd05d469"
-
-[[package]]
-name = "windows_i686_gnu"
-version = "0.52.6"
-source = "registry+https://github.com/rust-lang/crates.io-index"
-checksum = "8e9b5ad5ab802e97eb8e295ac6720e509ee4c243f69d781394014ebfe8bbfa0b"
-
-[[package]]
-name = "windows_i686_gnullvm"
-version = "0.52.6"
-source = "registry+https://github.com/rust-lang/crates.io-index"
-checksum = "0eee52d38c090b3caa76c563b86c3a4bd71ef1a819287c19d586d7334ae8ed66"
-
-[[package]]
-name = "windows_i686_msvc"
-version = "0.52.6"
-source = "registry+https://github.com/rust-lang/crates.io-index"
-checksum = "240948bc05c5e7c6dabba28bf89d89ffce3e303022809e73deaefe4f6ec56c66"
-
-[[package]]
-name = "windows_x86_64_gnu"
-version = "0.52.6"
-source = "registry+https://github.com/rust-lang/crates.io-index"
-checksum = "147a5c80aabfbf0c7d901cb5895d1de30ef2907eb21fbbab29ca94c5b08b1a78"
-
-[[package]]
-name = "windows_x86_64_gnullvm"
-version = "0.52.6"
-source = "registry+https://github.com/rust-lang/crates.io-index"
-checksum = "24d5b23dc417412679681396f2b49f3de8c1473deb516bd34410872eff51ed0d"
-
-[[package]]
-name = "windows_x86_64_msvc"
-version = "0.52.6"
-source = "registry+https://github.com/rust-lang/crates.io-index"
-checksum = "589f6da84c646204747d1270a2a5661ea66ed1cced2631d546fdfb155959f9ec"
-
 [[package]]
 name = "zerocopy"
 version = "0.8.57"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "d35102a9f36d089ccae9e4c6802bc118be4487b80aaffc0ab4e0cf5ce92d2873"
 dependencies = [
@@ -1256,11 +1579,17 @@ checksum = "146c01f5ab44258da43cf276c74a2763db2ff3969c9c652c3f2de07041d0b2bc"
 dependencies = [
  "proc-macro2",
  "quote",
  "syn 2.0.119",
 ]
 
+[[package]]
+name = "zeroize"
+version = "1.9.0"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "e13c156562582aa81c60cb29407084cdb54c4164760106ab78e6c5b0858cf64e"
+
 [[package]]
 name = "zmij"
 version = "1.0.23"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "29666d0abbfad1e3dc4dcf6144730dd3a3ab225bbbdac83319345b1b44ccfc1b"

## FILE: server/Cargo.toml

diff --git a/server/Cargo.toml b/server/Cargo.toml
index db95a87..9c80f97 100644
--- a/server/Cargo.toml
+++ b/server/Cargo.toml
@@ -1,11 +1,11 @@
 [package]
 name = "mw-server"
 version = "0.1.0"
 edition.workspace = true
-rust-version.workspace = true
+rust-version = "1.85"
 license.workspace = true
 publish = false
 
 [lib]
 name = "server"
 
@@ -21,13 +21,13 @@ tokio.workspace = true
 rusqlite.workspace = true
 serde.workspace = true
 serde_json.workspace = true
 sha2.workspace = true
 hex.workspace = true
 anyhow.workspace = true
-jsonwebtoken = "9.3.1"
+jsonwebtoken = { version = "=10.3.0", features = ["rust_crypto"] }
 
 [dev-dependencies]
 mw-test-support = { path = "../engine/test-support" }
 tower.workspace = true
 http-body-util.workspace = true
 tempfile.workspace = true

## FILE: server/src/api.rs

diff --git a/server/src/api.rs b/server/src/api.rs
index 654f21e..ecec8ca 100644
--- a/server/src/api.rs
+++ b/server/src/api.rs
@@ -127,51 +127,72 @@ pub fn load_model(
 /// The real clock in seconds, as the store requires it. The store itself never reads the
 /// clock: time is passed in so lock expiry is testable without sleeping.
 fn now_seconds() -> i64 {
     now_epoch().parse().unwrap_or(0)
 }
 
-/// A body may name an actor in an `author` or `holder` field. Once authentication is
-/// configured that claimed name must agree with the verified identity, or the request is
-/// refused with 403 BEFORE anything is written, so a caller can never put another person's
-/// name into the record. A missing or empty name proceeds - it names nobody. In open mode
-/// nobody was authenticated, so no name can be "someone else's" and the check is skipped;
-/// the audit still records the honest subject, "anonymous".
+/// The author a commit records. In configured mode an empty (or absent) author defaults to
+/// the verified subject, and a non-empty author must equal it or the request is refused with
+/// 403 BEFORE anything is written - so a caller can never put another person's name into the
+/// record, and a blank author can never contradict the audit's verified subject. In open mode
+/// nobody was authenticated, so no name can be "someone else's" and the claimed name passes
+/// through unchanged.
+pub fn resolve_author(
+    auth: &AuthConfig,
+    identity: &Identity,
+    claimed: &str,
+) -> Result<String, ApiError> {
+    if matches!(auth, AuthConfig::Open) {
+        return Ok(claimed.to_string());
+    }
+    if claimed.is_empty() {
+        return Ok(identity.subject.clone());
+    }
+    if claimed == identity.subject.as_str() {
+        return Ok(claimed.to_string());
+    }
+    Err(ApiError::forbidden(
+        "the request names an actor other than the authenticated caller",
+    ))
+}
+
+/// A body may name an actor in a `holder` field. Once authentication is configured that
+/// claimed name must agree with the verified identity, or the request is refused with 403
+/// BEFORE anything is written, so a caller can never put another person's name into the
+/// record. A missing or empty name proceeds - it names nobody. In open mode nobody was
+/// authenticated, so no name can be "someone else's" and the check is skipped.
 pub fn verify_actor(
     auth: &AuthConfig,
     identity: &Identity,
     claimed: Option<&str>,
 ) -> Result<(), ApiError> {
-    if matches!(auth, AuthConfig::Open) {
-        return Ok(());
-    }
     match claimed {
-        Some(name) if !name.is_empty() && name != identity.subject.as_str() => Err(
-            ApiError::forbidden("the request names an actor other than the authenticated caller"),
-        ),
-        _ => Ok(()),
+        Some(name) => resolve_author(auth, identity, name).map(|_| ()),
+        None => Ok(()),
     }
 }
 
 /// Record a refusal - an action that was ATTEMPTED but refused - in the audit log. A
 /// refusal is not a mutation, so it appends directly rather than riding a transaction; the
 /// event matters even though nothing changed.
 pub fn record_refusal(
     store: &dyn Store,
     project: &str,
     actor: &str,
+    mechanism: &str,
     action: &str,
     subject: &str,
     detail: &str,
 ) -> Result<(), ApiError> {
     store
         .append_audit(&AuditEntry {
             id: 0,
             project: project.to_string(),
             at: now_seconds(),
             actor: actor.to_string(),
+            mechanism: mechanism.to_string(),
             action: action.to_string(),
             subject: subject.to_string(),
             detail: detail.to_string(),
         })
         .map(|_| ())
         .map_err(map_store_error)
@@ -198,12 +219,13 @@ pub fn commit_refusal_guard(
             // still correctly refused, and reporting 500 would tell the caller their commit
             // failed for an unrelated reason and invite a retry that cannot succeed.
             if let Err(recording) = record_refusal(
                 state.store.as_ref(),
                 project,
                 actor,
+                state.auth.mechanism(),
                 "commit.refused",
                 branch,
                 &detail,
             ) {
                 eprintln!("could not record the refusal: {:?}", recording);
             }
@@ -304,12 +326,13 @@ pub async fn create_project(
     validate_name("project name", &body.name)?;
     let audit = AuditEntry {
         id: 0,
         project: body.name.clone(),
         at: now_seconds(),
         actor: identity.subject.clone(),
+        mechanism: state.auth.mechanism().to_string(),
         action: "project.create".to_string(),
         subject: body.name.clone(),
         detail: "project created".to_string(),
     };
     let project = state
         .store
@@ -340,12 +363,13 @@ pub async fn list_projects(
     Ok(Json(Value::Array(out)))
 }
 
 #[derive(Deserialize)]
 pub struct CreateCommit {
     pub branch: String,
+    #[serde(default)]
     pub author: String,
     pub message: String,
     pub okf: Value,
     pub holder: Option<String>,
 }
 
@@ -358,13 +382,15 @@ pub async fn create_commit(
     if !identity.may(Permission::Write) {
         return Err(ApiError::forbidden("write permission required"));
     }
     if !identity.may_reach(&project) {
         return Err(ApiError::forbidden("project not in scope"));
     }
-    verify_actor(&state.auth, &identity, Some(&body.author))?;
+    // In configured mode an empty author is the verified subject, never a blank string that
+    // would contradict the audit's actor.
+    let author = resolve_author(&state.auth, &identity, &body.author)?;
     verify_actor(&state.auth, &identity, body.holder.as_deref())?;
     if state
         .store
         .project(&project)
         .map_err(map_store_error)?
         .is_none()
@@ -433,12 +459,13 @@ pub async fn create_commit(
     // commit and its record of who made it succeed or fail together.
     let audit = AuditEntry {
         id: 0,
         project: project.clone(),
         at: now,
         actor: identity.subject.clone(),
+        mechanism: state.auth.mechanism().to_string(),
         action: "commit.create".to_string(),
         subject: body.branch.clone(),
         detail: body.message.clone(),
     };
     let commit = commit_refusal_guard(
         &state,
@@ -446,13 +473,13 @@ pub async fn create_commit(
         &body.branch,
         &identity.subject,
         state.store.commit_model(
             &project,
             &body.branch,
             &okf_hash,
-            &body.author,
+            &author,
             &body.message,
             Some(guard),
             Some(&audit),
         ),
     )?;
     Ok((StatusCode::CREATED, Json(commit_json(&commit))))
@@ -537,12 +564,13 @@ pub async fn create_branch(
     validate_name("branch name", &body.name)?;
     let audit = AuditEntry {
         id: 0,
         project: project.clone(),
         at: now_seconds(),
         actor: identity.subject.clone(),
+        mechanism: state.auth.mechanism().to_string(),
         action: "branch.create".to_string(),
         subject: body.name.clone(),
         detail: format!("from {}", body.from),
     };
     state
         .store
@@ -598,12 +626,13 @@ pub async fn delete_branch(
     validate_name("branch name", &name)?;
     let audit = AuditEntry {
         id: 0,
         project: project.clone(),
         at: now_seconds(),
         actor: identity.subject.clone(),
+        mechanism: state.auth.mechanism().to_string(),
         action: "branch.delete".to_string(),
         subject: name.clone(),
         detail: "branch deleted".to_string(),
     };
     state
         .store
@@ -612,12 +641,13 @@ pub async fn delete_branch(
     Ok(StatusCode::NO_CONTENT)
 }
 
 #[derive(Deserialize)]
 pub struct ResetBranch {
     pub to: String,
+    #[serde(default)]
     pub author: String,
     pub message: String,
     /// Who is reverting. As with a commit, supplying the holder lets the lease holder
     /// proceed; omitting it means any live lease on a changed element refuses the reset.
     pub holder: Option<String>,
 }
@@ -634,13 +664,13 @@ pub async fn reset_branch(
     if !identity.may(Permission::Write) {
         return Err(ApiError::forbidden("write permission required"));
     }
     if !identity.may_reach(&project) {
         return Err(ApiError::forbidden("project not in scope"));
     }
-    verify_actor(&state.auth, &identity, Some(&body.author))?;
+    let author = resolve_author(&state.auth, &identity, &body.author)?;
     verify_actor(&state.auth, &identity, body.holder.as_deref())?;
     validate_name("branch name", &name)?;
     if state
         .store
         .project(&project)
         .map_err(map_store_error)?
@@ -675,12 +705,13 @@ pub async fn reset_branch(
     // the bytes: the restored content is byte-identical to the original by construction.
     let audit = AuditEntry {
         id: 0,
         project: project.clone(),
         at: now_seconds(),
         actor: identity.subject.clone(),
+        mechanism: state.auth.mechanism().to_string(),
         action: "branch.reset".to_string(),
         subject: name.clone(),
         detail: format!("reset to {}", body.to),
     };
     let commit = commit_refusal_guard(
         &state,
@@ -688,13 +719,13 @@ pub async fn reset_branch(
         &name,
         &identity.subject,
         state.store.commit_model(
             &project,
             &name,
             &target.okf_hash,
-            &body.author,
+            &author,
             &body.message,
             Some(guard),
             Some(&audit),
         ),
     )?;
     Ok((StatusCode::CREATED, Json(commit_json(&commit))))

## FILE: server/src/auth.rs

diff --git a/server/src/auth.rs b/server/src/auth.rs
index a25bc1a..91d7b49 100644
--- a/server/src/auth.rs
+++ b/server/src/auth.rs
@@ -3,14 +3,14 @@
 //!
 //! Authentication is OPT-IN. With no configuration the service runs in OPEN mode, every
 //! request is accepted, and the identity is an anonymous admin (`Identity::open()`). When
 //! a static bearer token is configured, a request must present it (SHA-256, compared in
 //! constant time) or be refused with 401. When a JWKS is configured, a request must
 //! present a signed JWT whose RS256/RS384/RS512 signature verifies against one of the
-//! configured keys and whose expiry, issuer and audience are valid; roles and projects
-//! arrive from configurable claims.
+//! configured keys and whose expiry, not-before, issuer and audience are valid; roles and
+//! projects arrive from configurable claims.
 
 use std::collections::HashMap;
 
 use axum::extract::FromRequestParts;
 use axum::http::request::Parts;
 use axum::http::HeaderMap;
@@ -145,32 +145,26 @@ impl std::fmt::Debug for AuthConfig {
         }
     }
 }
 
 impl AuthConfig {
     /// Read the configuration from the environment. A static token (`MW_AUTH_TOKEN`) is
-    /// the simplest option; signed JWTs arrive from a JWKS at a file path
-    /// (`MW_AUTH_JWKS`, a mounted secret - what an air-gapped install has) or, second, a
-    /// URL fetched once at startup (`MW_AUTH_JWKS_URL`). With neither the service runs
-    /// OPEN. A malformed JWKS is a startup error, not a silent fall back to open mode.
+    /// the simplest option; signed JWTs arrive from a JWKS at the file path `MW_AUTH_JWKS`
+    /// (a mounted secret, which is what an air-gapped install has). With neither the service
+    /// runs OPEN. A malformed JWKS is a startup error, not a silent fall back to open mode.
     pub fn from_env() -> anyhow::Result<AuthConfig> {
         if let Ok(token) = std::env::var("MW_AUTH_TOKEN") {
             if !token.trim().is_empty() {
                 return Ok(AuthConfig::static_token(token.trim()));
             }
         }
         if let Ok(path) = std::env::var("MW_AUTH_JWKS") {
             if !path.trim().is_empty() {
                 return AuthConfig::from_jwks_file(path.trim());
             }
         }
-        if let Ok(url) = std::env::var("MW_AUTH_JWKS_URL") {
-            if !url.trim().is_empty() {
-                return AuthConfig::from_jwks_url(url.trim());
-            }
-        }
         Ok(AuthConfig::Open)
     }
 
     /// Build the static-token configuration, hashing the token ONCE so every later
     /// comparison is over a fixed-width digest and no token length is leaked.
     pub fn static_token(token: &str) -> AuthConfig {
@@ -209,15 +203,14 @@ impl AuthConfig {
             audience,
             role_claim,
             project_claim,
         }
     }
 
-    /// Build a JWT configuration from a JWKS FILE (the primary source: a mounted secret,
-    /// which is what an air-gapped install has). Issuer, audience and claim names come
-    /// from the environment.
+    /// Build a JWT configuration from a JWKS FILE (a mounted secret, which is what an
+    /// air-gapped install has). Issuer, audience and claim names come from the environment.
     pub fn from_jwks_file(path: &str) -> anyhow::Result<AuthConfig> {
         let jwks = std::fs::read_to_string(path)
             .map_err(|e| anyhow::anyhow!("cannot read the JWKS at {}: {}", path, e))?;
         let keys = parse_jwks(&jwks)?;
         Ok(AuthConfig::jwt_with_claims(
             keys,
@@ -225,33 +218,31 @@ impl AuthConfig {
             jwt_env_audience(),
             jwt_env_claim("MW_AUTH_ROLES_CLAIM", "roles"),
             jwt_env_claim("MW_AUTH_PROJECTS_CLAIM", "projects"),
         ))
     }
 
-    /// Build a JWT configuration from a JWKS fetched once at startup from a URL. This is
-    /// the second choice behind the file path: a service that cannot start without
-    /// outbound network access cannot run in an air-gapped install.
-    pub fn from_jwks_url(url: &str) -> anyhow::Result<AuthConfig> {
-        let jwks = fetch_jwks_url(url)?;
-        let keys = parse_jwks(&jwks)?;
-        Ok(AuthConfig::jwt_with_claims(
-            keys,
-            jwt_env_issuer(),
-            jwt_env_audience(),
-            jwt_env_claim("MW_AUTH_ROLES_CLAIM", "roles"),
-            jwt_env_claim("MW_AUTH_PROJECTS_CLAIM", "projects"),
-        ))
-    }
-
     /// Pin every request to one identity. This is a test hook: `from_env` never produces
     /// it, and it exists so the role and project-scope decisions on every route can be
     /// exercised with a viewer, an author or a single-project scope.
     pub fn fixed(identity: Identity) -> AuthConfig {
         AuthConfig::Fixed(identity)
     }
+
+    /// HOW the caller authenticated, for the audit log and the health check. This is a
+    /// fixed set - `open`, `static`, `jwt`, or `fixed` (the test-only hook) - so a year-later
+    /// reader can tell a shared token from a named JWT subject. It is the mechanism ONLY:
+    /// never a token, a key or a path.
+    pub fn mechanism(&self) -> &'static str {
+        match self {
+            AuthConfig::Open => "open",
+            AuthConfig::Static { .. } => "static",
+            AuthConfig::Jwt { .. } => "jwt",
+            AuthConfig::Fixed(_) => "fixed",
+        }
+    }
 }
 
 /// SHA-256 of a token as lowercase hex. The configured token is hashed once at startup so
 /// the stored secret is a fixed-width digest, never the token itself.
 pub fn hash_token(token: &str) -> String {
     hex::encode(Sha256::digest(token.as_bytes()))
@@ -294,52 +285,44 @@ pub fn parse_identity_from_static(token: &str, config: &AuthConfig) -> Option<Id
         Some(static_identity())
     } else {
         None
     }
 }
 
-/// Parse a JWKS document into decoding keys, keyed by each key's `kid` (an empty string
-/// when a key declares none). Only RSA keys are kept: they are the only kind that can
-/// verify the RSA signatures this service accepts, and a set that also carries an EC or
-/// octet key is common rather than erroneous.
+/// Parse a JWKS document into decoding keys, keyed by each key's `kid`. Only RSA keys are
+/// kept: they are the only kind that can verify the RSA signatures this service accepts, and
+/// a set that also carries an EC or octet key is common rather than erroneous. A missing or
+/// duplicate `kid` is a startup ERROR rather than a silent overwrite: a rotation that made
+/// the previous key unreachable must not pass without a signal.
 pub fn parse_jwks(jwks: &str) -> anyhow::Result<HashMap<String, DecodingKey>> {
     let set: jsonwebtoken::jwk::JwkSet = serde_json::from_str(jwks)
         .map_err(|e| anyhow::anyhow!("the JWKS is not valid JSON: {}", e))?;
     let mut keys = HashMap::new();
     for jwk in set.keys {
         let jsonwebtoken::jwk::AlgorithmParameters::RSA(rsa) = jwk.algorithm else {
             continue;
         };
+        let kid = jwk
+            .common
+            .key_id
+            .ok_or_else(|| anyhow::anyhow!("a JWKS RSA key has no kid"))?;
+        if kid.is_empty() {
+            return Err(anyhow::anyhow!("a JWKS RSA key has an empty kid"));
+        }
         let key = DecodingKey::from_rsa_components(&rsa.n, &rsa.e)
             .map_err(|e| anyhow::anyhow!("a JWKS RSA key is unusable: {}", e))?;
-        keys.insert(jwk.common.key_id.unwrap_or_default(), key);
+        if keys.insert(kid.clone(), key).is_some() {
+            return Err(anyhow::anyhow!("duplicate JWKS kid {}", kid));
+        }
     }
     if keys.is_empty() {
         return Err(anyhow::anyhow!("the JWKS contains no RSA keys"));
     }
     Ok(keys)
 }
 
-/// Fetch a JWKS from a URL once, at startup, by shelling out to `curl`. This is the only
-/// way to reach an HTTPS URL without adding a second dependency (an HTTP/TLS stack), and it
-/// is deliberately a startup-time operation for the URL path, which only exists for
-/// environments that already have outbound network access.
-fn fetch_jwks_url(url: &str) -> anyhow::Result<String> {
-    let output = std::process::Command::new("curl")
-        .args(["--fail", "--silent", "--show-error", "--location", url])
-        .output()
-        .map_err(|e| anyhow::anyhow!("cannot run curl to fetch the JWKS: {}", e))?;
-    if !output.status.success() {
-        return Err(anyhow::anyhow!(
-            "curl failed to fetch the JWKS: {}",
-            String::from_utf8_lossy(&output.stderr).trim()
-        ));
-    }
-    String::from_utf8(output.stdout).map_err(|_| anyhow::anyhow!("the fetched JWKS is not UTF-8"))
-}
-
 /// The expected issuer from `MW_AUTH_ISSUER`, or `None` when it is unset or empty.
 fn jwt_env_issuer() -> Option<String> {
     std::env::var("MW_AUTH_ISSUER")
         .ok()
         .filter(|v| !v.trim().is_empty())
 }
@@ -372,14 +355,14 @@ fn string_list_claim(claims: &serde_json::Value, key: &str) -> Vec<String> {
             .collect(),
         _ => Vec::new(),
     }
 }
 
 /// Resolve a presented token against the JWT configuration: `Some(identity)` when the
-/// signature, expiry, issuer and audience all verify, `None` otherwise. A non-JWT
-/// configuration has no keys to verify against, so it is `None`.
+/// signature, expiry, not-before, issuer and audience all verify, `None` otherwise. A
+/// non-JWT configuration has no keys to verify against, so it is `None`.
 pub fn parse_identity_from_jwt(token: &str, config: &AuthConfig) -> Option<Identity> {
     let AuthConfig::Jwt {
         keys,
         issuer,
         audience,
         role_claim,
@@ -407,12 +390,21 @@ pub fn parse_identity_from_jwt(token: &str, config: &AuthConfig) -> Option<Ident
     let mut validation = Validation::new(header.alg);
     // 60 seconds of clock skew, so a service and an identity provider whose clocks differ
     // by seconds do not lock users out. Validation::new already requires `exp` and
     // rejects a malformed or absent expiry, so a token cannot shed its expiry by giving it
     // the wrong JSON type.
     validation.leeway = 60;
+    // Enforce `nbf` exactly like `exp`: a future not-before is refused, and because `nbf`
+    // is required, a token whose `nbf` has the wrong JSON type is refused rather than
+    // treated as absent (the same type-confusion that motivated requiring `exp`).
+    validation.validate_nbf = true;
+    validation.required_spec_claims.insert("nbf".to_string());
+    // A subject is mandatory: the audit log records the verified `sub` as the actor, so a
+    // token without one (or with a wrong-typed one) must be refused rather than accepted as
+    // an identity with an empty subject that then breaks every write.
+    validation.required_spec_claims.insert("sub".to_string());
 
     if let Some(iss) = issuer {
         validation.set_issuer(&[iss.as_str()]);
         // Requiring the claim makes a missing OR malformed issuer a hard failure rather
         // than a silently skipped check.
         validation.required_spec_claims.insert("iss".to_string());
@@ -430,17 +422,20 @@ pub fn parse_identity_from_jwt(token: &str, config: &AuthConfig) -> Option<Ident
         }
     }
 
     let data = decode::<serde_json::Value>(token, key, &validation).ok()?;
     let claims = data.claims;
 
+    // `required_spec_claims` guarantees the claim is PRESENT; this guarantees it is a
+    // non-empty STRING. A `sub` of the wrong JSON type (or an empty string) is refused with
+    // 401, never accepted as an identity with an empty subject.
     let subject = claims
         .get("sub")
         .and_then(|v| v.as_str())
-        .unwrap_or("")
-        .to_string();
+        .filter(|s| !s.is_empty())
+        .map(|s| s.to_string())?;
     let roles = string_list_claim(&claims, role_claim);
     let projects = string_list_claim(&claims, project_claim);
 
     Some(Identity {
         subject,
         roles,
@@ -619,38 +614,63 @@ mod tests {
         assert!(!a.contains("the-token"));
         assert_ne!(hash_token("the-token"), hash_token("other-token"));
     }
 
     #[test]
     fn parse_jwks_keeps_rsa_keys_by_kid_and_skips_others() {
-        // Two RSA keys (one kid-less) and one octet key that must be skipped.
+        // Two RSA keys with distinct kids and one octet key that must be skipped.
         let jwks = serde_json::json!({
             "keys": [
                 { "kty": "RSA", "kid": "k1", "n": "AQID", "e": "AQAB" },
-                { "kty": "RSA", "n": "BAUG", "e": "AQAB" },
+                { "kty": "RSA", "kid": "k3", "n": "BAUG", "e": "AQAB" },
                 { "kty": "oct", "kid": "k2", "k": "c2VjcmV0" },
             ]
         });
         let keys = parse_jwks(&jwks.to_string()).expect("a JWKS with RSA keys parses");
         assert_eq!(keys.len(), 2, "the octet key must be skipped");
         assert!(keys.contains_key("k1"), "kid k1 must be present");
-        assert!(
-            keys.contains_key(""),
-            "the kid-less key maps to the empty string"
-        );
+        assert!(keys.contains_key("k3"), "kid k3 must be present");
         assert!(!keys.contains_key("k2"), "the octet key must not be kept");
     }
 
     #[test]
     fn parse_jwks_rejects_a_set_with_no_rsa_keys() {
         let jwks = serde_json::json!({
             "keys": [ { "kty": "oct", "kid": "k", "k": "c2VjcmV0" } ]
         });
         assert!(parse_jwks(&jwks.to_string()).is_err());
     }
 
+    #[test]
+    fn parse_jwks_rejects_a_missing_or_empty_kid() {
+        // A rotation that ships a key without a kid would otherwise make that key silently
+        // unreachable; a missing kid must be a startup error.
+        let missing = serde_json::json!({
+            "keys": [ { "kty": "RSA", "n": "AQID", "e": "AQAB" } ]
+        });
+        assert!(parse_jwks(&missing.to_string()).is_err());
+
+        let empty = serde_json::json!({
+            "keys": [ { "kty": "RSA", "kid": "", "n": "AQID", "e": "AQAB" } ]
+        });
+        assert!(parse_jwks(&empty.to_string()).is_err());
+    }
+
+    #[test]
+    fn parse_jwks_rejects_a_duplicate_kid() {
+        // Two keys claiming the same kid would silently overwrite one with the other; the
+        // later key would never be reachable and the earlier would be lost.
+        let jwks = serde_json::json!({
+            "keys": [
+                { "kty": "RSA", "kid": "k1", "n": "AQID", "e": "AQAB" },
+                { "kty": "RSA", "kid": "k1", "n": "BAUG", "e": "AQAB" },
+            ]
+        });
+        assert!(parse_jwks(&jwks.to_string()).is_err());
+    }
+
     #[test]
     fn string_list_claim_reads_array_single_string_and_denies_absence() {
         let claims = serde_json::json!({
             "roles": ["author", "reviewer"],
             "one": "admin",
             "wrong": 7,
@@ -663,16 +683,30 @@ mod tests {
         assert_eq!(string_list_claim(&claims, "wrong"), Vec::<String>::new());
         assert_eq!(string_list_claim(&claims, "absent"), Vec::<String>::new());
     }
 
     #[test]
     fn jwt_debug_redacts_the_keys() {
-        let config = AuthConfig::jwt(HashMap::new(), Some("iss".into()), Some("aud".into()));
+        // Build the config from a REAL parsed JWKS: an empty key map would pass this
+        // assertion even if the Debug impl printed every key, because there would be no
+        // key material to print.
+        let jwks = serde_json::json!({
+            "keys": [ { "kty": "RSA", "kid": "k1", "n": "AQID", "e": "AQAB" } ]
+        });
+        let keys = parse_jwks(&jwks.to_string()).expect("the JWKS parses");
+        let config = AuthConfig::jwt(keys, Some("iss".into()), Some("aud".into()));
         let debug = format!("{:?}", config);
         assert!(debug.contains("AuthConfig::Jwt"));
-        assert!(debug.contains("keys"));
+        assert!(
+            debug.contains("keys: 1"),
+            "the key COUNT is reported, not the keys themselves"
+        );
+        assert!(
+            !debug.contains("k1"),
+            "a JWKS kid must not appear in the debug output"
+        );
         assert!(
             !debug.contains("AQID"),
-            "a JWKS key must not appear in the debug output"
+            "a JWKS modulus must not appear in the debug output"
         );
     }
 }

## FILE: server/src/gate_api.rs

diff --git a/server/src/gate_api.rs b/server/src/gate_api.rs
index d6c00e3..402850d 100644
--- a/server/src/gate_api.rs
+++ b/server/src/gate_api.rs
@@ -57,12 +57,13 @@ pub async fn run_gate(
     let verdict = if outcome.passed { "passed" } else { "failed" };
     let audit = AuditEntry {
         id: 0,
         project: project.clone(),
         at: now_seconds(),
         actor: identity.subject.clone(),
+        mechanism: state.auth.mechanism().to_string(),
         action: "gate.run".to_string(),
         subject: body.candidate.clone(),
         detail: format!(
             "{}: candidate {} against reference {}",
             verdict, body.candidate, body.reference
         ),
@@ -90,14 +91,16 @@ pub async fn run_gate(
 
 pub async fn list_gate_runs(
     identity: Identity,
     State(state): State<ApiState>,
     Path(project): Path<String>,
 ) -> Result<Json<Value>, ApiError> {
-    if !identity.may(Permission::Review) {
-        return Err(ApiError::forbidden("review permission required"));
+    // An author may RUN a gate (Write), so it must be able to SEE the result too; a
+    // reviewer reads runs it did not start. Either role may list.
+    if !identity.may(Permission::Write) && !identity.may(Permission::Review) {
+        return Err(ApiError::forbidden("write or review permission required"));
     }
     if !identity.may_reach(&project) {
         return Err(ApiError::forbidden("project not in scope"));
     }
     let runs = state.store.gate_runs(&project).map_err(map_store_error)?;
     let out: Vec<Value> = runs

## FILE: server/src/lib.rs

diff --git a/server/src/lib.rs b/server/src/lib.rs
index 65038a9..29d607d 100644
--- a/server/src/lib.rs
+++ b/server/src/lib.rs
@@ -10,12 +10,13 @@ pub mod merge_api;
 pub mod store;
 
 pub use error::ApiError;
 
 use std::sync::Arc;
 
+use axum::extract::State;
 use axum::routing::{get, post};
 use axum::{Json, Router};
 use serde_json::json;
 
 #[derive(Clone)]
 pub struct AppState {
@@ -82,17 +83,19 @@ pub fn app(state: AppState) -> Router {
             "/projects/:project/locks/release",
             post(locks_api::release_locks),
         )
         .with_state(api_state)
 }
 
-/// Liveness. Public on purpose, and note it takes NO state: it has no store to reach, so
-/// it cannot disclose or touch anything. A health check that needs a token is a health
-/// check that fails during the incident it exists to detect.
-async fn health() -> Json<serde_json::Value> {
-    Json(json!({ "status": "ok" }))
+/// Liveness. Public on purpose: it never reaches the store, and it needs no token - a
+/// health check that requires a credential fails exactly during the incident it exists to
+/// detect. It reports the AUTH MODE so a deployment that forgot to configure authentication
+/// is visible to monitoring rather than only in a stderr line; it reports the mode ONLY,
+/// never a token, a key or a path.
+async fn health(State(state): State<api::ApiState>) -> Json<serde_json::Value> {
+    Json(json!({ "status": "ok", "authMode": state.auth.mechanism() }))
 }
 
 /// Build information. Public and stateless for the same reason as health.
 async fn version() -> Json<serde_json::Value> {
     Json(json!({
         "server": env!("CARGO_PKG_VERSION"),

## FILE: server/src/locks_api.rs

diff --git a/server/src/locks_api.rs b/server/src/locks_api.rs
index f637c99..b18aa43 100644
--- a/server/src/locks_api.rs
+++ b/server/src/locks_api.rs
@@ -90,12 +90,13 @@ pub async fn acquire_locks(
     let now = now_seconds();
     let audit = AuditEntry {
         id: 0,
         project: project.clone(),
         at: now,
         actor: identity.subject.clone(),
+        mechanism: state.auth.mechanism().to_string(),
         action: "lock.acquire".to_string(),
         subject: elements.join(","),
         detail: format!(
             "{} element(s) by {} until {}",
             elements.len(),
             body.holder,
@@ -119,12 +120,13 @@ pub async fn acquire_locks(
                 // As with a refused commit: failing to record a refusal must not change the
                 // answer. The acquire was correctly refused; the caller is told so.
                 if let Err(recording) = record_refusal(
                     state.store.as_ref(),
                     &project,
                     &identity.subject,
+                    state.auth.mechanism(),
                     "lock.denied",
                     &elements.join(","),
                     &error.to_string(),
                 ) {
                     eprintln!("could not record the refusal: {:?}", recording);
                 }
@@ -192,12 +194,13 @@ pub async fn release_locks(
     // released ids), so the store writes the audit row only when it actually removed one.
     let audit = AuditEntry {
         id: 0,
         project: project.clone(),
         at: now_seconds(),
         actor: identity.subject.clone(),
+        mechanism: state.auth.mechanism().to_string(),
         action: "lock.release".to_string(),
         subject: body.ids.join(","),
         detail: "released lock(s)".to_string(),
     };
     let released = state
         .store

## FILE: server/src/main.rs

diff --git a/server/src/main.rs b/server/src/main.rs
index 0bdc33d..b0525ef 100644
--- a/server/src/main.rs
+++ b/server/src/main.rs
@@ -23,13 +23,14 @@ async fn main() -> anyhow::Result<()> {
     // installs working, so the warning is deliberate and loud, not an error.
     let auth = AuthConfig::from_env()?;
     if matches!(&auth, AuthConfig::Open) {
         eprintln!(
             "WARNING: mw-server is running WITHOUT authentication (open mode); \
              every request is accepted as an anonymous admin. Set MW_AUTH_TOKEN to \
-             require a bearer token."
+             require a shared bearer token, or MW_AUTH_JWKS to the path of a JWKS \
+             file to require signed JWTs."
         );
     }
 
     let store = Arc::new(SqliteStore::open(std::path::Path::new(&db_path))?);
     let addr = SocketAddr::from(([127, 0, 0, 1], port));
     let listener = tokio::net::TcpListener::bind(addr).await?;

## FILE: server/src/merge_api.rs

diff --git a/server/src/merge_api.rs b/server/src/merge_api.rs
index e94f78f..c9beb97 100644
--- a/server/src/merge_api.rs
+++ b/server/src/merge_api.rs
@@ -3,24 +3,25 @@ use axum::extract::{Path, State};
 use axum::http::StatusCode;
 use axum::Json;
 use serde::Deserialize;
 use serde_json::{json, Value};
 
 use crate::api::{
-    commit_json, commit_refusal_guard, load_model, map_store_error, touched_elements,
-    validate_name, verify_actor, ApiState,
+    commit_json, commit_refusal_guard, load_model, map_store_error, resolve_author,
+    touched_elements, validate_name, verify_actor, ApiState,
 };
 use crate::auth::{Identity, Permission};
 use crate::error::ApiError;
 use crate::merge::merge;
 use crate::store::{now_seconds, AuditEntry, CommitGuard};
 
 #[derive(Deserialize)]
 pub struct MergeRequest {
     pub branch: String,
     pub other: String,
+    #[serde(default)]
     pub author: String,
     pub message: String,
     /// Who is merging. Supplying it lets a caller proceed on elements it holds a lease on;
     /// omitting it means the caller cannot be the holder, so any live lease on a changed
     /// element refuses the merge rather than overwriting somebody else's work.
     pub holder: Option<String>,
@@ -122,13 +123,13 @@ pub async fn merge_branches(
     if !identity.may(Permission::Write) {
         return Err(ApiError::forbidden("write permission required"));
     }
     if !identity.may_reach(&project) {
         return Err(ApiError::forbidden("project not in scope"));
     }
-    verify_actor(&state.auth, &identity, Some(&body.author))?;
+    let author = resolve_author(&state.auth, &identity, &body.author)?;
     verify_actor(&state.auth, &identity, body.holder.as_deref())?;
     validate_name("branch name", &body.branch)?;
     validate_name("branch name", &body.other)?;
     if state
         .store
         .project(&project)
@@ -164,12 +165,13 @@ pub async fn merge_branches(
             .store
             .append_audit(&AuditEntry {
                 id: 0,
                 project: project.clone(),
                 at: now_seconds(),
                 actor: identity.subject.clone(),
+                mechanism: state.auth.mechanism().to_string(),
                 action: "merge.conflict".to_string(),
                 subject: body.branch.clone(),
                 detail: format!("merge conflict between {} and {}", body.branch, body.other),
             })
             .map_err(map_store_error)?;
         return Ok((
@@ -234,12 +236,13 @@ pub async fn merge_branches(
     };
     let audit = AuditEntry {
         id: 0,
         project: project.clone(),
         at: now_seconds(),
         actor: identity.subject.clone(),
+        mechanism: state.auth.mechanism().to_string(),
         action: "merge.clean".to_string(),
         subject: body.branch.clone(),
         detail: format!("merged {} into {}", body.other, body.branch),
     };
     let commit = commit_refusal_guard(
         &state,
@@ -248,13 +251,13 @@ pub async fn merge_branches(
         &identity.subject,
         state.store.commit_merge(
             &project,
             &body.branch,
             &parents,
             &okf_hash,
-            &body.author,
+            &author,
             &body.message,
             Some(guard),
             Some(&audit),
         ),
     )?;
 

## FILE: server/src/store/mod.rs

diff --git a/server/src/store/mod.rs b/server/src/store/mod.rs
index a830e7f..c97c37a 100644
--- a/server/src/store/mod.rs
+++ b/server/src/store/mod.rs
@@ -49,20 +49,24 @@ pub struct Lock {
 }
 
 /// One entry in the append-only audit log. The `id` is assigned by the store on append
 /// (callers pass 0); `at` is the wall-clock time supplied by the HTTP layer, never read
 /// inside the store; `actor` is the verified identity's subject - who actually performed
 /// the action - never a name taken from the request body. In open mode that subject is
-/// "anonymous": nobody was authenticated, which is the honest statement.
+/// "anonymous": nobody was authenticated, which is the honest statement. `mechanism` records
+/// HOW the caller authenticated (`open`, `static` or `jwt`) so a shared token is never
+/// recorded byte-identically to a named individual; it is the subject's companion, not a
+/// substitute for it.
 #[derive(Debug, Clone, PartialEq, Serialize)]
 #[serde(rename_all = "camelCase")]
 pub struct AuditEntry {
     pub id: i64,
     pub project: String,
     pub at: i64,
     pub actor: String,
+    pub mechanism: String,
     pub action: String,
     pub subject: String,
     pub detail: String,
 }
 
 #[derive(Debug)]

## FILE: server/src/store/sqlite.rs

diff --git a/server/src/store/sqlite.rs b/server/src/store/sqlite.rs
index 00059f2..bc00570 100644
--- a/server/src/store/sqlite.rs
+++ b/server/src/store/sqlite.rs
@@ -55,20 +55,25 @@ CREATE TABLE IF NOT EXISTS locks (
 CREATE INDEX IF NOT EXISTS locks_element ON locks(project, element);
 CREATE TABLE IF NOT EXISTS audit (
     id INTEGER PRIMARY KEY AUTOINCREMENT,
     project TEXT NOT NULL,
     at INTEGER NOT NULL,
     actor TEXT NOT NULL,
+    mechanism TEXT NOT NULL,
     action TEXT NOT NULL,
     subject TEXT NOT NULL,
     detail TEXT NOT NULL,
     -- An entry that names nobody or nothing is not a record of anything. The constraint is
     -- also how a test can make an audit write fail on purpose: if the entry cannot be
     -- written, the mutation it describes must not survive either, which is the atomicity
     -- the audit trail promises.
     CHECK (length(actor) > 0),
+    -- The mechanism must always be recorded: without it, a shared token and a named
+    -- individual become byte-identical once the subject matches, which is exactly the
+    -- per-person attribution the log must not imply.
+    CHECK (length(mechanism) > 0),
     CHECK (length(action) > 0)
 );
 -- Append-only is a property of the DATABASE, not a convention of the trait: these
 -- triggers make UPDATE and DELETE on the audit table fail outright, so a written entry
 -- can never be rewritten or removed by any code path that reaches SQLite.
 CREATE TRIGGER IF NOT EXISTS audit_no_update
@@ -129,14 +134,14 @@ fn parse_parents(hash: &str, raw: &str) -> Result<Vec<String>, StoreError> {
 /// Insert one audit row and return its AUTOINCREMENT id. The caller's `id` field is
 /// ignored: the store assigns ids, and no update or delete path ever reuses or rewrites one.
 /// Shared by `append_audit` and by the transactions that must write the audit row
 /// atomically with the mutation it describes.
 fn insert_audit(c: &Connection, entry: &AuditEntry) -> rusqlite::Result<i64> {
     c.execute(
-        "INSERT INTO audit (project, at, actor, action, subject, detail) VALUES (?1, ?2, ?3, ?4, ?5, ?6)",
-        params![entry.project, entry.at, entry.actor, entry.action, entry.subject, entry.detail],
+        "INSERT INTO audit (project, at, actor, mechanism, action, subject, detail) VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7)",
+        params![entry.project, entry.at, entry.actor, entry.mechanism, entry.action, entry.subject, entry.detail],
     )?;
     Ok(c.last_insert_rowid())
 }
 
 /// Run a closure inside ONE write transaction, committing only when it succeeds. On
 /// failure the transaction is dropped, which rolls back every statement the closure ran.
@@ -667,23 +672,24 @@ impl Store for SqliteStore {
     }
 
     fn audit(&self, project: &str, limit: i64) -> Result<Vec<AuditEntry>, StoreError> {
         let limit = limit.clamp(1, 1000);
         self.with(|c| {
             let mut stmt = c.prepare(
-                "SELECT id, project, at, actor, action, subject, detail FROM audit WHERE project = ?1 ORDER BY id DESC LIMIT ?2",
+                "SELECT id, project, at, actor, mechanism, action, subject, detail FROM audit WHERE project = ?1 ORDER BY id DESC LIMIT ?2",
             )?;
             let rows = stmt.query_map(params![project, limit], |row| {
                 Ok(AuditEntry {
                     id: row.get(0)?,
                     project: row.get(1)?,
                     at: row.get(2)?,
                     actor: row.get(3)?,
-                    action: row.get(4)?,
-                    subject: row.get(5)?,
-                    detail: row.get(6)?,
+                    mechanism: row.get(4)?,
+                    action: row.get(5)?,
+                    subject: row.get(6)?,
+                    detail: row.get(7)?,
                 })
             })?;
             rows.collect()
         })
     }
 

## FILE: server/tests/audit.rs

diff --git a/server/tests/audit.rs b/server/tests/audit.rs
index 1ddbee2..1450292 100644
--- a/server/tests/audit.rs
+++ b/server/tests/audit.rs
@@ -715,6 +715,36 @@ async fn every_path_records_the_identity_rather_than_the_claimed_name() {
             entry["actor"], "anonymous",
             "{} recorded a claimed name instead of the verified subject",
             entry["action"]
         );
     }
 }
+#[tokio::test]
+async fn an_empty_or_absent_author_defaults_to_the_verified_subject() {
+    let (router, store, _dir) = app_with_identity(identity("alex"));
+    store.create_project("coffee", None).unwrap();
+
+    // An empty author must become the verified subject, not a blank string that would
+    // contradict the audit's actor.
+    let committed = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/commits",
+            json!({ "branch": "main", "author": "", "message": "base", "okf": model("Block") }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(committed.status(), StatusCode::CREATED);
+    assert_eq!(json_body(committed).await["author"], "alex");
+
+    // An absent author field is the same as an empty one in configured mode.
+    let committed = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/commits",
+            json!({ "branch": "main", "message": "second", "okf": model("Block") }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(committed.status(), StatusCode::CREATED);
+    assert_eq!(json_body(committed).await["author"], "alex");
+}

## FILE: server/tests/auth.rs

diff --git a/server/tests/auth.rs b/server/tests/auth.rs
index 535dada..e0f5261 100644
--- a/server/tests/auth.rs
+++ b/server/tests/auth.rs
@@ -168,12 +168,16 @@ fn viewer() -> Identity {
 }
 
 fn author() -> Identity {
     identity("author", &["author"], &["*"])
 }
 
+fn reviewer() -> Identity {
+    identity("reviewer", &["reviewer"], &["*"])
+}
+
 /// No roles at all: cannot even Read, so it is the denial identity for a route whose only
 /// requirement is Read and which has no project to scope (list projects).
 fn nobody() -> Identity {
     identity("nobody", &[], &["*"])
 }
 
@@ -223,12 +227,26 @@ fn app_with_identity(identity: Identity) -> (Router, Arc<SqliteStore>, tempfile:
         evidence_dir: dir.path().to_path_buf(),
         auth: AuthConfig::fixed(identity),
     };
     (app(state), store, dir)
 }
 
+/// Build the full application router with an ARBITRARY auth configuration (open, static or
+/// jwt), returning a handle to the store and the tempdir. Used to prove the audit log records
+/// HOW the caller authenticated, not just who they claimed to be.
+fn app_with_auth(auth: AuthConfig) -> (Router, Arc<SqliteStore>, tempfile::TempDir) {
+    let dir = tempfile::tempdir().unwrap();
+    let store = Arc::new(SqliteStore::open(&dir.path().join("mw.db")).unwrap());
+    let state = AppState {
+        store: store.clone(),
+        evidence_dir: dir.path().to_path_buf(),
+        auth,
+    };
+    (app(state), store, dir)
+}
+
 #[tokio::test]
 async fn static_mode_requires_a_token_on_a_real_route() {
     // A real route (not /whoami) must refuse a missing token with 401 BEFORE consulting the
     // store: with the token absent and no "coffee" project, reaching the store would 404.
     let dir = tempfile::tempdir().unwrap();
     let store = Arc::new(SqliteStore::open(&dir.path().join("mw.db")).unwrap());
@@ -380,13 +398,13 @@ async fn every_route_denies_a_caller_without_permission_or_scope() {
             "merge_branches",
             viewer(),
             post("/projects/coffee/merge", merge()),
         ),
         (
             "list_gate_runs",
-            author(),
+            viewer(),
             get("/projects/coffee/gate-runs"),
         ),
         ("list_audit", scoped_coffee(), get("/projects/tea/audit")),
         (
             "acquire_locks",
             viewer(),
@@ -518,12 +536,37 @@ async fn a_identity_that_reaches_nothing_sees_an_empty_listing() {
     assert_eq!(response.status(), StatusCode::OK);
     assert!(
         json_body(response).await.as_array().unwrap().is_empty(),
         "an identity scoped to nothing sees nothing"
     );
 }
+
+#[tokio::test]
+async fn an_author_and_a_reviewer_can_list_gate_runs() {
+    // An author may RUN a gate (Write), so it must be able to SEE the result too; a
+    // reviewer reads runs it did not start. A viewer holds neither role and stays refused.
+    for ident in [author(), reviewer()] {
+        let (router, _store, _dir) = app_with_identity(ident);
+        let response = router
+            .oneshot(get("/projects/coffee/gate-runs"))
+            .await
+            .unwrap();
+        assert_eq!(
+            response.status(),
+            StatusCode::OK,
+            "Write OR Review must list gate runs"
+        );
+    }
+
+    let (router, _store, _dir) = app_with_identity(viewer());
+    let response = router
+        .oneshot(get("/projects/coffee/gate-runs"))
+        .await
+        .unwrap();
+    assert_eq!(response.status(), StatusCode::FORBIDDEN);
+}
 // ---------------------------------------------------------------------------
 // Task 4: signed tokens (JWT) against a JWKS. A committed RSA-2048 key pair
 // (generated once, committed so tests need no network and no identity provider)
 // signs tokens; the JWKS carries only the public half. A second private key
 // proves that a token signed by the wrong key is refused.
 // ---------------------------------------------------------------------------
@@ -609,12 +652,13 @@ async fn jwt_mode_accepts_a_valid_token() {
         json!({
             "sub": "alex",
             "roles": ["author", "reviewer"],
             "projects": ["coffee"],
             "iss": "https://idp.example.com",
             "aud": "modelwrite",
+            "nbf": now() - 3600,
             "exp": now() + 3600,
         }),
         "test-key",
         PRIVATE_KEY,
     );
     let response = router.oneshot(bearer("/whoami", &token)).await.unwrap();
@@ -623,17 +667,57 @@ async fn jwt_mode_accepts_a_valid_token() {
     assert_eq!(body["subject"], "alex");
     assert_eq!(body["roles"][0], "author");
     assert_eq!(body["roles"][1], "reviewer");
     assert_eq!(body["projects"][0], "coffee");
 }
 
+#[tokio::test]
+async fn jwt_mode_rejects_a_token_with_no_sub() {
+    // A signed token with no subject must be refused, not accepted as an identity whose
+    // subject is empty: such an identity reads fine and then breaks every write at the audit
+    // table's non-empty-actor constraint.
+    let router = router(jwt_config(None, None));
+    let token = sign(
+        json!({ "roles": ["admin"], "nbf": now() - 3600, "exp": now() + 3600 }),
+        "test-key",
+        PRIVATE_KEY,
+    );
+    let response = router.oneshot(bearer("/whoami", &token)).await.unwrap();
+    assert_eq!(response.status(), StatusCode::UNAUTHORIZED);
+}
+
+#[tokio::test]
+async fn jwt_mode_rejects_a_token_with_an_empty_sub() {
+    let router = router(jwt_config(None, None));
+    let token = sign(
+        json!({ "sub": "", "roles": ["admin"], "nbf": now() - 3600, "exp": now() + 3600 }),
+        "test-key",
+        PRIVATE_KEY,
+    );
+    let response = router.oneshot(bearer("/whoami", &token)).await.unwrap();
+    assert_eq!(response.status(), StatusCode::UNAUTHORIZED);
+}
+
+#[tokio::test]
+async fn jwt_mode_rejects_a_wrong_typed_sub() {
+    // A `sub` of the wrong JSON type must be refused rather than treated as absent.
+    let router = router(jwt_config(None, None));
+    let token = sign(
+        json!({ "sub": 123, "roles": ["admin"], "nbf": now() - 3600, "exp": now() + 3600 }),
+        "test-key",
+        PRIVATE_KEY,
+    );
+    let response = router.oneshot(bearer("/whoami", &token)).await.unwrap();
+    assert_eq!(response.status(), StatusCode::UNAUTHORIZED);
+}
+
 #[tokio::test]
 async fn jwt_mode_rejects_an_expired_token_without_echoing_it() {
     let router = router(jwt_config(None, None));
     let token = sign(
-        json!({ "sub": "alex", "roles": ["author"], "exp": now() - 120 }),
+        json!({ "sub": "alex", "roles": ["author"], "nbf": now() - 3600, "exp": now() - 120 }),
         "test-key",
         PRIVATE_KEY,
     );
     let response = router.oneshot(bearer("/whoami", &token)).await.unwrap();
     assert_eq!(response.status(), StatusCode::UNAUTHORIZED);
     let text = body_text(response).await;
@@ -647,13 +731,13 @@ async fn jwt_mode_rejects_an_expired_token_without_echoing_it() {
 #[tokio::test]
 async fn jwt_mode_rejects_a_token_signed_by_the_wrong_key() {
     let router = router(jwt_config(None, None));
     // Signed with the OTHER private key but claiming the configured kid, so the right key
     // is selected and the signature check fails.
     let token = sign(
-        json!({ "sub": "alex", "roles": ["author"], "exp": now() + 3600 }),
+        json!({ "sub": "alex", "roles": ["author"], "nbf": now() - 3600, "exp": now() + 3600 }),
         "test-key",
         OTHER_PRIVATE_KEY,
     );
     let response = router.oneshot(bearer("/whoami", &token)).await.unwrap();
     assert_eq!(response.status(), StatusCode::UNAUTHORIZED);
 }
@@ -663,12 +747,13 @@ async fn jwt_mode_rejects_a_wrong_issuer() {
     let router = router(jwt_config(Some("https://idp.example.com"), None));
     let token = sign(
         json!({
             "sub": "alex",
             "roles": ["author"],
             "iss": "https://evil.example.com",
+            "nbf": now() - 3600,
             "exp": now() + 3600,
         }),
         "test-key",
         PRIVATE_KEY,
     );
     let response = router.oneshot(bearer("/whoami", &token)).await.unwrap();
@@ -676,13 +761,13 @@ async fn jwt_mode_rejects_a_wrong_issuer() {
 }
 
 #[tokio::test]
 async fn jwt_mode_rejects_a_missing_issuer() {
     let router = router(jwt_config(Some("https://idp.example.com"), None));
     let token = sign(
-        json!({ "sub": "alex", "roles": ["author"], "exp": now() + 3600 }),
+        json!({ "sub": "alex", "roles": ["author"], "nbf": now() - 3600, "exp": now() + 3600 }),
         "test-key",
         PRIVATE_KEY,
     );
     let response = router.oneshot(bearer("/whoami", &token)).await.unwrap();
     assert_eq!(response.status(), StatusCode::UNAUTHORIZED);
 }
@@ -692,12 +777,13 @@ async fn jwt_mode_rejects_a_wrong_audience() {
     let router = router(jwt_config(None, Some("modelwrite")));
     let token = sign(
         json!({
             "sub": "alex",
             "roles": ["author"],
             "aud": "some-other-service",
+            "nbf": now() - 3600,
             "exp": now() + 3600,
         }),
         "test-key",
         PRIVATE_KEY,
     );
     let response = router.oneshot(bearer("/whoami", &token)).await.unwrap();
@@ -721,13 +807,50 @@ async fn jwt_mode_rejects_alg_none() {
 #[tokio::test]
 async fn jwt_mode_rejects_a_malformed_expiry_type() {
     // A malformed exp (a string rather than a number) must be refused, not silently
     // treated as absent: otherwise an attacker could shed the expiry entirely.
     let router = router(jwt_config(None, None));
     let token = sign(
-        json!({ "sub": "alex", "roles": ["author"], "exp": "not-a-number" }),
+        json!({ "sub": "alex", "roles": ["author"], "nbf": now() - 3600, "exp": "not-a-number" }),
+        "test-key",
+        PRIVATE_KEY,
+    );
+    let response = router.oneshot(bearer("/whoami", &token)).await.unwrap();
+    assert_eq!(response.status(), StatusCode::UNAUTHORIZED);
+}
+
+#[tokio::test]
+async fn jwt_mode_rejects_a_token_whose_nbf_is_in_the_future() {
+    // A token whose not-before is still ahead must be refused, not accepted early.
+    let router = router(jwt_config(None, None));
+    let token = sign(
+        json!({
+            "sub": "alex",
+            "roles": ["author"],
+            "exp": now() + 7200,
+            "nbf": now() + 3600,
+        }),
+        "test-key",
+        PRIVATE_KEY,
+    );
+    let response = router.oneshot(bearer("/whoami", &token)).await.unwrap();
+    assert_eq!(response.status(), StatusCode::UNAUTHORIZED);
+}
+
+#[tokio::test]
+async fn jwt_mode_rejects_a_malformed_not_before_type() {
+    // A malformed nbf (a string rather than a number) must be refused, not silently
+    // treated as absent: otherwise a not-before could be shed entirely.
+    let router = router(jwt_config(None, None));
+    let token = sign(
+        json!({
+            "sub": "alex",
+            "roles": ["author"],
+            "exp": now() + 3600,
+            "nbf": "not-a-number",
+        }),
         "test-key",
         PRIVATE_KEY,
     );
     let response = router.oneshot(bearer("/whoami", &token)).await.unwrap();
     assert_eq!(response.status(), StatusCode::UNAUTHORIZED);
 }
@@ -735,26 +858,26 @@ async fn jwt_mode_rejects_a_malformed_expiry_type() {
 #[tokio::test]
 async fn jwt_mode_tolerates_clock_skew_within_the_window_but_not_beyond() {
     // 30 seconds of past expiry is inside the 60-second window, so a user is not locked
     // out by an identity provider whose clock runs slightly ahead.
     let router = router(jwt_config(None, None));
     let within = sign(
-        json!({ "sub": "alex", "roles": ["viewer"], "exp": now() - 30 }),
+        json!({ "sub": "alex", "roles": ["viewer"], "nbf": now() - 3600, "exp": now() - 30 }),
         "test-key",
         PRIVATE_KEY,
     );
     let response = router
         .clone()
         .oneshot(bearer("/whoami", &within))
         .await
         .unwrap();
     assert_eq!(response.status(), StatusCode::OK);
 
     // 120 seconds of past expiry is beyond the window and must be refused.
     let beyond = sign(
-        json!({ "sub": "alex", "roles": ["viewer"], "exp": now() - 120 }),
+        json!({ "sub": "alex", "roles": ["viewer"], "nbf": now() - 3600, "exp": now() - 120 }),
         "test-key",
         PRIVATE_KEY,
     );
     let response = router.oneshot(bearer("/whoami", &beyond)).await.unwrap();
     assert_eq!(response.status(), StatusCode::UNAUTHORIZED);
 }
@@ -770,13 +893,13 @@ async fn jwt_mode_without_a_roles_claim_cannot_write() {
         auth: jwt_config(None, None),
     };
     let router = app(state);
     // A valid token with no roles claim: it verifies, but holds no role, so a write is
     // refused with 403 rather than defaulting to a permissive identity.
     let token = sign(
-        json!({ "sub": "alex", "exp": now() + 3600 }),
+        json!({ "sub": "alex", "nbf": now() - 3600, "exp": now() + 3600 }),
         "test-key",
         PRIVATE_KEY,
     );
     let response = router
         .oneshot(bearer_post(
             "/projects/coffee/commits",
@@ -802,6 +925,83 @@ async fn from_jwks_file_loads_a_configuration() {
         AuthConfig::Jwt { keys, .. } => {
             assert!(keys.contains_key("test-key"), "the committed kid must load");
         }
         other => panic!("expected a Jwt config, got {:?}", other),
     }
 }
+async fn audit_entries(router: &axum::Router, token: Option<&str>) -> Vec<Value> {
+    let response = match token {
+        Some(t) => router.clone().oneshot(bearer("/projects/coffee/audit", t)),
+        None => router.clone().oneshot(get("/projects/coffee/audit")),
+    }
+    .await
+    .unwrap();
+    assert_eq!(response.status(), StatusCode::OK);
+    json_body(response).await.as_array().unwrap().clone()
+}
+
+#[tokio::test]
+async fn audit_entries_record_how_the_caller_authenticated() {
+    // OPEN: nobody was authenticated; the honest subject is "anonymous" and the mechanism
+    // says so.
+    let (router, _store, _dir) = app_with_auth(AuthConfig::Open);
+    let created = router
+        .clone()
+        .oneshot(post("/projects", json!({ "name": "coffee" })))
+        .await
+        .unwrap();
+    assert_eq!(created.status(), StatusCode::CREATED);
+    for entry in audit_entries(&router, None).await {
+        assert_eq!(entry["mechanism"], "open");
+        assert_eq!(
+            entry["actor"], "anonymous",
+            "the mechanism must not change the subject"
+        );
+    }
+
+    // STATIC: a shared token maps to the fixed subject "admin", but the log must say it was a
+    // shared token rather than imply a named individual.
+    let (router, _store, _dir) = app_with_auth(AuthConfig::static_token("the-token"));
+    let created = router
+        .clone()
+        .oneshot(bearer_post(
+            "/projects",
+            json!({ "name": "coffee" }),
+            "the-token",
+        ))
+        .await
+        .unwrap();
+    assert_eq!(created.status(), StatusCode::CREATED);
+    for entry in audit_entries(&router, Some("the-token")).await {
+        assert_eq!(entry["mechanism"], "static");
+        assert_eq!(entry["actor"], "admin");
+    }
+
+    // JWT: the subject arrives from the verified sub claim, and the mechanism records that a
+    // signed token was verified.
+    let (router, _store, _dir) = app_with_auth(jwt_config(None, None));
+    let token = sign(
+        json!({
+            "sub": "alex",
+            "roles": ["admin"],
+            "projects": ["*"],
+            "nbf": now() - 3600,
+            "exp": now() + 3600,
+        }),
+        "test-key",
+        PRIVATE_KEY,
+    );
+    let created = router
+        .clone()
+        .oneshot(bearer_post(
+            "/projects",
+            json!({ "name": "coffee" }),
+            &token,
+        ))
+        .await
+        .unwrap();
+    assert_eq!(created.status(), StatusCode::CREATED);
+    for entry in audit_entries(&router, Some(&token)).await {
+        assert_eq!(entry["mechanism"], "jwt");
+        assert_eq!(entry["actor"], "alex");
+    }
+}

## FILE: server/tests/fixtures/README.md

diff --git a/server/tests/fixtures/README.md b/server/tests/fixtures/README.md
new file mode 100644
index 0000000..7d888e3
--- /dev/null
+++ b/server/tests/fixtures/README.md
@@ -0,0 +1,16 @@
+These keys are TEST ONLY and must never be used to sign real tokens.
+
+This directory holds a committed RSA-2048 key pair (plus a second private key) used
+only by the JWT authentication tests under `server/tests/auth.rs`. They are committed
+on purpose: tests need no network access to an identity provider and no in-test key
+generation, so the suite is deterministic and works in an air-gapped checkout.
+
+- `rs256_private.pem` - the signing key the tests use; it is NOT a secret.
+- `rs256_other_private.pem` - a different signing key proving that a token signed by
+  the wrong key is refused.
+- `jwks.json` - the public half only (`kid` `test-key`, modulus `n`, exponent
+  `e`), in JWK-set form, which is what an operator would mount at `MW_AUTH_JWKS`.
+
+Because the private keys are published in this repository, they provide no security at
+all: never sign a production token with them, and never reuse them in a real identity
+provider.

## FILE: server/tests/http.rs

diff --git a/server/tests/http.rs b/server/tests/http.rs
index 1ffe790..b9b572c 100644
--- a/server/tests/http.rs
+++ b/server/tests/http.rs
@@ -1,38 +1,73 @@
 // SPDX-License-Identifier: AGPL-3.0-or-later
 use axum::body::Body;
 use axum::http::{Request, StatusCode};
 use http_body_util::BodyExt;
 use tower::ServiceExt;
 
-fn state(dir: &std::path::Path) -> server::AppState {
+use server::auth::AuthConfig;
+
+fn state_with_auth(dir: &std::path::Path, auth: AuthConfig) -> server::AppState {
     let store = server::store::sqlite::SqliteStore::open(&dir.join("mw.db")).unwrap();
     server::AppState {
         store: std::sync::Arc::new(store),
         evidence_dir: dir.to_path_buf(),
-        auth: server::auth::AuthConfig::Open,
+        auth,
     }
 }
 
-#[tokio::test]
-async fn health_answers_ok() {
-    let dir = tempfile::tempdir().unwrap();
-    let router = server::app(state(dir.path()));
+fn state(dir: &std::path::Path) -> server::AppState {
+    state_with_auth(dir, AuthConfig::Open)
+}
+
+async fn health_body(router: axum::Router) -> serde_json::Value {
     let response = router
         .oneshot(
             Request::builder()
                 .uri("/health")
                 .body(Body::empty())
                 .unwrap(),
         )
         .await
         .unwrap();
     assert_eq!(response.status(), StatusCode::OK);
     let bytes = response.into_body().collect().await.unwrap().to_bytes();
-    let value: serde_json::Value = serde_json::from_slice(&bytes).unwrap();
+    serde_json::from_slice(&bytes).unwrap()
+}
+
+#[tokio::test]
+async fn health_answers_ok_and_reports_the_open_mode() {
+    let dir = tempfile::tempdir().unwrap();
+    let router = server::app(state(dir.path()));
+    let value = health_body(router).await;
     assert_eq!(value["status"], "ok");
+    assert_eq!(value["authMode"], "open");
+}
+
+#[tokio::test]
+async fn health_reports_the_auth_mode_and_never_a_secret() {
+    let dir = tempfile::tempdir().unwrap();
+    let router = server::app(state_with_auth(
+        dir.path(),
+        AuthConfig::static_token("the-token"),
+    ));
+    let value = health_body(router).await;
+    assert_eq!(value["authMode"], "static");
+    assert!(
+        !value.to_string().contains("the-token"),
+        "a token must never appear in the health response"
+    );
+
+    // The mode is reported, not the keys: an empty key map is enough to prove the value.
+    let dir = tempfile::tempdir().unwrap();
+    let router = server::app(state_with_auth(
+        dir.path(),
+        AuthConfig::jwt(std::collections::HashMap::new(), None, None),
+    ));
+    let value = health_body(router).await;
+    assert_eq!(value["authMode"], "jwt");
 }
 
 #[tokio::test]
 async fn version_names_the_service() {
     let dir = tempfile::tempdir().unwrap();
     let router = server::app(state(dir.path()));

## FILE: server/tests/store.rs

diff --git a/server/tests/store.rs b/server/tests/store.rs
index 52f9513..291b405 100644
--- a/server/tests/store.rs
+++ b/server/tests/store.rs
@@ -393,12 +393,13 @@ fn audit_rows_ride_each_mutation_transaction() {
     let (store, _dir) = store();
     let entry = |action: &str| AuditEntry {
         id: 0,
         project: "coffee".to_string(),
         at: 1,
         actor: "alex".to_string(),
+        mechanism: "jwt".to_string(),
         action: action.to_string(),
         subject: "s".to_string(),
         detail: "d".to_string(),
     };
 
     store
@@ -485,12 +486,13 @@ fn the_audit_table_refuses_update_and_delete() {
     store
         .append_audit(&AuditEntry {
             id: 0,
             project: "coffee".to_string(),
             at: 1,
             actor: "a".to_string(),
+            mechanism: "open".to_string(),
             action: "x".to_string(),
             subject: "s".to_string(),
             detail: "d".to_string(),
         })
         .unwrap();
 
@@ -515,12 +517,13 @@ fn a_mutation_rolls_back_when_its_audit_entry_cannot_be_written() {
     let (store, _dir) = store();
     let unwritable = AuditEntry {
         id: 0,
         project: "coffee".to_string(),
         at: 0,
         actor: String::new(),
+        mechanism: "open".to_string(),
         action: "project.create".to_string(),
         subject: "coffee".to_string(),
         detail: "an entry that names nobody is not a record".to_string(),
     };
 
     let refused = store.create_project("coffee", Some(&unwritable));
