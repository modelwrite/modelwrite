# Task 3 Report: The audit actor becomes the verified identity

## Status

DONE_WITH_CONCERNS

## Commits

- 2384112 feat: record verified actors in the audit log

## Test summary

135 tests passed, 0 failed across the whole workspace (server 91: lib 8, api 11, audit 10, auth 11, corpus 1, gate_api 3, http 2, locks 15, merge 15, merge_api 4, store 11; engine 44: capi 4, gate 5, graph 7, mcp 13, okf_diff 8, okf_validation 7).

## What changed

- server/src/api.rs: added `verify_actor` (refuses a body author/holder that disagrees with the verified identity with 403, skipped in open mode); project.create, branch.create, branch.delete, commit.create and branch.reset audit `actor` now carry `identity.subject`; `commit_refusal_guard` takes the verified `actor`.
- server/src/merge_api.rs: merge.conflict and merge.clean audit actors carry `identity.subject`; author/holder verified.
- server/src/locks_api.rs: lock.acquire, lock.release and lock.denied actors carry `identity.subject`; holder verified on acquire and release.
- server/src/gate_api.rs: gate.run actor carries `identity.subject` (no longer "unknown").
- server/src/store/mod.rs: `AuditEntry.actor` documented as the verified subject.
- server/tests/audit.rs: five new tests — every previously-"unknown" path names the identity; an authenticated commit records the identity; a mismatched author is refused 403 with nothing recorded; a mismatched holder is refused 403 with nothing recorded; open mode records "anonymous".

## Self-review

- Every audit entry names the verified identity subject (all `actor:` sites use `identity.subject`).
- The four previously-"unknown" paths (project.create, branch.create, branch.delete, gate.run) now name a subject.
- A mismatched actor is refused with 403 BEFORE any write, leaving no commit, no lock and no audit entry.
- Open mode records "anonymous" (the honest statement that nobody was authenticated) while still accepting the claimed body author/holder.
- No path panics; the refusal error body carries a generic message with no internal detail and no token.
- The audit row still rides the mutation's own transaction (only the `actor` value changed, not the write path).

## Concerns

- `cargo fmt --all` reformatted one pre-existing line in `server/tests/auth.rs` (`a_scoped_identity_only_sees_the_projects_it_may_reach`) that was over rustfmt's preferred width. This is a formatting-only change, not part of the task's functional scope, but it is required to keep `cargo fmt --all --check` clean and is inside server/, so it was committed alongside the task's changes.

## Verification

- cargo test --workspace --no-fail-fast: exit 0 (135 passed, 0 failed).
- cargo fmt --all --check: exit 0 (clean).
- cargo clippy --workspace --all-targets -- -D warnings: exit 0 (clean).
