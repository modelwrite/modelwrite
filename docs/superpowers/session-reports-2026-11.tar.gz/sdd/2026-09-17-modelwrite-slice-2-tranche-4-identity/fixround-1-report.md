# Fix Round 1 — Slice 2 Tranche 4 (Identity)

Status: DONE

## Commits

- `98b52ce` fix: enforce nbf, drop curl JWKS fetch, upgrade jsonwebtoken

## Test summary

156 tests passed, 0 failed across the workspace (17 non-empty test binaries: capi 4, gate 5, graph 7, mcp 13, okf_diff 8, okf_validation 7, server-lib 12, api 11, audit 11, auth 27, corpus 1, gate_api 3, http 2, locks 15, merge 15, merge_api 4, store 11). `cargo fmt --all` clean; `cargo clippy --workspace --all-targets -- -D warnings` clean.

## Dependency (Ruling 1)

- Crate version: jsonwebtoken 10.3.0 (pinned exactly; the registry also offers 10.4.0 and 11.1.0).
- Crypto backend: `rust_crypto` — pure Rust (rsa / p256 / p384 / ed25519-dalek / hmac / sha2); no C toolchain (`aws-lc-rs` was not selected).
- Server MSRV: 1.85 (jsonwebtoken 10.3.0 declares `rust-version = "1.85.0"`).
- API changes requiring code changes: none. `decode`, `decode_header`, `Validation`, `DecodingKey::from_rsa_components`, and `jsonwebtoken::jwk::JwkSet` keep the same shapes used here; the only migration cost was choosing a crypto backend (mandatory in 10.x). The nbf changes are a deliberate security fix, not an API migration.

## Changes made

- Ruling 1: `server/Cargo.toml` upgrades jsonwebtoken 9.3.1 -> 10.3.0 with `rust_crypto`, and the server crate's `rust-version` moves 1.75 -> 1.85. The workspace `Cargo.toml` and all engine crates are untouched (they carry their own `rust-version`; only the server's was raised).
- Ruling 2: removed `MW_AUTH_JWKS_URL`, `AuthConfig::from_jwks_url`, and `fetch_jwks_url` (the curl shell-out) from `server/src/auth.rs`. `MW_AUTH_JWKS` (file) is now the only JWKS source; the `from_env` doc and related comments name the file path only.
- Finding 1: in `parse_identity_from_jwt`, set `validation.validate_nbf = true` and added `"nbf"` to `required_spec_claims`. Added two tests: a future-nbf token is refused, and a wrong-type-nbf token is refused.
- M1: added `server/tests/fixtures/README.md` (first line states the keys are TEST ONLY; explains they are committed so tests need no network and no in-test key generation).
- M2: the open-mode startup warning now names both `MW_AUTH_TOKEN` and `MW_AUTH_JWKS`.
- M3: `jwt_debug_redacts_the_keys` now parses a real JWKS and asserts the kid and modulus do not appear, so redaction is actually exercised.

## Concerns / deviations

- Pinned `=10.3.0` rather than a caret `10.3.0` (which would resolve to 10.4.0, MSRV 1.88). Reason: the ruling named 10.3.0 and reported MSRV "1.85+"; 10.4.0 and 11.1.0 both require MSRV 1.88. 10.3.0 contains the type-confusion fix (CHANGELOG: "Fix type confusion with exp/nbf when not required"; CVE-2026-25537 / GHSA-h395-gr6q-cpjc). If the controller prefers the newest release, that is a one-line change to `server/Cargo.toml` (10.4.0 or 11.1.0) plus `rust-version = "1.88"`.
- Because nbf is now a required claim, every pre-existing test token that must verify now carries a past `nbf`; this is a direct consequence of Finding 1, not a behavior change outside it.
