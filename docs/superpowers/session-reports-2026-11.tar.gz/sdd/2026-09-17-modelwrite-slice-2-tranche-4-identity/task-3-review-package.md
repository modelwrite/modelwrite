﻿# Tranche 4 Task 3 review package (verified actors in the audit log)

## Commits under review

3414025 test: pin the public routes, the no-role denial, and the empty-scope listing
2384112 feat: record verified actors in the audit log

## Diff stat

 server/src/api.rs       |  48 ++++++++---
 server/src/auth.rs      |   2 +
 server/src/gate_api.rs  |   2 +-
 server/src/lib.rs       |   4 +
 server/src/locks_api.rs |  12 ++-
 server/src/merge_api.rs |  10 ++-
 server/src/store/mod.rs |   5 +-
 server/tests/audit.rs   | 220 ++++++++++++++++++++++++++++++++++++++++++++++++
 server/tests/auth.rs    |  75 ++++++++++++++++-
 9 files changed, 356 insertions(+), 22 deletions(-)

## Every changed file, in full

## FILE: server/src/api.rs

diff --git a/server/src/api.rs b/server/src/api.rs
index 659efab..654f21e 100644
--- a/server/src/api.rs
+++ b/server/src/api.rs
@@ -127,12 +127,34 @@ pub fn load_model(
 /// The real clock in seconds, as the store requires it. The store itself never reads the
 /// clock: time is passed in so lock expiry is testable without sleeping.
 fn now_seconds() -> i64 {
     now_epoch().parse().unwrap_or(0)
 }
 
+/// A body may name an actor in an `author` or `holder` field. Once authentication is
+/// configured that claimed name must agree with the verified identity, or the request is
+/// refused with 403 BEFORE anything is written, so a caller can never put another person's
+/// name into the record. A missing or empty name proceeds - it names nobody. In open mode
+/// nobody was authenticated, so no name can be "someone else's" and the check is skipped;
+/// the audit still records the honest subject, "anonymous".
+pub fn verify_actor(
+    auth: &AuthConfig,
+    identity: &Identity,
+    claimed: Option<&str>,
+) -> Result<(), ApiError> {
+    if matches!(auth, AuthConfig::Open) {
+        return Ok(());
+    }
+    match claimed {
+        Some(name) if !name.is_empty() && name != identity.subject.as_str() => Err(
+            ApiError::forbidden("the request names an actor other than the authenticated caller"),
+        ),
+        _ => Ok(()),
+    }
+}
+
 /// Record a refusal - an action that was ATTEMPTED but refused - in the audit log. A
 /// refusal is not a mutation, so it appends directly rather than riding a transaction; the
 /// event matters even though nothing changed.
 pub fn record_refusal(
     store: &dyn Store,
     project: &str,
@@ -154,18 +176,20 @@ pub fn record_refusal(
         .map(|_| ())
         .map_err(map_store_error)
 }
 
 /// Call a commit-producing store method and, if it is refused because an element is
 /// locked, record commit.refused before surfacing the 409. A lock refusal is the
-/// highest-value event this feature produces: it is the overwrite the lock prevented.
+/// highest-value event this feature produces: it is the overwrite the lock prevented. The
+/// `actor` is the verified identity's subject - a refusal is an audit entry and must carry
+/// the same verified actor as every other entry.
 pub fn commit_refusal_guard(
     state: &ApiState,
     project: &str,
     branch: &str,
-    author: &str,
+    actor: &str,
     result: Result<Commit, StoreError>,
 ) -> Result<Commit, ApiError> {
     match result {
         Ok(commit) => Ok(commit),
         Err(error) if is_lock_refusal(&error) => {
             let detail = error.to_string();
@@ -173,13 +197,13 @@ pub fn commit_refusal_guard(
             // written, that is a problem with the log, not with the caller: the write was
             // still correctly refused, and reporting 500 would tell the caller their commit
             // failed for an unrelated reason and invite a retry that cannot succeed.
             if let Err(recording) = record_refusal(
                 state.store.as_ref(),
                 project,
-                author,
+                actor,
                 "commit.refused",
                 branch,
                 &detail,
             ) {
                 eprintln!("could not record the refusal: {:?}", recording);
             }
@@ -279,13 +303,13 @@ pub async fn create_project(
     }
     validate_name("project name", &body.name)?;
     let audit = AuditEntry {
         id: 0,
         project: body.name.clone(),
         at: now_seconds(),
-        actor: "unknown".to_string(),
+        actor: identity.subject.clone(),
         action: "project.create".to_string(),
         subject: body.name.clone(),
         detail: "project created".to_string(),
     };
     let project = state
         .store
@@ -334,12 +358,14 @@ pub async fn create_commit(
     if !identity.may(Permission::Write) {
         return Err(ApiError::forbidden("write permission required"));
     }
     if !identity.may_reach(&project) {
         return Err(ApiError::forbidden("project not in scope"));
     }
+    verify_actor(&state.auth, &identity, Some(&body.author))?;
+    verify_actor(&state.auth, &identity, body.holder.as_deref())?;
     if state
         .store
         .project(&project)
         .map_err(map_store_error)?
         .is_none()
     {
@@ -406,22 +432,22 @@ pub async fn create_commit(
     // instead of forking the history. The audit row rides the SAME transaction, so the
     // commit and its record of who made it succeed or fail together.
     let audit = AuditEntry {
         id: 0,
         project: project.clone(),
         at: now,
-        actor: body.author.clone(),
+        actor: identity.subject.clone(),
         action: "commit.create".to_string(),
         subject: body.branch.clone(),
         detail: body.message.clone(),
     };
     let commit = commit_refusal_guard(
         &state,
         &project,
         &body.branch,
-        &body.author,
+        &identity.subject,
         state.store.commit_model(
             &project,
             &body.branch,
             &okf_hash,
             &body.author,
             &body.message,
@@ -510,13 +536,13 @@ pub async fn create_branch(
     }
     validate_name("branch name", &body.name)?;
     let audit = AuditEntry {
         id: 0,
         project: project.clone(),
         at: now_seconds(),
-        actor: "unknown".to_string(),
+        actor: identity.subject.clone(),
         action: "branch.create".to_string(),
         subject: body.name.clone(),
         detail: format!("from {}", body.from),
     };
     state
         .store
@@ -571,13 +597,13 @@ pub async fn delete_branch(
     }
     validate_name("branch name", &name)?;
     let audit = AuditEntry {
         id: 0,
         project: project.clone(),
         at: now_seconds(),
-        actor: "unknown".to_string(),
+        actor: identity.subject.clone(),
         action: "branch.delete".to_string(),
         subject: name.clone(),
         detail: "branch deleted".to_string(),
     };
     state
         .store
@@ -608,12 +634,14 @@ pub async fn reset_branch(
     if !identity.may(Permission::Write) {
         return Err(ApiError::forbidden("write permission required"));
     }
     if !identity.may_reach(&project) {
         return Err(ApiError::forbidden("project not in scope"));
     }
+    verify_actor(&state.auth, &identity, Some(&body.author))?;
+    verify_actor(&state.auth, &identity, body.holder.as_deref())?;
     validate_name("branch name", &name)?;
     if state
         .store
         .project(&project)
         .map_err(map_store_error)?
         .is_none()
@@ -646,22 +674,22 @@ pub async fn reset_branch(
     // The target's model is already stored, so this reuses its blob rather than copying
     // the bytes: the restored content is byte-identical to the original by construction.
     let audit = AuditEntry {
         id: 0,
         project: project.clone(),
         at: now_seconds(),
-        actor: body.author.clone(),
+        actor: identity.subject.clone(),
         action: "branch.reset".to_string(),
         subject: name.clone(),
         detail: format!("reset to {}", body.to),
     };
     let commit = commit_refusal_guard(
         &state,
         &project,
         &name,
-        &body.author,
+        &identity.subject,
         state.store.commit_model(
             &project,
             &name,
             &target.okf_hash,
             &body.author,
             &body.message,

## FILE: server/src/auth.rs

diff --git a/server/src/auth.rs b/server/src/auth.rs
index d3c15d3..92dbc80 100644
--- a/server/src/auth.rs
+++ b/server/src/auth.rs
@@ -114,12 +114,14 @@ impl std::fmt::Debug for AuthConfig {
                 .debug_struct("AuthConfig::Jwt")
                 .field("jwks_source", jwks_source)
                 .finish(),
             AuthConfig::Fixed(identity) => f
                 .debug_struct("AuthConfig::Fixed")
                 .field("subject", &identity.subject)
+                .field("roles", &identity.roles)
+                .field("projects", &identity.projects)
                 .finish(),
         }
     }
 }
 
 impl AuthConfig {

## FILE: server/src/gate_api.rs

diff --git a/server/src/gate_api.rs b/server/src/gate_api.rs
index 27575ea..d6c00e3 100644
--- a/server/src/gate_api.rs
+++ b/server/src/gate_api.rs
@@ -56,13 +56,13 @@ pub async fn run_gate(
     // run always has its record and vice versa.
     let verdict = if outcome.passed { "passed" } else { "failed" };
     let audit = AuditEntry {
         id: 0,
         project: project.clone(),
         at: now_seconds(),
-        actor: "unknown".to_string(),
+        actor: identity.subject.clone(),
         action: "gate.run".to_string(),
         subject: body.candidate.clone(),
         detail: format!(
             "{}: candidate {} against reference {}",
             verdict, body.candidate, body.reference
         ),

## FILE: server/src/lib.rs

diff --git a/server/src/lib.rs b/server/src/lib.rs
index 1a0b8c1..65038a9 100644
--- a/server/src/lib.rs
+++ b/server/src/lib.rs
@@ -82,16 +82,20 @@ pub fn app(state: AppState) -> Router {
             "/projects/:project/locks/release",
             post(locks_api::release_locks),
         )
         .with_state(api_state)
 }
 
+/// Liveness. Public on purpose, and note it takes NO state: it has no store to reach, so
+/// it cannot disclose or touch anything. A health check that needs a token is a health
+/// check that fails during the incident it exists to detect.
 async fn health() -> Json<serde_json::Value> {
     Json(json!({ "status": "ok" }))
 }
 
+/// Build information. Public and stateless for the same reason as health.
 async fn version() -> Json<serde_json::Value> {
     Json(json!({
         "server": env!("CARGO_PKG_VERSION"),
         "service": "mw-server"
     }))
 }

## FILE: server/src/locks_api.rs

diff --git a/server/src/locks_api.rs b/server/src/locks_api.rs
index 58198db..f637c99 100644
--- a/server/src/locks_api.rs
+++ b/server/src/locks_api.rs
@@ -2,13 +2,15 @@
 use axum::extract::{Path, State};
 use axum::http::StatusCode;
 use axum::Json;
 use serde::Deserialize;
 use serde_json::{json, Value};
 
-use crate::api::{map_store_error, record_refusal, validate_element_name, validate_name, ApiState};
+use crate::api::{
+    map_store_error, record_refusal, validate_element_name, validate_name, verify_actor, ApiState,
+};
 use crate::auth::{Identity, Permission};
 use crate::error::ApiError;
 use crate::store::{now_epoch, AuditEntry, Lock};
 
 /// The real clock in seconds, as the store requires it. The store itself never reads the
 /// clock: time is passed in so lock expiry is testable without sleeping.
@@ -49,12 +51,13 @@ pub async fn acquire_locks(
     if !identity.may(Permission::Write) {
         return Err(ApiError::forbidden("write permission required"));
     }
     if !identity.may_reach(&project) {
         return Err(ApiError::forbidden("project not in scope"));
     }
+    verify_actor(&state.auth, &identity, Some(&body.holder))?;
     validate_name("branch name", &body.branch)?;
     validate_holder(&body.holder)?;
     if body.elements.is_empty() {
         return Err(ApiError::bad_request("at least one element is required"));
     }
     for element in &body.elements {
@@ -86,13 +89,13 @@ pub async fn acquire_locks(
 
     let now = now_seconds();
     let audit = AuditEntry {
         id: 0,
         project: project.clone(),
         at: now,
-        actor: body.holder.clone(),
+        actor: identity.subject.clone(),
         action: "lock.acquire".to_string(),
         subject: elements.join(","),
         detail: format!(
             "{} element(s) by {} until {}",
             elements.len(),
             body.holder,
@@ -115,13 +118,13 @@ pub async fn acquire_locks(
             if crate::store::is_lock_refusal(&error) {
                 // As with a refused commit: failing to record a refusal must not change the
                 // answer. The acquire was correctly refused; the caller is told so.
                 if let Err(recording) = record_refusal(
                     state.store.as_ref(),
                     &project,
-                    &body.holder,
+                    &identity.subject,
                     "lock.denied",
                     &elements.join(","),
                     &error.to_string(),
                 ) {
                     eprintln!("could not record the refusal: {:?}", recording);
                 }
@@ -173,12 +176,13 @@ pub async fn release_locks(
     if !identity.may(Permission::Write) {
         return Err(ApiError::forbidden("write permission required"));
     }
     if !identity.may_reach(&project) {
         return Err(ApiError::forbidden("project not in scope"));
     }
+    verify_actor(&state.auth, &identity, Some(&body.holder))?;
     if state
         .store
         .project(&project)
         .map_err(map_store_error)?
         .is_none()
     {
@@ -187,13 +191,13 @@ pub async fn release_locks(
     // A release that removes nothing is not a mutation (a foreign holder, or already
     // released ids), so the store writes the audit row only when it actually removed one.
     let audit = AuditEntry {
         id: 0,
         project: project.clone(),
         at: now_seconds(),
-        actor: body.holder.clone(),
+        actor: identity.subject.clone(),
         action: "lock.release".to_string(),
         subject: body.ids.join(","),
         detail: "released lock(s)".to_string(),
     };
     let released = state
         .store

## FILE: server/src/merge_api.rs

diff --git a/server/src/merge_api.rs b/server/src/merge_api.rs
index 7108f73..e94f78f 100644
--- a/server/src/merge_api.rs
+++ b/server/src/merge_api.rs
@@ -4,13 +4,13 @@ use axum::http::StatusCode;
 use axum::Json;
 use serde::Deserialize;
 use serde_json::{json, Value};
 
 use crate::api::{
     commit_json, commit_refusal_guard, load_model, map_store_error, touched_elements,
-    validate_name, ApiState,
+    validate_name, verify_actor, ApiState,
 };
 use crate::auth::{Identity, Permission};
 use crate::error::ApiError;
 use crate::merge::merge;
 use crate::store::{now_seconds, AuditEntry, CommitGuard};
 
@@ -122,12 +122,14 @@ pub async fn merge_branches(
     if !identity.may(Permission::Write) {
         return Err(ApiError::forbidden("write permission required"));
     }
     if !identity.may_reach(&project) {
         return Err(ApiError::forbidden("project not in scope"));
     }
+    verify_actor(&state.auth, &identity, Some(&body.author))?;
+    verify_actor(&state.auth, &identity, body.holder.as_deref())?;
     validate_name("branch name", &body.branch)?;
     validate_name("branch name", &body.other)?;
     if state
         .store
         .project(&project)
         .map_err(map_store_error)?
@@ -161,13 +163,13 @@ pub async fn merge_branches(
         state
             .store
             .append_audit(&AuditEntry {
                 id: 0,
                 project: project.clone(),
                 at: now_seconds(),
-                actor: body.author.clone(),
+                actor: identity.subject.clone(),
                 action: "merge.conflict".to_string(),
                 subject: body.branch.clone(),
                 detail: format!("merge conflict between {} and {}", body.branch, body.other),
             })
             .map_err(map_store_error)?;
         return Ok((
@@ -231,22 +233,22 @@ pub async fn merge_branches(
         expected_tip: Some(&parents[0]),
     };
     let audit = AuditEntry {
         id: 0,
         project: project.clone(),
         at: now_seconds(),
-        actor: body.author.clone(),
+        actor: identity.subject.clone(),
         action: "merge.clean".to_string(),
         subject: body.branch.clone(),
         detail: format!("merged {} into {}", body.other, body.branch),
     };
     let commit = commit_refusal_guard(
         &state,
         &project,
         &body.branch,
-        &body.author,
+        &identity.subject,
         state.store.commit_merge(
             &project,
             &body.branch,
             &parents,
             &okf_hash,
             &body.author,

## FILE: server/src/store/mod.rs

diff --git a/server/src/store/mod.rs b/server/src/store/mod.rs
index ac204a5..a830e7f 100644
--- a/server/src/store/mod.rs
+++ b/server/src/store/mod.rs
@@ -47,14 +47,15 @@ pub struct Lock {
     pub acquired_at: i64,
     pub expires_at: i64,
 }
 
 /// One entry in the append-only audit log. The `id` is assigned by the store on append
 /// (callers pass 0); `at` is the wall-clock time supplied by the HTTP layer, never read
-/// inside the store; `actor` is what the request SAID it was - its author or holder - not
-/// a verified identity, which is a later tranche.
+/// inside the store; `actor` is the verified identity's subject - who actually performed
+/// the action - never a name taken from the request body. In open mode that subject is
+/// "anonymous": nobody was authenticated, which is the honest statement.
 #[derive(Debug, Clone, PartialEq, Serialize)]
 #[serde(rename_all = "camelCase")]
 pub struct AuditEntry {
     pub id: i64,
     pub project: String,
     pub at: i64,

## FILE: server/tests/audit.rs

diff --git a/server/tests/audit.rs b/server/tests/audit.rs
index 667cfd8..431ba50 100644
--- a/server/tests/audit.rs
+++ b/server/tests/audit.rs
@@ -1,13 +1,18 @@
 // SPDX-License-Identifier: AGPL-3.0-or-later
+use std::sync::Arc;
+
 use axum::body::Body;
 use axum::http::{Request, StatusCode};
 use http_body_util::BodyExt;
 use serde_json::{json, Value};
 use tower::ServiceExt;
 
+use server::auth::{AuthConfig, Identity};
+use server::store::{sqlite::SqliteStore, Store};
+
 fn state(dir: &std::path::Path) -> server::AppState {
     let store = server::store::sqlite::SqliteStore::open(&dir.join("mw.db")).unwrap();
     server::AppState {
         store: std::sync::Arc::new(store),
         evidence_dir: dir.to_path_buf(),
         auth: server::auth::AuthConfig::Open,
@@ -80,12 +85,36 @@ async fn commit(router: &axum::Router, branch: &str, message: &str, okf: Value)
     json_body(response).await["hash"]
         .as_str()
         .unwrap()
         .to_string()
 }
 
+/// An authenticated identity pinned to the given subject with the admin role, so it can
+/// create projects, commits, branches, gate runs and delete branches.
+fn identity(subject: &str) -> Identity {
+    Identity {
+        subject: subject.to_string(),
+        roles: vec!["admin".to_string()],
+        projects: vec!["*".to_string()],
+    }
+}
+
+/// Build the full application router pinned to one identity, returning a handle to the
+/// store so a test can prove a refused request recorded nothing. The tempdir is returned so
+/// it stays alive for as long as the router (and its open SQLite connection) is used.
+fn app_with_identity(identity: Identity) -> (axum::Router, Arc<SqliteStore>, tempfile::TempDir) {
+    let dir = tempfile::tempdir().unwrap();
+    let store = Arc::new(SqliteStore::open(&dir.path().join("mw.db")).unwrap());
+    let state = server::AppState {
+        store: store.clone(),
+        evidence_dir: dir.path().to_path_buf(),
+        auth: AuthConfig::fixed(identity),
+    };
+    (server::app(state), store, dir)
+}
+
 #[tokio::test]
 async fn every_mutation_is_recorded() {
     let dir = tempfile::tempdir().unwrap();
     let router = server::app(state(dir.path()));
 
     // project.create
@@ -388,6 +417,197 @@ async fn the_log_is_newest_first_and_capped() {
     assert_eq!(entries.len(), 2, "limit=2 must return exactly two entries");
     assert!(
         entries[0]["id"].as_i64().unwrap() > entries[1]["id"].as_i64().unwrap(),
         "the log must be newest first"
     );
 }
+
+#[tokio::test]
+async fn every_unknown_actor_path_now_names_the_identity() {
+    let (router, _store, _dir) = app_with_identity(identity("alex"));
+
+    // project.create
+    let created = router
+        .clone()
+        .oneshot(post("/projects", json!({ "name": "coffee" })))
+        .await
+        .unwrap();
+    assert_eq!(created.status(), StatusCode::CREATED);
+
+    // commit.create (base), then branch.create, gate.run and branch.delete.
+    let base = commit(&router, "main", "base", model("Block")).await;
+    let branched = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/branches",
+            json!({ "name": "feature", "from": base }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(branched.status(), StatusCode::CREATED);
+
+    let gated = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/gate",
+            json!({ "reference": base, "candidate": base }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(gated.status(), StatusCode::OK);
+
+    let deleted = router
+        .clone()
+        .oneshot(
+            Request::builder()
+                .method("DELETE")
+                .uri("/projects/coffee/branches/feature")
+                .body(Body::empty())
+                .unwrap(),
+        )
+        .await
+        .unwrap();
+    assert_eq!(deleted.status(), StatusCode::NO_CONTENT);
+
+    // Every previously-"unknown" action now names the verified identity.
+    let entries = read_audit(&router).await;
+    for action in [
+        "project.create",
+        "branch.create",
+        "gate.run",
+        "branch.delete",
+    ] {
+        let entry = entries
+            .iter()
+            .find(|e| e["action"] == action)
+            .unwrap_or_else(|| panic!("missing audit action {}", action));
+        assert_eq!(
+            entry["actor"], "alex",
+            "{} must name the verified identity, not \"unknown\"",
+            action
+        );
+    }
+}
+
+#[tokio::test]
+async fn an_authenticated_commit_records_the_identity() {
+    let (router, _store, _dir) = app_with_identity(identity("alex"));
+    let created = router
+        .clone()
+        .oneshot(post("/projects", json!({ "name": "coffee" })))
+        .await
+        .unwrap();
+    assert_eq!(created.status(), StatusCode::CREATED);
+
+    let committed = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/commits",
+            json!({ "branch": "main", "author": "alex", "message": "base", "okf": model("Block") }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(committed.status(), StatusCode::CREATED);
+
+    let entries = read_audit(&router).await;
+    let commit_entry = entries
+        .iter()
+        .find(|e| e["action"] == "commit.create")
+        .expect("a commit.create entry must be recorded");
+    assert_eq!(
+        commit_entry["actor"], "alex",
+        "the commit must be attributed to the verified identity"
+    );
+}
+
+#[tokio::test]
+async fn a_body_naming_another_actor_is_refused_and_records_nothing() {
+    let (router, store, _dir) = app_with_identity(identity("alex"));
+    // Seed the project directly so a denied commit is observable as "nothing changed".
+    store.create_project("coffee", None).unwrap();
+
+    let response = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/commits",
+            json!({ "branch": "main", "author": "someone-else", "message": "m", "okf": model("Block") }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(
+        response.status(),
+        StatusCode::FORBIDDEN,
+        "a body naming another actor must be refused with 403"
+    );
+
+    assert!(
+        store.commits_on("coffee", "main").unwrap().is_empty(),
+        "a refused commit must write no commit"
+    );
+    assert!(
+        store.audit("coffee", 1000).unwrap().is_empty(),
+        "a refused commit must write no audit entry"
+    );
+}
+
+#[tokio::test]
+async fn a_holder_naming_another_actor_is_refused_and_records_nothing() {
+    let (router, store, _dir) = app_with_identity(identity("alex"));
+    store.create_project("coffee", None).unwrap();
+
+    let response = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/locks",
+            json!({ "branch": "main", "elements": ["b1"], "holder": "someone-else", "ttlSeconds": 300 }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(
+        response.status(),
+        StatusCode::FORBIDDEN,
+        "a holder naming another actor must be refused with 403"
+    );
+
+    assert!(
+        store.locks("coffee", 0).unwrap().is_empty(),
+        "a refused acquire must create no lock"
+    );
+    assert!(
+        store.audit("coffee", 1000).unwrap().is_empty(),
+        "a refused acquire must write no audit entry"
+    );
+}
+
+#[tokio::test]
+async fn open_mode_records_anonymous() {
+    let dir = tempfile::tempdir().unwrap();
+    let router = server::app(state(dir.path()));
+
+    let created = router
+        .clone()
+        .oneshot(post("/projects", json!({ "name": "coffee" })))
+        .await
+        .unwrap();
+    assert_eq!(created.status(), StatusCode::CREATED);
+
+    // The body still claims "alex" and is accepted (open mode has no "someone else"), but
+    // the audit must record the honest subject: nobody was authenticated.
+    let committed = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/commits",
+            json!({ "branch": "main", "author": "alex", "message": "base", "okf": model("Block") }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(committed.status(), StatusCode::CREATED);
+
+    let entries = read_audit(&router).await;
+    assert!(!entries.is_empty(), "open mode must still record actions");
+    for entry in &entries {
+        assert_eq!(
+            entry["actor"], "anonymous",
+            "open mode must record the honest anonymous subject"
+        );
+    }
+}

## FILE: server/tests/auth.rs

diff --git a/server/tests/auth.rs b/server/tests/auth.rs
index 6e7026e..11dfc59 100644
--- a/server/tests/auth.rs
+++ b/server/tests/auth.rs
@@ -431,19 +431,92 @@ async fn a_scoped_identity_only_sees_the_projects_it_may_reach() {
         projects: vec!["coffee".to_string()],
     });
     store.create_project("coffee", None).unwrap();
     store.create_project("tea", None).unwrap();
 
     let response = router
-        .oneshot(Request::builder().uri("/projects").body(Body::empty()).unwrap())
+        .oneshot(
+            Request::builder()
+                .uri("/projects")
+                .body(Body::empty())
+                .unwrap(),
+        )
         .await
         .unwrap();
     assert_eq!(response.status(), StatusCode::OK);
     let body = json_body(response).await;
     let names: Vec<String> = body
         .as_array()
         .unwrap()
         .iter()
         .map(|p| p["name"].as_str().unwrap().to_string())
         .collect();
     assert_eq!(names, vec!["coffee"], "tea must not be disclosed");
 }
+#[tokio::test]
+async fn liveness_and_version_are_public_and_reach_nothing() {
+    // These two routes are deliberately outside the permission model, so they must be
+    // reachable with no token even when authentication is configured - a probe that needs
+    // a credential fails exactly when it is needed. They take no state at all, so they
+    // cannot reach the store and cannot disclose anything from it.
+    let (router, _store, _dir) = app_with_identity(Identity::open());
+    for uri in ["/health", "/version"] {
+        let response = router
+            .clone()
+            .oneshot(Request::builder().uri(uri).body(Body::empty()).unwrap())
+            .await
+            .unwrap();
+        assert_eq!(response.status(), StatusCode::OK, "{} must be public", uri);
+    }
+}
+
+#[tokio::test]
+async fn a_identity_with_no_roles_is_denied_a_read() {
+    // Scope and permission are separate decisions: an identity that reaches the project
+    // must STILL be refused if it holds no role that grants reading.
+    let (router, store, _dir) = app_with_identity(Identity {
+        subject: "nobody".to_string(),
+        roles: Vec::new(),
+        projects: vec!["*".to_string()],
+    });
+    store.create_project("coffee", None).unwrap();
+
+    let response = router
+        .oneshot(
+            Request::builder()
+                .uri("/projects/coffee/commits?branch=main")
+                .body(Body::empty())
+                .unwrap(),
+        )
+        .await
+        .unwrap();
+    assert_eq!(
+        response.status(),
+        StatusCode::FORBIDDEN,
+        "holding no role must be refused even with full scope"
+    );
+}
+
+#[tokio::test]
+async fn a_identity_that_reaches_nothing_sees_an_empty_listing() {
+    let (router, store, _dir) = app_with_identity(Identity {
+        subject: "scopeless".to_string(),
+        roles: vec!["viewer".to_string()],
+        projects: Vec::new(),
+    });
+    store.create_project("coffee", None).unwrap();
+
+    let response = router
+        .oneshot(
+            Request::builder()
+                .uri("/projects")
+                .body(Body::empty())
+                .unwrap(),
+        )
+        .await
+        .unwrap();
+    assert_eq!(response.status(), StatusCode::OK);
+    assert!(
+        json_body(response).await.as_array().unwrap().is_empty(),
+        "an identity scoped to nothing sees nothing"
+    );
+}
