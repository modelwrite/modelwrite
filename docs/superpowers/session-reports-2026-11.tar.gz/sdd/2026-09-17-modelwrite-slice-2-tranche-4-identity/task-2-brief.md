## Global Constraints

- Rust stable; edition 2021; rust-version 1.75. NO new dependency before Task 4, which declares exactly one and says why.
- Every source file begins with: // SPDX-License-Identifier: AGPL-3.0-or-later
- Cargo is not on PATH in fresh shells: begin every shell command sequence with $env:Path = "$env:USERPROFILE\\.cargo\\bin;" + $env:Path
- Use --no-fail-fast when running a test suite.
- Stage and commit only the paths a task owns. Never amend or rewrite a commit.
- AUTHENTICATION MUST BE OPT-IN so the existing 57 tests keep working: when no auth configuration is present (no MW_AUTH_TOKEN, no MW_AUTH_JWKS), the service runs in OPEN mode, every request is accepted, and the identity is `Identity::open()` with role admin and subject "anonymous". A test asserts open mode still works, and the startup path logs a loud warning that the service is unauthenticated.
- A VERIFIED ACTOR REPLACES A CLAIMED ONE: once auth is configured, the audit actor is the identity's subject and the request body's author or holder is IGNORED for attribution. If the body names a different actor, the request is refused with 403 rather than quietly recorded under the wrong name.
- Comparison of secrets is CONSTANT TIME. A token comparison that returns early on the first differing byte is a timing oracle.
- Never log a token, and never put one in an error body.
- Roles are `admin`, `author`, `reviewer`, `viewer`. Permissions: viewer reads; author adds commits, branches, resets, merges and locks; reviewer adds reading gate runs and evidence; admin adds project creation, branch deletion and lock breaking.
- Every request path returns a structured error and never panics: 401 for a missing or invalid token, 403 for an authenticated caller without the permission, and 500 with a generic message and no internal detail.

## Task 2: Enforce identity and roles across every route

**Files:**
- Modify: server/src/lib.rs (apply the extractor), api.rs, gate_api.rs, merge_api.rs, locks_api.rs, audit_api.rs
- Test: server/tests/auth.rs

**Interfaces:**
- Produces: every handler takes `Identity` as an extractor and calls `identity.may(...)` before doing anything; read routes require `Read`, mutations require `Write`, project creation and branch deletion require `Administer`, gate runs require `Write` to run and `Review` to list evidence. Every handler also checks `identity.may_reach(&project)`.

**Steps:**

- [ ] **Step 1: Thread the identity through the routes.** Where a handler already takes several extractors, Identity goes first. Keep each handler's body otherwise unchanged.

- [ ] **Step 2: Test the denials** in server/tests/auth.rs: a viewer is refused a commit with 403; an author is refused project creation with 403; a token scoped to project "coffee" is refused on project "tea" with 403; every route that exists appears in at least one denial test, so a new route cannot be added without a permission decision.

- [ ] **Step 3: Run, lint and commit** with `feat: enforce roles and project scope on every route`.

---

