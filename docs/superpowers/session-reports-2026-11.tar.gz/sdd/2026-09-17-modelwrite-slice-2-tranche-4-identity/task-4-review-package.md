﻿# Tranche 4 Task 4 review package (signed tokens)

## Commit

e0ab956 feat: accept signed tokens from an identity provider

## Diff stat

 Cargo.lock                                    | 328 +++++++++++++++++++++-
 server/Cargo.toml                             |   1 +
 server/src/auth.rs                            | 374 +++++++++++++++++++++++---
 server/src/main.rs                            |   2 +-
 server/tests/auth.rs                          | 287 +++++++++++++++++++-
 server/tests/fixtures/jwks.json               |  12 +
 server/tests/fixtures/rs256_other_private.pem |  28 ++
 server/tests/fixtures/rs256_private.pem       |  28 ++
 8 files changed, 1017 insertions(+), 43 deletions(-)

## Every changed file, in full

## FILE: Cargo.lock

diff --git a/Cargo.lock b/Cargo.lock
index f5a2df0..8337c1e 100644
--- a/Cargo.lock
+++ b/Cargo.lock
@@ -34,12 +34,18 @@ dependencies = [
 [[package]]
 name = "atomic-waker"
 version = "1.1.2"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "1505bd5d3d116872e7271a6d4e16d81d0c8570876c8de68093a09ac269d8aac0"
 
+[[package]]
+name = "autocfg"
+version = "1.5.1"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "f2032f911046de80f0a198e0901378627c33f59ea0ac00e363d481118bd70a53"
+
 [[package]]
 name = "axum"
 version = "0.7.9"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "edca88bc138befd0323b20752846e6587272d3b03b0343c8ea28a6f819e6e71f"
 dependencies = [
@@ -89,12 +95,18 @@ dependencies = [
  "sync_wrapper",
  "tower-layer",
  "tower-service",
  "tracing",
 ]
 
+[[package]]
+name = "base64"
+version = "0.22.1"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "72b3254f16251a8381aa12e40e3c4d2f0199f8c6508fbecb9d91f575e0fbb8c6"
+
 [[package]]
 name = "bitflags"
 version = "2.13.2"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "3ded4057c258ba199e2d26386d3af3780957ecaee6c4ef4041c6b4b8b97c0b06"
 
@@ -104,12 +116,18 @@ version = "0.10.4"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "3078c7629b62d3f0439517fa394996acacc5cbc91c5a20d8c658e77abd503a71"
 dependencies = [
  "generic-array",
 ]
 
+[[package]]
+name = "bumpalo"
+version = "3.20.3"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "72f5acc6cb2ba439de613abc23857ec3d78374d8ed5ac84e9d11336e87da8649"
+
 [[package]]
 name = "bytes"
 version = "1.12.1"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "fc652a48c352aef3ea3aed32080501cf3ef6ed5da78602a020c991775b0aff04"
 
@@ -145,12 +163,18 @@ source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "78c8292055d1c1df0cce5d180393dc8cce0abec0a7102adb6c7b1eef6016d60a"
 dependencies = [
  "generic-array",
  "typenum",
 ]
 
+[[package]]
+name = "deranged"
+version = "0.5.8"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "7cd812cc2bc1d69d4764bd80df88b4317eaef9e773c75226407d9bc0876b211c"
+
 [[package]]
 name = "digest"
 version = "0.10.7"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "9ed9a281f7bc9b7576e61468ba615a66a5c8cfdff42420a70aa82701a3b1e292"
 dependencies = [
@@ -168,13 +192,13 @@ checksum = "877a4ace8713b0bcf2a4e7eec82529c029f1d0619886d18145fea96c3ffe5c0f"
 name = "errno"
 version = "0.3.14"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "39cab71617ae0d63f51a36d69f866391735b51691dbda63cf6f96d042b63efeb"
 dependencies = [
  "libc",
- "windows-sys",
+ "windows-sys 0.61.2",
 ]
 
 [[package]]
 name = "fallible-iterator"
 version = "0.3.0"
 source = "registry+https://github.com/rust-lang/crates.io-index"
@@ -253,12 +277,25 @@ source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "85649ca51fd72272d7821adaf274ad91c288277713d9c18820d8499a7ff69e9a"
 dependencies = [
  "typenum",
  "version_check",
 ]
 
+[[package]]
+name = "getrandom"
+version = "0.2.17"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "ff2abc00be7fca6ebc474524697ae276ad847ad0a6b3faa4bcb027e9a4614ad0"
+dependencies = [
+ "cfg-if",
+ "js-sys",
+ "libc",
+ "wasi",
+ "wasm-bindgen",
+]
+
 [[package]]
 name = "getrandom"
 version = "0.4.3"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "300e883d756b2e4ec94e02791f39b04b522276138852cfc41d9fb7e904106099"
 dependencies = [
@@ -390,12 +427,38 @@ dependencies = [
 [[package]]
 name = "itoa"
 version = "1.0.18"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "8f42a60cbdf9a97f5d2305f08a87dc4e09308d1276d28c869c684d7777685682"
 
+[[package]]
+name = "js-sys"
+version = "0.3.105"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "ce57d20d1ea864ce2ac172ab472d409214f4fd359f0b2a2775abdf522e2af99e"
+dependencies = [
+ "cfg-if",
+ "futures-util",
+ "wasm-bindgen",
+]
+
+[[package]]
+name = "jsonwebtoken"
+version = "9.3.1"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "5a87cc7a48537badeae96744432de36f4be2b4a34a05a5ef32e9dd8a1c169dde"
+dependencies = [
+ "base64",
+ "js-sys",
+ "pem",
+ "ring",
+ "serde",
+ "serde_json",
+ "simple_asn1",
+]
+
 [[package]]
 name = "libc"
 version = "0.2.189"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "3eaf3ede3fee6db1a4c2ee091bf8a8b4dccdc6d17f656fb07896ee72867612f2"
 
@@ -445,13 +508,13 @@ name = "mio"
 version = "1.2.3"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "4b18443e9c262bfe8fa82f51666e2642c53393f7e5c27b3e1aeab922cff5b9d8"
 dependencies = [
  "libc",
  "wasi",
- "windows-sys",
+ "windows-sys 0.61.2",
 ]
 
 [[package]]
 name = "mw-capi"
 version = "0.1.0"
 dependencies = [
@@ -510,12 +573,13 @@ name = "mw-server"
 version = "0.1.0"
 dependencies = [
  "anyhow",
  "axum",
  "hex",
  "http-body-util",
+ "jsonwebtoken",
  "mw-gate",
  "mw-okf",
  "mw-test-support",
  "rusqlite",
  "serde",
  "serde_json",
@@ -526,18 +590,62 @@ dependencies = [
 ]
 
 [[package]]
 name = "mw-test-support"
 version = "0.1.0"
 
+[[package]]
+name = "num-bigint"
+version = "0.4.8"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "c89e69e7e0f03bea5ef08013795c25018e101932225a656383bd384495ecc367"
+dependencies = [
+ "num-integer",
+ "num-traits",
+]
+
+[[package]]
+name = "num-conv"
+version = "0.2.2"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "521739c6d2bac4aa25192232afe6841231376b2b26d4d9fae5ecf8ca5772e441"
+
+[[package]]
+name = "num-integer"
+version = "0.1.47"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "7ce2d95d4b3734dc35aa2f45e1aa22cd416814592a4f9d9205e11affd5b8e10b"
+dependencies = [
+ "num-traits",
+]
+
+[[package]]
+name = "num-traits"
+version = "0.2.19"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "071dfc062690e90b734c0b2273ce72ad0ffa95f0c74596bc250dcfd960262841"
+dependencies = [
+ "autocfg",
+]
+
 [[package]]
 name = "once_cell"
 version = "1.21.4"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "9f7c3e4beb33f85d45ae3e3a1792185706c8e16d043238c593331cc7cd313b50"
 
+[[package]]
+name = "pem"
+version = "3.0.6"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "1d30c53c26bc5b31a98cd02d20f25a7c8567146caf63ed593a9d87b2775291be"
+dependencies = [
+ "base64",
+ "serde_core",
+]
+
 [[package]]
 name = "percent-encoding"
 version = "2.3.2"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "9b4f627cb1b25917193a259e49bdad08f671f8d9708acfd5fe0a8c1455d87220"
 
@@ -580,12 +688,18 @@ checksum = "a89322df9ebe1c1578d689c92318e070967d1042b512afbe49518723f4e6d5cd"
 [[package]]
 name = "pkg-config"
 version = "0.3.34"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "f6b464fbc74e149a392436b17d523f769e057cb6877f6a5c4618bc6f11800548"
 
+[[package]]
+name = "powerfmt"
+version = "0.2.0"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "439ee305def115ba05938db6eb1644ff94165c5ab5e9420d1c1bcedbba909391"
+
 [[package]]
 name = "proc-macro2"
 version = "1.0.107"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "985e7ec9bb745e6ce6535b544d84d6cd6f7ad8bd711c398938ae983b91a766d9"
 dependencies = [
@@ -604,12 +718,26 @@ dependencies = [
 [[package]]
 name = "r-efi"
 version = "6.0.0"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "f8dcc9c7d52a811697d2151c701e0d08956f92b0e24136cf4cf27b57a6a0d9bf"
 
+[[package]]
+name = "ring"
+version = "0.17.14"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "a4689e6c2294d81e88dc6261c768b63bc4fcdb852be6d1352498b114f61383b7"
+dependencies = [
+ "cc",
+ "cfg-if",
+ "getrandom 0.2.17",
+ "libc",
+ "untrusted",
+ "windows-sys 0.52.0",
+]
+
 [[package]]
 name = "rusqlite"
 version = "0.31.0"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "b838eba278d213a8beaf485bd313fd580ca4505a00d5871caeb1457c55322cae"
 dependencies = [
@@ -628,13 +756,13 @@ source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "891efababe418670775f199f0d233d84843c227a0949a883ce15b37c78d6629d"
 dependencies = [
  "bitflags",
  "errno",
  "libc",
  "linux-raw-sys",
- "windows-sys",
+ "windows-sys 0.61.2",
 ]
 
 [[package]]
 name = "rustversion"
 version = "1.0.23"
 source = "registry+https://github.com/rust-lang/crates.io-index"
@@ -726,12 +854,24 @@ dependencies = [
 [[package]]
 name = "shlex"
 version = "2.0.1"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "f8fadd59c855ef2080decdef8ff161eb6661b86933c9d82e5ba29dc602a55aba"
 
+[[package]]
+name = "simple_asn1"
+version = "0.6.4"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "0d585997b0ac10be3c5ee635f1bab02d512760d14b7c468801ac8a01d9ae5f1d"
+dependencies = [
+ "num-bigint",
+ "num-traits",
+ "thiserror",
+ "time",
+]
+
 [[package]]
 name = "slab"
 version = "0.4.12"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "0c790de23124f9ab44544d7ac05d60440adc586479ce501c1d6d7da3cd8c9cf5"
 
@@ -745,13 +885,13 @@ checksum = "ba467056f1b547ed52077911161fc86985becbc60e8e1857c8a144dab0def891"
 name = "socket2"
 version = "0.6.5"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "c3d1e2c7f27f8d4cb10542a02c49005dbd6e93095799d6f3be745fae9f8fedd4"
 dependencies = [
  "libc",
- "windows-sys",
+ "windows-sys 0.61.2",
 ]
 
 [[package]]
 name = "syn"
 version = "2.0.119"
 source = "registry+https://github.com/rust-lang/crates.io-index"
@@ -783,16 +923,66 @@ checksum = "0bf256ce5efdfa370213c1dabab5935a12e49f2c58d15e9eac2870d3b4f27263"
 name = "tempfile"
 version = "3.27.0"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "32497e9a4c7b38532efcdebeef879707aa9f794296a4f0244f6f69e9bc8574bd"
 dependencies = [
  "fastrand",
- "getrandom",
+ "getrandom 0.4.3",
  "once_cell",
  "rustix",
- "windows-sys",
+ "windows-sys 0.61.2",
+]
+
+[[package]]
+name = "thiserror"
+version = "2.0.20"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "ec86235f5fcc2a73650310756d2ac5b138a5780bbbdfae3eeccec992c435ba4f"
+dependencies = [
+ "thiserror-impl",
+]
+
+[[package]]
+name = "thiserror-impl"
+version = "2.0.20"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "bc04cd3e1236dd4a98afca4569f2deb3f120e5422a4023be2cb683f8486292af"
+dependencies = [
+ "proc-macro2",
+ "quote",
+ "syn 3.0.6",
+]
+
+[[package]]
+name = "time"
+version = "0.3.55"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "cdb87b95ec50ddfa440816d227a17b2ccbdda963a316a727fda0fc4334f7d134"
+dependencies = [
+ "deranged",
+ "num-conv",
+ "powerfmt",
+ "serde_core",
+ "time-core",
+ "time-macros",
+]
+
+[[package]]
+name = "time-core"
+version = "0.1.9"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "9e1c906769ad99c88eaa54e728060edef082f8e358ff32030cb7c7d315e81109"
+
+[[package]]
+name = "time-macros"
+version = "0.2.32"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "7e689342a48d2ea927c87ea50cabf8594854bf940e9310208848d680d668ed85"
+dependencies = [
+ "num-conv",
+ "time-core",
 ]
 
 [[package]]
 name = "tokio"
 version = "1.53.1"
 source = "registry+https://github.com/rust-lang/crates.io-index"
@@ -800,13 +990,13 @@ checksum = "202caea871b69668250d242070849eb495be178ed697a3e98aebce5bc81a0bed"
 dependencies = [
  "libc",
  "mio",
  "pin-project-lite",
  "socket2",
  "tokio-macros",
- "windows-sys",
+ "windows-sys 0.61.2",
 ]
 
 [[package]]
 name = "tokio-macros"
 version = "2.7.2"
 source = "registry+https://github.com/rust-lang/crates.io-index"
@@ -889,12 +1079,18 @@ checksum = "b6f5e870be6c3b371b77fe0ee0bafb859fa4964b4404c27de1d380043c4dda20"
 [[package]]
 name = "unicode-ident"
 version = "1.0.26"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "d245f478577f809a851594d02313b640fb437e0bb33866753cff937863096954"
 
+[[package]]
+name = "untrusted"
+version = "0.9.0"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "8ecb6da28b8a351d773b68d5825ac39017e680750f980f3a1a85cd8dd28a47c1"
+
 [[package]]
 name = "vcpkg"
 version = "0.2.15"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "accd4ea62f7bb7a82fe23066fb0957d48ef677f6eeb8215f372f52e48bb32426"
 
@@ -907,27 +1103,145 @@ checksum = "0b928f33d975fc6ad9f86c8f283853ad26bdd5b10b7f1542aa2fa15e2289105a"
 [[package]]
 name = "wasi"
 version = "0.11.1+wasi-snapshot-preview1"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "ccf3ec651a847eb01de73ccad15eb7d99f80485de043efb2f370cd654f4ea44b"
 
+[[package]]
+name = "wasm-bindgen"
+version = "0.2.128"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "aecb87a33d3b0c5e3b7aa46336eaf486cffafbd281b195e4c8b80d50df2351bf"
+dependencies = [
+ "cfg-if",
+ "once_cell",
+ "rustversion",
+ "wasm-bindgen-macro",
+ "wasm-bindgen-shared",
+]
+
+[[package]]
+name = "wasm-bindgen-macro"
+version = "0.2.128"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "a690d511e3c1a8b3a55e33511e3c2c00c78415cd23650f32b808627f5696b9ed"
+dependencies = [
+ "quote",
+ "wasm-bindgen-macro-support",
+]
+
+[[package]]
+name = "wasm-bindgen-macro-support"
+version = "0.2.128"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "411e4887f0071ef2d2164a9d5fdf2d20efbef78fccd3a78b0c10a1dc5295e48a"
+dependencies = [
+ "bumpalo",
+ "proc-macro2",
+ "quote",
+ "syn 3.0.6",
+ "wasm-bindgen-shared",
+]
+
+[[package]]
+name = "wasm-bindgen-shared"
+version = "0.2.128"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "81941cd78d0c92026c33e5e01312845a4cb1e9af3407f9134b100dd03144103e"
+dependencies = [
+ "unicode-ident",
+]
+
 [[package]]
 name = "windows-link"
 version = "0.2.1"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "f0805222e57f7521d6a62e36fa9163bc891acd422f971defe97d64e70d0a4fe5"
 
+[[package]]
+name = "windows-sys"
+version = "0.52.0"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "282be5f36a8ce781fad8c8ae18fa3f9beff57ec1b52cb3de0789201425d9a33d"
+dependencies = [
+ "windows-targets",
+]
+
 [[package]]
 name = "windows-sys"
 version = "0.61.2"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "ae137229bcbd6cdf0f7b80a31df61766145077ddf49416a728b02cb3921ff3fc"
 dependencies = [
  "windows-link",
 ]
 
+[[package]]
+name = "windows-targets"
+version = "0.52.6"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "9b724f72796e036ab90c1021d4780d4d3d648aca59e491e6b98e725b84e99973"
+dependencies = [
+ "windows_aarch64_gnullvm",
+ "windows_aarch64_msvc",
+ "windows_i686_gnu",
+ "windows_i686_gnullvm",
+ "windows_i686_msvc",
+ "windows_x86_64_gnu",
+ "windows_x86_64_gnullvm",
+ "windows_x86_64_msvc",
+]
+
+[[package]]
+name = "windows_aarch64_gnullvm"
+version = "0.52.6"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "32a4622180e7a0ec044bb555404c800bc9fd9ec262ec147edd5989ccd0c02cd3"
+
+[[package]]
+name = "windows_aarch64_msvc"
+version = "0.52.6"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "09ec2a7bb152e2252b53fa7803150007879548bc709c039df7627cabbd05d469"
+
+[[package]]
+name = "windows_i686_gnu"
+version = "0.52.6"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "8e9b5ad5ab802e97eb8e295ac6720e509ee4c243f69d781394014ebfe8bbfa0b"
+
+[[package]]
+name = "windows_i686_gnullvm"
+version = "0.52.6"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "0eee52d38c090b3caa76c563b86c3a4bd71ef1a819287c19d586d7334ae8ed66"
+
+[[package]]
+name = "windows_i686_msvc"
+version = "0.52.6"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "240948bc05c5e7c6dabba28bf89d89ffce3e303022809e73deaefe4f6ec56c66"
+
+[[package]]
+name = "windows_x86_64_gnu"
+version = "0.52.6"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "147a5c80aabfbf0c7d901cb5895d1de30ef2907eb21fbbab29ca94c5b08b1a78"
+
+[[package]]
+name = "windows_x86_64_gnullvm"
+version = "0.52.6"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "24d5b23dc417412679681396f2b49f3de8c1473deb516bd34410872eff51ed0d"
+
+[[package]]
+name = "windows_x86_64_msvc"
+version = "0.52.6"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "589f6da84c646204747d1270a2a5661ea66ed1cced2631d546fdfb155959f9ec"
+
 [[package]]
 name = "zerocopy"
 version = "0.8.57"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "d35102a9f36d089ccae9e4c6802bc118be4487b80aaffc0ab4e0cf5ce92d2873"
 dependencies = [

## FILE: server/Cargo.toml

diff --git a/server/Cargo.toml b/server/Cargo.toml
index e84db54..db95a87 100644
--- a/server/Cargo.toml
+++ b/server/Cargo.toml
@@ -21,12 +21,13 @@ tokio.workspace = true
 rusqlite.workspace = true
 serde.workspace = true
 serde_json.workspace = true
 sha2.workspace = true
 hex.workspace = true
 anyhow.workspace = true
+jsonwebtoken = "9.3.1"
 
 [dev-dependencies]
 mw-test-support = { path = "../engine/test-support" }
 tower.workspace = true
 http-body-util.workspace = true
 tempfile.workspace = true

## FILE: server/src/auth.rs

diff --git a/server/src/auth.rs b/server/src/auth.rs
index 92dbc80..a25bc1a 100644
--- a/server/src/auth.rs
+++ b/server/src/auth.rs
@@ -1,17 +1,23 @@
 // SPDX-License-Identifier: AGPL-3.0-or-later
 //! Identity, roles and the opt-in authentication layer.
 //!
 //! Authentication is OPT-IN. With no configuration the service runs in OPEN mode, every
 //! request is accepted, and the identity is an anonymous admin (`Identity::open()`). When
 //! a static bearer token is configured, a request must present it (SHA-256, compared in
-//! constant time) or be refused with 401. Signed JWTs arrive in Task 4.
+//! constant time) or be refused with 401. When a JWKS is configured, a request must
+//! present a signed JWT whose RS256/RS384/RS512 signature verifies against one of the
+//! configured keys and whose expiry, issuer and audience are valid; roles and projects
+//! arrive from configurable claims.
+
+use std::collections::HashMap;
 
 use axum::extract::FromRequestParts;
 use axum::http::request::Parts;
 use axum::http::HeaderMap;
+use jsonwebtoken::{decode, decode_header, Algorithm, DecodingKey, Validation};
 use sha2::{Digest, Sha256};
 
 use crate::api::ApiState;
 use crate::error::ApiError;
 
 /// The verified actor behind a request: who they are, what roles they hold, and which
@@ -75,80 +81,174 @@ impl Permission {
             Permission::Administer => &["admin"],
         }
     }
 }
 
 /// How the service decides who a request is. Authentication is opt-in: the `Open` variant
-/// is the default, and the only non-open variant Task 1's startup path constructs is
-/// `Static`.
+/// is the default, and a request is accepted without a credential. The `Static` and
+/// `Jwt` variants require a bearer token.
 #[derive(Clone)]
 pub enum AuthConfig {
     Open,
     /// A single shared bearer token, stored as its SHA-256 hex digest so the secret itself
     /// is never held and comparison is over a fixed-width digest.
     Static {
         token_hash: String,
     },
-    /// Signed JWTs verified against a JWKS. Task 4 implements this variant; until then it
-    /// is present only so the configuration is complete and matches stay exhaustive about
-    /// the not-yet-implemented path.
+    /// Signed JWTs verified against a JWKS. `keys` is keyed by the `kid` each key
+    /// declares; `issuer` and `audience`, when present, must match the corresponding
+    /// claim. `role_claim` and `project_claim` name the claims that carry the caller's
+    /// roles and projects.
     Jwt {
-        jwks_source: String,
+        keys: HashMap<String, DecodingKey>,
+        issuer: Option<String>,
+        audience: Option<String>,
+        role_claim: String,
+        project_claim: String,
     },
     /// Every request resolves to this exact identity. Only tests construct this: it lets
     /// the permission and project-scope decisions be exercised with a specific role or
-    /// scope before Task 4 wires a real per-claim authority. `from_env` never produces it.
+    /// scope. `from_env` never produces it.
     Fixed(Identity),
 }
 
-/// Redacted on purpose: a derived Debug would print the token digest, and a configuration
-/// that can be printed into a log is a configuration that eventually will be. The digest is
-/// not the secret, but it is the thing compared to the secret, so it stays out of logs.
+/// Redacted on purpose: a derived Debug would print the token digest or the JWKS keys, and
+/// a configuration that can be printed into a log is a configuration that eventually will
+/// be. The digest is not the secret but it is the thing compared to the secret, so it stays
+/// out of logs; the JWKS keys are public, but their count is all a log needs.
 impl std::fmt::Debug for AuthConfig {
     fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
         match self {
             AuthConfig::Open => write!(f, "AuthConfig::Open"),
             AuthConfig::Static { .. } => {
                 write!(f, "AuthConfig::Static {{ token_hash: <redacted> }}")
             }
-            AuthConfig::Jwt { jwks_source } => f
+            AuthConfig::Jwt {
+                keys,
+                issuer,
+                audience,
+                role_claim,
+                project_claim,
+            } => f
                 .debug_struct("AuthConfig::Jwt")
-                .field("jwks_source", jwks_source)
+                .field("keys", &keys.len())
+                .field("issuer", issuer)
+                .field("audience", audience)
+                .field("role_claim", role_claim)
+                .field("project_claim", project_claim)
                 .finish(),
             AuthConfig::Fixed(identity) => f
                 .debug_struct("AuthConfig::Fixed")
                 .field("subject", &identity.subject)
                 .field("roles", &identity.roles)
                 .field("projects", &identity.projects)
                 .finish(),
         }
     }
 }
 
 impl AuthConfig {
-    /// Read the configuration from the environment. Task 1 wires the static token only;
-    /// Task 4 wires the JWKS. With no `MW_AUTH_TOKEN` the service runs OPEN.
-    pub fn from_env() -> AuthConfig {
-        match std::env::var("MW_AUTH_TOKEN") {
-            Ok(token) if !token.trim().is_empty() => AuthConfig::static_token(token.trim()),
-            _ => AuthConfig::Open,
+    /// Read the configuration from the environment. A static token (`MW_AUTH_TOKEN`) is
+    /// the simplest option; signed JWTs arrive from a JWKS at a file path
+    /// (`MW_AUTH_JWKS`, a mounted secret - what an air-gapped install has) or, second, a
+    /// URL fetched once at startup (`MW_AUTH_JWKS_URL`). With neither the service runs
+    /// OPEN. A malformed JWKS is a startup error, not a silent fall back to open mode.
+    pub fn from_env() -> anyhow::Result<AuthConfig> {
+        if let Ok(token) = std::env::var("MW_AUTH_TOKEN") {
+            if !token.trim().is_empty() {
+                return Ok(AuthConfig::static_token(token.trim()));
+            }
+        }
+        if let Ok(path) = std::env::var("MW_AUTH_JWKS") {
+            if !path.trim().is_empty() {
+                return AuthConfig::from_jwks_file(path.trim());
+            }
+        }
+        if let Ok(url) = std::env::var("MW_AUTH_JWKS_URL") {
+            if !url.trim().is_empty() {
+                return AuthConfig::from_jwks_url(url.trim());
+            }
         }
+        Ok(AuthConfig::Open)
     }
 
     /// Build the static-token configuration, hashing the token ONCE so every later
     /// comparison is over a fixed-width digest and no token length is leaked.
     pub fn static_token(token: &str) -> AuthConfig {
         AuthConfig::Static {
             token_hash: hash_token(token),
         }
     }
 
+    /// The JWT configuration with the default claim names: roles in `roles`, projects in
+    /// `projects`. Use `jwt_with_claims` to rename them.
+    pub fn jwt(
+        keys: HashMap<String, DecodingKey>,
+        issuer: Option<String>,
+        audience: Option<String>,
+    ) -> AuthConfig {
+        AuthConfig::jwt_with_claims(
+            keys,
+            issuer,
+            audience,
+            "roles".to_string(),
+            "projects".to_string(),
+        )
+    }
+
+    /// The JWT configuration with explicit claim names.
+    pub fn jwt_with_claims(
+        keys: HashMap<String, DecodingKey>,
+        issuer: Option<String>,
+        audience: Option<String>,
+        role_claim: String,
+        project_claim: String,
+    ) -> AuthConfig {
+        AuthConfig::Jwt {
+            keys,
+            issuer,
+            audience,
+            role_claim,
+            project_claim,
+        }
+    }
+
+    /// Build a JWT configuration from a JWKS FILE (the primary source: a mounted secret,
+    /// which is what an air-gapped install has). Issuer, audience and claim names come
+    /// from the environment.
+    pub fn from_jwks_file(path: &str) -> anyhow::Result<AuthConfig> {
+        let jwks = std::fs::read_to_string(path)
+            .map_err(|e| anyhow::anyhow!("cannot read the JWKS at {}: {}", path, e))?;
+        let keys = parse_jwks(&jwks)?;
+        Ok(AuthConfig::jwt_with_claims(
+            keys,
+            jwt_env_issuer(),
+            jwt_env_audience(),
+            jwt_env_claim("MW_AUTH_ROLES_CLAIM", "roles"),
+            jwt_env_claim("MW_AUTH_PROJECTS_CLAIM", "projects"),
+        ))
+    }
+
+    /// Build a JWT configuration from a JWKS fetched once at startup from a URL. This is
+    /// the second choice behind the file path: a service that cannot start without
+    /// outbound network access cannot run in an air-gapped install.
+    pub fn from_jwks_url(url: &str) -> anyhow::Result<AuthConfig> {
+        let jwks = fetch_jwks_url(url)?;
+        let keys = parse_jwks(&jwks)?;
+        Ok(AuthConfig::jwt_with_claims(
+            keys,
+            jwt_env_issuer(),
+            jwt_env_audience(),
+            jwt_env_claim("MW_AUTH_ROLES_CLAIM", "roles"),
+            jwt_env_claim("MW_AUTH_PROJECTS_CLAIM", "projects"),
+        ))
+    }
+
     /// Pin every request to one identity. This is a test hook: `from_env` never produces
     /// it, and it exists so the role and project-scope decisions on every route can be
-    /// exercised with a viewer, an author or a single-project scope before Task 4 adds a
-    /// real token authority that can express those claims.
+    /// exercised with a viewer, an author or a single-project scope.
     pub fn fixed(identity: Identity) -> AuthConfig {
         AuthConfig::Fixed(identity)
     }
 }
 
 /// SHA-256 of a token as lowercase hex. The configured token is hashed once at startup so
@@ -194,12 +294,163 @@ pub fn parse_identity_from_static(token: &str, config: &AuthConfig) -> Option<Id
         Some(static_identity())
     } else {
         None
     }
 }
 
+/// Parse a JWKS document into decoding keys, keyed by each key's `kid` (an empty string
+/// when a key declares none). Only RSA keys are kept: they are the only kind that can
+/// verify the RSA signatures this service accepts, and a set that also carries an EC or
+/// octet key is common rather than erroneous.
+pub fn parse_jwks(jwks: &str) -> anyhow::Result<HashMap<String, DecodingKey>> {
+    let set: jsonwebtoken::jwk::JwkSet = serde_json::from_str(jwks)
+        .map_err(|e| anyhow::anyhow!("the JWKS is not valid JSON: {}", e))?;
+    let mut keys = HashMap::new();
+    for jwk in set.keys {
+        let jsonwebtoken::jwk::AlgorithmParameters::RSA(rsa) = jwk.algorithm else {
+            continue;
+        };
+        let key = DecodingKey::from_rsa_components(&rsa.n, &rsa.e)
+            .map_err(|e| anyhow::anyhow!("a JWKS RSA key is unusable: {}", e))?;
+        keys.insert(jwk.common.key_id.unwrap_or_default(), key);
+    }
+    if keys.is_empty() {
+        return Err(anyhow::anyhow!("the JWKS contains no RSA keys"));
+    }
+    Ok(keys)
+}
+
+/// Fetch a JWKS from a URL once, at startup, by shelling out to `curl`. This is the only
+/// way to reach an HTTPS URL without adding a second dependency (an HTTP/TLS stack), and it
+/// is deliberately a startup-time operation for the URL path, which only exists for
+/// environments that already have outbound network access.
+fn fetch_jwks_url(url: &str) -> anyhow::Result<String> {
+    let output = std::process::Command::new("curl")
+        .args(["--fail", "--silent", "--show-error", "--location", url])
+        .output()
+        .map_err(|e| anyhow::anyhow!("cannot run curl to fetch the JWKS: {}", e))?;
+    if !output.status.success() {
+        return Err(anyhow::anyhow!(
+            "curl failed to fetch the JWKS: {}",
+            String::from_utf8_lossy(&output.stderr).trim()
+        ));
+    }
+    String::from_utf8(output.stdout).map_err(|_| anyhow::anyhow!("the fetched JWKS is not UTF-8"))
+}
+
+/// The expected issuer from `MW_AUTH_ISSUER`, or `None` when it is unset or empty.
+fn jwt_env_issuer() -> Option<String> {
+    std::env::var("MW_AUTH_ISSUER")
+        .ok()
+        .filter(|v| !v.trim().is_empty())
+}
+
+/// The expected audience from `MW_AUTH_AUDIENCE`, or `None` when it is unset or empty.
+fn jwt_env_audience() -> Option<String> {
+    std::env::var("MW_AUTH_AUDIENCE")
+        .ok()
+        .filter(|v| !v.trim().is_empty())
+}
+
+/// A claim name from the environment, with a default. Empty values fall back to the
+/// default rather than producing a claim that can never match.
+fn jwt_env_claim(var: &str, default: &str) -> String {
+    std::env::var(var)
+        .ok()
+        .filter(|v| !v.trim().is_empty())
+        .unwrap_or_else(|| default.to_string())
+}
+
+/// A roles or projects claim is either a JSON array of strings or a single string. Anything
+/// else - absent, a number, an object - yields nothing, because absence must deny rather
+/// than default to something permissive.
+fn string_list_claim(claims: &serde_json::Value, key: &str) -> Vec<String> {
+    match claims.get(key) {
+        Some(serde_json::Value::String(s)) => vec![s.clone()],
+        Some(serde_json::Value::Array(items)) => items
+            .iter()
+            .filter_map(|item| item.as_str().map(|s| s.to_string()))
+            .collect(),
+        _ => Vec::new(),
+    }
+}
+
+/// Resolve a presented token against the JWT configuration: `Some(identity)` when the
+/// signature, expiry, issuer and audience all verify, `None` otherwise. A non-JWT
+/// configuration has no keys to verify against, so it is `None`.
+pub fn parse_identity_from_jwt(token: &str, config: &AuthConfig) -> Option<Identity> {
+    let AuthConfig::Jwt {
+        keys,
+        issuer,
+        audience,
+        role_claim,
+        project_claim,
+    } = config
+    else {
+        return None;
+    };
+
+    // The header selects the key (kid) and must declare a supported RSA algorithm. An
+    // `alg: none` header does not even parse here, and the HMAC family is refused before
+    // any key is consulted, so a signed-token check cannot be downgraded to a shared-secret
+    // check.
+    let header = decode_header(token).ok()?;
+    if !matches!(
+        header.alg,
+        Algorithm::RS256 | Algorithm::RS384 | Algorithm::RS512
+    ) {
+        return None;
+    }
+
+    let kid = header.kid.as_deref().unwrap_or("");
+    let key = keys.get(kid)?;
+
+    let mut validation = Validation::new(header.alg);
+    // 60 seconds of clock skew, so a service and an identity provider whose clocks differ
+    // by seconds do not lock users out. Validation::new already requires `exp` and
+    // rejects a malformed or absent expiry, so a token cannot shed its expiry by giving it
+    // the wrong JSON type.
+    validation.leeway = 60;
+
+    if let Some(iss) = issuer {
+        validation.set_issuer(&[iss.as_str()]);
+        // Requiring the claim makes a missing OR malformed issuer a hard failure rather
+        // than a silently skipped check.
+        validation.required_spec_claims.insert("iss".to_string());
+    }
+
+    match audience {
+        Some(aud) => {
+            validation.set_audience(&[aud.as_str()]);
+            validation.required_spec_claims.insert("aud".to_string());
+        }
+        None => {
+            // No audience is configured, so a token carrying an audience is not a mismatch:
+            // audience verification is simply not enforced.
+            validation.validate_aud = false;
+        }
+    }
+
+    let data = decode::<serde_json::Value>(token, key, &validation).ok()?;
+    let claims = data.claims;
+
+    let subject = claims
+        .get("sub")
+        .and_then(|v| v.as_str())
+        .unwrap_or("")
+        .to_string();
+    let roles = string_list_claim(&claims, role_claim);
+    let projects = string_list_claim(&claims, project_claim);
+
+    Some(Identity {
+        subject,
+        roles,
+        projects,
+    })
+}
+
 /// The `Authorization: Bearer <token>` value, or `None` when the header is missing or does
 /// not carry a non-empty bearer token.
 fn bearer_token(headers: &HeaderMap) -> Option<&str> {
     let value = headers.get(axum::http::header::AUTHORIZATION)?;
     let value = value.to_str().ok()?;
     let rest = value.strip_prefix("Bearer ")?;
@@ -208,28 +459,30 @@ fn bearer_token(headers: &HeaderMap) -> Option<&str> {
     } else {
         Some(rest)
     }
 }
 
 /// Resolve the request's identity against the configured authentication. In open mode every
-/// request is the anonymous admin; in static mode the bearer token must match, or the call
-/// is refused with 401. This is the extraction layer Task 2 threads through every route.
+/// request is the anonymous admin; in static mode the bearer token must match; in JWT mode
+/// the bearer token must verify against the configured JWKS. A missing or bad token is 401.
 pub async fn identity(state: &ApiState, headers: &HeaderMap) -> Result<Identity, ApiError> {
     match &state.auth {
         AuthConfig::Open => Ok(Identity::open()),
         AuthConfig::Fixed(identity) => Ok(identity.clone()),
         AuthConfig::Static { .. } => {
             let token = bearer_token(headers)
                 .ok_or_else(|| ApiError::unauthorized("missing bearer token"))?;
             parse_identity_from_static(token, &state.auth)
                 .ok_or_else(|| ApiError::unauthorized("invalid bearer token"))
         }
-        // Task 4 implements signed-token verification. Task 1's startup never constructs
-        // this variant, so the arm is unreachable until then; it still refuses rather than
-        // panicking or admitting an unverified caller.
-        AuthConfig::Jwt { .. } => Err(ApiError::unauthorized("authentication unavailable")),
+        AuthConfig::Jwt { .. } => {
+            let token = bearer_token(headers)
+                .ok_or_else(|| ApiError::unauthorized("missing bearer token"))?;
+            parse_identity_from_jwt(token, &state.auth)
+                .ok_or_else(|| ApiError::unauthorized("invalid bearer token"))
+        }
     }
 }
 
 #[axum::async_trait]
 impl FromRequestParts<ApiState> for Identity {
     type Rejection = ApiError;
@@ -348,25 +601,78 @@ mod tests {
 
         assert!(parse_identity_from_static("wrong-token", &config).is_none());
         // A token that only shares a prefix must not match: the digest is compared in full.
         assert!(parse_identity_from_static("s3cret-toke", &config).is_none());
         // A static token cannot be resolved against a non-static configuration.
         assert!(parse_identity_from_static(token, &AuthConfig::Open).is_none());
-        assert!(parse_identity_from_static(
-            token,
-            &AuthConfig::Jwt {
-                jwks_source: "x".to_string()
-            }
-        )
-        .is_none());
+        assert!(
+            parse_identity_from_static(token, &AuthConfig::jwt(HashMap::new(), None, None))
+                .is_none()
+        );
     }
 
     #[test]
     fn hashing_is_stable_hex_and_reveals_nothing() {
         let a = hash_token("the-token");
         let b = hash_token("the-token");
         assert_eq!(a, b);
         assert_eq!(a.len(), 64);
         assert!(!a.contains("the-token"));
         assert_ne!(hash_token("the-token"), hash_token("other-token"));
     }
+
+    #[test]
+    fn parse_jwks_keeps_rsa_keys_by_kid_and_skips_others() {
+        // Two RSA keys (one kid-less) and one octet key that must be skipped.
+        let jwks = serde_json::json!({
+            "keys": [
+                { "kty": "RSA", "kid": "k1", "n": "AQID", "e": "AQAB" },
+                { "kty": "RSA", "n": "BAUG", "e": "AQAB" },
+                { "kty": "oct", "kid": "k2", "k": "c2VjcmV0" },
+            ]
+        });
+        let keys = parse_jwks(&jwks.to_string()).expect("a JWKS with RSA keys parses");
+        assert_eq!(keys.len(), 2, "the octet key must be skipped");
+        assert!(keys.contains_key("k1"), "kid k1 must be present");
+        assert!(
+            keys.contains_key(""),
+            "the kid-less key maps to the empty string"
+        );
+        assert!(!keys.contains_key("k2"), "the octet key must not be kept");
+    }
+
+    #[test]
+    fn parse_jwks_rejects_a_set_with_no_rsa_keys() {
+        let jwks = serde_json::json!({
+            "keys": [ { "kty": "oct", "kid": "k", "k": "c2VjcmV0" } ]
+        });
+        assert!(parse_jwks(&jwks.to_string()).is_err());
+    }
+
+    #[test]
+    fn string_list_claim_reads_array_single_string_and_denies_absence() {
+        let claims = serde_json::json!({
+            "roles": ["author", "reviewer"],
+            "one": "admin",
+            "wrong": 7,
+        });
+        assert_eq!(
+            string_list_claim(&claims, "roles"),
+            vec!["author".to_string(), "reviewer".to_string()]
+        );
+        assert_eq!(string_list_claim(&claims, "one"), vec!["admin".to_string()]);
+        assert_eq!(string_list_claim(&claims, "wrong"), Vec::<String>::new());
+        assert_eq!(string_list_claim(&claims, "absent"), Vec::<String>::new());
+    }
+
+    #[test]
+    fn jwt_debug_redacts_the_keys() {
+        let config = AuthConfig::jwt(HashMap::new(), Some("iss".into()), Some("aud".into()));
+        let debug = format!("{:?}", config);
+        assert!(debug.contains("AuthConfig::Jwt"));
+        assert!(debug.contains("keys"));
+        assert!(
+            !debug.contains("AQID"),
+            "a JWKS key must not appear in the debug output"
+        );
+    }
 }

## FILE: server/src/main.rs

diff --git a/server/src/main.rs b/server/src/main.rs
index f0199e0..0bdc33d 100644
--- a/server/src/main.rs
+++ b/server/src/main.rs
@@ -18,13 +18,13 @@ async fn main() -> anyhow::Result<()> {
         .map(PathBuf::from)
         .unwrap_or_else(|_| PathBuf::from("docs/evidence"));
 
     // Authentication is opt-in. With no token configured the service runs in OPEN mode:
     // every request is accepted as an anonymous admin. That keeps pilots and air-gapped
     // installs working, so the warning is deliberate and loud, not an error.
-    let auth = AuthConfig::from_env();
+    let auth = AuthConfig::from_env()?;
     if matches!(&auth, AuthConfig::Open) {
         eprintln!(
             "WARNING: mw-server is running WITHOUT authentication (open mode); \
              every request is accepted as an anonymous admin. Set MW_AUTH_TOKEN to \
              require a bearer token."
         );

## FILE: server/tests/auth.rs

diff --git a/server/tests/auth.rs b/server/tests/auth.rs
index 11dfc59..535dada 100644
--- a/server/tests/auth.rs
+++ b/server/tests/auth.rs
@@ -10,17 +10,18 @@ use std::sync::Arc;
 
 use axum::body::Body;
 use axum::http::{Request, StatusCode};
 use axum::routing::get as axum_get;
 use axum::{Json, Router};
 use http_body_util::BodyExt;
+use jsonwebtoken::{encode, Algorithm, EncodingKey, Header};
 use serde_json::{json, Value};
 use tower::ServiceExt;
 
 use server::api::ApiState;
-use server::auth::{AuthConfig, Identity};
+use server::auth::{parse_jwks, AuthConfig, Identity};
 use server::store::{sqlite::SqliteStore, Store};
 use server::{app, AppState};
 
 /// A route that exercises the Identity extractor and returns what it resolved. The rest of
 /// the service threads Identity through its real routes in Task 2; this is the minimal
 /// surface the extraction layer needs to be proven against.
@@ -517,6 +518,290 @@ async fn a_identity_that_reaches_nothing_sees_an_empty_listing() {
     assert_eq!(response.status(), StatusCode::OK);
     assert!(
         json_body(response).await.as_array().unwrap().is_empty(),
         "an identity scoped to nothing sees nothing"
     );
 }
+// ---------------------------------------------------------------------------
+// Task 4: signed tokens (JWT) against a JWKS. A committed RSA-2048 key pair
+// (generated once, committed so tests need no network and no identity provider)
+// signs tokens; the JWKS carries only the public half. A second private key
+// proves that a token signed by the wrong key is refused.
+// ---------------------------------------------------------------------------
+
+const JWKS: &str = include_str!("fixtures/jwks.json");
+const PRIVATE_KEY: &str = include_str!("fixtures/rs256_private.pem");
+const OTHER_PRIVATE_KEY: &str = include_str!("fixtures/rs256_other_private.pem");
+
+fn now() -> u64 {
+    std::time::SystemTime::now()
+        .duration_since(std::time::UNIX_EPOCH)
+        .unwrap()
+        .as_secs()
+}
+
+/// Sign an RS256 token with the given claims, kid and private key PEM.
+fn sign(claims: Value, kid: &str, pem: &str) -> String {
+    let mut header = Header::new(Algorithm::RS256);
+    header.kid = Some(kid.to_string());
+    encode(
+        &header,
+        &claims,
+        &EncodingKey::from_rsa_pem(pem.as_bytes()).unwrap(),
+    )
+    .unwrap()
+}
+
+fn jwt_config(issuer: Option<&str>, audience: Option<&str>) -> AuthConfig {
+    AuthConfig::jwt(
+        parse_jwks(JWKS).unwrap(),
+        issuer.map(str::to_string),
+        audience.map(str::to_string),
+    )
+}
+
+fn bearer(uri: &str, token: &str) -> Request<Body> {
+    Request::builder()
+        .uri(uri)
+        .header("authorization", format!("Bearer {}", token))
+        .body(Body::empty())
+        .unwrap()
+}
+
+fn bearer_post(uri: &str, body: Value, token: &str) -> Request<Body> {
+    Request::builder()
+        .method("POST")
+        .uri(uri)
+        .header("content-type", "application/json")
+        .header("authorization", format!("Bearer {}", token))
+        .body(Body::from(body.to_string()))
+        .unwrap()
+}
+
+/// base64url without padding, for the hand-crafted alg:none token (jsonwebtoken cannot
+/// emit an alg:none header, by design).
+fn b64url(input: &[u8]) -> String {
+    const ALPHABET: &[u8; 64] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";
+    let mut out = String::new();
+    for chunk in input.chunks(3) {
+        let b0 = chunk[0] as u32;
+        let b1 = chunk.get(1).copied().unwrap_or(0) as u32;
+        let b2 = chunk.get(2).copied().unwrap_or(0) as u32;
+        let n = (b0 << 16) | (b1 << 8) | b2;
+        out.push(ALPHABET[((n >> 18) & 63) as usize] as char);
+        out.push(ALPHABET[((n >> 12) & 63) as usize] as char);
+        if chunk.len() > 1 {
+            out.push(ALPHABET[((n >> 6) & 63) as usize] as char);
+        }
+        if chunk.len() > 2 {
+            out.push(ALPHABET[(n & 63) as usize] as char);
+        }
+    }
+    out
+}
+
+#[tokio::test]
+async fn jwt_mode_accepts_a_valid_token() {
+    let router = router(jwt_config(
+        Some("https://idp.example.com"),
+        Some("modelwrite"),
+    ));
+    let token = sign(
+        json!({
+            "sub": "alex",
+            "roles": ["author", "reviewer"],
+            "projects": ["coffee"],
+            "iss": "https://idp.example.com",
+            "aud": "modelwrite",
+            "exp": now() + 3600,
+        }),
+        "test-key",
+        PRIVATE_KEY,
+    );
+    let response = router.oneshot(bearer("/whoami", &token)).await.unwrap();
+    assert_eq!(response.status(), StatusCode::OK);
+    let body = json_body(response).await;
+    assert_eq!(body["subject"], "alex");
+    assert_eq!(body["roles"][0], "author");
+    assert_eq!(body["roles"][1], "reviewer");
+    assert_eq!(body["projects"][0], "coffee");
+}
+
+#[tokio::test]
+async fn jwt_mode_rejects_an_expired_token_without_echoing_it() {
+    let router = router(jwt_config(None, None));
+    let token = sign(
+        json!({ "sub": "alex", "roles": ["author"], "exp": now() - 120 }),
+        "test-key",
+        PRIVATE_KEY,
+    );
+    let response = router.oneshot(bearer("/whoami", &token)).await.unwrap();
+    assert_eq!(response.status(), StatusCode::UNAUTHORIZED);
+    let text = body_text(response).await;
+    assert!(text.contains("error"), "a 401 must be a structured error");
+    assert!(
+        !text.contains(&token),
+        "a token must never appear in a response body"
+    );
+}
+
+#[tokio::test]
+async fn jwt_mode_rejects_a_token_signed_by_the_wrong_key() {
+    let router = router(jwt_config(None, None));
+    // Signed with the OTHER private key but claiming the configured kid, so the right key
+    // is selected and the signature check fails.
+    let token = sign(
+        json!({ "sub": "alex", "roles": ["author"], "exp": now() + 3600 }),
+        "test-key",
+        OTHER_PRIVATE_KEY,
+    );
+    let response = router.oneshot(bearer("/whoami", &token)).await.unwrap();
+    assert_eq!(response.status(), StatusCode::UNAUTHORIZED);
+}
+
+#[tokio::test]
+async fn jwt_mode_rejects_a_wrong_issuer() {
+    let router = router(jwt_config(Some("https://idp.example.com"), None));
+    let token = sign(
+        json!({
+            "sub": "alex",
+            "roles": ["author"],
+            "iss": "https://evil.example.com",
+            "exp": now() + 3600,
+        }),
+        "test-key",
+        PRIVATE_KEY,
+    );
+    let response = router.oneshot(bearer("/whoami", &token)).await.unwrap();
+    assert_eq!(response.status(), StatusCode::UNAUTHORIZED);
+}
+
+#[tokio::test]
+async fn jwt_mode_rejects_a_missing_issuer() {
+    let router = router(jwt_config(Some("https://idp.example.com"), None));
+    let token = sign(
+        json!({ "sub": "alex", "roles": ["author"], "exp": now() + 3600 }),
+        "test-key",
+        PRIVATE_KEY,
+    );
+    let response = router.oneshot(bearer("/whoami", &token)).await.unwrap();
+    assert_eq!(response.status(), StatusCode::UNAUTHORIZED);
+}
+
+#[tokio::test]
+async fn jwt_mode_rejects_a_wrong_audience() {
+    let router = router(jwt_config(None, Some("modelwrite")));
+    let token = sign(
+        json!({
+            "sub": "alex",
+            "roles": ["author"],
+            "aud": "some-other-service",
+            "exp": now() + 3600,
+        }),
+        "test-key",
+        PRIVATE_KEY,
+    );
+    let response = router.oneshot(bearer("/whoami", &token)).await.unwrap();
+    assert_eq!(response.status(), StatusCode::UNAUTHORIZED);
+}
+
+#[tokio::test]
+async fn jwt_mode_rejects_alg_none() {
+    let router = router(jwt_config(None, None));
+    let header = b64url(br#"{"alg":"none","kid":"test-key"}"#);
+    let claims = b64url(br#"{"sub":"alex","roles":["admin"],"exp":9999999999}"#);
+    let token = format!("{}.{}.", header, claims);
+    let response = router.oneshot(bearer("/whoami", &token)).await.unwrap();
+    assert_eq!(
+        response.status(),
+        StatusCode::UNAUTHORIZED,
+        "alg:none must be refused outright"
+    );
+}
+
+#[tokio::test]
+async fn jwt_mode_rejects_a_malformed_expiry_type() {
+    // A malformed exp (a string rather than a number) must be refused, not silently
+    // treated as absent: otherwise an attacker could shed the expiry entirely.
+    let router = router(jwt_config(None, None));
+    let token = sign(
+        json!({ "sub": "alex", "roles": ["author"], "exp": "not-a-number" }),
+        "test-key",
+        PRIVATE_KEY,
+    );
+    let response = router.oneshot(bearer("/whoami", &token)).await.unwrap();
+    assert_eq!(response.status(), StatusCode::UNAUTHORIZED);
+}
+
+#[tokio::test]
+async fn jwt_mode_tolerates_clock_skew_within_the_window_but_not_beyond() {
+    // 30 seconds of past expiry is inside the 60-second window, so a user is not locked
+    // out by an identity provider whose clock runs slightly ahead.
+    let router = router(jwt_config(None, None));
+    let within = sign(
+        json!({ "sub": "alex", "roles": ["viewer"], "exp": now() - 30 }),
+        "test-key",
+        PRIVATE_KEY,
+    );
+    let response = router
+        .clone()
+        .oneshot(bearer("/whoami", &within))
+        .await
+        .unwrap();
+    assert_eq!(response.status(), StatusCode::OK);
+
+    // 120 seconds of past expiry is beyond the window and must be refused.
+    let beyond = sign(
+        json!({ "sub": "alex", "roles": ["viewer"], "exp": now() - 120 }),
+        "test-key",
+        PRIVATE_KEY,
+    );
+    let response = router.oneshot(bearer("/whoami", &beyond)).await.unwrap();
+    assert_eq!(response.status(), StatusCode::UNAUTHORIZED);
+}
+
+#[tokio::test]
+async fn jwt_mode_without_a_roles_claim_cannot_write() {
+    let dir = tempfile::tempdir().unwrap();
+    let store = Arc::new(SqliteStore::open(&dir.path().join("mw.db")).unwrap());
+    store.create_project("coffee", None).unwrap();
+    let state = AppState {
+        store: store.clone(),
+        evidence_dir: dir.path().to_path_buf(),
+        auth: jwt_config(None, None),
+    };
+    let router = app(state);
+    // A valid token with no roles claim: it verifies, but holds no role, so a write is
+    // refused with 403 rather than defaulting to a permissive identity.
+    let token = sign(
+        json!({ "sub": "alex", "exp": now() + 3600 }),
+        "test-key",
+        PRIVATE_KEY,
+    );
+    let response = router
+        .oneshot(bearer_post(
+            "/projects/coffee/commits",
+            json!({ "branch": "main", "author": "alex", "message": "m", "okf": {} }),
+            &token,
+        ))
+        .await
+        .unwrap();
+    assert_eq!(
+        response.status(),
+        StatusCode::FORBIDDEN,
+        "a no-role identity must be refused a write, not treated as permissive"
+    );
+}
+
+#[tokio::test]
+async fn from_jwks_file_loads_a_configuration() {
+    let dir = tempfile::tempdir().unwrap();
+    let path = dir.path().join("jwks.json");
+    std::fs::write(&path, JWKS).unwrap();
+    let config = AuthConfig::from_jwks_file(path.to_str().unwrap()).unwrap();
+    match &config {
+        AuthConfig::Jwt { keys, .. } => {
+            assert!(keys.contains_key("test-key"), "the committed kid must load");
+        }
+        other => panic!("expected a Jwt config, got {:?}", other),
+    }
+}

## FILE: server/tests/fixtures/jwks.json

diff --git a/server/tests/fixtures/jwks.json b/server/tests/fixtures/jwks.json
new file mode 100644
index 0000000..1f4889f
--- /dev/null
+++ b/server/tests/fixtures/jwks.json
@@ -0,0 +1,12 @@
+{
+  "keys": [
+    {
+      "alg": "RS256",
+      "e": "AQAB",
+      "kid": "test-key",
+      "kty": "RSA",
+      "n": "zG3ISWB2R2e6yvH62NqByix4-312ZZoB8mVwRZYet4G8CIHl0y1ETmmjww_8o3nUcRKVIyMMg8kEqoW5RxI0lWKhv-pUBe8fxOPM6jyz4lRZrRHp5jiZl4bbhvozILwJlqVgu2Vt1PVE9KRrkLHEDHKTvBsqH2PRUx8vmxKAq0yDfCkAC7rS4yuc3dFfOcDDmlve5oA3G-46GBxtRcf27rboQEfjQQzwSbaIh76P0Al23L7mx_8bhWt9wzPR0b7XHcEVoEGd-FjUa-gs6Sg8_jyYbEjhIE0zXIh3ratO3JApAFmWOU0m5nAcIrLZ3n0VTVgb4EMfk7LCEaAWkU6gzw",
+      "use": "sig"
+    }
+  ]
+}

## FILE: server/tests/fixtures/rs256_other_private.pem

diff --git a/server/tests/fixtures/rs256_other_private.pem b/server/tests/fixtures/rs256_other_private.pem
new file mode 100644
index 0000000..bbf3612
--- /dev/null
+++ b/server/tests/fixtures/rs256_other_private.pem
@@ -0,0 +1,28 @@
+-----BEGIN PRIVATE KEY-----
+MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQC2shBAeZw3trzI
+sqfeybzaE+vpDuqPe/y/Di8hRqX5uySNRzlonpSyhncc5RI9gCQ24M35MxbuAzB5
+jqETbr8Ebzf8MxrJzLOPnLUnz42IbNfe8Eh2kW+tGTc9wliww2w4t9bp5cdVc+uY
+iastxwRUixzZ1nqNKgKElEV22RCpcqqirbLuWeoTKJPhuWlE33riziukM345Guym
+ml2k3B3btGoocQmR2AxXF3fGEzFOXkCG9zySxtBhZdkEsWNecVCSg8hrv131/C8y
+rHBStVVjclKO2zx9YHpJraMlQ+H6BgVn9aX90TH5CQq8/ghG7z064Wez150OBHS6
+qMis7GPPAgMBAAECggEAGKEKpdZ/I9ejvZ6wGM2zgua6n/Gd13gMi6ka226Nw4vi
+EpWufJccTrDn7+JFwjq7JxbJTbYAele9ujVrK5Z7c9qWfo5ZJylMb6jdlx9Y4jJi
+K7DS5AEZQAmtM8s2b6X4ufC2rVOHutJkyWyNwh8ZS1hxrEBIxy0Jp9vhPXNn1p/f
+O11qSlkyKNqN6/mYOZpz7UQHJ+CS2+fAsF3742kC5poUSQ0EKQ+vy/edinN+au8m
+YXMwx+09bCKxv1/sHPLfxhLvBSb2aD7PLucbok7wWS2a4xn0ni2ASivOLf1BpNcb
+hXSwwbYgvf3D6keAHI5M+9jOI53UKddmeYwS3p3maQKBgQDINnq7ONO+t4zLQWlS
+vF9YK6HNN1rCQrFrC6gx8h6cEgLHjyOX3RnJOpKZER1LUsOueM+UmDVfoMkqIu0F
+xfy1ZF2s5yvW0fDJ0UCaI4DkiRATwE0iD//f0dJtAlCiYr1C4PIttlfxFtDGu+zv
+uqK6DjtZmVmB80E/nX80TsBYDQKBgQDpmgx/d4fzfcd03we64J/26Zef4kr2xO7V
+xq4DNTENjHgI6Hv5E/2baQgk2uOAq+d95lrSDEz1+LwJxszezT/g5bBvQUuYFeXr
+BlA1EVB4YiLYPdOCEcC7KYhF4FKPW7BAHt5uyuGylKqMYlN3wqyb6lRYGFlt1vFx
+h5pmEt74SwKBgBxJLh/DUI8SSY7xx9qLiIDhcTOYDXeCiqRP+kxMI6zzEnd1Lpcn
+ApyebNW5SEU7BTBiGxmoQ2omQiV0173IEgLikiV6Z4QrFvS8Xn8oYu5muuG/emZE
+kmbhsvP5rsCyaIDJXQ2+REBoc8iQBlJ8ML9OgW4QL0gfwOkm7DDMq3oFAoGBALxp
+dqkcxLd8fHJkLPzqjbr930CiqWntnuEntVR7A4x0/p/Yu51DJWrCxUHMlnBCtpzS
+PfBq4WwG6ctM4BLYIyyGtc6WMJ2DFAWC+xBCXdAq/wXAoCapoPSUZAhQDOb5weeF
+vkxIMM/znrdJ2x6eEtBSqSLAyOiR0/2IrNylXdePAoGAIdmhfFR88QdcJaisKodP
+lpZ7fW1vgnAqrEGOTPWrGZYaiwU+zt/NJDO1UgysM09qxiIhWlUSPP7HgPHuh8iH
+Q3AS9qCflHtYAOSjGQzo6ooh/SUFmbW6huCTM22HNRfNnPuM3926pYhTRPZdlAm6
+eJYUALfRPvU0ot6uB18xBwc=
+-----END PRIVATE KEY-----

## FILE: server/tests/fixtures/rs256_private.pem

diff --git a/server/tests/fixtures/rs256_private.pem b/server/tests/fixtures/rs256_private.pem
new file mode 100644
index 0000000..596c37a
--- /dev/null
+++ b/server/tests/fixtures/rs256_private.pem
@@ -0,0 +1,28 @@
+-----BEGIN PRIVATE KEY-----
+MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQDMbchJYHZHZ7rK
+8frY2oHKLHj7fXZlmgHyZXBFlh63gbwIgeXTLUROaaPDD/yjedRxEpUjIwyDyQSq
+hblHEjSVYqG/6lQF7x/E48zqPLPiVFmtEenmOJmXhtuG+jMgvAmWpWC7ZW3U9UT0
+pGuQscQMcpO8GyofY9FTHy+bEoCrTIN8KQALutLjK5zd0V85wMOaW97mgDcb7joY
+HG1Fx/butuhAR+NBDPBJtoiHvo/QCXbcvubH/xuFa33DM9HRvtcdwRWgQZ34WNRr
+6CzpKDz+PJhsSOEgTTNciHetq07ckCkAWZY5TSbmcBwistnefRVNWBvgQx+TssIR
+oBaRTqDPAgMBAAECggEAD1Wc1IQ72xdY16hXHLUnTzcOzC6ZFv36b2hUh6O/IhzF
+Mg4sYy7eFNOvyQ4F8W1OFj1CmqQiaDBH/VKSl1YyQ5Jmd7LoIpnRVD+SO2/aPnv9
+ThIt7WsJemhPR0y1URtJzNcS7nupRXQwe/lpaC0te5GMq2uOOVSPeyC3vXYh2Ld+
+IFkpVBAJdujyjS4IV2gSwIb1hiu9yKSYeFo1QT8QfnDDoPJsTvyjpC0wdCK/ZGyk
+DYVggtFhwi+P+xipI0kH1gII/jPTdc431TdhxBQsTqsW19LuQkzhQDEhiRei8nf3
+nnmu6r4VP1yS6VE1zFDWS/1/y5dZcqYj4yZmJrEYYQKBgQD6Ia1tlHFQU8zdAop9
+QCIPvOsM0zGR504ylLtBBIlEvEGtTEzDAgzAKowKIp2ZzMSGRBkCdZIEi47fDV3B
+Jauj8Z2MjP37QuIX1IivxnfHzIICa1GaI0Xxl9kPsN+kqkgCSy2zgXiFpN9dE8Fd
++jzBsD1LtezWW6VszI1CaQYzywKBgQDROZvFb4JL1QZauHXhESLcPmtMSdDVuCV9
+xyVOpxYyA7u8bRq42y0LNdPO8BsnNu0DOwwPo1slXwbKuzf0I1FRolr+wIbUaE49
+xDLB5wPB6KWtY9DXe+1zfv04YSKGDQ2CphsmL1emmL9+zb0/Mm9EKA0TmP0UakYR
+FrZGqk0OjQKBgQDL7V8OouKLYfb5DRRJr1rVx+k+iIS2doVreZT9GiyrzGwjVLyU
+lHw+w7FupfAlryteZ/CX77C/YeR2d9hDG2pHfDo9l8mN62aXlSBnZoDLdTFdtY9P
+AokIwgsm3sZG4slYjWBSJDFVjCjLIssYymZ0ZzJiIo1X6loBTPex+BwlZwKBgA57
+9322l4WabMMxC/AV2Jz4sULpxUxWYDoR5FJKnO2/dmq3/uaXPcoN4ujrlGWllsjn
+eJFIlNHEf1rflSMQotuM6tHCEFN6GRiLkZv82zS8X2PeiiGw0aJyQyN5DgPLuYi2
+6SA+nMnKv08O/S/31N4aC7W0nKiiJtGeCeZgec8tAoGAYX50vXlpLJ/s/8TFy8FK
+IuSPVg1L5DTAtf7j38mGUVjS+ybpg7ue32r674JnzJkYqofqigkaxBFQ/aUpojZd
+ppmSc8UhS4QHTaviUzvKX4NFOuPje/PkN2e+9yvhcxlmMWRvKCqUNsA+F1ze8pWW
++oyQysgsVTWiVT/eXMWI29E=
+-----END PRIVATE KEY-----
