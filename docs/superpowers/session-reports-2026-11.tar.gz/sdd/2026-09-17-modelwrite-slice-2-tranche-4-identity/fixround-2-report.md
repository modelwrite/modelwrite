# Fix Round 2 — Slice 2 Tranche 4 (Identity)

Status: DONE

## Commits

- 26cbb37 fix: require a non-empty JWT subject and record the auth mechanism in the audit log

## Test summary

165 workspace tests, all green (0 failed). Per binary: mw-server 121 (lib 14, api 11, audit 12, auth 32, corpus 1, gate_api 3, http 3, locks 15, merge 15, merge_api 4, store 11), mw-okf 15, mw-mcp 13, mw-graph 7, mw-gate 5, mw-capi 4, mw-test-support 0; doc-tests 0.

## What changed

### MUST-FIX 1 — a token with no subject is accepted, then breaks every write
- `sub` is now a required spec claim, and the extracted subject must be a non-empty string; any other shape is refused with 401 (server/src/auth.rs).
- Tests (server/tests/auth.rs): a validly signed token with no `sub` → 401; empty-string `sub` → 401; non-string `sub` → 401.

### MUST-FIX 2 — the audit log cannot tell a shared token from a person
- `AuditEntry` gains a `mechanism` field (`open` | `static` | `jwt`), populated on every mutation and every refusal; the SQLite `audit` table gains a non-empty `mechanism` column with a CHECK, and the append-only triggers are untouched. The subject is unchanged — `actor` still records exactly what the identity provider said.
- The audit API response now includes `mechanism` (server/src/store/mod.rs, sqlite.rs, api.rs, gate_api.rs, locks_api.rs, merge_api.rs).
- Test (server/tests/auth.rs): entries written in open, static and jwt mode each carry the right mechanism, with the subject unchanged.

### Minors closed
- M1: a duplicate, missing or empty JWKS `kid` is now a startup error (server/src/auth.rs, `parse_jwks`).
- M2: an empty or absent commit author defaults to `identity.subject` in configured mode; a non-empty author that differs is still refused with 403 (server/src/api.rs `resolve_author`, merge_api.rs).
- M3: listing gate runs now accepts Write OR Review; running a gate stays Write (server/src/gate_api.rs).
- M4: `/health` reports `authMode` (`open` | `static` | `jwt`) and never a token, key or path (server/src/lib.rs).

## Concerns / notes

- `AuthConfig::mechanism()` returns `"fixed"` for the test-only `Fixed` hook; that value can only appear in tests, never in production (open/static/jwt).
- Making the `author` field `#[serde(default)]` means an ABSENT author now deserializes as empty. In configured mode that defaults to the verified subject (the intended fix). In open mode an absent author is now treated identically to an empty author (recorded as-is) instead of being rejected as a missing required field — a deliberate consequence of the "empty or absent" wording; open-mode identity and permissions are otherwise unchanged.

## Verification

- `cargo test --workspace --no-fail-fast` → 165 passed, 0 failed.
- `cargo fmt --all` → clean.
- `cargo clippy --workspace --all-targets -- -D warnings` → clean.

## Deviation

- None. (The `author` `#[serde(default)]` note above is the only intentional scope clarification; no requirement was skipped.)
