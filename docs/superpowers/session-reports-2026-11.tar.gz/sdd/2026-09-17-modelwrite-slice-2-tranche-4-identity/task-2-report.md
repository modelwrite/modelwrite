# Task 2 Report: Enforce identity, roles and project scope on every route

## Status

DONE

## Commits

- 98561bf feat: enforce roles and project scope on every route

## Test summary

cargo test --workspace --no-fail-fast: 129 passed, 0 failed across 16 test binaries —
capi 4, gate 5, graph 7, mcp 13, okf 15 (8 diff + 7 validation), server 85
(lib-unit 8, api 11, audit 5, auth 10, corpus 1, gate_api 3, http 2, locks 15,
merge 15, merge_api 4, store 11).

## What changed

- Every project-scoped handler now takes Identity as its first extractor and, before any
  store access, checks the required permission and identity.may_reach(project):
  reads -> Read; mutations (commit, branch create, reset, merge, locks acquire/release) ->
  Write; gate run -> Write; gate-runs list -> Review; project create and branch delete ->
  Administer.
- Added a test-only AuthConfig::Fixed(Identity) variant (plus AuthConfig::fixed) so the
  denial tests can pin a request to a viewer, an author, a no-role caller, or a
  single-project scope. from_env never produces it; Task 4's JWTs supersede the need.
- server/tests/auth.rs now proves the denials: a viewer is refused a commit (403) with the
  store untouched, an author is refused project creation (403), a coffee-scoped token is
  refused on "tea" (403), a missing token is refused on a real route (401) before the store
  is consulted, and a table-driven test walks every route in lib.rs asserting 403 for an
  under-privileged or out-of-scope caller.

## Self-review

- Every project route has a permission check and appears in a denial test (17/17); /health and
  /version are documented as public and excluded by design.
- A denied request touches nothing: the named viewer test asserts commits/branches/audit stay
  empty; the table test asserts the store stays empty for every route.
- Open mode is unchanged: Identity::open() is an anonymous admin, so every existing test still
  passes.

## Concerns

- AuthConfig::Fixed(Identity) is a public variant; it is reachable only via the test helper and
  from_env never constructs it, but it is a temporary fixture until Task 4 lands JWTs.
- list_projects requires Read but performs no per-project scope check (there is no project in
  the path), so a scoped identity can list project names. Filtering was deliberately left out
  to honour "keep each handler's body otherwise unchanged"; production static mode is an admin
  scoped to "*", so this only becomes observable once Task 4 introduces scoped claims.

## Deviations

- /health and /version remain public (no Identity extractor). They are liveness/information
  endpoints outside the project-scoped permission model, and requiring a token would break
  readiness/liveness probes in static mode. The brief's "every route has a permission check"
  is applied to the project routes.
