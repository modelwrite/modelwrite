﻿# Slice 2 tranche 4 - whole-tranche review package (identity, roles, verified actors, signed tokens)

## Commits

a71876d test: pin the verified actor on every path with a claimed name
e0ab956 feat: accept signed tokens from an identity provider
3414025 test: pin the public routes, the no-role denial, and the empty-scope listing
2384112 feat: record verified actors in the audit log
4e8f5f5 fix: filter project listings by scope and redact the auth configuration
98561bf feat: enforce roles and project scope on every route

## Diff stat

 Cargo.lock                                    | 328 ++++++++++++-
 server/Cargo.toml                             |   1 +
 server/src/api.rs                             | 118 ++++-
 server/src/audit_api.rs                       |   8 +
 server/src/auth.rs                            | 397 +++++++++++++--
 server/src/gate_api.rs                        |  17 +-
 server/src/lib.rs                             |   9 +
 server/src/locks_api.rs                       |  34 +-
 server/src/main.rs                            |   2 +-
 server/src/merge_api.rs                       |  18 +-
 server/src/store/mod.rs                       |   5 +-
 server/tests/audit.rs                         | 327 +++++++++++++
 server/tests/auth.rs                          | 672 +++++++++++++++++++++++++-
 server/tests/fixtures/jwks.json               |  12 +
 server/tests/fixtures/rs256_other_private.pem |  28 ++
 server/tests/fixtures/rs256_private.pem       |  28 ++
 16 files changed, 1942 insertions(+), 62 deletions(-)

## Verification observed by the controller

```
cargo test --workspace --no-fail-fast -> 154 tests pass (engine 44, service 110)
cargo fmt --all and cargo clippy --workspace --all-targets -- -D warnings -> clean
```

## Files changed in this tranche

 Cargo.lock                                    | 328 ++++++++++++-
 server/Cargo.toml                             |   1 +
 server/src/api.rs                             | 118 ++++-
 server/src/audit_api.rs                       |   8 +
 server/src/auth.rs                            | 397 +++++++++++++--
 server/src/gate_api.rs                        |  17 +-
 server/src/lib.rs                             |   9 +
 server/src/locks_api.rs                       |  34 +-
 server/src/main.rs                            |   2 +-
 server/src/merge_api.rs                       |  18 +-
 server/src/store/mod.rs                       |   5 +-
 server/tests/audit.rs                         | 327 +++++++++++++
 server/tests/auth.rs                          | 672 +++++++++++++++++++++++++-
 server/tests/fixtures/jwks.json               |  12 +
 server/tests/fixtures/rs256_other_private.pem |  28 ++
 server/tests/fixtures/rs256_private.pem       |  28 ++
