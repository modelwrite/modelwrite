# Assist UI report

## Status

DONE

## Commits

- `assist-ui` (one commit): the assist panel, accept form, and proposals page.

## One-line test summary

`cargo test --workspace --no-fail-fast` passes (all binaries green, 0 failed; 5 new
`ui_assist` integration tests plus 9 new unit tests), `cargo fmt --all -- --check` clean,
`cargo clippy --workspace --all-targets -- -D warnings` clean.

## The click path

1. Open the model page `GET /ui/projects/:project/model` (a caller with Write sees the
   **Assist** panel: a text box with the heater placeholder and a **Submit** button; a
   read-only viewer sees no panel and no Accept button).
2. Type a natural-language request and click **Submit** — the form POSTs to
   `/ui/projects/:project/assist`, which runs the reasoner and renders the **Assist review**
   page: the agent, the request, and each proposed change with its action and rationale,
   low-confidence items marked. Nothing is committed; the proposal is recorded by id.
3. Review the proposal, type a commit message, and click **Accept** — the form POSTs to
   `/ui/projects/:project/proposals/:id/accept`, which commits through the shared
   acceptance core and renders **Proposal accepted** with the commit and the provenance
   naming both parties (Proposed by agent / Accepted by human).
4. Click **View the accepted model** to see the result; visit
   `/ui/projects/:project/proposals` (linked from the project page) to see every proposal,
   newest first, with its decision (open / accepted by whom / refused by whom) and accepted
   items.

## Concerns

- The UI is a client of the existing API in this project's own idiom (the one used by merge,
  import and commit): the panel posts to a thin `/ui/.../assist` form route that calls the
  SAME `assist::assist_core` as the JSON `POST /projects/:project/assist` handler, and the
  Accept form calls the SAME `proposal_api::accept_proposal_core` as the JSON acceptance
  route. No store method was added and no second sequence exists; the form targets
  `/ui/...` routes only because a native form must receive an HTML page, not JSON, to work
  without JavaScript.
- The live reasoner path (Anthropic key) is not exercised end-to-end here — it needs a
  network/key — but its selection and answer validation are unit-tested; the panel and accept
  flow are proven against the deterministic scripted reasoner.
- The reasoner status (`assist::reasoner_status`) and the reasoner selection
  (`select_reasoner_from`) share one pure decision function so the panel's status line can
  never disagree with what a request will actually do; a deployment with no key is told
  plainly and pointed at `MW_ASSIST_REASONER=scripted` rather than shown a bare error.
