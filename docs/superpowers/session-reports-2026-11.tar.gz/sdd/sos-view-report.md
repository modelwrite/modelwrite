# System-of-Systems and Business-Process views — report

Status: DONE

## Commits

- `9141497` feat(ui): composition section — subsystem references and business-process views
  (4 files, +1182/−10: `server/src/ui/composition.rs`, `e2e/tests/composition.spec.js`,
  `e2e/tests/navigation.spec.js`, `e2e/models/cafe-stand.json`)

This builds on the committed stub `ef2cfbb` (route + `pub mod composition` + navigator/CSS),
which was green; the stub's untracked `server/src/ui/composition.rs` was completed, linted and
committed here.

## Test summary (one line)

Rust `cargo test --workspace` (target-tests) all green, `cargo clippy --workspace --all-targets -- -D warnings`
green, `cargo fmt --all` clean, and Playwright 16/16 passing (4 new composition tests).

## What each view shows

1. **Subsystems (system-of-systems)** — one card per typed reference, showing the role chip,
   the project, the pinned revision as an 8-char short hash with the full 64-char hash on hover
   (title attribute), the bounds list, and a green/red "resolves" chip. Above the cards a summary
   line: "3 subsystems, all resolving at their pinned revisions". The resolve chip reuses
   `crate::api::check_reference` — the exact function the resolve endpoint calls — so the page
   can never disagree with `/references/resolve`.
2. **Process** — the business process as an ordered left-to-right flow
   (Take Order → Take Payment → Provision Beverage ∥ Provision Food → Complete Order), each step
   showing its `allocatedTo` value as a chip and the requirement it satisfies where a Satisfy
   edge exists (CS-2 on Take Payment; CS-1 and CS-3 on Complete Order).
3. **Boundary** — two clearly separated panels: "Measured — proved" vs "Not measured — asserted,
   not proved", read verbatim from the S1 gate's own evidence.
4. **Models without references** — says plainly "This model declares no subsystem references…"
   and links to cafe-stand as the example.

## Boundary wording (verbatim, from the gate's evidence)

- Measured (proved): "every subsystem reference resolves at its pinned revision";
  "every integrated revision was itself gated"; "every platform requirement is covered within
  the platform model".
- Asserted (not proved): "the combined system-of-systems, as a whole, has the global graph
  property (connected, coverage-complete, orphan-free); proving it would require importing every
  subsystem, which is the copy R1 forbids".

## Limitation wording (rendered on the page)

"The link from a platform activity to a specific element inside a subsystem is carried by the
activity's `allocatedTo` attribute, which names a role — it is not yet a first-class
cross-model edge."

## Concerns

- **Visual check**: this model (`deepseek-v4-pro`) cannot read images, so the screenshot was
  NOT visually inspected. The page was verified by DOM inspection of the rendered HTML against a
  freshly built + seeded server (subsystems cards, resolve chips, flow layers/arrows, boundary
  panels, fidelity note all present and correct).
- **Red (non-resolving) chip is not e2e-reachable**: the commit path refuses a platform model
  whose references do not resolve (422), and there is no project/commit deletion, so a red chip
  cannot be produced through the public API. The green path is asserted; the red path is covered
  by the existing Rust `references.rs`/resolve-endpoint tests, and the page shares
  `check_reference` with them.
- **Pre-existing junk left untouched**: untracked `tmp-*.rs/json`, `e2e/diag-*.js` and
  screenshot PNGs, and a malformed `.gitignore` line (`e2e/*.png`ne2e/diag-*.js`) were left
  as-is (outside this task's ownership). The commit was staged with explicit paths.
