# app.modelwrite.org — registered trial deploy — report

Status: DONE_WITH_CONCERNS

## URL and proof

- URL: https://app.modelwrite.org
- Served by idc-1's hatch tunnel → http://localhost:3103 (`modelwrite-app.service`),
  REGISTERED mode (`authMode:"session"`), proxied CNAME to
  `895153ce-0e3a-44dd-ae05-d2546302cdcb.cfargotunnel.com`.

Verbatim (from the workstation, public internet):

    $ curl -sS -i https://app.modelwrite.org/health
    HTTP/1.1 200 OK
    {"authMode":"session","status":"ok"}

    $ curl -sS -i https://app.modelwrite.org/
    HTTP/1.1 303 See Other
    location: /register

DNS resolves to Cloudflare's proxied edge (104.21.21.15 / 172.67.195.173).

## Verbatim registration run

Register A (the code is printed to the operator log, NOT emailed — console-only mailer):

    $ curl -sS -i -X POST https://app.modelwrite.org/register \
        -H 'Content-Type: application/x-www-form-urlencoded' \
        --data 'email=app.e2e.a@example.com'
    HTTP/1.1 200 OK
    Content-Type: text/html; charset=utf-8
    <!DOCTYPE html>…<title>Check your email</title>…
    "If that address is registered or eligible, a login code is on its way."

    $ sudo journalctl -u modelwrite-app -n 40 --no-pager -o cat | grep mailer:console
    [mailer:console] to=app.e2e.a@example.com subject=Your Modelwrite login code body=Your Modelwrite login code is 868463. It expires in 10 minutes.

Redeem A's code, land in an empty workspace:

    $ curl -sS -i -X POST https://app.modelwrite.org/login \
        -H 'Content-Type: application/x-www-form-urlencoded' \
        --data 'email=app.e2e.a@example.com&code=868463' -c a.cookies
    HTTP/1.1 303 See Other
    location: /ui
    Set-Cookie: mw_session=c597fa65b8ed9496968d96c0e6502d4231a3e821b71bd067e6022c5a8f189c0f; Path=/; HttpOnly; SameSite=Lax; Max-Age=2592000

    $ curl -sS -b a.cookies https://app.modelwrite.org/projects
    []                                  [http=200]

    $ curl -sS -b a.cookies -X POST https://app.modelwrite.org/projects \
        -H 'Content-Type: application/json' -d '{"name":"a-project"}'
    {"createdAt":"1789972104","name":"a-project"}      [http=201]

Register B and create a project called `secret`:

    $ curl -sS -X POST https://app.modelwrite.org/register \
        -H 'Content-Type: application/x-www-form-urlencoded' \
        --data 'email=app.e2e.b@example.com'
    [HTTP 200]

    $ sudo journalctl -u modelwrite-app -n 20 --no-pager -o cat | grep mailer:console | tail -1
    [mailer:console] to=app.e2e.b@example.com subject=Your Modelwrite login code body=Your Modelwrite login code is 616840. It expires in 10 minutes.

    $ curl -sS -i -X POST https://app.modelwrite.org/login \
        -H 'Content-Type: application/x-www-form-urlencoded' \
        --data 'email=app.e2e.b@example.com&code=616840' -c b.cookies
    HTTP/1.1 303 See Other
    location: /ui
    Set-Cookie: mw_session=a4036acf538d02831a63291ce693c74e83f5154c3f87e31319fb7736b598f914; Path=/; HttpOnly; SameSite=Lax; Max-Age=2592000

    $ curl -sS -b b.cookies -X POST https://app.modelwrite.org/projects \
        -H 'Content-Type: application/json' -d '{"name":"secret"}'
    {"createdAt":"1789972111","name":"secret"}         [http=201]

## Cross-trial refusal pair (the 404/200)

A holds B's project name (`secret`) but has no session for B's trial; the project is looked
up in the SESSION's own per-trial database, so A gets 404 while B gets 200:

    $ curl -sS -i -b a.cookies https://app.modelwrite.org/projects/secret/branches
    HTTP/1.1 404 Not Found
    {"error":"project secret"}

    $ curl -sS -i -b b.cookies https://app.modelwrite.org/projects/secret/branches
    HTTP/1.1 200 OK
    []

    $ curl -sS -b a.cookies https://app.modelwrite.org/projects
    [{"createdAt":"1789972104","name":"a-project"}]    [A sees only its own workspace]

    $ curl -sS -b b.cookies https://app.modelwrite.org/projects
    [{"createdAt":"1789972111","name":"secret"}]        [B sees only its own workspace]

On disk, two separate per-trial SQLite databases (different trial ids), two accounts:

    $ sudo sqlite3 /opt/modelwrite/trials/identity.db 'SELECT email, trial_id FROM accounts ORDER BY email;'
    app.e2e.a@example.com|e2f7f3d0ba6153d354fb599ae8e65319
    app.e2e.b@example.com|91fd324c6cf943912427d5a2f4bc63fd

## What changed (and revert)

- `/opt/modelwrite/src`: `195cbf8` → `94953fc` (94953fc was pushed to `origin/slice-2-repository`
  first, then fetched on idc-1; detached HEAD at 94953fc).
- Image: `modelwrite/modelwrite:idc-1-app` (id `04d37fea2f5c`, ~149 MB), built CPU-bounded
  with `--cpuset-cpus=0-3`. The showcase image `modelwrite/modelwrite:idc-1-trial`
  (`73211ddac82b`) is UNTOUCHED.
- New: `modelwrite-app.service` (enabled, active), `/opt/modelwrite/deploy/modelwrite-app.env`
  (600), data dir `/opt/modelwrite/trials` (65532:65532).
- Ingress: `/etc/cloudflared/hatch-config.yml` gained the `app.modelwrite.org` →
  `http://localhost:3103` entry. Backup `/etc/cloudflared/hatch-config.yml.bak-pre-app`.
  Revert: delete the two added lines and `sudo systemctl restart cloudflared-hatch`.
- DNS: created `app.modelwrite.org` proxied CNAME → hatch tunnel. Old state: NO record.
  Revert: `DELETE /zones/869c1664050c14a7da2b7e6b3f0a94a0/dns_records/1f643ec46f0e582cb91e416a7114ee47`.

## Remaining blocker (exactly one)

Real transactional email delivery is blocked on an SMTP credential. The operator must
provide an SMTP account (Postmark, Resend, SES or SMTP2GO are all fine — any host, port,
username and password/API key) plus an envelope sender that is a real address on
`modelwrite.org` (e.g. `no-reply@modelwrite.org`). It plugs in at the `Mailer` trait seam in
`server/src/trial/mailer.rs`: implement an SMTP transport behind `MW_MAILER=smtp` + the
credential; the login-code flow is unchanged. Until then the mailer stays console-only and
the website's registered-trial door correctly reads "Rolling out now".

## Concerns

1. Email is console-only: a real visitor cannot complete login (the single blocker above).
2. `MW_TRIAL_DATA_ROOT` is `/opt/modelwrite/trials` per the task brief; the
   registered-trials report wrote `/opt/modelwrite/registered`. I followed the task brief.
3. The build emitted one pre-existing warning (`unused variable: tb`,
   `server/src/ui/diagram.rs:481`); the binary compiled cleanly and the 619-test suite was
   already green per the registered-trials report.
4. The website door copy still says "Not serving yet … no link to click" even though the
   registration form now serves; per instructions I left the "Rolling out now" state
   untouched (correct until real email delivery exists).
5. Nothing else was disturbed: `modelwrite.service`, `cloudflared.service` and
   `modelwrite-trial-reset.timer` remain active; no haproxy or `/opt/insights` changes.
