# N3 — Version control in the workbench

Status: DONE

## What shipped

Versions are branches, exactly as the plan's 'Change control' section rules. The
context bar now carries a **version selector** (a plain <details> disclosure of
server-rendered links), plus the three version actions, and each action is a client of
the existing branch/compare/merge endpoints — no new engine concept, no new store
method.

1. **Version selector** — the context bar shows the current project, version and
   commit. The selector lists every branch (one click to switch, with
   ?branch=<name> in the URL) and the recent commits (one click to open a
   historical ?commit=<hash>).
2. **New version** — 'New version' opens /ui/projects/:project/version/new; the
   form names a version and branches from a branch tip or a recent commit, posting to
   the existing POST /ui/projects/:project/branch (which lands on the new branch
   via ?branch=<name>).
3. **See what happens** — the selector's per-branch 'compare' link opens
   /ui/projects/:project/compare?from=&to= with both sides pre-filled, rendering
   the ENGINE's section-scoped diff (okf::diff::diff) plus the ENGINE's gate
   verdict (gate::run). The 'Compare' action also opens a chooser when only the
   'from' side is known.
4. **Make current** — 'Make current' (offered only from a non-main branch) opens
   /ui/projects/:project/version/make-current?candidate=, which runs the gate
   FIRST and renders its verdict and failures BEFORE the merge form. The form posts to
   the existing POST /ui/projects/:project/merge, so a clean merge is a commit and
   a conflicting merge renders base/ours/theirs (the existing merge page).

The record: branch creation and promotion go through the existing audit path
(branch.create and merge.clean / merge.conflict), and a promotion appears in
Changes as the main line's new tip with the actor's identity.

## Commits

- 0a91380 — the N3 UI code (server/src/ui/version.rs, the layout.rs selector,
  model.rs / review.rs / pages.rs, the routes, and e2e/tests/version-control.spec.js)
  landed here alongside the floor-robot integration commit.
- b34f21c — the e2e assertion/seed fixes (composition.spec.js and diagram.spec.js)
  that make the cafe-stand platform scenario resolve and assert the four-subsystem,
  six-step process flow.

## Tests

- Playwright: 24 passed, 0 failed (20 existing + 4 new version-control tests).
- cargo test --workspace --no-fail-fast: 73 targets ok, 0 failed.
- cargo fmt --all --check: clean. cargo clippy --workspace --all-targets -- -D warnings: clean.

## Click path: new version -> edit -> compare -> make current

1. Context bar -> 'New version' -> name the version, choose the commit to branch from -> 'Create version' (lands on /overview?branch=<name>).
2. Edit on that version (the overview's 'Add element' link, the per-element edit link, or the Assist panel — all already take the branch).
3. Context bar -> version selector -> the other branch's 'compare' link -> /compare?from=<name>&to=<other> (engine diff + gate verdict).
4. Context bar -> 'Make current' -> /version/make-current?candidate=<name> (gate verdict shown first) -> 'Merge and make current' -> POST /merge (branch=main, other=<name>).

## Concerns

- Visual verification: this model cannot read images, so the three screenshots
  (e2e/version-selector.png, e2e/compare.png, e2e/make-current.png) were verified by
  DOM inspection and by the passing Playwright assertions instead of by reading the
  pixels.
- The N3 UI landed inside the concurrent 'floor robot' integration commit (0a91380),
  not a dedicated N3 commit; the e2e assertion fixes are committed separately.
- The bare /ui/projects/:project/overview URL canonicalises to ?branch=main (the
  version is always in the address); the legacy /model URL deliberately does not
  redirect, to preserve the 200-status contract the Rust suite asserts.
