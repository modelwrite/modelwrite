import { setTimeout as sleep } from 'node:timers/promises';
const BASE = 'http://127.0.0.1:14102';
const TOKEN = '71e6652c4980128f654b957fb40fb275b5ae02096253727f3f3ea5e14ef90267';
const AUTH = { authorization: 'Bearer ' + TOKEN };
const MAIN = 'dd905e708e8c21a6ea0660a4ea08e2b0814d1a3fe3dc32e16481942681d208f1';

function section(t) { console.log('\n===== ' + t + ' ====='); }

function ctx(html, marker, before, after) {
  const i = html.indexOf(marker);
  if (i < 0) return '<NOT FOUND: ' + marker + '>';
  return html.slice(Math.max(0, i - before), i + marker.length + after).replace(/\s+/g, ' ');
}

const res = async (path, opts) => {
  const r = await fetch(BASE + path, opts);
  const text = await r.text();
  return { status: r.status, text };
};

// 1. projects list (authenticated)
{
  const r = await res('/projects', { headers: AUTH });
  section('GET /projects (authenticated)');
  console.log('status', r.status);
  console.log(r.text);
}

// 2. references resolve (authenticated)
{
  const r = await res('/projects/cafe-stand/commits/' + MAIN + '/references/resolve', { headers: AUTH });
  section('references/resolve (cafe-stand main)');
  console.log('status', r.status);
  console.log(r.text);
}

// 3. composition UI
{
  const r = await res('/ui/projects/cafe-stand/composition', { headers: AUTH });
  section('UI composition');
  console.log('status', r.status);
  console.log('has "4 subsystems, all resolving":', r.text.includes('4 subsystems, all resolving'));
  console.log('subsystem-card count:', (r.text.match(/subsystem-card/g) || []).length);
  for (const role of ['payment','beverage','food','floor-care']) {
    console.log('role', role, 'present:', r.text.includes(role));
  }
  console.log('data-resolves="true" count:', (r.text.match(/data-resolves="true"/g) || []).length);
}

// 4. compare UI (cross-model edge difference)
{
  const r = await res('/ui/projects/cafe-stand/compare?from=main&to=with-microduck', { headers: AUTH });
  section('UI compare main vs with-microduck');
  console.log('status', r.status);
  for (const m of ['Cup Collector','Gripper Arm','satisfied by','floor-robot','microduck','global graph property']) {
    console.log('marker "' + m + '":', r.text.includes(m));
  }
  console.log('--- context around "Cup Collector" ---');
  console.log(ctx(r.text, 'Cup Collector', 200, 200));
  console.log('--- context around "Gripper Arm" ---');
  console.log(ctx(r.text, 'Gripper Arm', 200, 200));
}

// 5. unauthenticated WRITE refused
{
  const r = await res('/projects', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ name: 'evil-project' }),
  });
  section('POST /projects (NO token)');
  console.log('status', r.status);
  console.log(r.text);
}

// 6. unauthenticated UI read refused
{
  const r = await res('/ui');
  section('GET /ui (NO token)');
  console.log('status', r.status);
  console.log(ctx(r.text, '401', 0, 400));
}
