# Analytics schema report — Packages 1 and 2 (report-and-artefact phase)

Status: DONE_WITH_CONCERNS

## What was verified, and how

- **No `bindings/` directory** — verified by directory listing; Python bindings are greenfield.
- **`mw-mcp` at `engine/mcp`** — read `engine/mcp/src/lib.rs` (4 document tools + 17 `repo.*` tools) and
  `engine/mcp/src/repository.rs::run_tool`.
- **No OpenAPI document** — searched `server`, `cli`, `engine`, `docs`, `spec`, `website`; none found.
- **No `server/src/qa_pipeline.rs`** — the import/artifact path is `binding_api.rs` + `store::ImportRecord`.
- **No `agents/generate.py`** — `agents/` contains only `CLAUDE.md`.
- **OKF carries no qualified name / no owner / no namespace** — read `engine/okf/src/types.rs`; the SysML v2
  reader records package structure as a named Lossy mapping (`binding-sysmlv2/src/lib.rs:496-501`).
- **Analyses slice not built** — no findings in the platform; gate failures are strings inside evidence.
- **TMT not loadable** — `engine/binding-xmi/tests/real_tmt.rs` pins 362 blocks, 7 req, 369 nodes, 633 edges,
  45,725 content losses + 2,828 lossy (= 48,553 blocking), 2,231 declarations, 36 MB / 255k-line XMI.
- **Trial open-mode, hourly reset** — `docs/deploy/idc-1-trial.md`.
- **Correction 9 is contradicted by the code** — `server/src/auth.rs` defines a `viewer` role
  (`Permission::Read → ["viewer", ...]`); "admin-or-nothing" is only the Open-mode default
  (`Identity::open()` = anonymous admin). Flagged, not silently "corrected".

## Engine surface read for the inventory

`server/src/lib.rs`, `server/src/api.rs`, `server/src/store/mod.rs`, `server/src/analytics_api.rs`,
`server/src/gate_api.rs`, `server/src/binding_api.rs`, `server/src/auth.rs`, `cli/src/main.rs`,
`engine/mcp/src/lib.rs`, `engine/mcp/src/repository.rs`, `engine/analytics/src/*.rs`,
`engine/graph/src/lib.rs`, `engine/okf/src/types.rs`, `engine/okf/src/validate.rs`,
`engine/binding/src/report.rs`, `engine/gate/src/lib.rs`.

## Adjusted table list (nine tables ship in v1)

`projects`, `commits`, `elements`, `relationships`, `requirements`, `trace_links`, `metrics`,
`metric_definitions`, `import_losses`.

## Dropped, and why

- **`qualified name`** (elements) — OKF carries no qualified name (correction 6, verified). `name` stands in.
- **`owner id`** (elements) — the OKF `Element` has no owner concept.
- **per-element `provenance kind` / `source binding` / `source artifact hash`** — these are per-commit /
  per-import, not per-element; join through `commits`.
- **`default_branch`** (projects) — the store has no default-branch concept ("main" is only a query fallback).
- **`findings` table** — deferred to v1.1 (analyses slice not built; no findings to ship — correction 7).

## The graph-gaps columns (ruling 4)

- `elements.element_id`, `.section`, `.name`, `.kind` — name every orphan.
- `relationships.source`, `.target`, `.kind`, `.label` — compute degree/components/dangling edges.
- `requirements.element_id`, `.covered`, `.covering_link_kinds` — name every uncovered requirement.
- `metrics.metric_id` (graph.isolated_count, graph.component_count, coverage.uncovered), `metrics.value`,
  `metrics.basis_element_count`, `metrics.basis_relationship_count`, `metrics.evidence_hash` — trend by baseline.
- `commits.hash`, `.committed_at`, `.parents` — baseline ordering.
- Honest gap: the engine counts/sizes isolated groups but does not expose per-node component membership
  (a v1.1 engine addition); the raw tables already let any consumer compute it.

## Files changed

- `docs/drafts/analytics-schema-proposal.md` — the proposal (Package 1).
- `spec/analytics/README.md`, `spec/analytics/metric_definitions.json`, `spec/analytics/jsonschema/*.schema.json`
  (9), `spec/analytics/arrow/*.arrow.json` (9) — the published artefact (Package 2).
- `engine/analytics/src/metrics.rs`, `engine/analytics/examples/gen_metric_definitions.rs`,
  `engine/analytics/tests/metric_definitions.rs`, `engine/analytics/src/lib.rs` (module wiring),
  `engine/analytics/Cargo.toml` (serde_json — already a workspace/dev dependency).

## Test summary

`cargo test --workspace --no-fail-fast`: **587 passed, 0 failed, 0 warnings** (86 suites, exit 0).
`cargo fmt --all`: clean. `cargo clippy --workspace --all-targets -- -D warnings`: clean.
Failing-test proof (red→green): removing one definition row turns `every_engine_metric_has_a_definition_row`
red — `engine metric gate.roundtrip.changed_attributes has no definition row`, exit 101; restored → green, exit 0.

## Commits

`9852eea` feat(analytics): mw-analytics-schema@1 proposal, schema artefact and metric-definitions generator
(26 files, +1376). The report file is NOT committed (`.superpowers/sdd/` is gitignored scratch).

## Concerns

1. **Licence (decision D1)** — the schema files carry Apache-2.0 per the brief, but the project's code and OKF
   spec are AGPL-3.0-or-later / header-less. The premise "matching the interchange licence the project already
   uses" is not borne out; the owner must decide Apache-2.0 (as drafted) vs AGPL (match the code).
2. **Correction 9 is wrong** — a viewer role exists in `auth.rs`; only the Open-mode trial is admin-or-nothing.
   The proposal records the truth; the owner may want to re-check the other nine corrections.
3. **"274 entries" (coffee-machine XMI)** — cited from the impact analysis; I could not locate the literal number
   in source, but verified the corpus itself (49 structure / 25 req / 9 signals / 8 activities / 99 nodes / 165 edges).
4. **Arrow schemas "build"** — authored as JSON in the Arrow DataType vocabulary and validated as well-formed,
   cross-consistent JSON; native Arrow validation/build lands with the arrow crate in Package 4 (no new deps this phase).

## The approval question

> **Approve mw-analytics-schema@1 as proposed? Transport packages 3-8 start only after your yes.**
