# Analytics transports: CLI (package 4) and MCP (package 5)

Status: IMPLEMENTED. The 'mw analytics' CLI group and the five new 'repo.*' analytics MCP
tools are built against mw-analytics-schema@1, with the basis rule enforced and the
contract + determinism proofs in place.

## What shipped

### Package 4 - the CLI (cli/)

- New 'mw analytics' subcommand group, in both --db (full) and --server (stubbed) modes:
  - 'analytics schema' - the schema document and version (9 tables, their columns, 25 metric definitions)
  - 'analytics tables' - lists tables and row counts for a commit (or branch head)
  - 'analytics export --project P [--commit C | --branch B | --all-commits] --format csv|ndjson|parquet --out DIR'
  - 'analytics metrics' (with --format json|csv)
  - 'analytics trend --metric M --branch B [--from C1 --to C2]' (with --format json|csv)
- Parquet via the arrow/parquet crates (arrow 55.2, parquet 55.2, MSRV 1.81 - a margin under
  the CLI's 1.88 floor). Build cost measured: ~50s on a warm cache, i.e. modest.
- Hive layout <out>/<table>/project=<p>/commit=<c>/part-0.parquet.
- Pipeline-safe: data on stdout, diagnostics on stderr.
- Files: cli/src/analytics.rs, cli/src/main.rs, cli/src/offline.rs, cli/src/http.rs,
  cli/Cargo.toml, cli/tests/analytics_export.rs.

### Package 5 - the MCP (engine/mcp)

- Extended the existing repo.* family (no new mw_* family):
  - repo.analyticsSchema - tables, columns, metric definitions
  - repo.metrics - metrics for a project at a commit/branch head, each WITH its basis
  - repo.trend - one metric across the commits of a branch
  - repo.table - bounded rows (default 50, max 500) with key filters + cursor, TOTAL row count on every page
  - repo.losses - paged full loss list (underlying entries behind repo.lossSummary)
- Every metric row carries its basis as data; every result carries the schema version.
- Files: engine/mcp/src/lib.rs, engine/mcp/src/repository.rs, engine/mcp/tests/mcp.rs,
  engine/mcp/tests/repository.rs.

### Published contract

- docs/agents/mcp-tools.json - five new tools added.
- docs/agents/mcp-agent.md - prose table + counts updated (26 tools: 4 document + 22 repo).
- server/tests/agent_contract.rs - the read-and-propose-only list now includes the five new
  tools, so a renamed or missing tool FAILS the contract; the wire-level GET-plus-one-POST
  proof in engine/mcp/tests/repository.rs now drives every new tool.

## The basis rule (enforced)

Every metrics row carries basis_element_count, basis_relationship_count,
constructs_not_carried, basis_note, engine_version, evidence_hash - as data, never only
prose. A metric without a basis is a defect; the smoke test asserts every one of the 25
metric rows carries all six basis columns.

## Verification

- cargo test -p mw-cli: 45 passed (parse tests, byte-identical export, DuckDB proof, smoke test).
- cargo test -p mw-mcp: 29 passed (tools/list, wire proof, analytics views with basis).
- cargo test -p mw-server --test agent_contract: 7 passed (manifest == tools/list,
  read-and-propose only, prose == manifest).
- cargo clippy -p mw-mcp --all-targets -- -D warnings: clean.
- cargo +1.75.0 build -p mw-mcp: passes (the engine 1.75 floor is preserved; no new deps).

### Byte-identical export proof

export_csv_and_ndjson_are_byte_identical_across_two_runs runs 'mw analytics export' of the
sample corpus (coffee-machine) twice, into two directories, for both CSV and NDJSON, and
asserts every one of the nine table files is byte-identical across the two runs. Row order is
canonical (sorted by key columns), no timestamps are added by the export.

### DuckDB row-count proof

duckdb_reads_the_parquet_tree_with_hive_partitioning_and_row_counts_match exports the corpus
as Parquet, then reads the tree back with DuckDB's read_parquet(..., hive_partitioning=true)
and asserts each table's row count equals 'mw analytics tables'. DuckDB 1.5.2 (Python module)
is installed on this machine; verified before writing the test.

## What I stubbed and why

- The CLI --server analytics commands build the planned Package 3 REST URLs
  (GET /analytics/schema, /analytics/{project}/tables/{table}, /analytics/{project}/metrics,
  /analytics/{project}/trend) but those endpoints do not exist yet (Package 3 is another task
  and server/src is out of scope). 'analytics export --server' returns a clear 'not
  implemented; use --db' error. The --db path is fully implemented.
- The MCP tools are thin pass-through clients over the same planned REST surface; their tests
  drive them through the injected transport with canned responses (no live network).

## Concerns

1. Coordination with the registered-trials task. Another task owns server/src right now and
   is actively editing it (the git tree shows many uncommitted server/src changes and new
   server/src/trial/, server/src/registered.rs). The server crate compiles intermittently
   (mid-refactor), which blocks cargo test --workspace, cargo clippy --workspace, and
   cargo clippy -p mw-cli from being green at the moment of writing. My crates (mw-cli tests,
   mw-mcp tests + clippy, agent_contract) are green on their own. I did NOT touch server/src
   (only server/tests/agent_contract.rs, which is mine per the task). The workspace-wide green
   gate is blocked on that task finishing, not on this work.
2. Cargo.lock is shared. I added arrow/parquet (my change) and the other task added
   'rand = "0.8"' to server/Cargo.toml (their change); both are in the working Cargo.lock.
   Committing must be coordinated so neither task clobbers the other's lock additions.
3. Single-commit metric semantics (a deliberate, documented reading, not an invention):
   compliance uses the model's own requirements as its specification (portfolio of one, so
   unknown_count is 0); cost reads no dataset (all requirements uncosted); the gate is the
   model gated against itself (round-trip counts 0). This matches how the engine's functions
   behave with no external inputs. Package 3 (REST) must match this reading for Package 7's
   equivalence test.
4. Hive layout for non-commit-scoped tables. projects and metric_definitions have no commit
   dimension, but the uniform layout writes them under project=<p>/commit=<c>/ (the task's
   single template). For a multi-commit export these are duplicated per commit (snapshot
   semantics); the tested single-commit path is unambiguous. The partition keys
   project/commit are excluded from the Parquet data files (they live in the directory), so
   DuckDB's hive_partitioning=true reconstructs them.
5. Accepted-commit import losses. import_losses is built from CommitProvenance::Imported
   (which carries the artifact hash). An Accepted commit's artifact hash is not on the commit
   record (it lives on the proposal), so accepted-import losses would need a proposal join -
   a candidate v1.1 refinement. Authored commits (the tested corpus) have no losses.

