# trial.modelwrite.org DNS move (revert record)
zone id: 869c1664050c14a7da2b7e6b3f0a94a0 (modelwrite.org)
record id: e37c08aa129ff2a0781286095b23d72d
type: CNAME
name: trial.modelwrite.org
OLD content (revert to): dff63553-e90e-4554-bc7a-c266b4b7455f.cfargotunnel.com  (workstation tunnel)
NEW content:             895153ce-0e3a-44dd-ae05-d2546302cdcb.cfargotunnel.com  (idc-1 hatch tunnel)
proxied: true
