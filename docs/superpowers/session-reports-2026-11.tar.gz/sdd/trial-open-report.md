# idc-1 trial — opened to the public

**Status:** DONE_WITH_CONCERNS

The trial at https://trial.modelwrite.org is now OPEN: no bearer token, no login form,
and a plain browser click renders the workbench. It is intentionally unauthenticated, and
it is bounded by a reset (now hourly) that is load-bearing.

## What changed (idc-1 only)

- `/opt/modelwrite/deploy/modelwrite.env` (mode 600): `MW_AUTH_TOKEN` blanked and
  `MW_ALLOW_OPEN=yes` added (that is the REAL variable the entrypoint guard requires —
  verified in `deploy/docker-entrypoint.sh` and `server/src/auth.rs`). `MW_BIND=0.0.0.0`
  unchanged.
- Restarted ONLY `modelwrite.service`. cloudflared, haproxy, `/opt/insights`, the local
  8080 trial, and every other unit were left untouched.
- The token line is KEPT-BUT-BLANKED (`MW_AUTH_TOKEN=`), not removed: `reset-trial.sh`,
  `seed-from-manifest.py` and `capture-seed.py` all read that line and would fail with
  "MW_AUTH_TOKEN not found" if it were deleted. Blank + open mode keeps them working.
- Backups taken on the host before editing:
  `/opt/modelwrite/deploy/modelwrite.env.bak-pre-open-20260921` (old env with the token)
  and `/opt/modelwrite/README.md.bak-pre-open-20260921`.

## Verbatim open-mode proof (public internet, from the workstation — not localhost/idc-1)

```
$ curl -sS https://trial.modelwrite.org/health
{"authMode":"open","status":"ok"}          [http=200]
```

```
$ curl -sS https://trial.modelwrite.org/projects
[{"createdAt":"1789940842","name":"cafe-stand"},{"createdAt":"1789940842","name":"coffee-machine"},{"createdAt":"1789940842","name":"floor-robot"},{"createdAt":"1789940842","name":"microduck"},{"createdAt":"1789940842","name":"purchasing-terminal"},{"createdAt":"1789940842","name":"sandwich-toaster"}]
[http=200]
```

Unauthenticated write succeeds (the intent):

```
$ curl -sS -X POST https://trial.modelwrite.org/projects -H 'content-type: application/json' -d '{"name":"open-mode-probe"}'
{"createdAt":"1789940624","name":"open-mode-probe"}
[http=201]
```

(The `open-mode-probe` project was then cleared within minutes by the hourly reset — see
below — which is itself proof the reset runs.)

## The UI renders

- `/ui` -> HTTP 200, `Content-Type: text/html; charset=utf-8`, 49023 bytes,
  `<!DOCTYPE html>`, `<title>modelwrite — projects</title>`, and all six project names
  present as content. No `401`, no `missing bearer token`.
- `/ui/projects/cafe-stand/model?branch=main` -> HTTP 200, `text/html`, 50910 bytes,
  `<!DOCTYPE html>`, `<title>modelwrite — cafe-stand</title>`. No `401`.
- Screenshots were captured with `e2e/shoot.js` against the public URL
  (`trial-open-projects.png`, `trial-open-cafe.png` — Playwright reached networkidle,
  i.e. the page fully loaded). I could not read them back: this model (deepseek-v4-pro)
  has no image input, so I verified the rendered page by the markup above and am saying so.

## The old token (for re-enabling later — not regenerated)

```
71e6652c4980128f654b957fb40fb275b5ae02096253727f3f3ea5e14ef90267
```

## How to re-enable auth (the one line to restore)

In `/opt/modelwrite/deploy/modelwrite.env`, set the token back and delete
`MW_ALLOW_OPEN=yes`, then restart:

```
MW_AUTH_TOKEN=71e6652c4980128f654b957fb40fb275b5ae02096253727f3f3ea5e14ef90267
```

then `sudo systemctl restart modelwrite`. (The token is also recorded in the env file's
own comment and in `idc-1-trial-deploy-2-report.md`; it is not in the repo.)

## Reset timer + backup (now load-bearing) — CONFIRMED, but schedule changed

The reset safety net is intact and is STRONGER than the original deploy reports described:

- Timer `modelwrite-trial-reset.timer`: `enabled`, `Persistent=yes`,
  `OnCalendar=hourly`. `systemctl list-timers` shows NEXT `Sun 2026-09-20 22:00:00 UTC`
  (LAST `21:47:21`, which ran `status=0/SUCCESS` and re-seeded the six models). It fires.
- Backup step in `reset-trial.sh`: the outgoing DB is copied to
  `/opt/modelwrite/backups/<date>T<time>.db` BEFORE the fresh-DB swap, keeping the last 48
  (~2 days). `/opt/modelwrite/backups/` holds `2026-09-20.db` and `2026-09-20T214733.db`.

**Divergence to note:** a second actor changed the reset from the documented nightly
`18:00 UTC` (per the deploy reports and the user brief) to HOURLY, with a comment that
"the trial is OPEN, so a visitor's mess should last minutes, not a day". It also rewrote
`reset-trial.sh` to build the fresh DB off to the side (the live service keeps serving
until the final backup+swap+restart) and to name backups by date AND time (no same-day
overwrite). I did not author that change and did not revert it, because for an open trial
it is strictly safer (damage bound is ~1 hour instead of ~24). The seed container and the
verification curls now run with an empty token, which open mode ignores — confirmed by the
21:47 run completing cleanly (all seven hashes reproduced, references resolve).

## Documentation updated

- Host `/opt/modelwrite/README.md`: health line `authMode=open`; Auth section says OPEN by
  decision and how to re-enable; the reset section (retitled "Hourly reset") and the "Open
  mode note" state that the trial is open by decision and the reset (with its backup) is
  load-bearing.
- `docs/deploy/idc-1-trial.md` committed and pushed (`9b65512` then `c82a52c`) — records
  the open decision, the env change, the re-enable procedure, and the hourly reset, with NO
  token in the repo.

## Concerns

1. The trial is fully open: any stranger with the URL is an anonymous admin with every
   project and every write/admin permission. The reset (backup -> rebuild -> swap) is the
   ONLY thing bounding that. It is healthy, but it is now the single point of safety.
2. Concurrent work: another actor is actively changing the same host's reset timer/script
   (nightly -> hourly) while this task ran. The end state is coherent and safer, but the
   ownership of this hostname/timer needs to be one agent going forward (flagged in the
   prior deploy reports too).
3. Screenshots were captured but not visually inspected (this model cannot read images);
   the rendered-page proof is the HTML markup instead.
4. A same-run note: the hourly reset ran during verification and cleared the throwaway
   `open-mode-probe` write, which demonstrates the reset rather than a defect.
