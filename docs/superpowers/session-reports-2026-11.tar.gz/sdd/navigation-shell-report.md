# Navigation shell report (N1/N2)

status: DONE

## Commits

- workbench: global navigation shell — model switcher, left navigator, per-section addresses

## One-line test summary

cargo test --workspace green; cargo fmt --all clean; cargo clippy --workspace --all-targets -- -D warnings clean; Playwright 11/11 passed (7 existing + 4 new navigator tests).

## Section routes

All server-rendered, all under /ui/projects/:project/:

- /overview (also /model, kept for backward compatibility and the existing test suite)
- /structure
- /requirements
- /traceability
- /diagram
- /checks (also /gate and /gate/:ref/:cand)
- /changes (also the bare /ui/projects/:project, which remains the branch-list/version history page)
- /proposals
- /import
- /assist (GET added alongside the existing POST)

The model switcher and navigator are server-rendered links (the switcher is a plain <details> disclosure), so everything works with JavaScript disabled.

## What the screenshots showed

Screenshots were captured (e2e/shots/project-list.png, overview.png, structure.png, requirements.png) against a server running the rebuilt binary on a copy of the trial database (the three models). read_image is unavailable for this session's model (deepseek-v4-pro does not declare image input), so visual verification was done by DOM/layout inspection through Playwright instead of reading the PNGs:

- Global top bar: full-width; the model switcher names the current model (coffee-machine) and its menu lists all three models.
- Left navigator: MODELS group lists all three models (current highlighted); SECTIONS group lists all ten sections (current highlighted).
- Context bar above the content: coffee-machine · version main · commit d427e847.
- Project list h1 Projects; overview h1 Overview; structure h1 Structure.
- One defect found and fixed: app.js was moving the context bar into the three-pane content pane (it rendered at x=472, right of the tree panel); corrected so it stays above the workbench spanning the full content width.

## Concerns

- Section links carry the full commit hash in the query (?commit=<64 hex>) so switching sections preserves the exact version being viewed; URLs are longer — the cost the plan acknowledged. N3 (version selector) should replace this with branch-level selection.
- read_image is unavailable for this model, so the screenshots were verified structurally rather than visually read.
- The three-pane IDE enhancement (app.js) remains on the Overview only; the per-section pages are plain server-rendered reading pages, which is the no-JS-first behaviour but means the tree is not repeated on every section.
