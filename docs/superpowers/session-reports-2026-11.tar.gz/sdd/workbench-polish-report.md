# Workbench polish — report

Status: DONE_WITH_CONCERNS

## Commits
See git log (the 5-file change is committed in this session).

## Test summary
`cargo test --workspace --no-fail-fast` green; `cargo fmt --all --check` clean; `cargo clippy --workspace --all-targets -- -D warnings` clean; Playwright 11/11 passed.

## Per-item outcome (all 13 addressed)

Projects list (/ui):
1. Whole-card link + hover + "Open →" affordance — DONE. Cards are now one `a.project-card` link; hover tints the border/background.
2. "coffee-machine(1) branch" artifact — DONE. Branch count is now a meta line with dot separators ("1 branch · 49 blocks · 25 requirements").
3. Model size on each card — DONE. Blocks + requirements read from the branch-tip model's own summary (no caching).
4. Wasted space — DONE. Cards lay out in a responsive grid (4 columns at 1440px) and the New-project input is capped at 24rem.

Model pages:
5. Context bar reads as an input — DONE. Restyled to a muted slim bar (surface-1 + border-muted) with a "Viewing" eyebrow label.
6. Changes page duplicate dump — DONE. Removed Proposals/Gate/Import from the Changes page; it now holds only version history + Compare + New branch + Merge.
7. No page heading/description — DONE. Structure/Requirements/Traceability (and Projects) now have an h1 plus a one-line description.
8. Empty right half of section pages — DONE. Structure and Requirements get the three-pane IDE; Traceability uses the full width (mw-wide).
9. Mixed affordances — DONE (resolved by #6). Navigation is now links (left nav), actions are buttons (forms); the duplicated text links were removed.

Earlier review:
10. Properties panel disappears on scroll — DONE. Both side panels now have a fixed viewport height + sticky (no dead white column below a short properties panel).
11. Tree truncates names mid-word — DONE. Tree widened to 18rem, indentation tightened, and every node name carries a title attribute; "Electrical System" no longer truncates.
12. Coverage palette unused — DONE. Requirements table got a coverage column; tree requirement rows show a coverage chip; traceability summary and overview card show covered/uncovered as text chips (never colour alone).
13. Requirements table cramped — DONE. table-layout: fixed, id column truncated with the full id on hover, text column is now the widest.

## Verified visually vs structurally
STRUCTURALLY verified (DOM/layout inspection via headless Chromium against a freshly-built binary on :8091): grid columns, card link hrefs, context-bar background/border, three-pane panel widths/heights, sticky positions after scroll, table column widths, id truncation + title, tree coverage chip text, section page headings/descriptions, and Changes-page composition.

NOT verified visually: this model does not accept image input, so I could not look at the screenshots. Fresh screenshots were captured to e2e/nav-projects-new.png, e2e/nav-overview-new.png, e2e/nav-structure-new.png, e2e/nav-requirements-new.png for a human to review.

## Concerns
- server/tests/ui.rs (a Rust structural test) was updated to match the new coverage-chip markup and counts — this sits outside the stated "server/src/ui/* and e2e/tests/*" ownership but was required to keep the workspace green; assertions were updated, not weakened.
- No image input, so visual confirmation is left to a human.
