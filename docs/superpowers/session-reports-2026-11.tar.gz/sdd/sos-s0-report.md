# System-of-systems S0 — platform-model primitive — report

**Status:** DONE_WITH_CONCERNS

**Commit:** 1e693cc86fdcc24a22e0cf5216c28a8906566abb — `feat(sos): add the typed, pinned subsystem-reference primitive (S0)`

**One-line test summary:** 480 passed, 0 failed, 24 ignored (12 new tests), `cargo fmt --all` clean, `cargo clippy --workspace --all-targets -- -D warnings` clean.

## What S0 proves (and only this)

A subsystem reference is **typed** (project + pinned revision + role, all required), **pinned** (a commit hash, never a branch name and never "latest"), **committed** (it lives in the `OkfRoot` document's `references` field, so it is versioned, diffed and gated like every other element — not a side table that can drift), **diffable** (the engine's own diff names the reference and reports a revision change as a one-line `changedAttributes` entry, e.g. `reference:radar`), and **resolves to a real element at a real revision** (the named project exists and the revision is a commit of it). A reference that does not resolve — the project does not exist, or the hash is not a commit of it — is a named validation error (422) at commit, never a silent dangling reference and never a panic. Two platform models integrating different revisions of the same subsystem differ visibly in the engine's diff output. The single-model gate is unchanged: a platform model gates exactly like any other model, references treated as ordinary content.

## What S0 deliberately does NOT prove

No cross-model traceability. S0 does not check was-gated, does not compute platform coverage across the subsystem boundary, does not verify bound elements inside a subsystem revision, and does not assert or measure the global system-of-systems graph property. Those are S1's compositional gate. Every test and message in this slice says "a reference resolves", never "cross-model traceability is proved".

## Concerns

1. **Forced minimal edits to DO-NOT-TOUCH crates.** Adding `references` to `OkfRoot` (required by R1: the reference is part of the model document) forces every Rust struct literal of `OkfRoot` to name the new field. That required a one-line mechanical `references: Vec::new(),` in five DO-NOT-TOUCH files: `engine/binding-xmi/src/lib.rs`, `engine/binding/tests/harness.rs`, `engine/binding-xmi/tests/xmi_harness.rs`, `engine/agent/tests/proposals.rs`, `engine/analytics/tests/cost.rs`. No logic changed; clippy and the full suite confirm those crates still behave identically.
2. **Merge path does not re-run resolution.** Resolution is enforced in `commit_core` (JSON commit, editor, import, proposal acceptance). The merge path (`store.commit_merge`) three-way-merges references keyed by project but does not re-check resolution. It cannot introduce a dangling reference: a merge combines only already-validated references from its parents, and the store never deletes a project or a commit, so resolution is monotonic. Stated rather than patched (a resolution failure there would need an awkward `StoreError` mapping).
3. **Resolve/list endpoint scope.** Both endpoints require Read and reach of the platform project, but apply no per-target scope filter: a reader of a platform model can see whether its declared subsystems resolve. The document already names the targets, and the commit path resolves them server-side regardless of author scope. Per-target scope filtering of cross-project resolution is deferred.
4. **Role vocabulary is open.** `role` is an open string, validated only as non-empty, per §9's open decision; no closed enum was invented for S0.
5. **Branch.** Committed on the checked-out branch `slice-2-repository`, not main (the task did not specify a branch).
