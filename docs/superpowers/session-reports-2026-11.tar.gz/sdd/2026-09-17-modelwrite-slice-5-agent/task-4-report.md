# Task 4 report — The agent HTTP contract, documented and tested against the real API

## Status

DONE

## Commits

- `61afabe` docs: document the agent HTTP contract and enforce it against the live router
  - modified: docs/agents/mcp-agent.md, docs/agents/mcp-tools.json
  - new: server/tests/agent_contract.rs

## Test summary

`cargo test --workspace --no-fail-fast` → **297 passed, 0 failed, 16 ignored** (the skipped
PostgreSQL suite, which CI runs for real).
Per crate: agent 14, binding 6, binding-xmi 18, capi 4, cli 34, gate 5, graph 7, mcp 13,
okf 17, server 179 (+16 ignored), test_support 0.
`cargo fmt --all` clean; `cargo clippy --workspace --all-targets -- -D warnings` clean.

## What was added

- **The repository HTTP surface** — 21 endpoints (method, path, permission, summary) derived
  from the route table in `server/src/lib.rs`: commits, branches, branch reset (revert),
  three-way merge, gate runs, the import endpoint and its loss report, the append-only audit
  log, element locks (acquire/list/release), plus `/health` and `/version`.
- **The authentication and identity model** — the four modes (open/static/jwt/agent), the
  agent-token mechanism (subject + authorizer + roles + projects), the four permissions and
  the roles that grant them, project scope, and the exact refusals (401/403/404/409/422).
- **The audit identity** — actor / mechanism / authorizer, and the fixed action vocabulary
  from `server/src/audit.rs`.
- **The enforcement test** `server/tests/agent_contract.rs` (5 tests): every endpoint in the
  manifest resolves on the live router on the declared method; every permissioned endpoint
  refuses a no-role caller with 403 (public routes answer 200); the manifest names exactly
  the four MCP tools with the right required arguments; the agent mechanism authenticates a
  named agent and is audited with actor/mechanism/authorizer; and an agent is refused what
  its roles do not grant.

## What was removed as stale

- The planned model-edit MCP tools `rules.check`, `model.read`, `model.propose`,
  `patterns.list`, `patterns.instantiate`, `evidence.write` — none ever shipped as an
  MCP tool or an HTTP route, and the agent is an HTTP client, not an MCP-tool caller.
- The old "Slice 1 / Slice 5" prose that described a model-edit API the service never
  acquired.

## What I could not verify

- The MCP tool names are asserted against a hardcoded authoritative list (which I read
  directly from `engine/mcp/src/lib.rs` `tools/list`) rather than by driving the MCP
  server's `tools/list` at runtime: `server` does not depend on `engine/mcp`, and adding
  that dependency would have touched `server/Cargo.toml`, outside the paths this task owns.
  The HTTP surface is verified against the real router, which is the high-drift surface.

## Concerns

- The pre-existing `server/tests/auth.rs` denial test (`every_route_denies_a_caller_without_permission_or_scope`)
  does not enumerate the two import routes; the new contract test covers them (resolve +
  403 on a no-role caller), so the contract surface is fully enforced.
- The `/ui/*` routes are deliberately out of the agent contract (they are the browser
  workbench; an agent is a JSON client) and are therefore not machine-checked by this test.
