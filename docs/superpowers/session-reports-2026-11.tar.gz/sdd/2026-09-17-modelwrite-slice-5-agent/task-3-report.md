# Task 3 report — The agent identity and the audit trail

## Status

DONE_WITH_CONCERNS

## Commits

- `25c4d3c` feat: add the agent identity and the audit trail
  - new: server/tests/agent_audit.rs
  - modified: server/src/auth.rs, server/src/api.rs, server/src/binding_api.rs, server/src/gate_api.rs, server/src/locks_api.rs, server/src/merge_api.rs, server/src/store/mod.rs, server/src/store/sqlite.rs, server/src/store/postgres.rs, server/src/ui/edit.rs, server/src/ui/import.rs, server/src/ui/review.rs, server/src/Cargo.toml, server/tests/migration.rs, server/tests/store.rs, server/tests/postgres.rs, Cargo.lock
  - modified (compile-fix, see deviation): cli/src/offline.rs

## Test summary

`cargo test --workspace --no-fail-fast` → **292 passed, 0 failed, 16 ignored** (the skipped PostgreSQL suite, which CI runs for real).
By crate: agent 14, binding 6, binding-xmi 18, capi 4, cli 34, gate 5, graph 7, mcp 13, okf 17, server 174, test_support 0.
Baseline was 284 passed; this task contributes the other 8 (5 agent-audit tests + 3 auth unit tests).

## What was built

- `AuthConfig::Agent { token_hash, subject, authorizer, roles, projects }` — an agent bearer token, with `agent_token(...)`, `mechanism() == "agent"`, `authorizer()`, `parse_identity_from_agent`, the `identity()` arm, `from_env` support (`MW_AUTH_AGENT_TOKEN`, `MW_AUTH_AGENT_SUBJECT`, `MW_AUTH_AGENT_AUTHORIZER`, `MW_AUTH_AGENT_ROLES`, `MW_AUTH_AGENT_PROJECTS`), and a redacted Debug.
- `AuditEntry.authorizer` — a first-class column on the append-only audit table (SQLite + Postgres, each with an idempotent migration), recorded on every entry. Empty for a human; the human/service's subject for an agent. Threaded through `record_refusal`, `CommitCore`, `ImportCore`, `MergeCore`, and every handler. `commit_refusal_guard` keeps its 6-argument form for the offline CLI, and the server write paths use the new `commit_refusal_guard_attributed`.
- The acceptance key reconciliation (below).

## Where the key reconciliation lives, and why

In `server/src/binding_api.rs`. `acceptance_matches(mapping, accepted)` reconciles an acceptance name to a mapping by `agent::losses::entry_identity(mapping)` — the SAME function the agent uses to name a proposal — with the binding's raw subject accepted as a backward-compatible alias for the workbench form. `import_core` records the accepted losses as the entry identity (`subject [verdict]`), never the raw subject, so the acceptance the server stores is exactly the entry the human chose and two losses that share a subject cannot collapse.

Why here: the seam is "the agent identifies a loss by (subject, verdict); the server's acceptLosses authority keys on the raw subject". That authority IS the acceptLosses handling in `import_core`, so the reconciliation lands there, on the ONE key both sides already share (`entry_identity`, imported from `mw-agent` rather than re-implemented, so the two cannot drift).

## Concerns

One, from the deviation below: `AuditEntry` gained a required `authorizer` field, which the offline CLI (`cli/src/offline.rs`) constructs directly in three places. Without a mechanical update the workspace would not compile, so those literals gained `authorizer: String::new()` — a no-op for the CLI (it has no authorizer), but it does touch `cli/`, which the brief said to leave alone.

## Deviation

- Modified `cli/src/offline.rs` (3 lines: `authorizer: String::new()` added to the three `AuditEntry` struct literals). Reason: adding the required `authorizer` column to `AuditEntry` breaks any external struct literal; the offline CLI constructs `AuditEntry` directly, and leaving it would make `cargo test --workspace` fail to compile, violating the "everything stays green" constraint. The change is mechanical and behavior-neutral (offline CLI entries carry an empty authorizer, exactly as before).

## Verification

- `cargo test --workspace --no-fail-fast` — green (292 passed, 0 failed, 16 ignored).
- `cargo fmt --all` — clean (exit 0).
- `cargo clippy --workspace --all-targets -- -D warnings` — clean (exit 0).

## Acceptance evidence (asserted in server/tests/agent_audit.rs and server/src/auth.rs)

- `an_agent_action_is_audited_with_the_agent_mechanism_and_authorizer` — project.create and commit.create under an agent token record mechanism "agent", actor "loss-report-resolver", authorizer "alex".
- `a_reader_can_tell_an_agent_action_from_a_human_one_from_the_log_alone` — the same action under a static token records mechanism "static"/actor "admin"/authorizer "", distinct from the agent's record.
- `an_agent_is_refused_an_action_its_permissions_do_not_allow` — a viewer agent is refused project creation with 403 and writes nothing.
- `accepting_by_agent_identity_stores_the_acceptance_the_human_chose` — importing coffee-grinder.xmi by its six entry identities commits and the stored `acceptedLosses` are exactly those identities.
- `an_entry_identity_accepts_exactly_the_entry_it_names` — the `subject [verdict]` identity reconciles to exactly one of two same-subject entries (Lossy vs Unmappable).
- auth unit tests: agent mechanism/authorizer, non-agent authorizer is None, agent Debug redacts the token.
