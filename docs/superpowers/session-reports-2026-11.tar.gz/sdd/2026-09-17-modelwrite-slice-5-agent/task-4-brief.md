## Global Constraints

- Rust stable; the engine crates stay at rust-version 1.75; the server is at 1.88.
- Every source file begins with: // SPDX-License-Identifier: AGPL-3.0-or-later
- Cargo is not on PATH in fresh shells: begin every shell command sequence with $env:Path = "$env:USERPROFILE\\.cargo\\bin;" + $env:Path
- Use --no-fail-fast when running a test suite.
- Stage and commit only the paths a task owns. Never amend or rewrite a commit.
- **AN AGENT IS A CLIENT, NOT A PRIVILEGED PATH.** Every agent action goes through the same handlers, permissions, locks, audit entries and gate as a human's. There is no "agent mode" that skips a check.
- **NO MODEL CHANGE IS COMMITTED BY AN AGENT ALONE.** The agent produces proposals; a human accepts them; the acceptance is recorded. The design says so, and this slice must not quietly relax it.
- **NO NETWORK IN ANY TEST.** The reasoning is a trait; tests use a scripted implementation.
- **ATTRIBUTION IS NOT OPTIONAL.** Every agent action is audited with the agent's identity and the mechanism, and the record says it was an agent, so a reader a year later can tell who decided.

## Task 4: The agent's HTTP contract, documented and tested against the real API

**Files:** modify docs/agents/mcp-agent.md and docs/agents/mcp-tools.json; test server/tests/agent_contract.rs.

**Interfaces:** the published agent contract (written in Slice 1) is brought up to date with everything Slices 2-4 added - import, the loss report, gate runs, locks, the audit log - and a test asserts that every tool the contract names EXISTS as a route, so the contract cannot drift from the service.

**Acceptance:** every endpoint named in the agent contract resolves; a tool that was renamed or removed fails the test rather than disappointing an agent later.

---

