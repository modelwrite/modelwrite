## Global Constraints

- Rust stable; the engine crates stay at rust-version 1.75; the server is at 1.88.
- Every source file begins with: // SPDX-License-Identifier: AGPL-3.0-or-later
- Cargo is not on PATH in fresh shells: begin every shell command sequence with $env:Path = "$env:USERPROFILE\\.cargo\\bin;" + $env:Path
- Use --no-fail-fast when running a test suite.
- Stage and commit only the paths a task owns. Never amend or rewrite a commit.
- **AN AGENT IS A CLIENT, NOT A PRIVILEGED PATH.** Every agent action goes through the same handlers, permissions, locks, audit entries and gate as a human's. There is no "agent mode" that skips a check.
- **NO MODEL CHANGE IS COMMITTED BY AN AGENT ALONE.** The agent produces proposals; a human accepts them; the acceptance is recorded. The design says so, and this slice must not quietly relax it.
- **NO NETWORK IN ANY TEST.** The reasoning is a trait; tests use a scripted implementation.
- **ATTRIBUTION IS NOT OPTIONAL.** Every agent action is audited with the agent's identity and the mechanism, and the record says it was an agent, so a reader a year later can tell who decided.

## Task 3: The agent identity and the audit trail

**Files:** modify server/src/auth.rs (an agent mechanism), server/src/audit.rs, server/src/api.rs if a route is needed for agent actions; test server/tests/agent_audit.rs.

**Interfaces:** the auth mechanism gains `agent` alongside open/static/jwt, so an action taken with an agent token is recorded as having been taken by an agent; the audit entry carries the agent's subject AND the human or service that authorised it where one exists.

**Acceptance:** an action taken with an agent token is audited with mechanism `agent`; a reader can tell an agent action from a human one from the audit log alone; an agent cannot take an action its permissions do not allow, proven by a denial test.

---

