## Global Constraints

- Rust stable; the engine crates stay at rust-version 1.75; the server is at 1.88.
- Every source file begins with: // SPDX-License-Identifier: AGPL-3.0-or-later
- Cargo is not on PATH in fresh shells: begin every shell command sequence with $env:Path = "$env:USERPROFILE\\.cargo\\bin;" + $env:Path
- Use --no-fail-fast when running a test suite.
- Stage and commit only the paths a task owns. Never amend or rewrite a commit.
- **AN AGENT IS A CLIENT, NOT A PRIVILEGED PATH.** Every agent action goes through the same handlers, permissions, locks, audit entries and gate as a human's. There is no "agent mode" that skips a check.
- **NO MODEL CHANGE IS COMMITTED BY AN AGENT ALONE.** The agent produces proposals; a human accepts them; the acceptance is recorded. The design says so, and this slice must not quietly relax it.
- **NO NETWORK IN ANY TEST.** The reasoning is a trait; tests use a scripted implementation.
- **ATTRIBUTION IS NOT OPTIONAL.** Every agent action is audited with the agent's identity and the mechanism, and the record says it was an agent, so a reader a year later can tell who decided.

## Task 2: The loss-report resolver

**Files:** create engine/agent/src/losses.rs; test engine/agent/tests/losses.rs.

**Interfaces:** `pub fn propose_loss_resolutions(report: &binding::LossReport, reasoner: &dyn Reasoner) -> Result<ReviewArtifact, AgentError>` which turns a binding's loss report into proposals, one per blocking entry, and NEVER proposes accepting a loss it cannot explain.

**Rulings:** an `Unmappable` loss is never proposed for acceptance by the agent alone (there is nothing to map it to); a `Lossy` loss is proposed with the reason taken from the report's own note, not invented; and the artifact lists what the agent does NOT know, because a review that hides its gaps is the failure this whole platform is built against.

**Acceptance:** the coffee-grinder fixture's six named losses produce six proposals; an Unmappable entry produces a Reject-with-reason or NoAction rather than an acceptance; the artifact names the entries the reasoner had nothing to say about.

---

