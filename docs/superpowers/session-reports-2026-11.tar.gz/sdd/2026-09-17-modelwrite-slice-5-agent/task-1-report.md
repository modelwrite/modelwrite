# Task 1 report — The proposal contract and the scripted reasoner

## Status

DONE

## Commits

- `cb88acf` feat: add the proposal contract and the scripted reasoner
  - new: engine/agent/src/lib.rs, engine/agent/src/report.rs, engine/agent/tests/proposals.rs, engine/agent/Cargo.toml
  - modified: Cargo.toml (one new workspace member), Cargo.lock

## Test summary

`cargo test --workspace --no-fail-fast` → **272 passed, 0 failed, 16 ignored** (the skipped PostgreSQL suite, which CI runs for real).
By crate: agent 8 (new), binding 5, binding-xmi 16, capi 4, cli 34, gate 5, graph 7, mcp 13, okf 17, server 163, test_support 0.

Baseline was 264 passed; this crate contributes the other 8.

## What was built

- `Reasoner` (the trait: `fn propose(&self, task: &AgentTask) -> Result<Vec<Proposal>, AgentError>`), `AgentTask { goal, material, constraints }`, `Material::{LossReport, Diff, Document}`, `Proposal { subject, action, rationale, confidence }`, `ProposedAction::{AcceptLoss, Reject, EditElement, DraftText, NoAction}`, `Confidence::{High, Medium, Low}` — engine/agent/src/lib.rs.
- `ReviewArtifact { task, proposals, agent, rationale_summary }` with `blocking()` and `render_text()` — engine/agent/src/lib.rs + engine/agent/src/report.rs.
- `ScriptedReasoner` (deterministic, script-driven) with `new`, `agent`, `review`, and `Reasoner` impl.
- `AgentError::{EmptyGoal, InvalidMaterial, Refused}` — the single typed error; no panics anywhere in the crate.

## The key design decisions

- **Whether a proposal changes the model is a property of the variant, not a field.** `ProposedAction::changes_model()` returns true only for `EditElement` and `DraftText`; `AcceptLoss`, `Reject` and `NoAction` are decisions or observations that change nothing. A human therefore cannot mislabel a change as an observation: the two are different enum variants, and `ReviewArtifact::blocking()` returns exactly the model-changing proposals.
- **Committing without a human is not expressible.** The crate has no write path at all — a reasoner's only output is `Vec<Proposal>` plus a `ReviewArtifact` for a human to read. There is no type or method that turns a proposal into a commit.
- **Attribution is in the artifact, not just the metadata.** `render_text()` opens with "This artifact was produced by an automated agent. Nothing here has changed a model…", so the record says it was an agent even if the surrounding system is lost.
- **Low confidence is marked, never buried.** `render_text()` appends `*** NEEDS ATTENTION ***` to the low-confidence proposal's own line, and the two sections ("PROPOSALS THAT CHANGE THE MODEL" / "PROPOSALS THAT DO NOT CHANGE THE MODEL") separate the short list a human must decide from the long list of observations.

## Acceptance evidence (asserted in tests/proposals.rs)

- `a_scripted_reasoner_renders_a_deterministic_artifact` — the full rendered text is pinned as an exact string, so a drift in wording, ordering or marking fails the test.
- `render_text_separates_model_changes_from_observations` — every model-changing subject sits under the changes heading, every other subject under the observations heading.
- `a_low_confidence_proposal_is_marked_for_attention` — the DraftText (Low) proposal's line carries the attention marker; the High-confidence edit line does not.
- `blocking_returns_only_proposals_that_change_the_model` — `blocking()` yields exactly the two model-changing proposals.
- `changes_model_is_a_property_of_the_action` — pins the change/no-change split for all five actions.
- `an_empty_goal_is_a_typed_error` — a blank goal returns `AgentError::EmptyGoal`, never a panic.
- `the_artifact_records_which_agent_proposed` and `a_document_material_renders_without_knowing_the_types` — attribution and type-free readability.

## Verification

- `cargo test --workspace --no-fail-fast` — green (272 passed, 16 ignored).
- `cargo fmt --all` — clean (exit 0).
- `cargo clippy --workspace --all-targets -- -D warnings` — clean (exit 0).
- `cargo +1.75.0 check -p mw-agent --all-targets` — clean (exit 0); the crate inherits `rust-version = "1.75"` from the workspace and uses no post-1.75 language features.

## Concerns

- None blocking. Two notes: `Material` carries a whole `OkfRoot` by value, which is a legitimate size (a document is larger than a report); clippy's `large_enum_variant` is suppressed on that enum with a WHY comment rather than boxing, to keep a `Box` out of the public contract API. And because `okf::diff::DiffReport` derives `Serialize` but not `Deserialize`, `Material`/ `AgentTask`/ `ReviewArtifact` derive `Serialize` only — the same shape as the existing `FidelityOutcome`.

## Deviation

- The brief/plan do not state a literal commit message; I used the project's conventional-commit style derived from the task title (`feat: add the proposal contract and the scripted reasoner`).
- Added `ProposedAction::changes_model()`, `Proposal::changes_model()`/`needs_attention()`, `AgentTask::validate()`, and `ScriptedReasoner::review()` beyond the brief's literal field list. These are what make "a proposal must say whether it would change a model", "no path panics" and "a deterministic artifact a test can pin" concrete; the trait signature itself matches the brief exactly.
