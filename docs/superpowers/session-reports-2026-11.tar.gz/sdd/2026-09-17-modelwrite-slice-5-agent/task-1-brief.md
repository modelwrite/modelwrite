## Global Constraints

- Rust stable; the engine crates stay at rust-version 1.75; the server is at 1.88.
- Every source file begins with: // SPDX-License-Identifier: AGPL-3.0-or-later
- Cargo is not on PATH in fresh shells: begin every shell command sequence with $env:Path = "$env:USERPROFILE\\.cargo\\bin;" + $env:Path
- Use --no-fail-fast when running a test suite.
- Stage and commit only the paths a task owns. Never amend or rewrite a commit.
- **AN AGENT IS A CLIENT, NOT A PRIVILEGED PATH.** Every agent action goes through the same handlers, permissions, locks, audit entries and gate as a human's. There is no "agent mode" that skips a check.
- **NO MODEL CHANGE IS COMMITTED BY AN AGENT ALONE.** The agent produces proposals; a human accepts them; the acceptance is recorded. The design says so, and this slice must not quietly relax it.
- **NO NETWORK IN ANY TEST.** The reasoning is a trait; tests use a scripted implementation.
- **ATTRIBUTION IS NOT OPTIONAL.** Every agent action is audited with the agent's identity and the mechanism, and the record says it was an agent, so a reader a year later can tell who decided.

## Task 1: The proposal contract and the scripted reasoner

**Files:** create engine/agent/src/lib.rs (the trait, the proposal types, the review artifact), engine/agent/src/report.rs; modify Cargo.toml; test engine/agent/tests/proposals.rs.

**Interfaces:**
- `pub trait Reasoner { fn propose(&self, task: &AgentTask) -> Result<Vec<Proposal>, AgentError>; }` where `AgentTask` carries the goal, the material (a loss report, a diff, a document excerpt) and the constraints.
- `pub struct Proposal { pub subject: String, pub action: ProposedAction, pub rationale: String, pub confidence: Confidence }` with `ProposedAction::{AcceptLoss, Reject, EditElement, DraftText, NoAction}` and `Confidence::{High, Medium, Low}`.
- `pub struct ReviewArtifact { pub task: AgentTask, pub proposals: Vec<Proposal>, pub agent: String, pub rationale_summary: String }` with `blocking()` and `render_text()` - the thing a human reads.
- `pub struct ScriptedReasoner` for tests.

**Acceptance:** a scripted reasoner's proposals render as a review artifact a human can read; a proposal with LOW confidence is marked for attention rather than buried; the artifact states which proposals CHANGE a model and which do not.

---

