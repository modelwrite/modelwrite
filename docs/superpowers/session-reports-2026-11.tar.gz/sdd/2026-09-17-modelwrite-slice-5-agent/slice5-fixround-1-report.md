# Slice 5 (agent loop) — fix round 1 report

## Status

DONE_WITH_CONCERNS

## Commits

- `7ac1178` fix(agent): an agent proposes and a human commits

## Test summary

`cargo test --workspace --no-fail-fast` — **304 passed, 16 ignored, 0 failed** (the 16 ignored are the PostgreSQL store tests that skip without `MW_TEST_DATABASE_URL`). `cargo fmt --all` clean; `cargo clippy --workspace --all-targets -- -D warnings` clean.

## What the contract now claims (docs/agents/mcp-agent.md)

- An agent may **read** and **propose**. It may **not write**: an agent token cannot hold a write role (`author`) or the `admin` role, and a deployment that configures one is **refused at startup** with a message saying an agent proposes and a human commits (`MW_AUTH_AGENT_ROLES` may hold only `viewer` and/or `reviewer`).
- There is **no automated acceptance path yet** — nothing outside `engine/agent` consumes an agent's proposals — so an agent **cannot cause a model change at all today**.
- A **human** performs the change through the ordinary routes. There is **no review-and-accept workflow to call**; the gate remains the only authority on correctness.
- The MCP tool list and the HTTP surface are both **enforced**: `server/tests/agent_contract.rs` drives the MCP server's own `tools/list` handler and the real router, and asserts the prose contract's tool table matches the manifest.
- The agent loop is explicitly **not wired** (rule 3): `propose_loss_resolutions` has no consumer outside `engine/agent`.

## Findings closed

- **CRITICAL** — make the "no agent commits" claim true where cheap, and state the remaining gap. Enforced at `AuthConfig::agent_token` (now `-> anyhow::Result`): roles `author`/`admin` are refused; `from_env` propagates the error so startup fails. Added a per-write-route denial test (commit, merge, reset, import). Rewrote the contract to say precisely "read and propose, not write, no acceptance path, a human acts through the ordinary routes".
- **IMPORTANT (acceptance key)** — `server/src/binding_api.rs`: `acceptance_matches` now matches only the entry identity; new `resolve_acceptances` resolves the whole blocking set and refuses (400) a legacy raw subject that matches more than one blocking entry. `server/src/ui/import.rs` submits the entry identity as the checkbox value. Added `two_entries_sharing_a_subject_require_the_entry_identity`.
- **IMPORTANT (contract half not enforced)** — `server/tests/agent_contract.rs` now drives the real `mcp::handle_request("tools/list")` and compares names + required arguments, instead of a hardcoded constant. Added `mw-mcp` as a server dev-dependency.
- **M1** — corrected the `entry_identity`/module justification in `engine/agent/src/losses.rs`: the binding emits distinct subjects ("uml:Comment <id>" vs "uml:Comment <id> body"); the identity is DEFENSIVE, not guarding an imminent collision.
- **M2** — reconciled `gate.run`'s arguments in the markdown table (now lists required `reference`, `candidate`; `strictCoverage` is named as optional) and added `the_prose_contract_names_exactly_the_manifest_tools` to make markdown↔manifest drift detectable.
- **M3** — the contract now states the agent loop is not wired.

## Tests changed and why

- `server/tests/agent_audit.rs`: `an_agent_action_is_audited_with_the_agent_mechanism_and_authorizer` and `a_reader_can_tell_an_agent_action_from_a_human_one_from_the_log_alone` encoded the OLD behaviour (an admin agent writing). They are replaced by `an_agent_authenticates_as_a_named_agent_and_can_read` and `an_agent_is_refused_every_model_change` — an agent can no longer write, so an agent-authored audit entry is unreachable today. `an_entry_identity_accepts_exactly_the_entry_it_names` no longer blesses the raw-subject path (`acceptance_matches(&lossy, "uml:Comment c1")` is now asserted false); the ambiguity test is new.
- `server/tests/agent_contract.rs`: `the_manifest_names_only_real_mcp_tools` → `the_manifest_names_exactly_the_mcp_servers_tools` (drives real `tools/list`). `the_agent_mechanism_authenticates_a_named_agent_and_audits_it` → `..._and_lets_it_read` (an agent no longer writes). Added `the_prose_contract_names_exactly_the_manifest_tools`.
- `server/src/auth.rs` unit tests: `agent_token_records_mechanism_agent_and_its_authorizer` role changed `author` → `reviewer` (an agent may no longer hold `author`); added `an_agent_token_refuses_write_or_admin_roles`; `.unwrap()` added where `agent_token` now returns `Result`.
- `server/tests/ui.rs`: the import-form acceptance now submits entry identities ("... [lossy]") and asserts the rendered checkbox `value` is the entry identity.
- `engine/agent/tests/losses.rs`: only a comment correction (the synthetic shared-subject scenario is defensive, not the binding's actual output). No assertion weakened.

## Concerns

1. **Shared files with the concurrent store/API/binding task.** My fixes required editing `server/src/binding_api.rs` (acceptance key) and `server/src/ui/import.rs` (checkbox). Both files were also being edited by the other task (`Box<Commit>`, `ImportProvenance.binding_id`/`binding_version`, the `import_artifact` simplification in binding_api.rs; `commit: *commit` in ui/import.rs). I committed **only my hunks** of those two files (via `git add -p`), leaving the other task's hunks unstaged in the working tree. The other task's changes to binding_api.rs reference `ImportProvenance.binding_id`/`binding_version`, which require their (uncommitted) `server/src/store/*` changes — so the other task must commit store + its binding_api/ui hunks together. The full working tree is green (tests/clippy/fmt), but my commit `7ac1178` deliberately excludes the other task's in-progress work.
2. The 16 ignored tests are PostgreSQL-only and skip without `MW_TEST_DATABASE_URL` (unchanged from baseline).

## Left for a later slice (not this fix round)

- No proposal-to-acceptance flow exists; an agent cannot cause a model change. Wiring `propose_loss_resolutions` into the server is future work, now stated explicitly in the contract rather than implied.
