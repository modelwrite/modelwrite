# SDD ledger - plan: docs/superpowers/plans/2026-09-17-modelwrite-slice-5-agent-loop.md

Working branch: slice-2-repository (pull request #2).

## Why this slice

The mandate: there are not enough engineers who can use MBSE tools, so the tooling must be usable by agents as well as people. Slice 1 shipped an MCP server and a published agent contract; Slices 2-4 gave that agent something worth doing. Slice 4's loss report is the first real job - a migration can produce thousands of lossy and unmappable entries and no human team has time to read them.

## Rulings

Ruling: AN AGENT IS A CLIENT, NEVER A PRIVILEGED PATH. It authenticates with the same tokens, takes the same locks, writes the same audit entries and is refused by the same gate. Cost if wrong: none that is acceptable; an agent-only write path would be a hole in every guarantee the previous slices built.
Ruling: NO MODEL CHANGE IS COMMITTED BY AN AGENT ALONE. The agent proposes, a human accepts, the acceptance is recorded. Cost if wrong: the loop is slower than an autonomous one, which is the point - the design already says a human approves until a reviewed corpus shows the agent's judgement is sound.
Ruling: NO NETWORK IN THE CRATE. The reasoning is a trait, so tests run against a scripted reasoner and the platform never embeds a model provider. Cost if wrong: the live reasoner is a separate process to run, which is also the deployment an organisation can audit.
Ruling: the loss resolver NEVER proposes accepting an Unmappable loss, because there is nothing to map it to, and the review artifact LISTS what the agent does not know. Cost if wrong: the artifact is longer. Benefit: a review that hides its gaps is the failure this whole platform is built against.

## Environment facts

- Baseline: 264 workspace tests passing, 16 ignored locally (the PostgreSQL suite, which CI runs for real), fmt and clippy clean, CI green on four jobs.
- Engine crates are at rust-version 1.75; the server is at 1.88. The agent crate is an ENGINE crate.
- The MCP server and the published agent contract already exist from Slice 1: engine/mcp, docs/agents/mcp-tools.json, docs/agents/mcp-agent.md.

## Progress

Task 1: dispatched

Whole-slice review of Slice 5: NOT READY. One Critical, two Important, four Minor. The engine/agent work is solid and the measurement-boundary correction was NOT regressed - but the slice central safety claim is false as deployed.
CRITICAL: the published contract says no model change is committed by an agent alone, and that is true only of one crate TYPES. engine/agent cannot express a commit; but the SERVER makes the opposite reachable, because an agent token carries whatever roles it is configured with and every write route commits for any caller holding the permission. There is no proposal-to-acceptance flow in the route table at all. THE SLICE OWN TEST IS THE COUNTEREXAMPLE: it grants the agent admin and has it commit directly. A guarantee that lives in one crate types, published as a system property, is the same defect this project has caught repeatedly - a claim outrunning its evidence - and worse here because the claim is about safety.
RULING, in two halves, both required: (a) make it TRUE where that is cheap - an agent identity must not be able to hold write or admin roles, refused at configuration time with a message saying an agent proposes and a human commits, with a denial test per write route; and (b) state the REMAINING GAP precisely - there is still no acceptance flow, so an agent cannot cause a model change at all today, and the contract must say that rather than implying a review workflow that does not exist.
IMPORTANT: the acceptance key still collapses two decisions - the workbench submits the RAW subject as the checkbox value rather than the entry identity, so one tick could accept two entries. Fix: the workbench submits the entry identity, and a raw-subject acceptance is honoured only when it matches exactly one entry and refused as ambiguous otherwise.
IMPORTANT: half the contract is not enforced - the MCP tool names are compared against a hardcoded constant rather than the MCP server own tools/list, so renaming a tool there would not fail the test. Either drive the real handler or say plainly that the MCP list is documented while the HTTP surface is enforced.
MINORS recorded: the justification in engine/agent for entry_identity overstates that the real binding collides (it emits distinct subjects) - the defence is right, the reason is wrong; the markdown route table and the JSON can drift and already disagree about gate.run arguments; and the contract should say plainly that the LOOP IS NOT WIRED, since nothing consumes propose_loss_resolutions outside the crate. Stating a gap is better than letting a reader assume an automation that does not exist.
WHAT THIS MEANS FOR THE MANDATE, stated plainly: the platform can PROPOSE at scale today and cannot yet ACCEPT at scale. Making an agent the author of a change needs the approval flow that records a verified human authorizer, and that is a Slice 6 design decision rather than a bug fix.
