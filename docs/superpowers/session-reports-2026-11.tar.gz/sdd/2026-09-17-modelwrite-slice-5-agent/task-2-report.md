# Task 2 report — The loss-report resolver

## Status

DONE

## Commits

- `92dfd5e` feat: add the loss-report resolver
  - new: engine/agent/src/losses.rs, engine/agent/tests/losses.rs
  - modified: engine/agent/src/lib.rs (public `losses` module; `ReviewArtifact.gaps`), engine/agent/src/report.rs (renders the gaps section), engine/agent/Cargo.toml (mw-binding-xmi dev-dependency), Cargo.lock

## Test summary

`cargo test --workspace --no-fail-fast` → **284 passed, 0 failed, 16 ignored** (the skipped PostgreSQL suite, which CI runs for real).
By crate: agent 14 (8 contract + 6 loss-resolver), binding 6, binding-xmi 18, capi 4, cli 34, gate 5, graph 7, mcp 13, okf 17, server 166, test_support 0.
Baseline was 278 passed; this crate contributes the other 6.

## What was built

- `propose_loss_resolutions(report, reasoner) -> Result<ReviewArtifact, AgentError>` — one proposal per blocking entry, with the rulings enforced whatever the reasoner returns (engine/agent/src/losses.rs).
- `entry_identity(mapping) -> String` — the (subject, verdict) pair rendered as `"subject [verdict]"`, the key every resolution and acceptance must use.
- `ReviewArtifact.gaps: Vec<String>` — the blocking entries the reasoner produced no proposal for, named (never buried) and rendered in their own section.

## The key decisions

- **Keying on (subject, verdict), not subject.** `MappingVerdict` is not `Hash` (it lives in engine/binding, which this task must not touch), so the resolver keys on the encoded entry identity `"subject [verdict]"` rather than a `(String, MappingVerdict)` tuple. The comment in `losses.rs` states why: a single XMI comment can produce a Lossy entry for its dropped id and an Unmappable entry for its dropped body, and a subject-only key would collapse them so an acceptance would accept both.
- **Unmappable is never accepted.** An `AcceptLoss` from the reasoner for an `Unmappable` entry is rewritten to `Reject` with the reason "there is nothing to map this entry to", at Low confidence so the forced override is marked for attention.
- **Lossy acceptance takes the report's own note.** An `AcceptLoss` for a `Lossy` entry keeps the reasoner's confidence but replaces the rationale with the report's `note`, never an invented reason.
- **Model edits are out of mandate.** `EditElement`/`DraftText` change the model; resolving a loss is not editing, so they are recorded as a gap (the reasoner said nothing about resolving the loss).
- **The measurement boundary is carried, not assumed.** `MEASUREMENT_BOUNDARY` is a task constraint and renders into the artifact: the report is the binding's own account, the engine measures only the OKF->XMI->OKF round trip, and the native XMI->OKF read is not independently measured. It stays consistent with the interoperability fix's wording (server/src/binding_api.rs module header, point 3).

## Acceptance evidence (asserted in tests/losses.rs)

- `the_coffee_grinder_six_named_losses_produce_six_proposals` — the real fixture's six named losses produce six proposals, all `AcceptLoss` with rationale equal to the report's note.
- `an_unmappable_entry_is_never_proposed_for_acceptance` — the two Unmappable entries in unknown-element.xmi are `Reject`-with-reason, never accepted; the Lossy model id is accepted with the report's note.
- `the_artifact_names_the_entries_the_reasoner_had_nothing_to_say_about` — a partial script leaves four entries as `gaps`, named in the rendered "WHAT THE AGENT DOES NOT KNOW" section.
- `two_entries_sharing_a_subject_are_two_decisions` — two entries sharing the subject "uml:Comment c1" (one Lossy, one Unmappable) produce two distinct decisions.
- `the_artifact_states_the_measurement_boundary` — the boundary is a task constraint and renders into the artifact.
- `a_lossless_report_produces_no_proposals_and_no_gaps` — an Exact-only report resolves to nothing.

## Verification

- `cargo test --workspace --no-fail-fast` — green (284 passed, 0 failed, 16 ignored).
- `cargo fmt --all` — clean (exit 0).
- `cargo clippy --workspace --all-targets -- -D warnings` — clean (exit 0).
- `cargo +1.75.0 check -p mw-agent --all-targets` — clean (exit 0); the crate inherits `rust-version = "1.75"` and uses no post-1.75 features.

## Concerns

- None blocking. Two notes:
  1. `ReviewArtifact` gained a `gaps` field, a small extension of the Task-1 contract. It is backward compatible — `ScriptedReasoner::review` fills it with an empty vec, and the renderer emits the section only when non-empty, so the Task-1 pinned-artifact test is unchanged — and it is the only honest way to satisfy "the artifact lists what the agent does NOT know".
  2. The proposal `subject` is the entry identity (`"subject [verdict]"`), which disambiguates for a human reader. The server's `acceptLosses` still keys on the binding's own raw subject; reconciling the agent's identity with that acceptance key is Task 3/4 territory and was left untouched.

## Deviation

- The brief does not state a literal commit message; I used the project's conventional-commit style derived from the task title (`feat: add the loss-report resolver`), matching Task 1.
- Beyond the brief's literal "create engine/agent/src/losses.rs", I added `pub mod losses;` and the `gaps` field to `ReviewArtifact` (plus its rendering) and a `mw-binding-xmi` dev-dependency, because the interface must return a `ReviewArtifact` that lists the agent's unknowns, and the acceptance criteria require the real binding fixtures.
