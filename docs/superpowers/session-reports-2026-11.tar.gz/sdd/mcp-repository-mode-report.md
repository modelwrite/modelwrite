# MCP repository mode — report

Status: **DONE**

Commit: `1e70bef` (branch `slice-2-repository`) — "MCP repository mode: read-and-propose tools over the service HTTP API"

## One-line test summary

`cargo test --workspace --no-fail-fast` → **427 passed, 0 failed, 24 ignored** (the 24 are the
PostgreSQL suite in `server/tests/postgres.rs`, which CI runs for real). `cargo fmt --all`
and `cargo clippy --workspace --all-targets -- -D warnings` are both clean.

Per-binary counts (non-zero):

| Crate | Test binaries (passed) | Total |
|-------|------------------------|-------|
| mw-mcp | lib 7, mcp.rs 13, repository.rs 5 | 25 |
| mw-server | lib 18, agent_audit 6, agent_contract 7, analytics_api 6, api 11, audit 12, auth 32, corpus 1, gate_api 7, governance 6, http 4, locks 15, merge 15, merge_api 4, migration 6, proposal 8, provenance 6, store 13, ui 35 | 212 |
| mw-cli | main 23, cli.rs 13 | 36 |
| mw-analytics | compliance 14, confidence 14, cost 21, dataset 21, money 9 | 79 |
| mw-okf | okf_diff 8, okf_validation 9 | 17 |
| mw-agent | losses 6, proposals 8 | 14 |
| mw-binding-xmi | xmi_harness 1, real_world 1, xmi 20 | 22 |
| mw-graph | graph_stats 7 | 7 |
| mw-binding | declaration 1, harness 5 | 6 |
| mw-gate | gate 5 | 5 |
| mw-capi | capi 4 | 4 |

(Plus 24 ignored in mw-server/postgres.)

## What was built

Repository mode in `engine/mcp`: nine `repo.*` tools that reach the running modelwrite
service over its HTTP API, authenticated with a bearer token, plus a pure-std HTTP/1.1 client
(`std::net::TcpStream`) so the engine's declared 1.75 floor stays true. The four
document-level tools are unchanged and remain the no-network default.

### Tool set, and why it is the smallest useful set

The set is one tool per distinct repository action an agent actually performs, nothing
speculative, mapped to the six needs in the brief:

| Tool | Need | Route(s) |
|------|------|----------|
| `repo.projects` | find the model | GET /projects |
| `repo.branches` | find the model | GET /projects/:project/branches |
| `repo.commits` | find the model | GET /projects/:project/commits?branch= |
| `repo.read` | get the thing + provenance | GET /commits/:hash + /commits/:hash/record |
| `repo.importReport` | a migration's loss report + fidelity | GET /import/:artifactHash/report |
| `repo.diff` | diff two revisions + gate verdict/evidence | reads two models, runs the engine gate LOCALLY (never records a run) |
| `repo.audit` | the governance record | GET /projects/:project/audit |
| `repo.checks` | a commit's checks | GET /commits/:hash/checks |
| `repo.propose` | RECORD A PROPOSAL (the agent's real job) | POST /projects/:project/proposals |

`repo.propose` closes the loop built by Slice 5: it POSTs the review artifact as the body
exactly as the acceptance flow persists it, needs the `review` role (which an agent token may
hold), and never writes. `repo.diff` deliberately does NOT call POST /gate (a write); it
reads the two models and runs the same `gate::run`/diff the service uses, returning verdict
and evidence without recording a run.

## How the no-write rule is enforced and proven

1. **No write tool exists.** `repository::run_tool` is the only repository dispatch, and every
   arm issues GET or the single POST /proposals. Proven two ways: a unit test
   (`a_write_attempt_is_refused_and_surfaced_once_not_retried`) and, at the wire level,
   `repository_mode_is_read_and_propose_only_on_the_wire` runs all nine tools against a
   recording transport and asserts the observed requests are all GET except exactly one POST to
   `/projects/coffee/proposals` — no commit/import/gate/merge/reset/lock/accept/refuse.
2. **A write attempt is refused, not retried.** The recording transport returns 403 for a
   write route and the client surfaces it as a tool error containing `HTTP 403` and the
   service's message, with exactly one request observed (no retry, no crash). The agent-token
   write refusal itself is already enforced in `server/tests/agent_audit.rs` and
   `server/tests/proposal.rs`.
3. **The contract enforces it.** `server/tests/agent_contract.rs` gained
   `the_mcp_toolset_is_read_and_propose_only`, which pins the `repo.*` subset against the
   live `tools/list` and asserts the manifest declares `repositoryMode.mode = readAndProposeOnly`.

## How the air gap is preserved

Repository mode is enabled only when BOTH `MW_MCP_SERVICE_URL` and `MW_MCP_TOKEN` are set
and non-empty (a half-configuration is a startup error). With neither set,
`Repository::disabled()` holds no transport and no client, so no socket can be opened; the
dispatcher answers "not configured" before any I/O exists. Proven by
`repository_tools_without_configuration_answer_not_configured_and_make_no_network_call` (the
tool answers "not configured" naming the two variables), and by construction: `TcpTransport`
is only ever constructed inside `configured`/`configured_with_transport`, reachable only
from a present configuration. Tests use an injected transport and a loopback server; no test
dials an external host, so the suite passes with no network.

## The MSRV problem, solved honestly

Option (A) was taken: the HTTP client is pure `std` (`TcpStream` + hand-rolled HTTP/1.1
request/response parsing, including Content-Length and chunked bodies), so no dependency and no
toolchain newer than 1.75 is needed. The engine floor was NOT raised. Verified on the declared
toolchain:

```
cargo +1.75.0 build -p mw-okf -p mw-test-support -p mw-graph -p mw-gate -p mw-binding \
  -p mw-binding-xmi -p mw-agent -p mw-capi -p mw-mcp -p mw-analytics --locked
# -> Finished dev [unoptimized + debuginfo] target(s) in 2.55s   (exit 0)
```

(rustc 1.75.0 / cargo 1.75.0.)

## HOW TO CONNECT YOUR AGENT

Set two environment variables for the MCP server:

| Variable | Meaning |
|----------|---------|
| `MW_MCP_SERVICE_URL` | The running service's base URL, e.g. `http://127.0.0.1:8080` (plain HTTP) |
| `MW_MCP_TOKEN` | The bearer token to present — an agent token (`viewer`/`reviewer`) |

With neither set, `mw-mcp` is a pure document processor and makes no network call. A typical
MCP client configuration:

```json
{
  "mcpServers": {
    "modelwrite": {
      "command": "mw-mcp",
      "env": {
        "MW_MCP_SERVICE_URL": "http://127.0.0.1:8080",
        "MW_MCP_TOKEN": "<the agent token from the service deployment>"
      }
    }
  }
}
```

## Concerns

1. **Plain HTTP only.** The client refuses `https://` (it implements no TLS). The service is a
   plain-HTTP loopback/internal service; an operator who needs transport security must front it
   with a reverse proxy and point `MW_MCP_SERVICE_URL` at the proxy. This is documented, not
   silently downgraded.
2. **Read timeout is fixed** (5s connect / 30s read) and not configurable. Fine for the current
   routes; worth an env var if a future route streams.
3. The manifest's `repositoryHttpSurface.endpoints` was completed (record, checks, artifact,
   proposals, analytics) to match the live router; that broadens what
   `agent_contract.rs` enforces, which is intended but worth a reviewer noting.
