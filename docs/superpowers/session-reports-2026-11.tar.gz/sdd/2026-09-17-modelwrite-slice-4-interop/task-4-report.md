# Task 4 report: The workbench shows a migration

## Status

DONE

## Commits

- `dc5c116` feat: render the migration and its loss report on the workbench

## Test summary

cargo test --workspace --no-fail-fast: 264 passed, 0 failed, 16 ignored (the PostgreSQL suite, which requires MW_TEST_DATABASE_URL). fmt clean; clippy --workspace --all-targets -- -D warnings clean.

Per-binary (non-zero) counts: binding harness 5, binding xmi_harness 1, binding-xmi xmi 15, capi 4, cli (bin) 22, cli 12, gate 5, graph_stats 7, mcp 13, okf_diff 8, okf_validation 9, server lib 14, api 11, audit 12, auth 32, corpus 1, gate_api 4, http 4, locks 15, merge 15, merge_api 4, migration 5, store 12, ui 34. Postgres: 0 passed, 16 ignored.

The four new UI tests (in server/tests/ui.rs) all pass: the_import_page_offers_the_registry_binding, a_lossy_import_shows_its_losses_and_requires_acceptance_before_committing, an_unmapped_import_groups_by_verdict_with_blocking_first, a_viewer_cannot_start_an_import; and the existing unauthenticated test now also covers the import route.

## Self-review

1. **The fixture imports through the page.** a_lossy_import_shows_its_losses_and_requires_acceptance_before_committing posts coffee-grinder.xmi through the form, asserts the refusal page, then posts again with the six named losses accepted, asserts 201 "Import committed", and reads the commit back through the JSON API (exactly one commit landed).
2. **A lossy import SHOWS its losses and requires acceptance before committing.** The refusal page (422, information, not an error page) renders the loss report grouped by verdict with blocking entries first; a subject left unchecked refuses the import. Verified: without acceptance the page is 422 and contains "lossy" (never "lossless") and each subject's name; with acceptance it commits.
3. **The page names what was retained.** Both the refusal and committed pages state "Source artifact retained byte-for-byte, content-addressed as <hash>"; the test asserts the exact blob hash appears. The committed page also names the landing commit hash and links to the model.
4. **A caller without write permission cannot start an import.** a_viewer_cannot_start_an_import asserts a 403 page naming "write permission required". The form's submit is also disabled for non-writers on GET.
5. **The page and the endpoint cannot disagree because they call the same code.** The endpoint's body was extracted into binding_api::import_core (the shared core: retain blob, import, round-trip, record report, refuse unaccepted blocking losses, audit the acceptance, commit through commit_core, attach provenance). Both import_artifact and the page's perform_import resolve identity/permission/scope/author in the same order, then call import_core; the existing migration.rs tests still pass unchanged, proving the endpoint behavior is preserved.

## Concerns

- None blocking. The acceptance control is a set of per-subject checkboxes (indexed accept_loss_ fields); a partial acceptance is carried forward by pre-checking already-accepted boxes so a resubmit cannot lose a prior decision.

## Deviation

- "Paste or upload": the page offers PASTE (a textarea accepting raw text or base64; base64 covers binary source artifacts, matching the endpoint's own decode_artifact). It does not render a <input type=file> multipart upload, because a multipart extractor requires the axum "multipart" feature (the multer dependency), which is not present in Cargo.lock and cannot be fetched offline (no network). The "or" in the brief is therefore satisfied via paste; base64 paste is the documented path for binary sources.
- Commit message: the brief carried no explicit commit message, so I used a conventional commit consistent with the slice's history ("feat: render the migration and its loss report on the workbench").

## Files changed

- Create: server/src/ui/import.rs (the page: form, loss report, acceptance control, retained/lost)
- Modify: server/src/ui/mod.rs (register import), server/src/ui/pages.rs (link on the project page), server/src/lib.rs (routes), server/src/ui/layout.rs (small stylesheet additions), server/src/binding_api.rs (extract import_core/ImportOutcome/ImportCore), server/src/binding_registry.rs (add bindings() list), server/tests/ui.rs (four new tests + import in the unauth list)
