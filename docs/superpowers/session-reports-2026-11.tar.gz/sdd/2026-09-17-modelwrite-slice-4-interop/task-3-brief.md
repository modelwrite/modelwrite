## Global Constraints

- Rust stable; edition 2021. The server crate is at rust-version 1.88; the engine crates are at 1.75 and MUST STAY THERE, because a binding belongs in the engine layer, not the service.
- Every source file begins with: // SPDX-License-Identifier: AGPL-3.0-or-later
- Cargo is not on PATH in fresh shells: begin every shell command sequence with $env:Path = "$env:USERPROFILE\\.cargo\\bin;" + $env:Path
- Use --no-fail-fast when running a test suite.
- Stage and commit only the paths a task owns. Never amend or rewrite a commit.
- **NO MAPPING IS EVER APPLIED SILENTLY.** Every loss is named, with the subject and the reason, before anything is committed. This is the whole point of the slice.
- **THE SOURCE ARTIFACT IS RETAINED BYTE FOR BYTE** and content-addressed before anything else happens, so a migration can never destroy the thing it migrated.
- **FIDELITY IS MEASURED, NOT ASSERTED.** A binding's claim about what it preserves is a corpus plus a report, produced by the existing gate, not a paragraph.
- A binding that cannot export is a VIEWER and must say so in its own metadata, so nobody mistakes reading for migrating.
- No network access in any test.

## Task 3: Migration as a gated operation

**Files:**
- Modify: server/src/api.rs (a migration endpoint) or create server/src/binding_api.rs
- Modify: server/src/lib.rs (the route)
- Test: server/tests/migration.rs

**Interfaces:**
- `POST /projects/:project/import` with `{ "binding": "sysml-v1-xmi@2.4", "branch": "main", "author": "...", "message": "...", "artifact": "<base64 or raw body>" }`:
  1. stores the source artifact as a BLOB first, so it is content-addressed and retained before anything can fail;
  2. imports it, producing a document and a loss report;
  3. runs the ENGINE's fidelity check on the result;
  4. refuses to commit when the loss report has blocking entries, returning them, UNLESS the request carries an explicit acceptance of named losses;
  5. commits on success with provenance recording the artifact hash, the binding id and version, and the accepted losses.
- `GET /projects/:project/import/:artifactHash/report` returns the loss report for a retained artifact.

**Acceptance:** importing the fixture commits and the commit's provenance names the artifact hash and the binding; importing a document with an unmapped element is refused until the request names that loss as accepted, and then the audit entry records that it was accepted; the original artifact is retrievable byte-identical after the import.

---

