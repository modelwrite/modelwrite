## Global Constraints

- Rust stable; edition 2021. The server crate is at rust-version 1.88; the engine crates are at 1.75 and MUST STAY THERE, because a binding belongs in the engine layer, not the service.
- Every source file begins with: // SPDX-License-Identifier: AGPL-3.0-or-later
- Cargo is not on PATH in fresh shells: begin every shell command sequence with $env:Path = "$env:USERPROFILE\\.cargo\\bin;" + $env:Path
- Use --no-fail-fast when running a test suite.
- Stage and commit only the paths a task owns. Never amend or rewrite a commit.
- **NO MAPPING IS EVER APPLIED SILENTLY.** Every loss is named, with the subject and the reason, before anything is committed. This is the whole point of the slice.
- **THE SOURCE ARTIFACT IS RETAINED BYTE FOR BYTE** and content-addressed before anything else happens, so a migration can never destroy the thing it migrated.
- **FIDELITY IS MEASURED, NOT ASSERTED.** A binding's claim about what it preserves is a corpus plus a report, produced by the existing gate, not a paragraph.
- A binding that cannot export is a VIEWER and must say so in its own metadata, so nobody mistakes reading for migrating.
- No network access in any test.

## Task 1: The binding contract and the fidelity harness

**Files:**
- Create: engine/binding/src/lib.rs (the trait and its metadata), engine/binding/src/report.rs (the loss report)
- Modify: Cargo.toml (a new workspace member)
- Test: engine/binding/tests/harness.rs

**Interfaces:**
- `pub struct BindingInfo { pub id: String, pub version: String, pub direction: Direction, pub description: String }` with `Direction::{ImportOnly, ImportAndExport}`.
- `pub enum MappingVerdict { Exact, Lossy, Unmappable }` and `pub struct Mapping { pub subject: String, pub verdict: MappingVerdict, pub note: String }`.
- `pub struct LossReport { pub binding: BindingInfo, pub mappings: Vec<Mapping>, pub artifact_hash: String }` with `is_lossless()` and `blocking()` (the entries a human must decide on).
- `pub trait Binding { fn info(&self) -> BindingInfo; fn import(&self, source: &[u8]) -> Result<(OkfRoot, LossReport), BindingError>; fn export(&self, root: &OkfRoot) -> Result<Vec<u8>, BindingError>; }`
- `pub fn round_trip(binding: &dyn Binding, source: &[u8]) -> Result<FidelityOutcome, BindingError>` where the outcome carries the import loss report AND the engine's own diff between the round-tripped and the original document, so a binding cannot claim fidelity the engine contradicts.

**Acceptance:** a deliberately broken test binding that drops an element on import produces a fidelity outcome whose engine diff names that element; a binding whose metadata claims export but which returns an error from export is rejected by the harness rather than trusted.

---

