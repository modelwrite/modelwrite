# Slice 4 (interoperability) — fix round 1 report

## Status

DONE

## Commits

- `fix(interop): close "the claim exceeds the evidence" Critical + three correctness bugs`

## One-line test summary

`cargo test --workspace --no-fail-fast`: 278 passed, 16 ignored, 0 failed; fmt clean; clippy `-D warnings` clean; `cargo +1.75.0 check -p mw-binding-xmi --all-targets` clean.

## What was measured vs. what was claimed (the Critical)

The slice said "fidelity is measured, not trusted." That was true only of one half. The engine's
`round_trip` feeds a binding its OWN OKF output, exports it to XMI, imports it back, and diffs
that journey against the OKF reference. The native XMI->OKF read — the actual migration — is
covered only by the binding's self-reported loss report and is NOT independently measured. A
silently lossy reader would produce a loss report already missing that loss, and the round trip,
fed the binding's own output, would report equality. The claim has been corrected everywhere it
appeared.

### Claims reworded (and to what)

- `server/src/binding_api.rs` — module-rule 3 was "Fidelity is measured, not trusted: the
  imported document is round-tripped through the binding and diffed by the engine." Now: "The
  one half of fidelity the engine can see is measured, not trusted: the binding's OWN
  OKF->XMI->OKF round trip is diffed by the engine ... the native XMI->OKF read ... is NOT
  independently measured; it rests on the binding's self-reported loss report." The Rule 3
  inline comment and the `import_core` doc say the same.
- `engine/binding/src/lib.rs` — module doc, `Direction` doc, `Binding` trait doc,
  `FidelityOutcome` doc and `round_trip` doc all now state that the harness measures ONLY the
  binding's own OKF->XMI->OKF round trip, and that the XMI->OKF read is the binding's word.
- `server/src/store/mod.rs` — `ImportRecord.fidelity_diff` and the `record_import` doc now
  describe the stored value as "the engine's diff of the binding's own OKF->XMI->OKF round trip",
  and `loss_report` is described as the only account of the native read.
- `server/tests/migration.rs` — module header and the "fidelity measurement" comment now say
  "diffs the binding's OWN OKF->XMI->OKF round trip".
- `engine/binding/tests/xmi_harness.rs` and `engine/binding/tests/harness.rs` — test headers
  and comments now say the harness DIFFS the OKF->XMI->OKF round trip, and that the native
  XMI->OKF read is not exercised there.

### Surfaced to the human on the import page (Critical b)

`server/src/ui/import.rs` now renders a `fidelity-note` on the import form, the refused-import
(acceptance) page, and the committed page: "Fidelity: the engine measured the binding's own
OKF->XMI->OKF round trip and diffed it. The native XMI->OKF read of your artifact is NOT
independently measured - the loss report is the binding's own account of that read."

## Correctness bugs closed

### Important 1 — imports table collided across projects

The `imports` table was keyed on `artifact_hash` alone, so a second project importing the same
content address got a no-op insert and an unretrievable report. The primary key is now
`(project, artifact_hash)` in both backends (`server/src/store/sqlite.rs`,
`server/src/store/postgres.rs`), and `record_import`/ON CONFLICT and `import_report` key on it.
Test: `the_same_artifact_imported_into_two_projects_keeps_a_report_each` (migration.rs) imports
one artifact into two projects and asserts each retrieves its own report.

### Important 2 — provenance was best-effort and could vanish

`attach_import_commit` was a post-commit UPDATE whose failure was logged and swallowed, so a
commit could land permanently unlinked from its source artifact. It is removed. The shared commit
core now takes an `ImportProvenance` (`store::ImportProvenance`), and `commit_model` writes the
import link (`commit_hash` + `accepted_losses`) INSIDE the same transaction as the commit row in
both backends; a missing import record rolls the whole commit back with `NotFound`. This changed
the shared `commit_model` signature (added an 8th `Option<&ImportProvenance>` argument) and
threaded through `commit_core`, all of its callers, and every test call site (mechanical `None`
for non-import commits). Test: `an_import_commit_rolls_back_when_its_import_record_is_missing`
(store.rs).

### Important 3 — the committed model was not the model that was measured

`binding_api.rs` measured a document with `state_machine: None`, then injected an empty state
machine and committed different bytes; `export()` refused any document with a state machine, so
the committed model was outside the subset the binding claimed to round-trip. Now the XMI binding
emits the empty state machine itself on import (`engine/binding-xmi/src/lib.rs`), `export()`
tolerates an EMPTY state machine (still refuses one with states), and `binding_api.rs` commits the
exact `import_bytes` it measured — nothing is mutated after measurement. Tests:
`import_emits_the_empty_state_machine_okf_requires` and
`export_tolerates_an_empty_state_machine_but_refuses_states` (xmi.rs).

### Minor — loss-report subjects were ambiguous

A comment produced a Lossy entry (dropped id) and an Unmappable entry (dropped body) with the
SAME subject `uml:Comment <id>`, so accepting one by subject accepted both. The body-drop
subjects now name what is lost and the target: `uml:Comment <id> body` / `uml:Comment <id> body
(target <target>)`, distinct from the id-drop `uml:Comment <id>`. The import page now renders
each loss with its verdict and note on both the loss report and the acceptance checkboxes.
Tests: `blocking_loss_subjects_are_unique` (xmi.rs) and
`the_import_pages_state_the_fidelity_boundary_and_label_losses` (ui.rs).

## Tests changed, and why

- `engine/binding/tests/xmi_harness.rs` — `subset_document()` now sets `state_machine: Some(empty)`.
  Encodes Important 3: the binding now emits the empty section, so a round-trip reference that
  omitted it would make the engine diff report an extra element the binding itself added.
- `engine/binding-xmi/tests/xmi.rs` — the three comment body-drop assertions' subjects changed
  from `uml:Comment <id>` to `uml:Comment <id> body (target <id>)` (the Minor disambiguation).
- `server/tests/store.rs`, `server/tests/postgres.rs`, `server/tests/ui.rs` — every
  `commit_model(...)` test call gained a trailing `None` for the new `import` parameter
  (mechanical, no assertion weakened).
- `server/tests/migration.rs` — module header and the fidelity comment reworded (no assertion
  change).

## Verification

- `cargo test --workspace --no-fail-fast`: 278 passed, 16 ignored, 0 failed.
- `cargo fmt` (touched packages mw-binding, mw-binding-xmi, mw-server, mw-cli): clean.
- `cargo clippy --workspace --all-targets -- -D warnings`: clean (exit 0).
- `cargo +1.75.0 check -p mw-binding-xmi --all-targets`: clean (exit 0).

Per-binary counts (passed / ignored):

- mw-agent: 8 / 0
- mw-binding: 6 / 0
- mw-binding-xmi: 18 / 0
- mw-capi: 4 / 0
- mw-cli: 34 / 0
- mw-gate: 5 / 0
- mw-graph: 7 / 0
- mw-mcp: 13 / 0
- mw-okf: 17 / 0
- mw-server: 166 / 0
- mw-server (postgres, `#[ignore]`): 0 / 16
- mw-test-support: 0 / 0

## Concerns

- The `imports` table primary-key change is applied to the CREATE TABLE statements but has no
  data migration. The table was introduced in this same slice and has never shipped, so there is
  no released database to migrate; a fresh checkout and every test use the new shape. If a
  pre-release build is ever expected to upgrade in place, a rebuild migration would be needed.
- The Critical (a) rewording is documentation and has no executable assertion (by nature); the
  testable half of the Critical — the import page stating the boundary — is covered by a UI test.
- The shared `commit_model` signature gained an eighth argument; this is the sanctioned change the
  finding called for, but it is a wider-than-usual blast radius for a store method.
