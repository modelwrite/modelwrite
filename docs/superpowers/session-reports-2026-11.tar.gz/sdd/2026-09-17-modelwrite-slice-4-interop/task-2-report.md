# Task 2 report — The SysML v1 XMI reader

## Status

DONE

## Commits

- `b8be6bf` feat: add the SysML v1 XMI binding
  - new: engine/binding-xmi/ (Cargo.toml, src/lib.rs, src/model.rs, tests/xmi.rs, fixtures/)
  - new: engine/binding/tests/xmi_harness.rs
  - modified: Cargo.toml (one new workspace member, one workspace dependency), Cargo.lock, engine/binding/Cargo.toml (a dev-dependency), engine/binding/src/lib.rs (one trait method)

## Test summary

`cargo test --workspace --no-fail-fast` → **245 passed, 0 failed, 16 ignored** (the skipped PostgreSQL suite).
By crate: binding 6 (harness 5 + xmi_harness 1), binding_xmi 5 (new), capi 4, cli 34, gate 5, graph 7, mcp 13, okf 17, server 154, test_support 0.
`cargo fmt --all -- --check` clean; `cargo clippy --workspace --all-targets -- -D warnings` clean; `cargo +1.75.0 check -p mw-binding-xmi --all-targets` clean.

## XML crate

**roxmltree 0.21.1** (declared as `roxmltree = "0.21"` in the workspace). Why:
- Pure Rust, zero-allocation, read-only DOM - the right tool for a reader; I hand-write the (small) exporter rather than pulling a second dependency.
- Declared MSRV 1.60, comfortably under the engine's 1.75 floor; verified by building the crate at Rust 1.75.0.
- Dependency-light: its only dependency is `memchr`, already present in the workspace lock, so no new transitive surface.

## What was built

- `XmiBinding` implementing `Binding` with id `sysml-v1-xmi`, version `2.4`, direction `ImportAndExport` - engine/binding-xmi/src/lib.rs.
- The subset stated as data in `model::mapping_table()`: uml:Package (Lossy, flattened), uml:Class+Block (Exact), uml:Property+aggregation (Exact), uml:Dependency+Satisfy/Allocate/Refine/Verify (Exact), uml:Comment (Exact), xmi:id (Exact).
- Import: XMI → OkfRoot + LossReport. Blocks, properties (with xmi:id→name type resolution), dependency edges (kind "dependency", label = stereotype), comments as documentation, xmi:id as the element id. Every element and attribute outside the subset is an Unmappable mapping naming the XMI element and its xmi:id. A malformed document is a clean BindingError::Import.
- Export: OKF → XMI for the subset, refusing (erroring) on anything it cannot carry, so a round trip can be measured rather than asserted.
- A fidelity-harness test (engine/binding/tests/xmi_harness.rs) runs the real binding through `round_trip`, and the engine's own diff - not the binding's claim - agrees the subset round-trips losslessly.

## Acceptance evidence (engine/binding-xmi/tests/xmi.rs)

- `the_fixture_imports_to_a_hand_checked_document` - the hand-written fixture imports to two blocks whose properties, documentation and Satisfy edge match the hand-checked expectation, and the one loss (the package flattening) is named.
- `an_unknown_element_and_attribute_are_named_not_dropped` - a uml:StateMachine and a `visibility` attribute are reported by name, nothing dropped in silence.
- `a_malformed_document_is_a_clean_error_not_a_panic` - broken XML is a clean Import error.
- `export_round_trips_the_subset` and the harness test prove the subset round-trips without loss.

## Concerns

- OKF has no package/namespace concept, so a package is flattened and its identity is carried as a Lossy mapping (never silent). A model with packages therefore imports non-lossless by design; this is the honest reading of the subset and is documented in the mapping table and the fixture README.
- The export is subset-only: it errors on content outside blocks/properties/dependency-edges rather than silently dropping it. Full vendor-faithful export (diagrams, extensions) is a later tranche per the plan.
- Property type resolution is id→name; a primitive type literal that happens to equal another element's xmi:id would resolve to that element's name. The synthetic fixture avoids the collision and the README states the convention.

## Deviation

- engine/binding/src/lib.rs: added a `mapping_table()` method to the `Binding` trait (defaulted to empty) so the subset-as-data is data the gate can read generically, per design §3/§6. This is the "small addition to the trait" the global constraint anticipates; the brief's literal file list named only engine/binding/Cargo.toml.
- Implemented a subset export and a harness round-trip test in engine/binding, which is what the brief's "Modify: engine/binding/Cargo.toml" is for. The interface requires ImportAndExport, so a claiming-but-failing export would be the lying binding the harness rejects; full export remains a later tranche.
