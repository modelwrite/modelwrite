# Task 1 report — The binding contract and the fidelity harness

## Status

DONE

## Commits

- `edffe28` feat: add the binding contract and the fidelity harness
  - new: engine/binding/src/lib.rs, engine/binding/src/report.rs, engine/binding/tests/harness.rs, engine/binding/Cargo.toml
  - modified: Cargo.toml (one new workspace member), Cargo.lock

## Test summary

`cargo test --workspace --no-fail-fast` → **239 passed, 0 failed, 16 ignored** (the skipped PostgreSQL suite).
By crate: binding 5 (new), capi 4, cli 34, gate 5, graph 7, mcp 13, okf 17, server 154, test_support 0.

The environment's "233 passing" baseline was already 234 when I finished: a concurrent fix commit (`16f0371`, another agent) added one UI test while I was working. My crate contributes the other 5.

## What was built

- `BindingInfo`, `Direction::{ImportOnly, ImportAndExport}`, the `Binding` trait, and `BindingError` — engine/binding/src/lib.rs.
- `MappingVerdict::{Exact, Lossy, Unmappable}`, `Mapping`, and `LossReport` with `is_lossless()` and `blocking()` — engine/binding/src/report.rs.
- `round_trip(binding, source) -> FidelityOutcome`, carrying the source's content address, the import loss report, and the engine's own diff.
- `artifact_hash(bytes)` — sha256 hex, content-addressing the source before anything else happens.

## The harness's key design decision

`round_trip` reads the reference ("the original document") with the ENGINE's own parser — `serde_json::from_slice::<OkfRoot>(source)` — never the binding's `import`. It then exports that reference through the binding, imports the result back, and diffs the two with `okf::diff::diff`. This is what makes the acceptance real: if the binding's `import` silently drops an element, the binding's own reading and the round-tripped reading both miss it, but the engine's reading of the source still has it, so the diff NAMES it. Had the reference been the binding's `import` output, a binding could drop on import and the harness would never see it — which is exactly the "fidelity is measured, not asserted" failure this slice exists to prevent.

## Acceptance evidence (asserted in tests/harness.rs)

- `a_binding_that_drops_an_element_on_import_is_named_by_the_engine_diff` — a binding that drops `LOST_BLOCK` on import produces an outcome whose `diff.missing_elements` contains `structure:LOST_BLOCK` (the engine's diff names the element, independent of the binding's claim). It also asserts the binding's own `loss_report.blocking()` names it, so no mapping is silent.
- `a_binding_that_claims_export_but_fails_is_rejected` — a binding with `direction: ImportAndExport` whose `export` returns an error makes `round_trip` return `BindingError::Export`, never a fabricated lossless outcome.
- `a_lossless_binding_reports_a_lossless_result` — a faithful JSON binding yields `is_lossless()`, an empty `blocking()`, and `diff.equal == true`.
- `a_viewer_is_refused_a_round_trip` — a binding declaring `ImportOnly` is refused with `BindingError::Viewer`.
- `artifact_hash_is_a_stable_content_address` — deterministic, 64 hex chars, differs across inputs.

## Verification

- `cargo test --workspace --no-fail-fast` — green (239 passed, 16 ignored).
- `cargo fmt --all -- --check` — clean.
- `cargo clippy --workspace --all-targets -- -D warnings` — clean.

## Concerns

- `round_trip` requires `source` to be an OKF document (the engine's canonical JSON), because the engine's diff compares two `OkfRoot`s and the reference must be read by the engine, not by the binding under test. This is the intended shape for a fidelity harness that measures a binding's OKF ↔ native ↔ OKF journey. A native-format source (XMI) is what `Binding::import` consumes; task 3's migration endpoint runs the engine's gate on the import result rather than through this harness.

## Deviation

- None in scope. The brief/plan do not state a literal commit message, so I used the project's conventional-commit style derived from the task title. `FidelityOutcome` additionally carries the source's `artifact_hash` (beyond the brief's "loss report plus diff") to make the "content-address before anything else" global constraint concrete in the harness; the metadata types derive `Serialize`/`Deserialize` to match the codebase's evidence serialization, and the small enums derive `Copy`.
