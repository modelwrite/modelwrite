# Task 3 report — Migration as a gated operation

## Status

DONE_WITH_CONCERNS

## Commits

- `44c3f11` feat: make import a gated, measured migration
  - new: server/src/binding_registry.rs, server/src/binding_api.rs, server/tests/migration.rs
  - modified: server/Cargo.toml, server/src/lib.rs, server/src/audit.rs, server/src/store/mod.rs, server/src/store/sqlite.rs, server/src/store/postgres.rs, Cargo.lock

## Test summary

`cargo test --workspace --no-fail-fast` → **250 passed, 0 failed, 16 ignored** (the skipped PostgreSQL suite).
By crate: binding 6 (harness 5 + xmi_harness 1), binding_xmi 5, capi 4, cli 34, gate 5, graph 7, mcp 13, okf 17, server 159 (incl. migration 5), test_support 0.
`cargo fmt --all -- --check` clean; `cargo clippy --workspace --all-targets -- -D warnings` clean.

## What was built

Two endpoints, plus the smallest binding registry and the storage behind them.

- `POST /projects/:project/import` (server/src/binding_api.rs) runs the four rules in order:
  1. `put_blob` stores the source artifact byte-for-byte and content-addresses it BEFORE `binding.import` is called, so nothing that follows can destroy the source.
  2. `binding.import` produces an OKF document and a loss report; `record_import` persists the report and the engine's fidelity measurement keyed by the artifact hash, so a refusal still has a retrievable report.
  3. Fidelity is measured, not trusted: `binding::round_trip` round-trips the imported document and diffs it with the engine's own diff; a non-equal diff refuses the import.
  4. Every blocking (`Lossy`/`Unmappable`) loss must be named in `acceptLosses`, otherwise the import is refused with the blocking entries returned. Acceptance is recorded in the audit trail (`import.accept`, actor = verified subject) BEFORE the commit, so a committed import always has its acceptance on record.
  - The commit then goes through the shared `commit_core` (validation, lock guard, `commit.create` audit), and the import record is linked to the landed commit with the accepted losses.
- `GET /projects/:project/import/:artifactHash/report` returns the loss report and the fidelity measurement for a retained artifact.
- server/src/binding_registry.rs maps a binding id + version to a `Binding` implementation; `sysml-v1-xmi@2.4` is registered. An unknown binding is a 400, never a 500.

## Acceptance evidence (server/tests/migration.rs)

- `importing_the_fixture_commits_with_provenance_and_retains_the_artifact` - the fixture commits, `commit.provenance` names the artifact hash (asserted equal to `blob_hash`), the binding id/version, and the accepted package loss; `store.blob(artifact_hash)` returns the original bytes unchanged.
- `an_unmapped_element_is_refused_until_named_and_then_recorded_in_the_audit` - unknown-element.xmi is refused (422) with the two blocking subjects returned; naming both lets it commit, and an `import.accept` audit entry records the actor and the named losses.
- `an_unknown_binding_is_a_clean_error_not_a_500` - a non-existent binding is a clean 400.
- `the_report_is_retrievable_after_a_refused_import` - a refused import's report is still retrievable by artifact hash.
- `a_base64_artifact_imports_the_same_as_a_raw_body` - both artifact encodings commit to the same artifact hash.

## Concerns

- **State-machine normalization.** The XMI binding's subset has no state-machine concept, so its import emits `stateMachine: None`, but OKF validation requires the section. The import handler adds an empty `stateMachine` before commit (the honest "no states" reading). This means the committed document is the binding's output plus that empty section, and the binding's own exporter (which refuses a present state machine) cannot re-export it - a pre-existing subset limit, not introduced here.
- **Provenance location.** Provenance is NOT a column on the `commits` table, because `commit_model`/`commit_merge` signatures cannot change (cli/src/offline.rs and the store tests call them). It is durable instead in the `imports` table (keyed by artifact hash AND the landed commit hash) plus the `import.accept` audit entry; the response embeds it as `commit.provenance`. A year-later reader reconstructs provenance from either source, but the `commits` row itself has no provenance column.
- **Fidelity is round-trip of the imported OKF.** The engine's harness (`binding::round_trip`) measures OKF→XMI→OKF losslessness; the XMI→OKF losses are the binding's own loss report, gated by the acceptance check. The two together cover the migration, but there is no engine diff against the raw XMI (there is no "reference OKF" for a first import).
- The import produces two audit rows (import.accept then commit.create); a lock-refused import leaves an orphan import.accept entry (harmless - it records that an acceptance was attempted). The import-record-to-commit link is best-effort after the commit (logged, not a 500) to avoid inviting a retry that would commit the same artifact twice.

## Deviation

- server/src/store (mod.rs, sqlite.rs, postgres.rs): added an `imports` table and three `Store` methods (`record_import`, `import_report`, `attach_import_commit`) rather than a `provenance` column on commits, because the `commit_model`/`commit_merge` trait signatures are frozen by cli/ and the store tests. This is the smallest way to make the commit's provenance durable without rewriting a fourth commit sequence.
- server/src/binding_api.rs: adds an empty `stateMachine` to the imported document before commit, as described under Concerns.
