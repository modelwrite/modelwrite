## Global Constraints

- Rust stable; edition 2021. The server crate is at rust-version 1.88; the engine crates are at 1.75 and MUST STAY THERE, because a binding belongs in the engine layer, not the service.
- Every source file begins with: // SPDX-License-Identifier: AGPL-3.0-or-later
- Cargo is not on PATH in fresh shells: begin every shell command sequence with $env:Path = "$env:USERPROFILE\\.cargo\\bin;" + $env:Path
- Use --no-fail-fast when running a test suite.
- Stage and commit only the paths a task owns. Never amend or rewrite a commit.
- **NO MAPPING IS EVER APPLIED SILENTLY.** Every loss is named, with the subject and the reason, before anything is committed. This is the whole point of the slice.
- **THE SOURCE ARTIFACT IS RETAINED BYTE FOR BYTE** and content-addressed before anything else happens, so a migration can never destroy the thing it migrated.
- **FIDELITY IS MEASURED, NOT ASSERTED.** A binding's claim about what it preserves is a corpus plus a report, produced by the existing gate, not a paragraph.
- A binding that cannot export is a VIEWER and must say so in its own metadata, so nobody mistakes reading for migrating.
- No network access in any test.

## Task 4: The workbench shows a migration

**Files:**
- Create: server/src/ui/import.rs
- Modify: server/src/ui/mod.rs, pages.rs, lib.rs
- Test: server/tests/ui.rs

**Interfaces:**
- `GET /ui/projects/:project/import` renders a form to paste or upload an artifact with a binding chosen from the registry, and, after a run, the loss report grouped by verdict with the blocking entries first, each naming its subject, and a control to accept a named loss.
- The page states plainly, in the page and not only in a log, what was retained and what was lost.

**Acceptance:** the fixture imports through the page; a lossy import shows its losses and requires the acceptance before committing; the page never claims a lossless migration the report contradicts.

---

