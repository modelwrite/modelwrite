# SDD ledger - plan: docs/superpowers/plans/2026-09-17-modelwrite-slice-4-interoperability.md

Design: docs/superpowers/specs/2026-09-17-modelwrite-standards-interoperability.md. READ IT FIRST.

Working branch: slice-2-repository (pull request #2).

## Why this slice

An organisation with twenty years of models has not built them in one standard. It has XMI exports from a tool that is no longer supported, requirements in a tool nobody licenses any more, and simulation models only one person can run. The usual answer, convert everything to the new standard, fails because conversion loses things silently, the original disappears, and the standards will change again. The answer here is that OKF is the constant and a standard is a BINDING: a versioned adapter with a conformance corpus, a mapping matrix and a fidelity record.

## Rulings

Ruling: no mapping is ever applied silently. Every loss is named with its subject and its reason before anything is committed, and a lossy migration cannot be committed until the specific loss is accepted by name. Cost if wrong: migrations are slower and noisier than a converter that just runs. Benefit: the difference between a migration somebody can audit and one they must trust.
Ruling: the source artifact is retained BYTE FOR BYTE and content-addressed BEFORE anything else happens, so a migration can never destroy the thing it migrated. Cost if wrong: storage. Benefit: the original question the model answered is still answerable.
Ruling: fidelity is MEASURED, not asserted. A binding's claim about what it preserves is a corpus plus a report produced by the existing gate, never a paragraph. Cost if wrong: nothing.
Ruling: a binding that cannot export declares itself a VIEWER in its own metadata, so nobody mistakes reading for migrating.
Ruling: the first XMI fixture is HAND-WRITTEN and says so in its own README. A synthetic document tests the READER; it is not evidence about any vendor's exporter, and the reports must never imply otherwise. Real vendor XMI needs its own corpus and its own report, which is a later tranche.

## Environment facts

- Baseline: 233 workspace tests passing, 16 ignored locally (the PostgreSQL suite, which CI runs for real), fmt and clippy clean, CI green on four jobs.
- The server crate is at rust-version 1.88; the ENGINE crates are at 1.75 and must stay there. A binding belongs in the engine layer, not the service.
- The gate is the fidelity authority: engine/gate. The diff is engine/okf/src/diff.rs. Neither is modified by this slice.

## Progress

Task 1: dispatched

Whole-slice review of Slice 4: MERGEABLE, but NOT complete on its own strongest claim. One Critical, four Important, four Minor.
CRITICAL, AND IT IS EXACTLY WHAT THE REVIEW WAS ASKED TO HUNT FOR: the slice says fidelity is MEASURED, NOT TRUSTED, and for a migration it is not. The import path calls round_trip with the BINDING OWN OUTPUT as the reference - round_trip structurally requires an OKF document - so what is measured is the binding OKF->XMI->OKF internal consistency, NOT whether the ORIGINAL artifact survived into OKF. The direction where real loss happens is the only one the engine cannot see: a reader that silently drops a vendor element produces a loss report already missing that loss, and the round-trip, fed the binding own output, reports equality. The engine certifies a document it never compared against the original.
Controller ruling: the DURABLE fix - a golden corpus per binding, measuring the reader on the native side - is a later tranche and the fixture README already says so. What must happen NOW is that THE CLAIM STOPS OUTRUNNING THE EVIDENCE. Every comment, doc and test header that says fidelity is measured must be reworded to say exactly what is measured and which half rests on the binding own report, and the human accepting a loss on the import page must be TOLD which half was measured and which half is the binding word. A limitation a customer can read is worth more than a claim they cannot check.
IMPORTANT 1: the imports table is keyed on artifact_hash ALONE, and a content address is global - so a second project importing the same artifact no-ops, its link update matches nothing, the error is swallowed, and that project commit lands with NO RETRIEVABLE LOSS REPORT. Fix: key on (project, artifact_hash) in both backends.
IMPORTANT 2: provenance is a best-effort post-commit UPDATE whose failure is swallowed, and the commit row carries none of it. A failed link leaves a commit permanently untraceable to its source artifact and its accepted losses. Ruling: provenance must be written in the SAME TRANSACTION as the commit. Governance will need exactly that answer a year from now.
IMPORTANT 3: the committed model is NOT the model that was measured - an empty state machine is injected after the round trip so validation passes - and the binding export then REFUSES the very document it produced. Ruling: the binding must emit what OKF requires of its own output, so the measured document IS the committed document.
IMPORTANT 4 (accepted as an inherent boundary, for Slice 6): the four rules hold on the IMPORT path, not on every path. A document converted outside the tool and committed through the plain commit path lands with no loss report and no marker. The honest statement is therefore that the rules hold on the migration path. Whether a commit needs a durable migration marker to make them repository-wide is a governance decision.
MINOR, fixed because it makes a human decision ambiguous: loss-report subjects are NOT unique - one comment yields a Lossy id entry AND an Unmappable body entry with the same subject - so accepting one accepts both, and a person cannot accept losing an id while refusing to lose the body.
Deferred with reasons: the mapping_table is currently dead data whose doc overstates it (reconcile or correct it in Slice 6); the import page does not render the engine fidelity result (being fixed as part of the Critical, since the claim and the surface go together); the BINDING_VERSION doc misattributes 2.4 to SysML v1 when it is the UML/XMI metamodel version (a doc fix, recorded).
ALSO WORTH RECORDING: the reviewer corrected the attribution of the earlier commit - the Binding trait and the silent-dropper harness proof were already at the base, and this slice additions to engine/binding were small. An accurate account of what a slice built is part of what a review is for.
