## Global Constraints

- Rust stable; edition 2021. The server crate is at rust-version 1.88; the engine crates are at 1.75 and MUST STAY THERE, because a binding belongs in the engine layer, not the service.
- Every source file begins with: // SPDX-License-Identifier: AGPL-3.0-or-later
- Cargo is not on PATH in fresh shells: begin every shell command sequence with $env:Path = "$env:USERPROFILE\\.cargo\\bin;" + $env:Path
- Use --no-fail-fast when running a test suite.
- Stage and commit only the paths a task owns. Never amend or rewrite a commit.
- **NO MAPPING IS EVER APPLIED SILENTLY.** Every loss is named, with the subject and the reason, before anything is committed. This is the whole point of the slice.
- **THE SOURCE ARTIFACT IS RETAINED BYTE FOR BYTE** and content-addressed before anything else happens, so a migration can never destroy the thing it migrated.
- **FIDELITY IS MEASURED, NOT ASSERTED.** A binding's claim about what it preserves is a corpus plus a report, produced by the existing gate, not a paragraph.
- A binding that cannot export is a VIEWER and must say so in its own metadata, so nobody mistakes reading for migrating.
- No network access in any test.

## Task 2: The SysML v1 XMI reader

**Files:**
- Create: engine/binding-xmi/src/lib.rs, engine/binding-xmi/src/model.rs (the subset it understands)
- Modify: Cargo.toml, engine/binding/Cargo.toml
- Test: engine/binding-xmi/tests/xmi.rs, fixtures under engine/binding-xmi/fixtures/

**Interfaces:**
- `pub struct XmiBinding` implementing `Binding` with id `sysml-v1-xmi`, version `2.4`, direction ImportAndExport.
- The subset it understands, stated as data in its mapping table: UML/SysML `packagedElement` of type `uml:Package`, `uml:Class` with the `Block` stereotype, `uml:Property` with an aggregation, `uml:Dependency` with the `Satisfy`/`Allocate`/`Refine`/`Verify` stereotypes, `uml:Comment` as documentation, and xmi:id as the element id.
- EVERYTHING ELSE is reported: unmapped elements and attributes are recorded as Unmappable mappings with the XMI element name and xmi:id, never dropped in silence.

**Rulings that shape this task:**
- The fixture is HAND-WRITTEN and says so. A synthetic XMI document exercising these structures is a test of the READER, not evidence about any vendor's exporter. Real vendor XMI needs its own corpus and its own report, and pretending otherwise would be the exact dishonesty the slice exists to prevent.
- Unknown elements are reported, not skipped.

**Acceptance:** the fixture imports to an OKF document whose blocks, properties and dependency edges match a hand-checked expectation; an unknown XMI element in the fixture produces an Unmappable entry naming it; a malformed document is a clean error, never a panic.

---

