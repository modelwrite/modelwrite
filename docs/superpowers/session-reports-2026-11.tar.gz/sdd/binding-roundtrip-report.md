# Binding round-trip report: export carries association/part/reference edges

status: DONE_WITH_CONCERNS

## Commits

`693d60f` — binding-xmi: export carries association/part/reference edges; real model round-trips

## One-line test summary

498 passed, 0 failed, 24 ignored (PostgreSQL suite) across the workspace; `cargo clippy -p mw-binding-xmi --all-targets -- -D warnings` clean; `cargo fmt --all` clean.

## Before / after totals

- Content losses (Unmappable): **124 → 124** (unchanged — see GAP 2).
- Import counts (real MagicDraw model): **41 blocks / 25 requirements / 66 graph nodes / 95 graph edges → unchanged**.
- Round-trip over the real model: **REFUSED (`BindingError::Export` "only dependency edges are in the subset") → EXACT (`diff.equal`, 0 missing/extra elements, 0 missing/extra edges, 0 changed attributes)**.

## GAP 1 — export now emits the association/part/reference edges it imports

The import tranche (commit `0d1b2ab`) carried association (28), part (34 = 28 PartProperty + 6 ports) and reference (5) edges on IMPORT, but `export_document` still rejected every edge whose `kind != "dependency"`, so an imported-then-exported real model no longer round-tripped. That refusal is removed:

- **association edges** are emitted as a self-contained `uml:Association` with two `memberEnd` idrefs plus two `ownedEnd` properties typed by the edge's source and target. This sidesteps the earlier "graph reduction cannot rebuild the association+part pair" concern: the association no longer depends on any pre-existing property id — the member ends are re-declared inline, so re-import rebuilds source = type(memberEnd[0]), target = type(memberEnd[1]) — the golden corpus direction.
- **part/reference edges** are rebuilt by marking the source block's attribute (matched on (owner, resolved type)) with a `PartProperty`/`ReferenceProperty` stereotype application. The OKF `Attribute` carries no stereotype, so the graph edge is the only source of truth; matching on (owner, type) is exact because the model has no duplicate element names (verified) and every part/reference edge has a matching attribute (verified).
- A part/reference edge that cannot be matched to any attribute is REFUSED (`BindingError::Export`), never silently dropped — the same "refuse rather than normalise" rule as the other out-of-subset refusals.

The engine's own diff (via `binding::round_trip`) over the real MagicDraw model is the arbiter, and it now reports `equal == true`. Pinned by `association_part_and_port_edges_round_trip_through_export` (fixture), `the_real_magicdraw_model_round_trips_through_the_harness` (real model), and `export_refuses_a_part_edge_with_no_matching_attribute`.

## GAP 2 — the remaining loss classes

The audit's 124 content losses break into two groups:

- **"Honest-slot" classes: 51 `visibility` + 8 port attributes (6 visibility + 2 isConjugated) + 5 `FlowProperty` direction = 64.** These have NO OKF slot to carry them: `okf::types::Attribute` is `{name, type, aggregation, default}`, `GraphEdge` is `{source, target, kind, label}` — no visibility, isConjugated or direction field anywhere in `engine/okf`. The concurrent task that owns `engine/okf` landed `SubsystemReference.bounds` (the S0 subsystem-reference primitive), NOT these fields. I was forbidden from touching `engine/okf`, so these remain NAMED losses (`Unmappable`) rather than being carried — nothing is dropped in silence.
- **Out-of-scope surface: 60** (5 Actor/UseCase associations, 9 uml:Signal, 6 SignalEvent, 5 Connector, 5 UseCase, 5 useCase, 3 Activity, 3 TimeEvent, 2 Actor, 2 Operation, 3 DataType, 3 ValueType, 3 classifierBehavior, 1 Constraint, 1 StateMachine, 1 Dependency, 1 Comment, 2 client/supplier). These stay NAMED, as required.

The loss count is therefore unchanged (124 → 124): the number is not made smaller by hiding anything. Carrying the 64 honest-slot losses is blocked on `engine/okf` gaining the three fields, which is the concurrent task's call.

## Concerns

1. **GAP 2 "carry" is not achievable from `engine/binding-xmi` alone.** The three classes the brief names as "honest OKF slot" (visibility, port visibility/isConjugated, flow direction) have no such slot in the current `engine/okf`, and I am barred from adding one ("do not touch engine/okf"). They remain NAMED losses; the loss count is unchanged at 124. To actually carry them, `engine/okf` must gain the fields, and then `binding-xmi` consumes them. (I recommend this be re-opened as a follow-up once the okf owner lands those fields.)
2. **The previous tranche's export concern is now closed.** `loss-reduction-report.md` concern #1 ("the graph reduction loses the property id/name needed to reconstruct a faithful uml:Association + PartProperty pair, so I did not attempt a lossy reconstruction") is resolved WITHOUT a lossy reconstruction: associations are re-declared self-contained, and part/reference edges are matched back to attributes by (owner, type), so the real model round-trips exactly.
3. **Concurrent workspace movement.** The concurrent task landed two commits during this session (`492020f` assist ids, `b598867` compositional gate S1); my commit `693d60f` sits on top of them and touches only `engine/binding-xmi`. The workspace is green after all three.
