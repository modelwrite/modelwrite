# Gen-AI Assist Loop

## Status

DONE_WITH_CONCERNS

## Commits

- `edf7ba6` — "feat(assist): build the gen-ai assist loop for model changes" (15 files: server/ only). Landed on `slice-2-repository`, the workspace's active branch.

## Test summary

`cargo test --workspace --no-fail-fast`: **457 passed, 0 failed, 24 ignored** (the PostgreSQL suite, skipped because MW_TEST_DATABASE_URL is unset). `cargo fmt --all`: clean. `cargo clippy --workspace --all-targets -- -D warnings`: clean.

New/affected tests:

- `server/tests/proposal_assist.rs` (new): 4 passed — scripted assist produces a review artifact AND writes no commit; a human accepts a model change and the commit's provenance names both parties; an invalid model change is refused with the validator's own errors; the proposals list is newest-first with decisions.
- `server/src/assist.rs` (unit tests): reasoner selection (no key -> 503 "no live reasoner configured", key -> live, scripted mode -> scripted, unknown mode -> 400), change-shape validation, and malformed-live-JSON refusal.
- `server/tests/proposal.rs` (existing, unchanged): 8 passed — the import-scoped acceptance flow still works.
- `server/tests/governance.rs`, `server/src/ui/create.rs`, `server/src/ui/edit.rs`, `server/src/binding_api.rs`: only the `acceptance: None` field added to existing `CommitCore` literals.

## User flow (request -> review -> accept -> commit)

1. **Request** — `POST /projects/:project/assist` with `{ request, branch }`. The server loads the branch tip model and runs a Reasoner (scripted in test mode, live behind a key). The result is a persisted, id-addressed PROPOSAL — never a commit. The proposal's agent is the reasoner (`scripted-assist` / `mw-assist`), and the audit actor is the requesting human.
2. **Review** — the response IS a `ReviewArtifact` (the existing shape): `task.goal` (the request), `task.material.Document` (the full candidate document — exactly what acceptance will apply), and one `Proposal` per change (subject = element/requirement id, action = EditElement/DraftText, rationale, confidence). `GET /projects/:project/proposals` lists them newest-first with decisions.
3. **Accept** — a human with Write posts `/projects/:project/proposals/:id/accept` (`acceptedItems` optional; empty = accept all). The acceptance extracts the candidate document from the SAME artifact the human read and commits it through `commit_core`, so it passes the SAME validator every commit passes. An invalid candidate is refused 422 with the validator's own errors.
4. **Commit** — the commit's provenance is `Accepted { proposalId, agent, acceptedBy, acceptedItems }`, written in the SAME store transaction as the commit row and the proposal's decided/decided-by/commit columns. An agent never commits: the acceptance requires Write (an agent token holds only read/review), and the commit path substantiates the proposal again inside its transaction.

## Live-key behaviour

- `MW_ANTHROPIC_API_KEY` present (env only, never logged, never in a request, never committed): the assist endpoint uses the LIVE reasoner — an Anthropic Messages API call (no provider SDK embedded; plain HTTPS via the minimal `ureq` client) demanding a strict JSON shape that maps onto `ProposedAction`, then validates the answer against the proposal types and REFUSES malformed output by name.
- Key absent: the assist endpoint returns **503 "no live reasoner configured"**, pointing at `MW_ASSIST_REASONER=scripted` (the deterministic, no-network test mode).
- Model name overridable via `MW_ANTHROPIC_MODEL` (default `claude-sonnet-4-20250514`).
- The live reasoner is never called from a test: every test uses the scripted reasoner, so no test makes a network call.

## Concerns

- **UI split.** The task brief's part A ("assist panel") and part C ("proposals page" HTML) are owned by the concurrent UI-uplift task (`server/src/ui/`). I built the API surface they render against — `POST /projects/:project/assist`, `GET /projects/:project/proposals`, and the extended accept/refuse endpoints — plus the store machinery, but no HTML page or panel. I did not touch `server/src/ui/` except the two mechanical `acceptance: None` lines forced by the `CommitCore` field addition.
- **Whole-proposal acceptance.** A model-change proposal is accepted as a whole: the candidate document (all proposed changes) is committed, and `acceptedItems` must name every proposed change (or be empty = accept all). There is no per-change partial acceptance, which keeps the provenance honest (acceptedItems == what the commit applies) but is less granular than the import flow's per-loss acceptance.
- **New dependency.** `ureq` (blocking HTTP, rustls) was added to `server/Cargo.toml` solely for the live reasoner's HTTPS call. It is minimal and TLS-verified, but it is a new dependency.
- **Live reasoner untested end-to-end** (correctly — the brief forbids calling it from tests). Its JSON validation is covered by the `parse_and_validate` unit test; the HTTP call itself is exercised only in a deployment that sets a key.
- `MW_ASSIST_REASONER=scripted` is a debug/test hook read from the environment; it is deliberately separate from `MW_ANTHROPIC_API_KEY` so a test can never accidentally reach the network.
