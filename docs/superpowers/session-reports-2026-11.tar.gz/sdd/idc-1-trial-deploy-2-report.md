# idc-1 trial deploy (2) — final report

**Status:** DONE_WITH_CONCERNS

## Contract
- **Port:** `127.0.0.1:3102` (loopback only; 80xx model-fleet range untouched)
- **Public hostname:** `trial.modelwrite.org` (moved to idc-1 — Decision 1)
- **Token:** `71e6652c4980128f654b957fb40fb275b5ae02096253727f3f3ea5e14ef90267`
  (only in `/opt/modelwrite/deploy/modelwrite.env` [600] and this report; never in a repo)
- **Commit built from:** `d66261e8483a98f64322aab1236d7afe5ea41519`
- **Image:** `modelwrite/modelwrite:idc-1-trial` (id `7f429a4147a2`)
- **Units:** `modelwrite.service` (active) · `modelwrite-trial-reset.service` + `.timer` (enabled)

## Decision 1 — trial.modelwrite.org moved to idc-1 (DONE, verified)
- idc-1 `/etc/cloudflared/hatch-config.yml` gained (backed up first; `cloudflared tunnel ingress validate` = OK):
  ```yaml
  - hostname: trial.modelwrite.org
    service: http://localhost:3102
  ```
- DNS: the `trial.modelwrite.org` CNAME now targets
  `895153ce-0e3a-44dd-ae05-d2546302cdcb.cfargotunnel.com` (idc-1's hatch tunnel; proxied). The
  write token `cfut_…` in `insights-oaic-poc/.env` has `#dns_records:edit`; the change was
  applied (record id `e37c08aa…`).
- `cloudflared-hatch.service` reloaded; workstation tunnel stopped and its
  `~/.cloudflared/modelwrite-trial.yml` no longer claims the hostname.
- **Third-place proof** (from the workstation, not localhost):
  ```
  $ curl -sS https://trial.modelwrite.org/health
  {"authMode":"static","status":"ok"}
  $ curl -sS https://trial.modelwrite.org/projects -H "Authorization: Bearer <token>"
  [ ... six models: cafe-stand, coffee-machine, floor-robot, microduck, purchasing-terminal, sandwich-toaster ]
  $ curl -sS -o /dev/null -w "%{http_code}" https://trial.modelwrite.org/projects
  401
  ```
  `authMode=static` (vs the local 8080 trial's `open`) and the six-model list (vs the local
  8080's nine-project list) prove it is idc-1, not the workstation's 8080 server (which was
  left running/unchanged).

## Decision 2 — nightly sandbox reset (DONE, tested twice)
- **Seed (outside the live DB), versioned + reproducible:** `/opt/modelwrite/seed/`
  - `manifest.json` + `documents/` — canonical capture with expected commit hashes
    (regenerate: `capture-seed.py`; replay: `seed-from-manifest.py`).
  - `models/` + `seed.mjs` — rebuilds the SAME six models (identical commit hashes) from a
    fresh checkout's `e2e/models` + `sample/corpus`. Verified: reproduced
    `8e373a72…`, `dd905e70…`, `33e1914b…` etc. exactly.
- **Reset:** `modelwrite-trial-reset.service` (Type=oneshot) → `/opt/modelwrite/deploy/reset-trial.sh`;
  `modelwrite-trial-reset.timer` `OnCalendar=*-*-* 18:00:00` (18:00 UTC = 04:00 Sydney, quiet),
  `Persistent=true`, enabled (next run listed).
  The script: stops the service → backs up to `/opt/modelwrite/backups/<date>.db` (keeps 7) →
  rebuilds a FRESH DB by replaying the manifest into a throwaway seed container (verifying every
  commit hash + cafe-stand references resolve) → swaps it in → restarts → logs. On failure the
  service is restarted on the last good DB. CPU-trivial (no build).
- **Backups:** `/opt/modelwrite/backups/2026-09-20.db` exists; bounded to 7.
- **Idempotency proven:** ran the reset twice (direct + via systemd); both produced the same
  six-model state; service stayed active.

## Documentation
- `/opt/modelwrite/README.md` (host) — service, seed, reset, ingress, browser note, per-user note.
- `/opt/modelwrite/seed/README.md` — canonical capture vs repo-reproducible seed, verification.
- `docs/deploy/idc-1-trial.md` committed (`83b31e9`) — full deployment record.

## Concerns
1. **Concurrent work overlap.** A parallel agent/process was acting on the same brief while I
   was (it did the idc-1 ingress + DNS + reload, and wrote `capture-seed.py`/`seed-from-manifest.py`/
   `reset-trial.sh`). I adopted its more-complete reset script (rebuild-from-manifest with hash
   verification) as canonical, wired it to the systemd units, removed my redundant
   `modelwrite-trial-reset.sh` + `baseline.db`, and verified the converged state. End state is
   coherent; transient churn (a brief service restart, a `manifest.json.hold` rename) settled.
2. **Built from d66261e (S2), not the v0.2.0 tag** — required by the crossModelEdges seed/verify spec.
3. **Repo doc committed locally** (`83b31e9` on `slice-2-repository`), not pushed — the branch is
   under active concurrent work (HEAD moved `d66261e` → `ece7092` mid-task); owner should push/merge.
4. **No browser login form** — a visitor must send `Authorization: Bearer <token>` (curl/extension,
   or Cloudflare Access in front of the hostname).
5. **Backups are date-only** (`<date>.db`), so a same-day re-run overwrites that day's backup.
