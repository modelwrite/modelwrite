# Edge Routing — Engineering Standard

## Status
DONE_WITH_CONCERNS

## Commits
- `ad68d84` engine: deterministic orthogonal edge routing (anchors, trunks, lanes, jumps)

## One-line test summary
Full Rust workspace green (fmt + clippy `-D warnings` clean), 11 new geometry assertions pass over both the cafe-stand process and 99-node structure diagrams, and all 27 Playwright tests pass.

## What the routing does now
`engine/graph/src/routing.rs` gained a graph-level router `route_graph`, and `server/src/ui/diagram.rs` renders through it:

- **Orthogonal (Manhattan) routing** — every node-to-node edge is an axis-aligned polyline that leaves one side anchor and lands on a facing side anchor; no arbitrary diagonals.
- **Anchor discipline** — edges touching a side are spread across it (ordered by the far endpoint's perpendicular position, tie-broken by draw index), so no two edges leave a source from the same point and no two arrowheads land on the same corner.
- **Shared trunks for fan-out** — horizontal edges leaving one source toward one target column share a single trunk x; they branch at right angles to their targets, which removes the self-crossing fan.
- **Node avoidance** — a trunk is used only when its vertical line is clear of every node box (with a 4px clearance, not the loose 0.5px tolerance); otherwise the edge falls back to the existing channel/detour router, so no segment ever passes through a box.
- **Separate lanes** — dependency (Satisfy) edges travel their own band (a different trunk offset) and stay dashed, never on the flow trunk.
- **Crossing jumps** — every proper crossing is detected, and the later-drawn edge is drawn with a small arc (a quadratic-bezier bump) at the crossing, so a crossing can never be mistaken for a junction.

## Per-defect outcome
1. **FAN-OUT CROSSES ITSELF** — CLOSED. The three flow edges from Take Payment now leave at distinct anchors (y 107/116/134) and share trunk x=262.4, so they no longer cross.
2. **ARROWHEADS CONVERGE ON CORNERS** — CLOSED. Spread anchors put distinct arrival points on a side (e.g. Complete Order receives at y 106/116/126; Provision Beverage at y 47/57).
3. **CROSSINGS ARE AMBIGUOUS** — CLOSED. Crossings are now rare after the trunk change (3 remain in the process diagram) and every remaining crossing carries a jump arc.
4. **Satisfy edges indistinguishable / same lanes** — CLOSED. Dependency edges take their own lane (trunk x=282.4 vs flow x=262.4) and are dashed.
5. **Long Satisfy edges visually equal flow edges** — CLOSED by the same separate-lane + dashed treatment.

## Concerns
- **Visual check not performed by me**: this model (deepseek-v4-pro) has no image input, so `read_image` on the screenshot is rejected. I did not visually inspect the result; I relied on the geometry assertions, which are the strong guarantee here (no segment crosses a box, distinct source anchors, arrowheads on borders, crossings marked, determinism).
- **Structure-diagram jump density**: the 99-node structure layout has many inherent multi-column crossings (442 detected), each now marked with a jump arc. This is correct but may read as visually busy; it is a property of the layered containment/traceability layout, not the routing.
- One residual class of crossing remains in the process diagram: a flow edge and its own parallel Satisfy edge to the same target cross (3 total), each jump-marked. Fully separating those would need edge-aware lane ordering, which is beyond the trunk change.
