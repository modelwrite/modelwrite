# Branding report — Modelwrite visual identity

## Status

DONE_WITH_CONCERNS

## Commits

- `13f8ce7` — feat(website): new visual identity - draughting/blueprint applied
  - `website/brand.html` (new), `website/favicon.svg` (new), `website/index.html` (mark + favicon), `website/styles.css` (palette + restyle)
  - pushed to `slice-2-repository` (6cb27f5..13f8ce7)
  - advanced `main` (1c52742..13f8ce7) — site goes live at modelwrite.org

## The four directions (one line each)

1. **Draughting / Blueprint** — ink-on-paper, a sheet-corner mark with a verified tick, monospace identifiers + clean sans prose, one green signal.
2. **Institutional / Assured** — deep navy + bone, a double-ruled seal, wide-tracked caps, generous space, brass hairline accent.
3. **Analytics / Instrument** — cool neutral field, a mark built from graph notation (nodes + edges + terminal), single amber for basis/caveat.
4. **Mark-first / Bold** — high-contrast black/white, a block-and-slash mark that survives a browser tab, wordmark secondary.

## Chosen: Draughting / Blueprint — why

It is the one direction that speaks the audience's native visual language: the
engineering drawing — line weights, a sheet corner, a datum, a verified tick.
The systems engineer and the sign-off manager read drawings all day; ink on
paper with one reserved green reads as precise and unadorned, and it is the
furthest thing from the generic-blue instrument look the owner rejected. It
also maps cleanly onto what the product already is: monospace carries the
identifiers, commands and hashes; the single green reserves colour for exactly
the verified/pass states, so colour stays earned by evidence, not decoration.

## Palette (applied) with measured WCAG contrast

Ink-on-paper, one green signal. Body text and every text/background pair pass AA (≥ 4.5:1).

| Role | Hex | Pair | Ratio |
|------|-----|------|-------|
| paper (bg) | #faf7ef | — | — |
| ink (body text) | #1b1813 | ink on paper | 16.53 |
| ink-soft (secondary) | #3f392e | on paper | 10.68 |
| muted (labels) | #6b6353 | on paper | 5.55 |
| line / line-strong | #d8d1c0 / #b4ab96 | borders | — |
| panel / panel-2 | #f1ede0 / #e7e2d0 | surfaces | — |
| signal (accent/links) | #175e3e | on paper | 7.25 |
| accent-deep (hover) | #103f2a | on paper | 11.10 |
| pass / pass-ink | #175e3e / #12472f | pass-ink on paper | 9.97 |
| fail / fail-ink | #a5231c / #7e1d16 | fail-ink on paper | 9.46 |
| warn | #7d5400 | warn on paper | 6.25 |

Primary buttons are ink-filled (paper text, 16.53:1); links and the verified/active
states are the single green signal; fail stays red and warn stays amber, both tuned
to the paper. Lowest body-text pair is muted at 5.55:1 — still AA.

## Verification (measurement, not screenshots)

- Computed styles confirmed via Playwright: body bg #faf7ef, body text #1b1813,
  masthead rgba(250,247,239,0.94), button ink-filled, tagline ink, nav links ink-soft,
  wordmark = system sans @ 650, pass #12472f, fail #7e1d16.
- Mark renders at 16 / 32 / 120 px on the exploration page (all four directions),
  and at 20 px (masthead) + 56 px (hero) on the site. Bracket stroke = ink #1b1813,
  tick stroke = signal #175e3e, stroke-width 3 in a 32 viewBox (1.5 px at 16 px).
- Diagram fragment: 3 boxes + 2 arrows + 1 requirement parallelogram + 1 orphan with
  a marker, present in all four directions.
- Network capture: 0 external requests (air-gapped, self-contained).
- All marks hand-drawn; no licensed path data, so NOTICE.md needs no addition.

## Concerns

1. **No visual verification possible.** deepseek-v4-pro has no image input, so the
   screenshots could not be inspected. Everything was verified by measurement instead:
   computed styles, SVG geometry, WCAG ratios, and a zero-external-request network capture.
2. **16 px mark stroke is 1.5 px** (stroke-width 3 in a 32-unit viewBox). It is a simple
   high-contrast corner-and-tick, judged legible by geometry and contrast, but not
   visually confirmed at that size.
3. **Advancing main carried forward 3 pre-existing slice-2 commits** (registered trials,
   analytics CLI/MCP transports, deploy docs) that were already ahead of main. Expected
   per the "advance main" instruction, but main now includes non-website work too.

## What the owner should look at

- Applied site: https://modelwrite.org/
- Exploration page (compare the other three): https://modelwrite.org/brand.html
