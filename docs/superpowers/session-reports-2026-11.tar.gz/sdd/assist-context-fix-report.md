# Assist context fix: compact model inventory

## Status
DONE_WITH_CONCERNS

## Commits
- 4737a90 assist: send a compact model inventory, not the full document

## Test summary
`cargo test --workspace --no-fail-fast` all green (postgres suite skipped, requires
MW_TEST_DATABASE_URL); `cargo fmt --all` clean; `cargo clippy --workspace --all-targets -- -D warnings` clean.

## What changed
`server/src/assist.rs` `user_prompt()` now sends a compact model inventory instead of the full
document: per structure element id/name/kind/stereotypes, per requirement id/name/reqId, per
interface and signal id/name, plus the graph node/edge counts. No documentation bodies, no
attributes, no edge endpoints, no provenance. `call_openai` adds `max_tokens: 2048` and keeps
`response_format: json_object`.

## Live result (fast tier, idc-1:8013, qwen3next-80b-a3b, 24,576-token context)
`POST /projects/coffee/assist` with `{"request":"add a grinder block","branch":"main"}`
returned 201 in **15.411 s** wall-clock, with one proposal:
`action=EditElement subject=grinder-block` (a new block "Grinder Block", kind=block, confidence=High).

The same request previously failed with
`400 request (33552 tokens) exceeds the available context size (24576 tokens)`.

## Concerns
1. The compact inventory is ~5.1k fleet tokens (8,953 chars; the full user message measured
   5,120 prompt_tokens against the fleet tokenizer), not the aspirational "under 2,000 tokens".
   The spec requires sending every element's full opaque id (83 ids averaging ~43 chars), which
   is irreducible. ~5.1k tokens is still ~6.6x smaller than the full document's 33,552 tokens
   and fits comfortably in 24,576 (system ~0.8k + inventory ~5.1k + 2,048-token answer ≈ 8k).
2. The fast-tier assist answered in ~15.4 s, above the "single-digit seconds" aspiration: the
   80B reasoning model spends the 2,048-token budget on reasoning. It is a ~34x improvement
   over the 524 s Cloudflare-tunnel timeout and the request now succeeds on the fast tier.
