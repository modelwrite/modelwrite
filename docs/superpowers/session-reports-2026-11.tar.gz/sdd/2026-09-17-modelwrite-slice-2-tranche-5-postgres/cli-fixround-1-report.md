# CLI fix round 1 report: offline parity with the server

Status: DONE

## Commits

- 791a753 fix: offline CLI enforces validation, locks, merge and gate parity with the server

Staged exactly cli/ (cli/Cargo.toml, cli/src/offline.rs, cli/tests/cli.rs) plus
Cargo.lock. Nothing else. README.md and the untracked deploy/ directory in the shared
working tree belong to a different task and were deliberately left unstaged.

## Test summary

cargo test --workspace --no-fail-fast: green (exit 0), 0 failed. 198 passed, 13 ignored.

Per binary:

- Engine 44: capi 4, gate 5, graph 7, mcp 13, okf 15 (okf_diff 8 + okf_validation 7).
- CLI 32: mw bin unit 21, cli integration 11 (4 new in this round).
- Server 122: lib 14, api 11, audit 12, auth 32, corpus 1, gate_api 3, http 3,
  locks 15, merge 15, merge_api 4, store 12.
- Postgres 13 ignored (MW_TEST_DATABASE_URL unset), test_support 0.

The 4 new CLI integration tests are:

- offline_commit_of_an_invalid_document_is_refused_with_the_validators_errors
- offline_commit_changing_a_locked_element_is_refused_naming_the_holder
- offline_merge_writes_a_two_parent_commit_and_a_conflict_writes_nothing
- offline_gate_matches_the_server_verdict_on_the_corpus_pair

cargo fmt --all: clean. cargo clippy --workspace --all-targets -- -D warnings: clean.

## What changed

cli/src/offline.rs now closes every gap the implementer reported:

1. Validate before storing. An offline commit parses the file into an OkfRoot and runs
   okf::validate::validate, refusing with "the model failed validation: <errors joined>"
   rather than the old "not valid JSON" message. Reset validates the target model the
   same way before re-pointing the branch.
2. Enforce locks. Commit, reset and merge all compute the touched-element set (via the
   server's public server::api::touched_elements, and a local all_touched for a first
   commit) and pass a CommitGuard into the store. A write that would change an element
   another holder has a live lease on is refused with the server's exact wording,
   naming element, holder and expiry, and records a commit.refused audit entry.
3. Merge and gate offline. Merge walks ancestry to find the lowest common ancestor,
   runs server::merge::merge, and writes a two-parent commit through commit_merge; a
   conflict records merge.conflict and refuses without writing. Gate loads both models,
   runs gate::run(reference, candidate, false), records the GateRun in the store, and
   returns the same evidence the server returns.

cli/tests/cli.rs gains four integration tests (above). The gate test commits the
coffee-machine corpus pair offline and then serves the SAME store file through the
in-process server, asserting the two evidence records are byte-for-byte equal and that
the broken pair fails.

## Workspace crates added

- mw-okf (dependency) - okf::validate, okf::diff, okf::types.
- mw-gate (dependency) - gate::run.
- mw-test-support (dev-dependency) - the corpus fixture loader used by the gate test.

No external dependency was added: Cargo.lock gained only three dependency edges on the
mw-cli entry (mw-gate, mw-okf, mw-test-support) and no new package. All three crates
were already workspace members present in the lock file via the server.

## Concerns / deviations

1. Reset validates the target model, which the server's own reset skips because it
   trusts already-stored blobs. The ruling says "every offline commit and reset
   validates", so the offline reset runs okf::validate on the target before re-pointing
   the branch. This is a deliberate superset of the server's reset and cannot refuse
   valid content; it only blocks re-pointing to a historically invalid blob.
2. Offline gate records the GateRun in the store (the evidence record the server calls
   "the authority") and returns identical evidence, but does not write the
   server-<reference>-<candidate>.json export file, because the offline CLI has no
   evidence directory - that path is a server-side concern keyed to evidence_dir. If a
   file export is wanted offline, it would need a new flag, which is out of scope here.
3. Concurrent work from another task landed in the same tree during this round: commit
   5e2f123 (a lock-store fix) landed before mine, and 0e632d0 (container/Compose/Helm
   deployment, touching README.md and deploy/) landed after it. This commit (791a753) is
   verified to contain only cli/ plus Cargo.lock, and the two other commits were not
   rewritten or amended.
