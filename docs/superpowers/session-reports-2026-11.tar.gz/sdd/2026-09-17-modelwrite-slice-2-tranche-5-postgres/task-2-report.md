# Task 2 report: the CLI

Status: DONE_WITH_CONCERNS

## Commits

- 82ecfd0 feat: add the modelwrite command line

## Test summary

cargo test --workspace --no-fail-fast: green (exit 0), 0 failed. 194 passed, 13 skipped.
Engine 44 (capi 4, gate 5, graph 7, mcp 13, okf 15); CLI 28 (mw bin unit 21, cli integration 7);
service 122 passed + 13 skipped (server lib 14, api 11, audit 12, auth 32, corpus 1, gate_api 3,
http 3, locks 15, merge 15, merge_api 4, postgres 13 skipped, store 12).

13 Postgres tests were SKIPPED: MW_TEST_DATABASE_URL is unset, so server/tests/postgres.rs is
gated with #[ignore] and never touched a database. CI runs them for real in Task 4.

cargo fmt --all: clean. cargo clippy --workspace --all-targets -- -D warnings: clean.

## What was built

cli/ is a new workspace member producing the binary mw, with two transports chosen up front:

- Offline (--db <path>) opens server::store::sqlite::SqliteStore directly and performs the
  store-level operations with no server and no network. The offline commit/log round trip and
  project/branch/lock/audit/reset commands are all exercised.
- HTTP (--server <url>) speaks HTTP/1.1 over std::net::TcpStream - request line, headers,
  Content-Length body, and response parsing that handles both Content-Length and chunked
  transfer-encoding. It refuses https:// with a message that TLS belongs at the reverse proxy.

The CLI adds NO third-party dependency: cli/Cargo.toml depends only on mw-server
(default-features off) and the already-present workspace serde_json. No new crate entered
Cargo.lock beyond the mw-cli package itself. Arguments are parsed by hand into a typed Command;
a token is read from the environment variable NAMED by --token, never from the command line,
and is never printed (the unit and integration tests assert a wrong token and a missing
variable leave no secret in stdout or stderr).

Offline mutations append audit entries with actor "anonymous" and mechanism "offline", so
`mw audit` is meaningful on an air-gapped database and the log stays append-only via the
store's own triggers.

## Concerns

1. Offline merge and gate are not implemented: both need the OKF engine (three-way merge and
   gate evaluation), which lives in the okf/gate crates and is not exposed through the store
   trait. The CLI depends only on the server crate, so those two commands return a clear
   "run with --server" error offline. They are fully exercised over HTTP.
2. Offline commit and reset do not enforce element locks. Enforcing a lock requires computing
   the touched-element set, which is an OKF diff the no-dependency offline path cannot do.
   Locks can still be acquired, listed and released offline, but a commit is not refused for a
   live lease offline the way the HTTP path refuses it.
3. Offline commit validates that the file is well-formed JSON but does not run the OKF
   validator; model validation is the service's job and is enforced on the HTTP path.
4. The shared working tree carries an untracked .superpowers/ directory; I staged only the
   seven files this task owns (Cargo.toml, Cargo.lock, cli/Cargo.toml, cli/src/main.rs,
   cli/src/http.rs, cli/src/offline.rs, cli/tests/cli.rs). Nothing outside cli/ and the two
   root Cargo files changed.

## Deviations

1. The brief's interface lists no project argument, but every endpoint is under /projects/:project,
   so project-scoped commands take the project name as their first positional argument
   (e.g. `mw commit coffee --branch main --message m --file okf.json`). This is a necessary
   completion of an interface that omitted it; every command still parses exactly as listed.
2. merge and reset gained a required --message flag: the brief lists only --branch/--other/--holder
   and --branch/--to/--holder, but the HTTP API requires a message on both, so the CLI requires
   it too rather than inventing one.
3. Offline merge and gate deliberately return "run with --server" instead of performing the
   operation, for the reason in concern 1. The brief's offline emphasis is "commit and inspect
   history", which is fully met; the two engine-backed operations remain server-only in this build.
