﻿# Postgres critical fix - re-review package

## Commit

2d76915 fix: strip a byte order mark a PowerShell edit left on a test file

## Files changed in the fix

 server/src/store/postgres.rs | 134 +++++++++++++++++++++-----------------
 server/tests/postgres.rs     | 150 +++++++++++++++++++++++++++----------------
 2 files changed, 169 insertions(+), 115 deletions(-)

## FILE: server/src/store/postgres.rs

diff --git a/server/src/store/postgres.rs b/server/src/store/postgres.rs
index b174e87..52d3338 100644
--- a/server/src/store/postgres.rs
+++ b/server/src/store/postgres.rs
@@ -6,31 +6,34 @@ use tokio_postgres_rustls::MakeRustlsConnect;
 
 use super::{
     now_epoch, AuditEntry, Commit, CommitGuard, GateRun, Lock, Project, Store, StoreError,
 };
 
 /// The schema, ported from the SQLite reference implementation. TEXT stays TEXT, the
 /// INTEGER seconds columns become BIGINT, the audit id becomes BIGSERIAL (a monotonic
 /// insertion key, so the log is ordered by insertion rather than wall-clock time), and the
-/// implicit SQLite rowid that ordered commits becomes an explicit BIGSERIAL id for the
-/// same reason. Every CHECK constraint is carried over, and the append-only property of the
-/// audit table is enforced by triggers exactly as it is on SQLite.
+/// implicit SQLite rowid that ordered commits becomes an explicit BIGSERIAL PRIMARY KEY id
+/// for the same reason. Every CHECK constraint is carried over, and the append-only
+/// property of the audit table is enforced by triggers exactly as it is on SQLite. The
+/// locks table carries a UNIQUE(project, element) constraint so "one holder per element"
+/// is a property of the DATABASE, not of the acquire code: two concurrent acquires by
+/// different holders serialise on the constraint and only one can win.
 const SCHEMA: &str = "
 CREATE TABLE IF NOT EXISTS projects (
     name TEXT PRIMARY KEY,
     created_at TEXT NOT NULL
 );
 CREATE TABLE IF NOT EXISTS blobs (
     hash TEXT PRIMARY KEY,
     bytes BYTEA NOT NULL
 );
 CREATE TABLE IF NOT EXISTS commits (
-    id BIGSERIAL NOT NULL,
-    hash TEXT PRIMARY KEY,
+    id BIGSERIAL PRIMARY KEY,
+    hash TEXT NOT NULL UNIQUE,
     project TEXT NOT NULL,
     branch TEXT NOT NULL,
     parents TEXT NOT NULL,
     okf_hash TEXT NOT NULL,
     author TEXT NOT NULL,
     message TEXT NOT NULL,
     created_at TEXT NOT NULL
 );
@@ -53,19 +56,19 @@ CREATE TABLE IF NOT EXISTS gate_runs (
 );
 CREATE TABLE IF NOT EXISTS locks (
     id TEXT PRIMARY KEY,
     project TEXT NOT NULL,
     branch TEXT NOT NULL,
     element TEXT NOT NULL,
     holder TEXT NOT NULL,
     acquired_at BIGINT NOT NULL,
-    expires_at BIGINT NOT NULL
+    expires_at BIGINT NOT NULL,
+    UNIQUE (project, element)
 );
-CREATE INDEX IF NOT EXISTS locks_element ON locks(project, element);
 CREATE TABLE IF NOT EXISTS audit (
     id BIGSERIAL PRIMARY KEY,
     project TEXT NOT NULL,
     at BIGINT NOT NULL,
     actor TEXT NOT NULL,
     mechanism TEXT NOT NULL,
     action TEXT NOT NULL,
     subject TEXT NOT NULL,
@@ -141,21 +144,26 @@ fn rustls_connector() -> Result<MakeRustlsConnect, StoreError> {
         .with_no_client_auth();
     Ok(MakeRustlsConnect::new(config))
 }
 
 impl PostgresStore {
     pub fn open(url: &str) -> Result<Self, StoreError> {
         let config: postgres::Config = url.parse().map_err(backend)?;
         let pool = match config.get_ssl_mode() {
-            SslMode::Disable | SslMode::Prefer => {
+            // `disable` is an explicit opt-out of transport security, so plaintext is
+            // exactly what was asked for.
+            SslMode::Disable => {
                 let manager = PostgresConnectionManager::new(config, NoTls);
                 Pool::Plain(r2d2::Pool::new(manager).map_err(backend)?)
             }
-            SslMode::Require => {
+            // `prefer` asks for TLS with a plaintext fallback. This client cannot negotiate
+            // that fallback, so it honours the preference by REQUIRING TLS instead of
+            // silently downgrading a transport-security setting to plaintext.
+            SslMode::Prefer | SslMode::Require => {
                 let manager = PostgresConnectionManager::new(config, rustls_connector()?);
                 Pool::Tls(r2d2::Pool::new(manager).map_err(backend)?)
             }
             _ => {
                 return Err(StoreError::Backend(
                     "unsupported sslmode in the connection string".to_string(),
                 ))
             }
@@ -584,20 +592,30 @@ impl Store for PostgresStore {
 
     fn create_branch(
         &self,
         project: &str,
         name: &str,
         from: &str,
         audit: Option<&AuditEntry>,
     ) -> Result<(), StoreError> {
-        if self.commit(project, from)?.is_none() {
-            return Err(StoreError::NotFound(format!("commit {}", from)));
-        }
         self.with_tx(|tx| {
+            // The source commit must exist, checked inside the transaction that writes the
+            // branch, so the check and the write see the same state.
+            let from_exists: bool = tx
+                .query_opt(
+                    "SELECT 1 FROM commits WHERE project = $1 AND hash = $2",
+                    &[&project, &from],
+                )
+                .map_err(backend)?
+                .is_some();
+            if !from_exists {
+                return Err(StoreError::NotFound(format!("commit {}", from)));
+            }
+
             let inserted = tx
                 .execute(
                     "INSERT INTO branches (project, name, tip) VALUES ($1, $2, $3) ON CONFLICT (project, name) DO NOTHING",
                     &[&project, &name, &from],
                 )
                 .map_err(backend)?;
             if inserted == 0 {
                 return Err(StoreError::Conflict(format!(
@@ -613,20 +631,27 @@ impl Store for PostgresStore {
     }
 
     fn delete_branch(
         &self,
         project: &str,
         name: &str,
         audit: Option<&AuditEntry>,
     ) -> Result<(), StoreError> {
-        if self.project(project)?.is_none() {
-            return Err(StoreError::NotFound(format!("project {}", project)));
-        }
         self.with_tx(|tx| {
+            // Ask which thing is missing inside the transaction that deletes, so the check
+            // and the delete see the same state.
+            let project_exists: bool = tx
+                .query_opt("SELECT 1 FROM projects WHERE name = $1", &[&project])
+                .map_err(backend)?
+                .is_some();
+            if !project_exists {
+                return Err(StoreError::NotFound(format!("project {}", project)));
+            }
+
             let removed = tx
                 .execute(
                     "DELETE FROM branches WHERE project = $1 AND name = $2",
                     &[&project, &name],
                 )
                 .map_err(backend)?;
             if removed == 0 {
                 return Err(StoreError::NotFound(format!("branch {}", name)));
@@ -735,72 +760,63 @@ impl Store for PostgresStore {
         branch: &str,
         elements: &[String],
         holder: &str,
         ttl_seconds: i64,
         now: i64,
         audit: Option<&AuditEntry>,
     ) -> Result<Vec<Lock>, StoreError> {
         self.with_tx(|tx| {
+            // Sweep dead leases first, so an expired lock never blocks a new holder.
             tx.execute("DELETE FROM locks WHERE expires_at <= $1", &[&now])
                 .map_err(backend)?;
 
+            let expires_at = now + ttl_seconds;
+            let mut locks = Vec::with_capacity(elements.len());
             for element in elements {
-                let conflict: Option<(String, i64)> = tx
+                // One statement, settled by the database: insert a fresh lease, or extend
+                // this holder's existing lease. The UNIQUE(project, element) constraint is
+                // the arbiter between two concurrent acquires by different holders - the
+                // loser's DO UPDATE ... WHERE fails its holder test and returns no row, so
+                // it is refused with the winner's identity instead of both holding it.
+                let id = super::lock_id(project, branch, element, holder, now);
+                let taken: Option<(String, i64)> = tx
                     .query_opt(
-                        "SELECT holder, expires_at FROM locks WHERE project = $1 AND element = $2 AND holder != $3",
-                        &[&project, &element, &holder],
+                        "INSERT INTO locks (id, project, branch, element, holder, acquired_at, expires_at) VALUES ($1, $2, $3, $4, $5, $6, $7) ON CONFLICT (project, element) DO UPDATE SET branch = EXCLUDED.branch, expires_at = EXCLUDED.expires_at WHERE locks.holder = EXCLUDED.holder RETURNING id, acquired_at",
+                        &[&id, &project, &branch, &element, &holder, &now, &expires_at],
                     )
                     .map_err(backend)?
                     .map(|row| (row.get(0), row.get(1)));
-                if let Some((other, expires_at)) = conflict {
-                    return Err(super::lock_refusal(element, &other, expires_at));
-                }
-            }
 
-            let mut locks = Vec::with_capacity(elements.len());
-            for element in elements {
-                let existing: Option<(String, String, i64)> = tx
-                    .query_opt(
-                        "SELECT id, branch, acquired_at FROM locks WHERE project = $1 AND element = $2 AND holder = $3",
-                        &[&project, &element, &holder],
-                    )
-                    .map_err(backend)?
-                    .map(|row| (row.get(0), row.get(1), row.get(2)));
-
-                let expires_at = now + ttl_seconds;
-                let (id, acquired_at) = match existing {
-                    Some((id, _branch, acquired_at)) => {
-                        tx.execute(
-                            "UPDATE locks SET branch = $1, expires_at = $2 WHERE id = $3",
-                            &[&branch, &expires_at, &id],
-                        )
-                        .map_err(backend)?;
-                        (id, acquired_at)
+                match taken {
+                    Some((id, acquired_at)) => {
+                        locks.push(Lock {
+                            id,
+                            project: project.to_string(),
+                            branch: branch.to_string(),
+                            element: element.clone(),
+                            holder: holder.to_string(),
+                            acquired_at,
+                            expires_at,
+                        });
                     }
                     None => {
-                        let id = super::lock_id(project, branch, element, holder, now);
-                        tx.execute(
-                            "INSERT INTO locks (id, project, branch, element, holder, acquired_at, expires_at) VALUES ($1, $2, $3, $4, $5, $6, $7)",
-                            &[&id, &project, &branch, &element, &holder, &now, &expires_at],
-                        )
-                        .map_err(backend)?;
-                        (id, now)
+                        // A different holder owns a live lease on this element. Returning
+                        // the error rolls back the whole transaction, so acquiring is all
+                        // or nothing for the requested elements.
+                        let (winner, winner_expires): (String, i64) = tx
+                            .query_one(
+                                "SELECT holder, expires_at FROM locks WHERE project = $1 AND element = $2",
+                                &[&project, &element],
+                            )
+                            .map_err(backend)
+                            .map(|row| (row.get(0), row.get(1)))?;
+                        return Err(super::lock_refusal(element, &winner, winner_expires));
                     }
-                };
-
-                locks.push(Lock {
-                    id,
-                    project: project.to_string(),
-                    branch: branch.to_string(),
-                    element: element.clone(),
-                    holder: holder.to_string(),
-                    acquired_at,
-                    expires_at,
-                });
+                }
             }
 
             if let Some(audit) = audit {
                 insert_audit(tx, audit)?;
             }
             Ok(locks)
         })
     }

## FILE: server/tests/postgres.rs

diff --git a/server/tests/postgres.rs b/server/tests/postgres.rs
index 93ebb4c..bb0407e 100644
--- a/server/tests/postgres.rs
+++ b/server/tests/postgres.rs
@@ -1,26 +1,29 @@
 // SPDX-License-Identifier: AGPL-3.0-or-later
 #![cfg(feature = "postgres")]
 
 use postgres::NoTls;
 use server::store::postgres::PostgresStore;
 use server::store::{AuditEntry, CommitGuard, GateRun, Store, StoreError};
 
-/// Every test in this file is skipped - not failed, and not passed - when
-/// MW_TEST_DATABASE_URL is unset, so the local suite (no PostgreSQL) stays green without
-/// pretending the backend was exercised. A test that cannot open the configured database
-/// panics: a misconfigured URL must fail loudly, not quietly skip.
-fn require_store() -> Option<PostgresStore> {
-    let url = std::env::var("MW_TEST_DATABASE_URL").ok()?;
+/// Every test in this file is marked `#[ignore = "requires MW_TEST_DATABASE_URL"]`, so a
+/// plain `cargo test` reports them as IGNORED (not passed) and they do no work. A developer
+/// who has a database runs them with `--include-ignored` after setting MW_TEST_DATABASE_URL;
+/// this helper then opens the configured database and panics - not skips - when the URL is
+/// unset, empty or unreachable, because a misconfigured URL must fail loudly.
+fn require_store() -> PostgresStore {
+    let url = std::env::var("MW_TEST_DATABASE_URL").expect(
+        "MW_TEST_DATABASE_URL must be set to run the ignored postgres tests (use --include-ignored)",
+    );
     if url.trim().is_empty() {
-        return None;
+        panic!("MW_TEST_DATABASE_URL is set but empty");
     }
     match PostgresStore::open(&url) {
-        Ok(store) => Some(store),
+        Ok(store) => store,
         Err(error) => panic!(
             "could not open the configured PostgreSQL database: {}",
             error
         ),
     }
 }
 
 /// A project name unique to this test run, so tests can share one database without
@@ -32,35 +35,31 @@ fn unique_project() -> String {
         .duration_since(std::time::UNIX_EPOCH)
         .unwrap_or_default()
         .as_nanos();
     let n = COUNTER.fetch_add(1, Ordering::Relaxed);
     format!("pgtest_{}_{}", nanos, n)
 }
 
 #[test]
+#[ignore = "requires MW_TEST_DATABASE_URL"]
 fn blobs_are_content_addressed() {
-    let Some(store) = require_store() else {
-        eprintln!("skipped: MW_TEST_DATABASE_URL is not set");
-        return;
-    };
+    let store = require_store();
     let a = store.put_blob(b"model-one").unwrap();
     let b = store.put_blob(b"model-one").unwrap();
     let c = store.put_blob(b"model-two").unwrap();
     assert_eq!(a, b, "identical bytes must share an address");
     assert_ne!(a, c);
     assert_eq!(store.blob(&a).unwrap().unwrap(), b"model-one");
 }
 
 #[test]
+#[ignore = "requires MW_TEST_DATABASE_URL"]
 fn commits_land_on_a_branch_and_move_its_tip() {
-    let Some(store) = require_store() else {
-        eprintln!("skipped: MW_TEST_DATABASE_URL is not set");
-        return;
-    };
+    let store = require_store();
     let project = unique_project();
     store.create_project(&project, None).unwrap();
     let first = store
         .commit_model(&project, "main", "okf1", "alex", "first commit", None, None)
         .unwrap();
     assert_eq!(
         store.branch_tip(&project, "main").unwrap().unwrap(),
         first.hash
@@ -82,21 +81,19 @@ fn commits_land_on_a_branch_and_move_its_tip() {
         second.hash
     );
     assert_eq!(store.commits_on(&project, "main").unwrap().len(), 2);
     assert!(first.parents.is_empty(), "the first commit has no parent");
     assert_eq!(second.parents, vec![first.hash.clone()]);
 }
 
 #[test]
+#[ignore = "requires MW_TEST_DATABASE_URL"]
 fn duplicate_projects_and_branches_are_conflicts() {
-    let Some(store) = require_store() else {
-        eprintln!("skipped: MW_TEST_DATABASE_URL is not set");
-        return;
-    };
+    let store = require_store();
     let project = unique_project();
     store.create_project(&project, None).unwrap();
     match store.create_project(&project, None) {
         Err(StoreError::Conflict(_)) => {}
         other => panic!("expected a conflict, got {:?}", other),
     }
     let commit = store
         .commit_model(&project, "main", "okf1", "alex", "first commit", None, None)
@@ -110,21 +107,19 @@ fn duplicate_projects_and_branches_are_conflicts() {
     }
     match store.create_branch(&project, "other", "missing-commit", None) {
         Err(StoreError::NotFound(_)) => {}
         other => panic!("expected not found, got {:?}", other),
     }
 }
 
 #[test]
+#[ignore = "requires MW_TEST_DATABASE_URL"]
 fn concurrent_commits_to_one_branch_form_a_linear_chain() {
-    let Some(store) = require_store() else {
-        eprintln!("skipped: MW_TEST_DATABASE_URL is not set");
-        return;
-    };
+    let store = require_store();
     let project = unique_project();
     store.create_project(&project, None).unwrap();
     let store = std::sync::Arc::new(store);
 
     let mut handles = Vec::new();
     for i in 0..8 {
         let store = store.clone();
         let project = project.clone();
@@ -188,21 +183,19 @@ fn concurrent_commits_to_one_branch_form_a_linear_chain() {
     assert_eq!(
         seen.len(),
         8,
         "walking back from the tip must reach all eight commits"
     );
 }
 
 #[test]
+#[ignore = "requires MW_TEST_DATABASE_URL"]
 fn a_merge_refuses_when_the_branch_moved_under_it() {
-    let Some(store) = require_store() else {
-        eprintln!("skipped: MW_TEST_DATABASE_URL is not set");
-        return;
-    };
+    let store = require_store();
     let project = unique_project();
     store.create_project(&project, None).unwrap();
     let root = store
         .commit_model(&project, "main", "okf-root", "alex", "root", None, None)
         .unwrap();
     store
         .create_branch(&project, "feature", &root.hash, None)
         .unwrap();
@@ -254,21 +247,19 @@ fn a_merge_refuses_when_the_branch_moved_under_it() {
         .unwrap()
         .into_iter()
         .filter(|c| c.parents.len() == 2)
         .collect();
     assert!(merges.is_empty(), "no merge commit may be written");
 }
 
 #[test]
+#[ignore = "requires MW_TEST_DATABASE_URL"]
 fn a_guarded_commit_is_refused_inside_the_transaction() {
-    let Some(store) = require_store() else {
-        eprintln!("skipped: MW_TEST_DATABASE_URL is not set");
-        return;
-    };
+    let store = require_store();
     let project = unique_project();
     store.create_project(&project, None).unwrap();
     let root = store
         .commit_model(&project, "main", "okf-root", "alex", "root", None, None)
         .unwrap();
     let root_hash = root.hash.clone();
 
     store
@@ -351,21 +342,19 @@ fn a_guarded_commit_is_refused_inside_the_transaction() {
             expected_tip: tip_now.as_deref(),
         }),
         None,
     );
     assert!(unrelated.is_ok(), "only the guarded elements are protected");
 }
 
 #[test]
+#[ignore = "requires MW_TEST_DATABASE_URL"]
 fn a_guard_computed_against_an_old_tip_is_refused() {
-    let Some(store) = require_store() else {
-        eprintln!("skipped: MW_TEST_DATABASE_URL is not set");
-        return;
-    };
+    let store = require_store();
     let project = unique_project();
     store.create_project(&project, None).unwrap();
     let root = store
         .commit_model(&project, "main", "okf-root", "alex", "root", None, None)
         .unwrap();
 
     store
         .commit_model(&project, "main", "okf-other", "alex", "moved", None, None)
@@ -399,21 +388,19 @@ fn a_guard_computed_against_an_old_tip_is_refused() {
     assert_eq!(
         store.commits_on(&project, "main").unwrap().len(),
         2,
         "nothing may be written"
     );
 }
 
 #[test]
+#[ignore = "requires MW_TEST_DATABASE_URL"]
 fn audit_rows_ride_each_mutation_transaction() {
-    let Some(store) = require_store() else {
-        eprintln!("skipped: MW_TEST_DATABASE_URL is not set");
-        return;
-    };
+    let store = require_store();
     let project = unique_project();
     let entry = |action: &str| AuditEntry {
         id: 0,
         project: project.clone(),
         at: 1,
         actor: "alex".to_string(),
         mechanism: "jwt".to_string(),
         action: action.to_string(),
@@ -491,21 +478,19 @@ fn audit_rows_ride_each_mutation_transaction() {
             actions.contains(&action.to_string()),
             "missing audit action {}",
             action
         );
     }
 }
 
 #[test]
+#[ignore = "requires MW_TEST_DATABASE_URL"]
 fn the_audit_table_refuses_update_and_delete() {
-    let Some(store) = require_store() else {
-        eprintln!("skipped: MW_TEST_DATABASE_URL is not set");
-        return;
-    };
+    let store = require_store();
     let project = unique_project();
     store.create_project(&project, None).unwrap();
     let id = store
         .append_audit(&AuditEntry {
             id: 0,
             project: project.clone(),
             at: 1,
             actor: "a".to_string(),
@@ -531,21 +516,19 @@ fn the_audit_table_refuses_update_and_delete() {
     assert!(
         conn.execute("DELETE FROM audit WHERE id = $1", &[&id])
             .is_err(),
         "DELETE on the audit table must be refused by the trigger"
     );
 }
 
 #[test]
+#[ignore = "requires MW_TEST_DATABASE_URL"]
 fn a_mutation_rolls_back_when_its_audit_entry_cannot_be_written() {
-    let Some(store) = require_store() else {
-        eprintln!("skipped: MW_TEST_DATABASE_URL is not set");
-        return;
-    };
+    let store = require_store();
     let project = unique_project();
     let unwritable = AuditEntry {
         id: 0,
         project: project.clone(),
         at: 0,
         actor: String::new(),
         mechanism: "open".to_string(),
         action: "project.create".to_string(),
@@ -560,21 +543,19 @@ fn a_mutation_rolls_back_when_its_audit_entry_cannot_be_written() {
     );
     assert!(
         store.project(&project).unwrap().is_none(),
         "the project must NOT survive: the mutation rolled back with its record"
     );
 }
 
 #[test]
+#[ignore = "requires MW_TEST_DATABASE_URL"]
 fn an_expired_lease_stops_blocking() {
-    let Some(store) = require_store() else {
-        eprintln!("skipped: MW_TEST_DATABASE_URL is not set");
-        return;
-    };
+    let store = require_store();
     let project = unique_project();
 
     // A acquires b1 at now = 1000 with ttl 30, so the lease expires at 1030.
     store
         .acquire_locks(
             &project,
             "main",
             &["b1".to_string()],
@@ -595,29 +576,86 @@ fn an_expired_lease_stops_blocking() {
     let acquired = store
         .acquire_locks(&project, "main", &["b1".to_string()], "bob", 30, 1031, None)
         .unwrap();
     assert_eq!(acquired.len(), 1);
     assert_eq!(acquired[0].holder, "bob");
 }
 
 #[test]
+#[ignore = "requires MW_TEST_DATABASE_URL"]
 fn deleting_a_branch_leaves_its_commits_readable() {
-    let Some(store) = require_store() else {
-        eprintln!("skipped: MW_TEST_DATABASE_URL is not set");
-        return;
-    };
+    let store = require_store();
     let project = unique_project();
     store.create_project(&project, None).unwrap();
     let commit = store
         .commit_model(&project, "main", "okf", "alex", "commit", None, None)
         .unwrap();
     store
         .create_branch(&project, "review", &commit.hash, None)
         .unwrap();
 
     store.delete_branch(&project, "review", None).unwrap();
 
     // Deleting a branch removes the pointer, never the commits it pointed at.
     let still = store.commit(&project, &commit.hash).unwrap();
     assert!(still.is_some(), "the commit must survive its branch");
     assert_eq!(still.unwrap().hash, commit.hash);
 }
+
+#[test]
+#[ignore = "requires MW_TEST_DATABASE_URL"]
+fn two_concurrent_acquires_by_different_holders_cannot_both_succeed() {
+    let store = require_store();
+    let project = unique_project();
+    let store = std::sync::Arc::new(store);
+
+    // Two holders race for the same element. The UNIQUE(project, element) constraint is
+    // the arbiter: exactly one INSERT ... ON CONFLICT wins, and the loser is refused with
+    // the winner's identity rather than also holding the element.
+    let handles: Vec<_> = ["alex".to_string(), "bob".to_string()]
+        .into_iter()
+        .map(|holder| {
+            let store = store.clone();
+            let project = project.clone();
+            std::thread::spawn(move || {
+                store.acquire_locks(
+                    &project,
+                    "main",
+                    &["b1".to_string()],
+                    &holder,
+                    600,
+                    1000,
+                    None,
+                )
+            })
+        })
+        .collect();
+
+    let results: Vec<_> = handles
+        .into_iter()
+        .map(|handle| handle.join().expect("worker thread"))
+        .collect();
+
+    let mut winners = 0;
+    let mut refusals: Vec<String> = Vec::new();
+    for result in results {
+        match result {
+            Ok(_) => winners += 1,
+            Err(StoreError::Locked {
+                element, holder, ..
+            }) => {
+                assert_eq!(element, "b1", "the refusal must name the element");
+                refusals.push(holder);
+            }
+            Err(other) => panic!("expected a lock refusal, got {:?}", other),
+        }
+    }
+    assert_eq!(winners, 1, "exactly one holder may win the lease");
+    assert_eq!(refusals.len(), 1, "the loser must be refused as Locked");
+
+    let locks = store.locks(&project, 1000).unwrap();
+    assert_eq!(locks.len(), 1, "exactly one live lock must exist");
+    assert_eq!(
+        locks[0].holder, refusals[0],
+        "the refusal must name the holder that actually won"
+    );
+}
