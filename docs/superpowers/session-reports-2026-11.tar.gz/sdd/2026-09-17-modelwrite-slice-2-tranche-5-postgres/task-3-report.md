# Task 3 report — Deployment (Slice 2, tranche 5)

## Status

DONE_WITH_CONCERNS

## Commits

- 0e632d093ff2e9f6ed1956b869fcb3fbe64892c1 — feat: add container, compose and Helm deployment

Staged exactly the paths this task owns: `deploy/` (12 files) and `README.md`
(one edit). The pre-existing untracked `.superpowers/` directory was left
alone. No commit was amended or rewritten.

## Test summary

`cargo test --workspace --no-fail-fast`: 0 failed, 198 passed, 13 ignored (the
PostgreSQL suite, skipped because `MW_TEST_DATABASE_URL` is unset). `cargo fmt
--all -- --check` and `cargo clippy --workspace --all-targets -- -D warnings`
are both clean.

## What I produced

- `deploy/Dockerfile` — multi-stage build (rust builder → `debian:bookworm-slim`
  runtime), `mw-server` built with `--locked -p mw-server` (postgres feature is
  on by default), non-root user uid/gid 65532, no C toolchain at runtime,
  `WORKDIR /data` with `MW_DB`/`MW_EVIDENCE_DIR` defaults under the writable
  volume.
- `deploy/docker-entrypoint.sh` — refuses to start when neither `MW_AUTH_TOKEN`
  nor `MW_AUTH_JWKS` is configured unless `MW_ALLOW_OPEN=yes` is set, mirroring
  the server's `trim().is_empty()` decision so a whitespace-only token is not
  treated as a credential.
- `deploy/docker-compose.yml` — trial stack (`postgres:16` + `mw-server`),
  named volumes, `read_only: true`, secrets referenced via `${VAR:?}`
  interpolation, never inlined.
- `deploy/helm/modelwrite/` — Chart.yaml, values.yaml, and templates for
  Deployment, Service, ConfigMap, PVC, plus `secret.yaml.example` and
  `_helpers.tpl`. Secrets are referenced by Secret name (`secretKeyRef` /
  mounted Secret), never inlined; liveness and readiness probes both hit
  `GET /health`; resource requests/limits are set; persistence is a PVC.
- `deploy/README.md` — open-mode warning in bold, air-gapped install path
  (image transfer, mounted JWKS, local Postgres or none), a "what the chart does
  NOT do" list (no TLS termination, no backups, no HA, no secret management), and
  a "what was and was not verified" section.
- `README.md` — a "Run the service" quick start pointing at `deploy/`.

## Validation performed

- Parsed `deploy/docker-compose.yml`, `deploy/helm/modelwrite/Chart.yaml`,
  `deploy/helm/modelwrite/values.yaml` and
  `deploy/helm/modelwrite/templates/secret.yaml.example` with Python 3.13.13 +
  PyYAML 6.0.3 — all parse cleanly (1 document each).
- Checked template directive balance (`if`/`with`/`define` vs `end`,
  `else` placement) across all five template files — balanced.
- Hand-rendered `deployment.yaml`, `service.yaml`, `configmap.yaml` and
  `pvc.yaml` against the default values and YAML-parsed the result (apps/v1
  Deployment, v1 Service, v1 ConfigMap, v1 PersistentVolumeClaim). Also
  hand-rendered and parsed the production branch (Postgres + bearer token + JWKS)
  to confirm the conditional env/volume mounts, both /health probes, and
  `readOnlyRootFilesystem: true` are well-formed.
- Kubernetes API versions used are all long-stable GA versions (`apps/v1`,
  `v1`); no API version was invented.

## Validation NOT performed (and why)

- **The image was never built.** No Docker on this machine.
- **The chart was never installed** and `helm template`/`helm lint` were not
  run. No Helm binary is installed, so the Go-template files could not be
  rendered by Helm itself; the "well-formed" claim rests on PyYAML parsing,
  directive-balance checks, and hand-rendering the two representative value sets.

## Concerns

1. **The service binds to 127.0.0.1 and there is no bind-address variable.**
   `server/src/main.rs` hardcodes `SocketAddr::from(([127, 0, 0, 1], port))`
   and reads only `MW_PORT`. Inside a container that means the service is
   reachable only from its own network namespace — the Compose `ports` mapping
   and the Kubernetes Service will not carry real traffic, and the HTTP probes
   (which connect to the pod IP) will fail, until the server grows a
   `MW_BIND`/`MW_HOST`-style variable. This is a server-code change, out of
   scope here (I was told not to touch `server/` and not to invent env vars),
   and it is documented in `deploy/README.md`. The deployment artefacts are the
   correct eventual shape; they cannot serve traffic as of this tranche.
2. **The build context is the repository root** (`docker build -f deploy/Dockerfile .`),
   which pulls the whole tree including `target/` unless the operator adds a
   `.dockerignore`. I did not commit a root `.dockerignore` because it is
   outside this task's owned paths; it is called out in `deploy/README.md`.
3. **`RUST_VERSION` defaults to 1.85** (the server crate's declared
   `rust-version`). The local toolchain is 1.98.1, so if a dependency has
   drifted above 1.85 the default build would fail; the `ARG` lets the operator
   override it.

## Deviations

- Added `templates/_helpers.tpl` and `templates/pvc.yaml`, which are not in
  the brief's file list. Reason: `_helpers.tpl` is the standard Helm naming/
  label helper the templates reference, and a dedicated PVC template is the
  correct way to realise the "persistence" requirement (a `volumeClaimTemplate`
  is StatefulSet-only). Both are conventional `helm create` files.
