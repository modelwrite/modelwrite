# Fix round 2 — Slice 2 tranche 5

## Status

DONE

## Commits

- `4d4eec5` fix: harden the postgres lock guard and add a migration path
- `eba89fa` fix: create the evidence directory before the first gate write
- `06e8b14` refactor: share merge-base and lock-refusal logic with the CLI
- `88d0538` fix: add HTTP timeouts to the CLI and declare the true MSRV
- `605e344` docs: document the mw CLI and the JWKS restart requirement
- `5d88ae2` ci: scope --include-ignored to the postgres test target

## Test summary

`cargo test --workspace --no-fail-fast`: **208 passed, 16 ignored, 0 failed**.
The 16 ignored are all the PostgreSQL suite (13 pre-existing + 3 added), which cannot run
on this machine (no PostgreSQL); they were compile-verified but not executed here.
`cargo fmt --all -- --check` clean; `cargo clippy --workspace --all-targets -- -D warnings` clean.

Per-binary passed: capi 4, mw(cli bin) 22, cli 12, gate 5, graph 7, mcp 13, okf 15,
server(lib) 14, mw-server(bin) 0, server/api 11, server/audit 12, server/auth 32,
server/corpus 1, server/gate_api 4, server/http 4, server/locks 15, server/merge 15,
server/merge_api 4, server/postgres 0 (16 ignored), server/store 12, server/ui 6,
test_support 0.

## Migration option chosen

`ALTER TABLE ... ADD COLUMN IF NOT EXISTS` (idempotent additive statements), **not** a
`schema_version` table. Each migration states WHAT it changes, so it cannot drift from the
schema it changes (a version row can claim N while a column is missing); it mirrors the
SQLite `migrate()` discipline one-for-one; and a non-additive migration (rename/drop) can
introduce a versioned table later if it is ever actually needed. The step runs inside the
same `pg_advisory_xact_lock(7071175)` transaction as the schema bootstrap, so two instances
starting at once still serialise.

## Findings closed

- **Important 1** — `enforce_guard` and `acquire_locks` now both take
  `pg_advisory_xact_lock(element_lock_key(project, element))` before their read/insert, so
  checking a lease and taking one are mutually exclusive. Key is a stable FNV-1a 64-bit hash.
  Two `#[ignore]`d tests cover the race (guard blocks on an in-flight acquire; acquire
  blocks on an in-flight check).
- **Important 2** — the evidence directory is created at startup (main.rs) and defensively in
  the gate handler, plus a test that gates against a non-existent directory.
- **Important 3** — idempotent postgres migration after the schema, plus a test that opens an
  old-shape (mechanism-less) database and finds it migrated.
- **Important 4** — `load_model`, `all_touched`, `ancestry_set`, `common_ancestor`,
  `commit_refusal_guard` and `lock_refusal_message` are now single public implementations
  taking `&dyn Store`; server handlers and the offline CLI both call them; the CLI's copies
  are deleted.
- **M1** — offline lock acquire/release check the project exists, and element lists are
  validated + deduplicated through the shared `prepare_lock_elements`.
- **M2** — README lists the `mw` CLI with an honest example.
- **M3** — cli/Cargo.toml declares `rust-version = "1.88"`.
- **M4** — the HTTP client has connect + read/write timeouts and a clear timeout message,
  with a unit test.
- **M5** — CI runs the workspace without `--include-ignored`, then runs only the postgres
  test target with it.
- **M6** — README notes a JWKS key add/remove requires a restart.

## Concerns

- The 16 PostgreSQL tests were not executed here (no local PostgreSQL); they compiled cleanly
  and are expected to run in the CI postgres job.
- `Cargo.lock` was deliberately NOT committed: this change adds no dependencies, and the only
  `Cargo.lock` delta in the tree (`mw-graph` for `mw-server`) belongs to the concurrent
  task's uncommitted `server/Cargo.toml` edit.
- The per-element advisory lock serialises multi-element acquires in caller order; a
  pathological two-holder deadlock is theoretically possible but is resolved by PostgreSQL's
  deadlock detector as a retryable backend error, never a corrupt lock state.

## Deviations

None. Every source file begins with the required SPDX line; engine/, judge/, sample/, docs/
and collateral/ were not modified; the concurrent task's paths (server/src/lib.rs,
server/Cargo.toml, server/src/ui/) were not touched.
