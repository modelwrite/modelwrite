﻿# Tranche 5 Task 3 review package (deployment)

## Commits under review

aee3df6 fix: make the bind configurable and refuse to expose an unauthenticated service
0e632d0 feat: add container, compose and Helm deployment

## Diff stat

 README.md                                          |  17 ++-
 deploy/Dockerfile                                  |  65 +++++++++++
 deploy/README.md                                   | 130 +++++++++++++++++++++
 deploy/docker-compose.yml                          |  59 ++++++++++
 deploy/docker-entrypoint.sh                        |  36 ++++++
 deploy/helm/modelwrite/Chart.yaml                  |   7 ++
 deploy/helm/modelwrite/templates/_helpers.tpl      |  30 +++++
 deploy/helm/modelwrite/templates/configmap.yaml    |  17 +++
 deploy/helm/modelwrite/templates/deployment.yaml   | 113 ++++++++++++++++++
 deploy/helm/modelwrite/templates/pvc.yaml          |  18 +++
 .../helm/modelwrite/templates/secret.yaml.example  |  25 ++++
 deploy/helm/modelwrite/templates/service.yaml      |  16 +++
 deploy/helm/modelwrite/values.yaml                 |  87 ++++++++++++++
 server/src/lib.rs                                  |  26 +++++
 server/src/main.rs                                 |  12 +-
 server/tests/http.rs                               |  29 +++++
 16 files changed, 685 insertions(+), 2 deletions(-)

## FILE: README.md

diff --git a/README.md b/README.md
index 7c2acef..0afd0b9 100644
--- a/README.md
+++ b/README.md
@@ -1,7 +1,7 @@
-﻿# Modelwrite
+# Modelwrite
 
 **The model you can prove.**
 
 Modelwrite is an open-source MBSE platform that turns legacy SysML models
 into portable, provable data — the Open Knowledge Format (OKF) — and
 automates the skilled work of building and reviewing models with grounded
@@ -14,12 +14,13 @@ AI.
   evidence records; the C ABI; the MCP server
 - judge/ — the gate-as-judge harness for scoring model migrations
 - agents/ — rule packs for AI coding agents working against OKF
 - sample/ — the coffee-machine corpus: the legacy CATIA Magic model, its
   OKF export, and the corrupted fixture the gate must reject
 - docs/ — the OKF 1.0 spec, the design documents, and the evidence annex
+- deploy/ — the container image, a Docker Compose trial stack, and a Helm chart
 
 ## Quickstart
 
 Requirements: Rust (stable, via rustup) and Python 3.12+ for the judge
 harness.
 
@@ -29,10 +30,24 @@ cargo test --workspace
 Run the gate on the corpus:
 
 cargo run -p mw-gate -- --reference sample/corpus/coffee-machine/okf/expected/coffee_machine_model.json --candidate sample/corpus/coffee-machine/okf/expected/coffee_machine_model.json
 
 Expected output: GATE PASS.
 
+## Run the service
+
+Deploy it as a container, a Compose trial, or a Helm release:
+
+docker build -f deploy/Dockerfile -t modelwrite/modelwrite:0.1.0 .
+docker compose -f deploy/docker-compose.yml up --build   # a trial on one machine
+helm install modelwrite deploy/helm/modelwrite          # a real install
+
+**The service runs in OPEN MODE (anonymous admin) when no authentication is
+configured. The image refuses to start that way unless you set
+`MW_ALLOW_OPEN=yes`; for anything shared, set `MW_AUTH_TOKEN` or `MW_AUTH_JWKS`
+instead.** See deploy/README.md for the full story, including the air-gapped
+install path and what the chart does not do (TLS, backups, HA).
+
 ## Licence
 
 The engine is AGPL-3.0-or-later. Importers and exporters will ship under
 Apache-2.0 as they land. See NOTICE.md for attribution.

## FILE: deploy/Dockerfile

diff --git a/deploy/Dockerfile b/deploy/Dockerfile
new file mode 100644
index 0000000..5ad648d
--- /dev/null
+++ b/deploy/Dockerfile
@@ -0,0 +1,65 @@
+# SPDX-License-Identifier: AGPL-3.0-or-later
+# Multi-stage build for the modelwrite service (mw-server).
+#
+# A single image serves both the PostgreSQL deployment and the SQLite fallback:
+# the postgres feature is a default feature of the server crate. The runtime image
+# carries no C toolchain and runs as a non-root user (uid 65532). The root
+# filesystem is meant to be mounted read-only (see the compose file and chart);
+# the only writable path is the /data volume (SQLite database and gate evidence).
+
+# ---- builder ---------------------------------------------------------------
+# The server crate declares rust-version = "1.85". Override RUST_VERSION to build
+# with a newer toolchain if a dependency ever raises the floor.
+ARG RUST_VERSION=1.85
+FROM rust:${RUST_VERSION}-slim AS builder
+
+# rusqlite is built with the "bundled" feature (compiles SQLite from C) and
+# rustls/ring need a C compiler too, so build-essential is required AT BUILD TIME
+# only. ca-certificates is for the crate fetches over HTTPS; it does not leak into
+# the runtime image.
+RUN apt-get update \
+    && apt-get install -y --no-install-recommends build-essential ca-certificates \
+    && rm -rf /var/lib/apt/lists/*
+
+WORKDIR /src
+
+# Copy the workspace manifest and every workspace member. Cargo must be able to
+# load the WHOLE workspace even though only mw-server is built, so the engine,
+# server and cli trees are all present.
+COPY Cargo.toml Cargo.lock ./
+COPY engine ./engine
+COPY server ./server
+COPY cli ./cli
+
+# --locked keeps the build reproducible against the committed Cargo.lock. The
+# postgres feature is on by default in server/Cargo.toml, so MW_DATABASE_URL works.
+RUN cargo build --release --locked -p mw-server
+
+# ---- runtime ----------------------------------------------------------------
+FROM debian:bookworm-slim AS runtime
+
+# ca-certificates is the system trust store that rustls-native-certs reads to
+# verify the TLS certificate of the PostgreSQL server; it is the only package the
+# runtime image needs. Create a dedicated non-root user for the service.
+RUN apt-get update \
+    && apt-get install -y --no-install-recommends ca-certificates \
+    && rm -rf /var/lib/apt/lists/* \
+    && groupadd --system --gid 65532 mw \
+    && useradd --system --uid 65532 --gid 65532 --no-create-home \
+        --home-dir /nonexistent --shell /usr/sbin/nologin mw
+
+COPY --from=builder /src/target/release/mw-server /usr/local/bin/mw-server
+COPY deploy/docker-entrypoint.sh /usr/local/bin/docker-entrypoint.sh
+RUN chmod +x /usr/local/bin/docker-entrypoint.sh
+
+# /data is the writable volume (SQLite database and gate evidence). These
+# defaults make the SQLite path work with no extra configuration once /data is
+# mounted; the chart and compose file mount a read-write volume here.
+WORKDIR /data
+ENV MW_DB=/data/modelwrite.db \
+    MW_EVIDENCE_DIR=/data/evidence
+
+USER 65532:65532
+
+EXPOSE 8080
+ENTRYPOINT ["/usr/local/bin/docker-entrypoint.sh"]

## FILE: deploy/README.md

diff --git a/deploy/README.md b/deploy/README.md
new file mode 100644
index 0000000..f0f9b7c
--- /dev/null
+++ b/deploy/README.md
@@ -0,0 +1,130 @@
+# Deploying modelwrite
+
+This directory turns the repository into software an organisation can install: a
+container image, a Docker Compose trial stack, and a Helm chart for Kubernetes.
+
+**WARNING — OPEN MODE. mw-server runs WITHOUT authentication when neither a token
+nor a JWKS is configured, and in that mode every request is accepted as an
+anonymous administrator. The container image refuses to start in that state
+unless the operator sets `MW_ALLOW_OPEN=yes` explicitly. Never run anything
+reachable by more than one person without `MW_AUTH_TOKEN` (a shared bearer
+token) or `MW_AUTH_JWKS` (a JWKS file for signed JWTs).**
+
+## What was and was not verified
+
+- **Verified here:** every YAML file in this directory parses cleanly, the Helm
+  templates are well-formed, and the Kubernetes API fields used are real for
+  `apps/v1`/`v1` (see `deploy/README.md` "Validation" below).
+- **NOT verified here:** the image was **never built** and the chart was **never
+  installed**. This machine has no Docker and no Kubernetes cluster, so none of
+  these files has been run. The Dockerfile's stages, paths and commands are
+  consistent by inspection only; a build failure would surface the first time the
+  image is actually built in CI or on an operator's machine.
+
+## What the chart does NOT do
+
+Operate on the truth, not on a wish list. This chart does **not** provide:
+
+- **TLS termination** — the service speaks plain HTTP on port 8080 and expects a
+  proxy/ingress in front of it. No certificate management is included.
+- **Backups** — the PostgreSQL data and the evidence volume are not backed up.
+  You are responsible for database backups and for keeping the gate evidence.
+- **High availability** — one replica, no leader election, no failover. The
+  SQLite backend is a single file and must never be shared between replicas.
+- **Secret management** — the chart references Secrets by name but does not
+  create or rotate them (see `templates/secret.yaml.example`).
+- **Database migration jobs or a managed database** — it expects an existing
+  PostgreSQL URL (or falls back to SQLite on the persistent volume).
+
+## The container image
+
+Build from the repository root (the build context is the root, not `deploy/`):
+
+    docker build -f deploy/Dockerfile -t modelwrite/modelwrite:0.1.0 .
+
+- Multi-stage: the binary is compiled in a `rust` image and copied into a slim
+  `debian:bookworm-slim` runtime with **no C toolchain**.
+- Runs as a **non-root user** (uid/gid 65532), with a read-only root filesystem
+  where the compose file and chart set `read_only`/`readOnlyRootFilesystem`.
+- The only writable path is `/data` (a volume): the SQLite database and the
+  gate evidence live there.
+- Building the image needs network access to crates.io (or a vendored registry).
+  The *air-gapped* path is about **deploying the already-built image**, described
+  next.
+
+Environment variables (the exact names the server reads): `MW_DATABASE_URL`
+(PostgreSQL URL) or `MW_DB` (SQLite path), `MW_EVIDENCE_DIR`,
+`MW_AUTH_TOKEN`, `MW_AUTH_JWKS` (a file path), `MW_AUTH_ISSUER`,
+`MW_AUTH_AUDIENCE`, `MW_AUTH_ROLES_CLAIM`, `MW_AUTH_PROJECTS_CLAIM`, and
+`MW_PORT`. The entrypoint additionally honours `MW_ALLOW_OPEN=yes` as the
+explicit opt-in to run open.
+
+### Known limitation: the service binds to loopback
+
+As of this tranche, mw-server binds to `127.0.0.1` and there is **no**
+`MW_BIND`/`MW_HOST` variable to change it. Inside a container that means the
+service is reachable only from its own container's network namespace, not through
+the published port (Compose) or the Service (Kubernetes). The probes, the port
+mapping and the Service here are the correct eventual configuration, but until a
+bind-address variable is added to the server they will not carry real traffic.
+This is a server-code change and is deliberately out of scope for this deployment
+task.
+
+## Docker Compose (a trial on one machine)
+
+    export POSTGRES_PASSWORD=...   # a real password, not the literal
+    export MW_AUTH_TOKEN=...       # or: export MW_ALLOW_OPEN=yes  (laptop pilot)
+    docker compose -f deploy/docker-compose.yml up --build
+
+- Brings up `postgres:16` and `mw-server`, with a named volume for the
+  database and one for the server's `/data`.
+- The server refuses to start until `MW_AUTH_TOKEN` (or `MW_ALLOW_OPEN=yes`)
+  is present, by design.
+- The password and token are referenced via environment interpolation, never
+  inlined.
+
+## Helm chart (a real install)
+
+    kubectl create secret generic modelwrite-secrets \
+      --from-literal=auth-token=... \
+      --from-file=jwks.json=... \           # or the bearer token, one of the two
+      --from-literal=database-url=postgres://...
+
+    helm install modelwrite deploy/helm/modelwrite \
+      --set auth.tokenSecret=modelwrite-secrets \
+      --set database.urlSecret=modelwrite-secrets
+
+- Secrets are referenced by name (`auth.tokenSecret`, `auth.jwksSecret`,
+  `database.urlSecret`) and never inlined in `values.yaml`; see
+  `templates/secret.yaml.example` for the exact keys.
+- Liveness and readiness probes both hit `GET /health`, which reports the auth
+  mode, so an accidentally-open deployment is visible to monitoring.
+- Resource requests and limits are set in `values.yaml`.
+- Leave `database.urlSecret` empty to run on SQLite at `/data/modelwrite.db`.
+
+## Air-gapped install
+
+An air-gapped site has no pull access to a registry and may have no PostgreSQL.
+Install the already-built image and its identity material:
+
+1. **Transfer the image** — `docker save` it on a connected machine, carry the
+   tar, and `docker load` it on the isolated host (or use a private registry on
+   the isolated network).
+2. **Mount the JWKS** — place the JWKS file where the container can read it and
+   point `MW_AUTH_JWKS` at its path (the chart mounts a `jwksSecret` at
+   `/jwks`). This is the air-gapped identity path: signed JWTs, verified
+   locally, no network identity provider.
+3. **Use a local database or none** — set `MW_DATABASE_URL` to a local
+   PostgreSQL, or omit it and let the service run on SQLite at `/data/modelwrite.db`.
+
+The gate evidence (`MW_EVIDENCE_DIR`) is written to `/data/evidence` and must
+be on a volume you back up.
+
+## Validation
+
+Performed with Python's PyYAML (6.0.3): `docker-compose.yml`, `Chart.yaml`,
+`values.yaml` and `templates/secret.yaml.example` all parse as YAML. The
+Go-template files (`deployment.yaml`, `service.yaml`, `configmap.yaml`,
+`pvc.yaml`, `_helpers.tpl`) were reviewed for well-formed output; they cannot
+be parsed as YAML before Helm renders them, and Helm is not installed here. The
+Kubernetes API versions used (`apps/v1`, `v1`) are stable and long-supported.

## FILE: deploy/docker-compose.yml

diff --git a/deploy/docker-compose.yml b/deploy/docker-compose.yml
new file mode 100644
index 0000000..1727713
--- /dev/null
+++ b/deploy/docker-compose.yml
@@ -0,0 +1,59 @@
+# SPDX-License-Identifier: AGPL-3.0-or-later
+# Trial stack: mw-server plus PostgreSQL, with named volumes for data.
+#
+# This is a TRIAL, not production: no TLS termination, no backups, no high
+# availability, no secret management. The image refuses to start with no
+# authentication configured, so set MW_AUTH_TOKEN (recommended) or
+# MW_ALLOW_OPEN=yes (laptop pilot only) in the environment or a .env file before
+# running `docker compose up`.
+
+services:
+  db:
+    image: postgres:16-alpine
+    restart: unless-stopped
+    environment:
+      # Never inline a real password here; it is interpolated from the environment.
+      POSTGRES_USER: modelwrite
+      POSTGRES_DB: modelwrite
+      POSTGRES_PASSWORD: ${POSTGRES_PASSWORD:?set POSTGRES_PASSWORD in the environment or .env}
+    volumes:
+      - pgdata:/var/lib/postgresql/data
+    healthcheck:
+      test: ["CMD-SHELL", "pg_isready -U modelwrite -d modelwrite"]
+      interval: 5s
+      timeout: 5s
+      retries: 12
+
+  server:
+    build:
+      context: ..
+      dockerfile: deploy/Dockerfile
+    image: modelwrite/modelwrite:local
+    restart: unless-stopped
+    depends_on:
+      db:
+        condition: service_healthy
+    environment:
+      # The database password appears only via interpolation; the token is read from
+      # the environment and never inlined. With neither MW_AUTH_TOKEN nor
+      # MW_ALLOW_OPEN=yes the entrypoint refuses to start (by design).
+      # A container must listen beyond loopback to be reachable at all. The server
+      # defaults to 127.0.0.1, which is right for a laptop and useless in a container.
+      MW_BIND: 0.0.0.0
+      MW_DATABASE_URL: postgres://modelwrite:${POSTGRES_PASSWORD:?set POSTGRES_PASSWORD}@db:5432/modelwrite
+      MW_AUTH_TOKEN: ${MW_AUTH_TOKEN:-}
+      MW_ALLOW_OPEN: ${MW_ALLOW_OPEN:-}
+      MW_EVIDENCE_DIR: /data/evidence
+    volumes:
+      - data:/data
+    ports:
+      - "8080:8080"
+    read_only: true
+    tmpfs:
+      - /tmp
+    security_opt:
+      - no-new-privileges:true
+
+volumes:
+  pgdata:
+  data:

## FILE: deploy/docker-entrypoint.sh

diff --git a/deploy/docker-entrypoint.sh b/deploy/docker-entrypoint.sh
new file mode 100644
index 0000000..02baf03
--- /dev/null
+++ b/deploy/docker-entrypoint.sh
@@ -0,0 +1,36 @@
+#!/bin/sh
+# SPDX-License-Identifier: AGPL-3.0-or-later
+# Entrypoint for the modelwrite service image.
+#
+# mw-server runs in OPEN mode when neither MW_AUTH_TOKEN nor MW_AUTH_JWKS is
+# configured, which accepts every request as an anonymous administrator. That is
+# correct for a pilot on a laptop and wrong for anything exposed, so this
+# entrypoint REFUSES to start unless authentication is configured OR the operator
+# sets MW_ALLOW_OPEN=yes explicitly. A production service must not be able to run
+# unauthenticated by accident.
+set -eu
+
+# Blank when empty or whitespace-only, matching the server's trim().is_empty().
+# This keeps the gate consistent with how mw-server itself decides there is no
+# credential: a whitespace-only MW_AUTH_TOKEN is NOT a token.
+is_blank() {
+    case "$1" in
+        *[![:space:]]*) return 1 ;;  # has a non-whitespace character
+        *) return 0 ;;               # empty or whitespace only
+    esac
+}
+
+if is_blank "${MW_AUTH_TOKEN:-}" && is_blank "${MW_AUTH_JWKS:-}"; then
+    if [ "${MW_ALLOW_OPEN:-}" != "yes" ]; then
+        cat >&2 <<'EOF'
+REFUSING TO START: no authentication is configured.
+mw-server runs in OPEN mode with no credential, which accepts every request as
+an anonymous administrator. Set MW_AUTH_TOKEN to require a shared bearer token,
+or MW_AUTH_JWKS to the path of a JWKS file to require signed JWTs. To run open on
+purpose (a laptop pilot only), set MW_ALLOW_OPEN=yes.
+EOF
+        exit 1
+    fi
+fi
+
+exec /usr/local/bin/mw-server "$@"

## FILE: deploy/helm/modelwrite/Chart.yaml

diff --git a/deploy/helm/modelwrite/Chart.yaml b/deploy/helm/modelwrite/Chart.yaml
new file mode 100644
index 0000000..b7af98b
--- /dev/null
+++ b/deploy/helm/modelwrite/Chart.yaml
@@ -0,0 +1,7 @@
+# SPDX-License-Identifier: AGPL-3.0-or-later
+apiVersion: v2
+name: modelwrite
+description: Modelwrite repository service (mw-server) backed by PostgreSQL or SQLite.
+type: application
+version: 0.1.0
+appVersion: "0.1.0"

## FILE: deploy/helm/modelwrite/templates/_helpers.tpl

diff --git a/deploy/helm/modelwrite/templates/_helpers.tpl b/deploy/helm/modelwrite/templates/_helpers.tpl
new file mode 100644
index 0000000..8937386
--- /dev/null
+++ b/deploy/helm/modelwrite/templates/_helpers.tpl
@@ -0,0 +1,30 @@
+{{/* SPDX-License-Identifier: AGPL-3.0-or-later */}}
+{{- define "modelwrite.name" -}}
+{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
+{{- end -}}
+
+{{- define "modelwrite.fullname" -}}
+{{- if .Values.fullnameOverride -}}
+{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
+{{- else -}}
+{{- $name := default .Chart.Name .Values.nameOverride -}}
+{{- if contains $name .Release.Name -}}
+{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
+{{- else -}}
+{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
+{{- end -}}
+{{- end -}}
+{{- end -}}
+
+{{- define "modelwrite.labels" -}}
+helm.sh/chart: {{ printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
+app.kubernetes.io/name: {{ include "modelwrite.name" . }}
+app.kubernetes.io/instance: {{ .Release.Name }}
+app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
+app.kubernetes.io/managed-by: {{ .Release.Service }}
+{{- end -}}
+
+{{- define "modelwrite.selectorLabels" -}}
+app.kubernetes.io/name: {{ include "modelwrite.name" . }}
+app.kubernetes.io/instance: {{ .Release.Name }}
+{{- end -}}

## FILE: deploy/helm/modelwrite/templates/configmap.yaml

diff --git a/deploy/helm/modelwrite/templates/configmap.yaml b/deploy/helm/modelwrite/templates/configmap.yaml
new file mode 100644
index 0000000..51a0ac5
--- /dev/null
+++ b/deploy/helm/modelwrite/templates/configmap.yaml
@@ -0,0 +1,17 @@
+# SPDX-License-Identifier: AGPL-3.0-or-later
+apiVersion: v1
+kind: ConfigMap
+metadata:
+  name: {{ include "modelwrite.fullname" . }}
+  labels:
+    {{- include "modelwrite.labels" . | nindent 4 }}
+data:
+  # The server defaults to binding loopback, which is correct on a laptop and useless in a
+  # pod: without this the Service and the probes would have nobody to reach.
+  MW_BIND: "0.0.0.0"
+  MW_PORT: {{ .Values.service.port | quote }}
+  MW_EVIDENCE_DIR: {{ printf "%s/evidence" .Values.persistence.mountPath | quote }}
+  MW_AUTH_ISSUER: {{ .Values.auth.issuer | quote }}
+  MW_AUTH_AUDIENCE: {{ .Values.auth.audience | quote }}
+  MW_AUTH_ROLES_CLAIM: {{ .Values.auth.rolesClaim | quote }}
+  MW_AUTH_PROJECTS_CLAIM: {{ .Values.auth.projectsClaim | quote }}

## FILE: deploy/helm/modelwrite/templates/deployment.yaml

diff --git a/deploy/helm/modelwrite/templates/deployment.yaml b/deploy/helm/modelwrite/templates/deployment.yaml
new file mode 100644
index 0000000..67cd538
--- /dev/null
+++ b/deploy/helm/modelwrite/templates/deployment.yaml
@@ -0,0 +1,113 @@
+# SPDX-License-Identifier: AGPL-3.0-or-later
+apiVersion: apps/v1
+kind: Deployment
+metadata:
+  name: {{ include "modelwrite.fullname" . }}
+  labels:
+    {{- include "modelwrite.labels" . | nindent 4 }}
+spec:
+  replicas: {{ .Values.replicaCount }}
+  selector:
+    matchLabels:
+      {{- include "modelwrite.selectorLabels" . | nindent 6 }}
+  template:
+    metadata:
+      labels:
+        {{- include "modelwrite.selectorLabels" . | nindent 8 }}
+      {{- with .Values.podAnnotations }}
+      annotations:
+        {{- toYaml . | nindent 8 }}
+      {{- end }}
+    spec:
+      securityContext:
+        {{- toYaml .Values.podSecurityContext | nindent 8 }}
+      containers:
+        - name: mw-server
+          image: "{{ .Values.image.repository }}:{{ .Values.image.tag | default .Chart.AppVersion }}"
+          imagePullPolicy: {{ .Values.image.pullPolicy }}
+          securityContext:
+            {{- toYaml .Values.containerSecurityContext | nindent 12 }}
+          ports:
+            - name: http
+              containerPort: {{ .Values.service.port }}
+              protocol: TCP
+          envFrom:
+            - configMapRef:
+                name: {{ include "modelwrite.fullname" . }}
+          env:
+            {{- if .Values.database.urlSecret }}
+            - name: MW_DATABASE_URL
+              valueFrom:
+                secretKeyRef:
+                  name: {{ .Values.database.urlSecret }}
+                  key: {{ .Values.database.urlKey }}
+            {{- else }}
+            - name: MW_DB
+              value: {{ printf "%s/modelwrite.db" .Values.persistence.mountPath | quote }}
+            {{- end }}
+            {{- if .Values.auth.tokenSecret }}
+            - name: MW_AUTH_TOKEN
+              valueFrom:
+                secretKeyRef:
+                  name: {{ .Values.auth.tokenSecret }}
+                  key: {{ .Values.auth.tokenKey }}
+            {{- end }}
+            {{- if .Values.auth.jwksSecret }}
+            - name: MW_AUTH_JWKS
+              value: {{ printf "/jwks/%s" .Values.auth.jwksKey | quote }}
+            {{- end }}
+            {{- if .Values.auth.allowOpen }}
+            - name: MW_ALLOW_OPEN
+              value: "yes"
+            {{- end }}
+          volumeMounts:
+            - name: data
+              mountPath: {{ .Values.persistence.mountPath }}
+            {{- if .Values.auth.jwksSecret }}
+            - name: jwks
+              mountPath: /jwks
+              readOnly: true
+            {{- end }}
+          livenessProbe:
+            httpGet:
+              path: /health
+              port: http
+            initialDelaySeconds: 5
+            periodSeconds: 10
+            timeoutSeconds: 3
+            failureThreshold: 3
+          readinessProbe:
+            httpGet:
+              path: /health
+              port: http
+            initialDelaySeconds: 2
+            periodSeconds: 5
+            timeoutSeconds: 3
+            failureThreshold: 3
+          resources:
+            {{- toYaml .Values.resources | nindent 12 }}
+      volumes:
+        - name: data
+          {{- if .Values.persistence.enabled }}
+          persistentVolumeClaim:
+            claimName: {{ include "modelwrite.fullname" . }}
+          {{- else }}
+          emptyDir: {}
+          {{- end }}
+        {{- if .Values.auth.jwksSecret }}
+        - name: jwks
+          secret:
+            secretName: {{ .Values.auth.jwksSecret }}
+        {{- end }}
+      {{- with .Values.nodeSelector }}
+      nodeSelector:
+        {{- toYaml . | nindent 8 }}
+      {{- end }}
+      {{- with .Values.affinity }}
+      affinity:
+        {{- toYaml . | nindent 8 }}
+      {{- end }}
+      {{- with .Values.tolerations }}
+      tolerations:
+        {{- toYaml . | nindent 8 }}
+      {{- end }}

## FILE: deploy/helm/modelwrite/templates/pvc.yaml

diff --git a/deploy/helm/modelwrite/templates/pvc.yaml b/deploy/helm/modelwrite/templates/pvc.yaml
new file mode 100644
index 0000000..9d69b20
--- /dev/null
+++ b/deploy/helm/modelwrite/templates/pvc.yaml
@@ -0,0 +1,18 @@
+# SPDX-License-Identifier: AGPL-3.0-or-later
+{{- if .Values.persistence.enabled }}
+apiVersion: v1
+kind: PersistentVolumeClaim
+metadata:
+  name: {{ include "modelwrite.fullname" . }}
+  labels:
+    {{- include "modelwrite.labels" . | nindent 4 }}
+spec:
+  accessModes:
+    - {{ .Values.persistence.accessMode | quote }}
+  {{- if .Values.persistence.storageClass }}
+  storageClassName: {{ .Values.persistence.storageClass | quote }}
+  {{- end }}
+  resources:
+    requests:
+      storage: {{ .Values.persistence.size | quote }}
+{{- end }}

## FILE: deploy/helm/modelwrite/templates/secret.yaml.example

diff --git a/deploy/helm/modelwrite/templates/secret.yaml.example b/deploy/helm/modelwrite/templates/secret.yaml.example
new file mode 100644
index 0000000..b138bec
--- /dev/null
+++ b/deploy/helm/modelwrite/templates/secret.yaml.example
@@ -0,0 +1,25 @@
+# SPDX-License-Identifier: AGPL-3.0-or-later
+# EXAMPLE ONLY - not installed by Helm (the .example extension is ignored by the
+# template loader). Copy this to a real Secret and fill in real values with your
+# secret manager (or `kubectl create secret`); never commit the filled-in copy.
+#
+# The chart reads these keys by NAME, all optional except that the pod will not
+# start with no auth configured unless MW_ALLOW_OPEN=yes:
+#   auth.tokenSecret  -> stringData.auth-token   (MW_AUTH_TOKEN)
+#   auth.jwksSecret   -> stringData.jwks.json    (MW_AUTH_JWKS, mounted at /jwks)
+#   database.urlSecret -> stringData.database-url (MW_DATABASE_URL)
+apiVersion: v1
+kind: Secret
+metadata:
+  name: modelwrite-secrets
+type: Opaque
+stringData:
+  # A shared bearer token: any high-entropy string. Alternative to the JWKS.
+  auth-token: "CHANGE-ME"
+  # The JWKS document (public signing keys) for JWT identity. This is the
+  # air-gapped identity path: ship the JWKS file alongside the image.
+  jwks.json: |
+    {"keys": []}
+  # A libpq-style PostgreSQL URL including the password. Required for PostgreSQL;
+  # omit it (and the chart's database.urlSecret) for SQLite.
+  database-url: "postgres://modelwrite:CHANGE-ME@postgres:5432/modelwrite"

## FILE: deploy/helm/modelwrite/templates/service.yaml

diff --git a/deploy/helm/modelwrite/templates/service.yaml b/deploy/helm/modelwrite/templates/service.yaml
new file mode 100644
index 0000000..6b41202
--- /dev/null
+++ b/deploy/helm/modelwrite/templates/service.yaml
@@ -0,0 +1,16 @@
+# SPDX-License-Identifier: AGPL-3.0-or-later
+apiVersion: v1
+kind: Service
+metadata:
+  name: {{ include "modelwrite.fullname" . }}
+  labels:
+    {{- include "modelwrite.labels" . | nindent 4 }}
+spec:
+  type: {{ .Values.service.type }}
+  selector:
+    {{- include "modelwrite.selectorLabels" . | nindent 4 }}
+  ports:
+    - name: http
+      port: {{ .Values.service.port }}
+      targetPort: http
+      protocol: TCP

## FILE: deploy/helm/modelwrite/values.yaml

diff --git a/deploy/helm/modelwrite/values.yaml b/deploy/helm/modelwrite/values.yaml
new file mode 100644
index 0000000..546d4a6
--- /dev/null
+++ b/deploy/helm/modelwrite/values.yaml
@@ -0,0 +1,87 @@
+# SPDX-License-Identifier: AGPL-3.0-or-later
+# Default values for the modelwrite chart.
+#
+# Secrets are NEVER inlined here. The bearer token, the JWKS document and the
+# database URL (which contains a password) are referenced by the NAME of an
+# existing Secret that the operator creates; see templates/secret.yaml.example
+# for the exact keys this chart reads.
+
+# Single instance. The service has no leader election and no shared write path
+# (the SQLite backend is one file), so leave this at 1: this chart does NOT do
+# high availability.
+replicaCount: 1
+
+image:
+  repository: modelwrite/modelwrite
+  # Empty means "use the chart's appVersion".
+  tag: ""
+  pullPolicy: IfNotPresent
+
+nameOverride: ""
+fullnameOverride: ""
+
+# The image refuses to start in open mode unless MW_ALLOW_OPEN is exactly "yes".
+# Set allowOpen only for a private, single-user pilot.
+auth:
+  allowOpen: false
+  # Shared bearer token (MW_AUTH_TOKEN), read from an existing Secret. Leave empty
+  # to disable. Exactly one of tokenSecret / jwksSecret should be set.
+  tokenSecret: ""     # Secret name
+  tokenKey: "auth-token"
+  # JWKS document (MW_AUTH_JWKS) mounted from an existing Secret, for JWT identity.
+  # This is the air-gapped identity path: ship the JWKS file alongside the image.
+  jwksSecret: ""      # Secret name
+  jwksKey: "jwks.json"
+  # JWT claim configuration (only read when jwksSecret is set).
+  issuer: ""
+  audience: ""
+  rolesClaim: "roles"
+  projectsClaim: "projects"
+
+database:
+  # MW_DATABASE_URL carries a password, so it is read from a Secret, never a value.
+  urlSecret: ""       # Secret name; when set, the service uses PostgreSQL.
+  urlKey: "database-url"
+  # When urlSecret is empty the service runs on SQLite at /data/modelwrite.db
+  # (the air-gapped, no-database path).
+
+persistence:
+  enabled: true
+  storageClass: ""
+  accessMode: ReadWriteOnce
+  size: 1Gi
+  mountPath: /data
+
+service:
+  type: ClusterIP
+  port: 8080
+
+resources:
+  requests:
+    cpu: 100m
+    memory: 128Mi
+  limits:
+    cpu: "1"
+    memory: 512Mi
+
+# uid/gid 65532 match the non-root user baked into the image; fsGroup makes the
+# /data volume writable by that user.
+podSecurityContext:
+  runAsNonRoot: true
+  runAsUser: 65532
+  runAsGroup: 65532
+  fsGroup: 65532
+  seccompProfile:
+    type: RuntimeDefault
+
+containerSecurityContext:
+  allowPrivilegeEscalation: false
+  readOnlyRootFilesystem: true
+  capabilities:
+    drop:
+      - ALL
+
+nodeSelector: {}
+tolerations: []
+affinity: {}
+podAnnotations: {}

## FILE: server/src/lib.rs

diff --git a/server/src/lib.rs b/server/src/lib.rs
index 29d607d..117997a 100644
--- a/server/src/lib.rs
+++ b/server/src/lib.rs
@@ -83,12 +83,38 @@ pub fn app(state: AppState) -> Router {
             "/projects/:project/locks/release",
             post(locks_api::release_locks),
         )
         .with_state(api_state)
 }
 
+/// Resolve the address the service binds to, and refuse the combination that leaks a
+/// system of record: listening beyond loopback while authentication is not configured, so
+/// every request would be an anonymous admin.
+///
+/// The default stays loopback on purpose. A container must say MW_BIND=0.0.0.0 to be
+/// reachable, which makes exposure a deliberate line in a deployment file rather than
+/// something that happens the first time the service starts.
+pub fn resolve_bind(
+    host: &str,
+    auth_is_open: bool,
+    allow_open: bool,
+) -> anyhow::Result<std::net::IpAddr> {
+    let ip: std::net::IpAddr = host
+        .parse()
+        .map_err(|_| anyhow::anyhow!("MW_BIND must be an IP address, got {}", host))?;
+    if auth_is_open && !ip.is_loopback() && !allow_open {
+        anyhow::bail!(
+            "refusing to bind {} while authentication is not configured: every request \
+             would be an anonymous admin. Configure MW_AUTH_TOKEN or MW_AUTH_JWKS, bind \
+             loopback, or set MW_ALLOW_OPEN=yes to accept the risk deliberately.",
+            ip
+        );
+    }
+    Ok(ip)
+}
+
 /// Liveness. Public on purpose: it never reaches the store, and it needs no token - a
 /// health check that requires a credential fails exactly during the incident it exists to
 /// detect. It reports the AUTH MODE so a deployment that forgot to configure authentication
 /// is visible to monitoring rather than only in a stderr line; it reports the mode ONLY,
 /// never a token, a key or a path.
 async fn health(State(state): State<api::ApiState>) -> Json<serde_json::Value> {

## FILE: server/src/main.rs

diff --git a/server/src/main.rs b/server/src/main.rs
index aa408e2..8933a7c 100644
--- a/server/src/main.rs
+++ b/server/src/main.rs
@@ -29,14 +29,24 @@ async fn main() -> anyhow::Result<()> {
              every request is accepted as an anonymous admin. Set MW_AUTH_TOKEN to \
              require a shared bearer token, or MW_AUTH_JWKS to the path of a JWKS \
              file to require signed JWTs."
         );
     }
 
+    // The bind address is configurable, but the DEFAULT stays loopback: a service that
+    // listens on every interface the moment it starts is a service that is exposed by
+    // accident. A container must set MW_BIND=0.0.0.0 to be reachable, which is a deliberate
+    // act in a deployment file rather than a silent default.
+    let host = std::env::var("MW_BIND").unwrap_or_else(|_| "127.0.0.1".to_string());
+    let allow_open = std::env::var("MW_ALLOW_OPEN")
+        .map(|v| v.eq_ignore_ascii_case("yes"))
+        .unwrap_or(false);
+    let ip = server::resolve_bind(&host, matches!(&auth, AuthConfig::Open), allow_open)?;
+
     let store = store::open_store(&config)?;
-    let addr = SocketAddr::from(([127, 0, 0, 1], port));
+    let addr = SocketAddr::new(ip, port);
     let listener = tokio::net::TcpListener::bind(addr).await?;
     // Never print a connection URL: it can carry a password. Report the backend and, for
     // SQLite, the path.
     let db_desc = match &config {
         StoreConfig::Sqlite(path) => path.display().to_string(),
         StoreConfig::Postgres(_) => "postgres".to_string(),

## FILE: server/tests/http.rs

diff --git a/server/tests/http.rs b/server/tests/http.rs
index b9b572c..7ca6050 100644
--- a/server/tests/http.rs
+++ b/server/tests/http.rs
@@ -83,6 +83,35 @@ async fn version_names_the_service() {
     assert_eq!(response.status(), StatusCode::OK);
     let bytes = response.into_body().collect().await.unwrap().to_bytes();
     let value: serde_json::Value = serde_json::from_slice(&bytes).unwrap();
     assert_eq!(value["service"], "mw-server");
     assert_eq!(value["server"], env!("CARGO_PKG_VERSION"));
 }
+#[test]
+fn the_bind_rule_refuses_to_expose_an_unauthenticated_service() {
+    // Open mode plus an interface anyone can route to means every request is an anonymous
+    // admin. The combination is refused unless the operator says so explicitly, and the
+    // safe default stays loopback.
+    use server::resolve_bind;
+
+    // Loopback is always allowed, authenticated or not.
+    assert!(resolve_bind("127.0.0.1", true, false).is_ok());
+    assert!(resolve_bind("127.0.0.1", false, false).is_ok());
+
+    // Beyond loopback WITH authentication is fine: the container case.
+    assert!(resolve_bind("0.0.0.0", false, false).is_ok());
+
+    // Beyond loopback WITHOUT authentication is refused...
+    let refused = resolve_bind("0.0.0.0", true, false);
+    assert!(
+        refused.is_err(),
+        "exposing an unauthenticated service must be refused"
+    );
+    let message = refused.unwrap_err().to_string();
+    assert!(message.contains("anonymous admin"), "got: {}", message);
+
+    // ...unless it is deliberate.
+    assert!(resolve_bind("0.0.0.0", true, true).is_ok());
+
+    // And a value that is not an address is a clear error, not a panic.
+    assert!(resolve_bind("not-an-address", false, false).is_err());
+}
