# Fix Round 1 — Slice 2 Tranche 5 (PostgreSQL backend)

Status: DONE_WITH_CONCERNS

## Commits

- `5e77752` fix: one lock holder per element, enforced by a UNIQUE constraint in the database

## Test summary

`cargo test --workspace --exclude mw-cli --no-fail-fast` → 166 passed, 0 failed, **13 ignored**.
The 13 ignored tests are the PostgreSQL suite: 12 carried over plus 1 new concurrent-acquire test.
They are now reported by libtest as IGNORED (not falsely as "passed"), and they did NOT run —
there is no PostgreSQL on this machine.

Per-binary counts (17 non-empty test binaries):
engine 44 — capi 4, gate 5, graph 7, mcp 13, okf_diff 8, okf_validation 7.
service 122 passed + 13 ignored — server lib 14, api 11, audit 12, auth 32, corpus 1,
gate_api 3, http 3, locks 15, merge 15, merge_api 4, postgres 13 (all ignored), store 12.

`cargo fmt --all` clean (exit 0, `--check` confirms). `cargo clippy --workspace --exclude mw-cli
--all-targets -- -D warnings` clean (exit 0).

## Findings closed

### Critical — two holders can win the same lock lease

The locks table now carries `UNIQUE (project, element)`, so "one holder per element" is a
property of the DATABASE, not of the acquire code. The redundant `locks_element` index was
dropped (the unique constraint supplies that index). `acquire_locks` is now a single
`INSERT ... ON CONFLICT (project, element) DO UPDATE ... WHERE locks.holder = EXCLUDED.holder
RETURNING id, acquired_at` per element: a fresh lease inserts, the same holder's re-acquire
extends (keeping the original id and acquired_at), and a different holder's DO UPDATE fails its
holder test and returns no row — the code then reports the holder that won and returns
`StoreError::Locked`, which rolls back the whole transaction. Acquiring is therefore all-or-
nothing, and re-acquiring your OWN lease extends rather than conflicts, matching SQLite. No
`pg_advisory_xact_lock` was added: the constraint is the guarantee, and it holds even if a
future code path forgets to check.

Added `two_concurrent_acquires_by_different_holders_cannot_both_succeed`: two holders race for
one element; exactly one wins and the loser is refused with the winner's identity.

### Important — the skip was invisible in normal output

Every Postgres test is now `#[ignore = "requires MW_TEST_DATABASE_URL"]`; `require_store()`
returns `PostgresStore` and panics (not skips) when `MW_TEST_DATABASE_URL` is unset, empty or
unreachable. A plain `cargo test` reports them as IGNORED, which is the truth; the env var now
only supplies the URL when the ignored tests are run with `--include-ignored`.

Exact command for a developer who HAS a database:

```
MW_TEST_DATABASE_URL='postgres://user:pass@host/db' cargo test -p mw-server --test postgres -- --include-ignored
```

(PowerShell: `$env:MW_TEST_DATABASE_URL='postgres://user:pass@host/db'; cargo test -p mw-server --test postgres -- --include-ignored`)

### M1 — commits.id had no PRIMARY KEY / UNIQUE

`commits.id` is now `BIGSERIAL PRIMARY KEY` and `hash` is `TEXT NOT NULL UNIQUE`, so the
insertion-order id is keyed and the content address stays unique. (A table can have only one
PRIMARY KEY, so `hash` moved from PRIMARY KEY to UNIQUE.)

### M2 — SslMode::Prefer silently downgraded TLS to plaintext

`SslMode::Prefer` now maps to the TLS path alongside `Require` (the client cannot negotiate
libpq's plaintext fallback, so it honours the preference by requiring TLS). Only `Disable`
uses `NoTls`; `VerifyCa`/full verification remain refused, as before. No silent downgrade.

### M3 — create_branch / delete_branch pre-checks ran outside the write transaction

Both existence checks moved inside `with_tx`: `create_branch` checks the source commit, and
`delete_branch` checks the project, with the same `NotFound`/error wording. Check and write
now see one state.

### M4 — audit clamp and release_locks zero-row audit path

Checked, found NO difference: `audit()` clamps `limit.clamp(1, 1000)` exactly as SQLite does,
and `release_locks` writes its audit entry only when `released > 0`, exactly as SQLite does.
No code change needed.

## Concerns

1. The PostgreSQL backend and its 13 tests still have NOT been executed: this machine has no
   PostgreSQL. They compile and are reported IGNORED; none of the backend's runtime behaviour
   (including the new ON CONFLICT path) was verified by execution. This report must not be read
   as "the Postgres tests passed".
2. A concurrent task is building a `cli/` crate. The workspace root `Cargo.toml` now lists
   `cli` as a member and `cli/src/main.rs` does not yet compile (E0106, missing lifetime), so
   the literal `--workspace` commands cannot run green. I ran the suite and clippy with
   `--exclude mw-cli` and did not stage or modify `Cargo.toml`, `Cargo.lock` or `cli/`.
3. `UNIQUE (project, element)` is added via `CREATE TABLE IF NOT EXISTS`, so it reaches fresh
   databases; there is no Postgres migration framework here and no deployed instance, so an
   existing database would need a manual `ALTER TABLE locks ADD CONSTRAINT`.

## Deviations

- `cargo test` / `cargo clippy` were run with `--exclude mw-cli` rather than the literal
  `--workspace`, because the concurrent cli crate is mid-edit and does not compile. Reason:
  it is out of scope ("do not touch cli") and not my code. Everything else ran exactly as
  specified.
