﻿# Tranche 5 Task 1 review package (PostgreSQL backend)

## Commits under review

a769783 fix: treat nbf as optional and give the audit schema a migration path
db0889f feat: add a PostgreSQL backend behind the store trait

## Diff stat

 Cargo.lock                   | 829 ++++++++++++++++++++++++++++++++++++++--
 server/Cargo.toml            |  21 +
 server/src/auth.rs           |   9 +-
 server/src/main.rs           |  17 +-
 server/src/store/mod.rs      |  47 +++
 server/src/store/postgres.rs | 889 +++++++++++++++++++++++++++++++++++++++++++
 server/src/store/sqlite.rs   |  22 ++
 server/tests/postgres.rs     | 623 ++++++++++++++++++++++++++++++
 server/tests/store.rs        |  39 +-
 9 files changed, 2444 insertions(+), 52 deletions(-)

## Every changed file, in full

## FILE: Cargo.lock

diff --git a/Cargo.lock b/Cargo.lock
index d316edf..f959167 100644
--- a/Cargo.lock
+++ b/Cargo.lock
@@ -128,18 +128,33 @@ version = "0.10.4"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "3078c7629b62d3f0439517fa394996acacc5cbc91c5a20d8c658e77abd503a71"
 dependencies = [
  "generic-array",
 ]
 
+[[package]]
+name = "block-buffer"
+version = "0.12.1"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "d2f6c7dbe95a6ed67ad9f18e57daf93a2f034c524b99fd2b76d18fdfeb6660aa"
+dependencies = [
+ "hybrid-array",
+]
+
 [[package]]
 name = "bumpalo"
 version = "3.20.3"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "72f5acc6cb2ba439de613abc23857ec3d78374d8ed5ac84e9d11336e87da8649"
 
+[[package]]
+name = "byteorder"
+version = "1.5.0"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "1fd0f2584146f6f2ef48085050886acf353beff7305ebd1ae69500e27c67f64b"
+
 [[package]]
 name = "bytes"
 version = "1.12.1"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "fc652a48c352aef3ea3aed32080501cf3ef6ed5da78602a020c991775b0aff04"
 
@@ -156,35 +171,83 @@ dependencies = [
 [[package]]
 name = "cfg-if"
 version = "1.0.5"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "4e7648175b45a9a48536d676f68d918270699102aa8dab5496df06904c914600"
 
+[[package]]
+name = "chacha20"
+version = "0.10.2"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "65c35e4b699c7e15ccbe7ee35c005e4fc0a278d22238a2857e6ce2dadeda1b06"
+dependencies = [
+ "cfg-if",
+ "cpufeatures 0.3.1",
+ "rand_core 0.10.1",
+]
+
+[[package]]
+name = "cmov"
+version = "0.5.4"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "0c9ea0ac24bc397ab3c98583a3c9ba74fa56b09a4449bbe172b9b1ddb016027a"
+
 [[package]]
 name = "const-oid"
 version = "0.9.6"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "c2459377285ad874054d797f3ccebf984978aa39129f6eafde5cdc8315b612f8"
 
+[[package]]
+name = "const-oid"
+version = "0.10.2"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "a6ef517f0926dd24a1582492c791b6a4818a4d94e789a334894aa15b0d12f55c"
+
+[[package]]
+name = "core-foundation"
+version = "0.10.1"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "b2a6cd9ae233e7f62ba4e9353e81a88df7fc8a5987b8d445b4d90c879bd156f6"
+dependencies = [
+ "core-foundation-sys",
+ "libc",
+]
+
+[[package]]
+name = "core-foundation-sys"
+version = "0.8.7"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "773648b94d0e5d620f64f280777445740e61fe701025087ec8b57f45c791888b"
+
 [[package]]
 name = "cpufeatures"
 version = "0.2.17"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "59ed5838eebb26a2bb2e58f6d5b5316989ae9d08bab10e0e6d103e656d1b0280"
 dependencies = [
  "libc",
 ]
 
+[[package]]
+name = "cpufeatures"
+version = "0.3.1"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "5ca28b0ae3115b884660db4118d803791fd6756b6e88f39c0f3f7859060d7566"
+dependencies = [
+ "libc",
+]
+
 [[package]]
 name = "crypto-bigint"
 version = "0.5.5"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "0dc92fb57ca44df6db8059111ab3af99a63d5d0f8375d9972e319a379c6bab76"
 dependencies = [
  "generic-array",
- "rand_core",
+ "rand_core 0.6.4",
  "subtle",
  "zeroize",
 ]
 
 [[package]]
 name = "crypto-common"
@@ -193,22 +256,40 @@ source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "78c8292055d1c1df0cce5d180393dc8cce0abec0a7102adb6c7b1eef6016d60a"
 dependencies = [
  "generic-array",
  "typenum",
 ]
 
+[[package]]
+name = "crypto-common"
+version = "0.2.2"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "ce6e4c961d6cd6c9a86db418387425e8bdeaf05b3c8bc1411e6dca4c252f1453"
+dependencies = [
+ "hybrid-array",
+]
+
+[[package]]
+name = "ctutils"
+version = "0.4.2"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "7d5515a3834141de9eafb9717ad39eea8247b5674e6066c404e8c4b365d2a29e"
+dependencies = [
+ "cmov",
+]
+
 [[package]]
 name = "curve25519-dalek"
 version = "4.1.3"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "97fb8b7c4503de7d6ae7b42ab72a5a59857b4c937ec27a3d4539dba95b5ab2be"
 dependencies = [
  "cfg-if",
- "cpufeatures",
+ "cpufeatures 0.2.17",
  "curve25519-dalek-derive",
- "digest",
+ "digest 0.10.7",
  "fiat-crypto",
  "rustc_version",
  "subtle",
  "zeroize",
 ]
 
@@ -226,43 +307,68 @@ dependencies = [
 [[package]]
 name = "der"
 version = "0.7.10"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "e7c1832837b905bbfb5101e07cc24c8deddf52f93225eee6ead5f4d63d53ddcb"
 dependencies = [
- "const-oid",
+ "const-oid 0.9.6",
+ "der_derive",
+ "flagset",
  "pem-rfc7468",
  "zeroize",
 ]
 
+[[package]]
+name = "der_derive"
+version = "0.7.3"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "8034092389675178f570469e6c3b0465d3d30b4505c294a6550db47f3c17ad18"
+dependencies = [
+ "proc-macro2",
+ "quote",
+ "syn 2.0.119",
+]
+
 [[package]]
 name = "deranged"
 version = "0.5.8"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "7cd812cc2bc1d69d4764bd80df88b4317eaef9e773c75226407d9bc0876b211c"
 
 [[package]]
 name = "digest"
 version = "0.10.7"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "9ed9a281f7bc9b7576e61468ba615a66a5c8cfdff42420a70aa82701a3b1e292"
 dependencies = [
- "block-buffer",
- "const-oid",
- "crypto-common",
+ "block-buffer 0.10.4",
+ "const-oid 0.9.6",
+ "crypto-common 0.1.7",
  "subtle",
 ]
 
+[[package]]
+name = "digest"
+version = "0.11.3"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "f1dd6dbb5841937940781866fa1281a1ff7bd3bf827091440879f9994983d5c2"
+dependencies = [
+ "block-buffer 0.12.1",
+ "const-oid 0.10.2",
+ "crypto-common 0.2.2",
+ "ctutils",
+]
+
 [[package]]
 name = "ecdsa"
 version = "0.16.9"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "ee27f32b5c5292967d2d4a9d7f1e0b0aed2c15daded5a60300e4abb9d8020bca"
 dependencies = [
  "der",
- "digest",
+ "digest 0.10.7",
  "elliptic-curve",
  "rfc6979",
  "signature",
  "spki",
 ]
 
@@ -282,33 +388,33 @@ version = "2.2.0"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "70e796c081cee67dc755e1a36a0a172b897fab85fc3f6bc48307991f64e4eca9"
 dependencies = [
  "curve25519-dalek",
  "ed25519",
  "serde",
- "sha2",
+ "sha2 0.10.9",
  "subtle",
  "zeroize",
 ]
 
 [[package]]
 name = "elliptic-curve"
 version = "0.13.8"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "b5e6043086bf7973472e0c7dff2142ea0b680d30e18d9cc40f267efbf222bd47"
 dependencies = [
  "base16ct",
  "crypto-bigint",
- "digest",
+ "digest 0.10.7",
  "ff",
  "generic-array",
  "group",
  "hkdf",
  "pem-rfc7468",
  "pkcs8",
- "rand_core",
+ "rand_core 0.6.4",
  "sec1",
  "subtle",
  "zeroize",
 ]
 
 [[package]]
@@ -321,15 +427,21 @@ checksum = "877a4ace8713b0bcf2a4e7eec82529c029f1d0619886d18145fea96c3ffe5c0f"
 name = "errno"
 version = "0.3.14"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "39cab71617ae0d63f51a36d69f866391735b51691dbda63cf6f96d042b63efeb"
 dependencies = [
  "libc",
- "windows-sys",
+ "windows-sys 0.61.2",
 ]
 
+[[package]]
+name = "fallible-iterator"
+version = "0.2.0"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "4443176a9f2c162692bd3d352d745ef9413eec5782a80d8fd6f8a1ac692a07f7"
+
 [[package]]
 name = "fallible-iterator"
 version = "0.3.0"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "2acce4a10f12dc2fb14a218589d4f1f62ef011b2d0cc4b3cb1bba8e94da14649"
 
@@ -348,13 +460,13 @@ checksum = "da7c62ceae207dd37ea5b845da6a0696c799f85e97da1ab5b7910be3c1c80223"
 [[package]]
 name = "ff"
 version = "0.13.1"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "c0b50bfb653653f9ca9095b427bed08ab8d75a137839d9ad64eb11810d5b6393"
 dependencies = [
- "rand_core",
+ "rand_core 0.6.4",
  "subtle",
 ]
 
 [[package]]
 name = "fiat-crypto"
 version = "0.2.9"
@@ -370,12 +482,18 @@ checksum = "3e0f1c7c3a72c66fd80abe965175f7523475c0489a87d3ff9d6e8c87d87a9d2d"
 [[package]]
 name = "fixedbitset"
 version = "0.4.2"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "0ce7134b9999ecaf8bcd65542e436736ef32ddca1b3e06094cb6ec5755203b80"
 
+[[package]]
+name = "flagset"
+version = "0.4.7"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "b7ac824320a75a52197e8f2d787f6a38b6718bb6897a35142d749af3c0e8f4fe"
+
 [[package]]
 name = "form_urlencoded"
 version = "1.2.2"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "cb4cb245038516f5f85277875cdaa4f7d2c9a0fa0468de06ed190163b1581fcf"
 dependencies = [
@@ -386,20 +504,27 @@ dependencies = [
 name = "futures-channel"
 version = "0.3.34"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "b1f9e3d69d39e4862ffed03ed071a76f9a13ba1d9109d355b0f0aa6b15e393c4"
 dependencies = [
  "futures-core",
+ "futures-sink",
 ]
 
 [[package]]
 name = "futures-core"
 version = "0.3.34"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "92d699e522242e69e3003b94ecc1f960f3a5e015aa7c5d7486e65ad01dd94f5e"
 
+[[package]]
+name = "futures-sink"
+version = "0.3.34"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "1944426bf7d03f1d14f708785e4b33efd750b36d48a157b836b3efc15ede8e1d"
+
 [[package]]
 name = "futures-task"
 version = "0.3.34"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "cd417de3d1d015fc3bfd2b1ea46dfc7bab72ef86f1cc7cc9c78e728b34a6d1fd"
 
@@ -407,12 +532,13 @@ checksum = "cd417de3d1d015fc3bfd2b1ea46dfc7bab72ef86f1cc7cc9c78e728b34a6d1fd"
 name = "futures-util"
 version = "0.3.34"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "0d50a92467f8ba5dd6e3ee5d4bd04d73ab2e4e1c44474a0674821dfce14b79bc"
 dependencies = [
  "futures-core",
+ "futures-sink",
  "futures-task",
  "pin-project-lite",
  "slab",
 ]
 
 [[package]]
@@ -431,34 +557,35 @@ name = "getrandom"
 version = "0.2.17"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "ff2abc00be7fca6ebc474524697ae276ad847ad0a6b3faa4bcb027e9a4614ad0"
 dependencies = [
  "cfg-if",
  "libc",
- "wasi",
+ "wasi 0.11.1+wasi-snapshot-preview1",
 ]
 
 [[package]]
 name = "getrandom"
 version = "0.4.3"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "300e883d756b2e4ec94e02791f39b04b522276138852cfc41d9fb7e904106099"
 dependencies = [
  "cfg-if",
  "libc",
  "r-efi",
+ "rand_core 0.10.1",
 ]
 
 [[package]]
 name = "group"
 version = "0.13.0"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "f0f9ef7462f7c099f518d754361858f86d8a07af53ba9af0fe635bbccb151a63"
 dependencies = [
  "ff",
- "rand_core",
+ "rand_core 0.6.4",
  "subtle",
 ]
 
 [[package]]
 name = "hashbrown"
 version = "0.14.5"
@@ -492,22 +619,31 @@ checksum = "7f24254aa9a54b5c858eaee2f5bccdb46aaf0e486a595ed5fd8f86ba55232a70"
 [[package]]
 name = "hkdf"
 version = "0.12.4"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "7b5f8eb2ad728638ea2c7d47a21db23b7b58a72ed6a38256b8a1849f15fbbdf7"
 dependencies = [
- "hmac",
+ "hmac 0.12.1",
 ]
 
 [[package]]
 name = "hmac"
 version = "0.12.1"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "6c49c37c09c17a53d937dfbb742eb3a961d65a994e6bcdcf37e7399d0cc8ab5e"
 dependencies = [
- "digest",
+ "digest 0.10.7",
+]
+
+[[package]]
+name = "hmac"
+version = "0.13.0"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "6303bc9732ae41b04cb554b844a762b4115a61bfaa81e3e83050991eeb56863f"
+dependencies = [
+ "digest 0.11.3",
 ]
 
 [[package]]
 name = "http"
 version = "1.5.0"
 source = "registry+https://github.com/rust-lang/crates.io-index"
@@ -549,12 +685,21 @@ checksum = "6dbf3de79e51f3d586ab4cb9d5c3e2c14aa28ed23d180cf89b4df0454a69cc87"
 [[package]]
 name = "httpdate"
 version = "1.0.3"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "df3b46402a9d5adb4c86a0cf463f42e19994e3ee891101b1841f30a545cb49a9"
 
+[[package]]
+name = "hybrid-array"
+version = "0.4.15"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "27f864f10dfb56725ce5ce5472bc52252c8f93a4ab86327122cebf62c5f59a17"
+dependencies = [
+ "typenum",
+]
+
 [[package]]
 name = "hyper"
 version = "1.11.1"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "27b501faa50e7a26c3d3560ca625132f4078a17771f4810baf70475ae48cbe43"
 dependencies = [
@@ -620,22 +765,22 @@ version = "10.3.0"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "0529410abe238729a60b108898784df8984c87f6054c9c4fcacc47e4803c1ce1"
 dependencies = [
  "base64",
  "ed25519-dalek",
  "getrandom 0.2.17",
- "hmac",
+ "hmac 0.12.1",
  "js-sys",
  "p256",
  "p384",
  "pem",
- "rand",
+ "rand 0.8.8",
  "rsa",
  "serde",
  "serde_json",
- "sha2",
+ "sha2 0.10.9",
  "signature",
  "simple_asn1",
 ]
 
 [[package]]
 name = "lazy_static"
@@ -655,12 +800,21 @@ checksum = "3eaf3ede3fee6db1a4c2ee091bf8a8b4dccdc6d17f656fb07896ee72867612f2"
 [[package]]
 name = "libm"
 version = "0.2.16"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "b6d2cec3eae94f9f509c767b45932f1ada8350c4bdb85af2fcab4a3c14807981"
 
+[[package]]
+name = "libredox"
+version = "0.1.24"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "6480ccc157a1389bb2e4891b24751b0f798ba640d22386f23143fbcc89da195a"
+dependencies = [
+ "libc",
+]
+
 [[package]]
 name = "libsqlite3-sys"
 version = "0.28.0"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "0c10584274047cb335c23d3e61bcef8e323adae7c5c8c760540f73610177fc3f"
 dependencies = [
@@ -672,24 +826,43 @@ dependencies = [
 [[package]]
 name = "linux-raw-sys"
 version = "0.12.1"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "32a66949e030da00e8c7d4434b251670a91556f4144941d37452769c25d58a53"
 
+[[package]]
+name = "lock_api"
+version = "0.4.14"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "224399e74b87b5f3557511d98dff8b14089b3dadafcab6bb93eab67d3aace965"
+dependencies = [
+ "scopeguard",
+]
+
 [[package]]
 name = "log"
 version = "0.4.34"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "f9f8bd3e56ce4dfc153cf470fffbfa98c7620958b312ca5c3a4b8d5181fd13c6"
 
 [[package]]
 name = "matchit"
 version = "0.7.3"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "0e7465ac9959cc2b1404e8e2367b43684a6d13790fe23056cc8c6c5a6b7bcb94"
 
+[[package]]
+name = "md-5"
+version = "0.11.0"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "69b6441f590336821bb897fb28fc622898ccceb1d6cea3fde5ea86b090c4de98"
+dependencies = [
+ "cfg-if",
+ "digest 0.11.3",
+]
+
 [[package]]
 name = "memchr"
 version = "2.8.3"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "cf8baf1c55e62ffcace7a9f06f4bd9cd3f0c4beb022d3b367256b91b87513d98"
 
@@ -703,14 +876,14 @@ checksum = "6877bb514081ee2a7ff5ef9de3281f14a4dd4bceac4c09388074a6b5df8a139a"
 name = "mio"
 version = "1.2.3"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "4b18443e9c262bfe8fa82f51666e2642c53393f7e5c27b3e1aeab922cff5b9d8"
 dependencies = [
  "libc",
- "wasi",
- "windows-sys",
+ "wasi 0.11.1+wasi-snapshot-preview1",
+ "windows-sys 0.61.2",
 ]
 
 [[package]]
 name = "mw-capi"
 version = "0.1.0"
 dependencies = [
@@ -758,13 +931,13 @@ name = "mw-okf"
 version = "0.1.0"
 dependencies = [
  "hex",
  "mw-test-support",
  "serde",
  "serde_json",
- "sha2",
+ "sha2 0.10.9",
 ]
 
 [[package]]
 name = "mw-server"
 version = "0.1.0"
 dependencies = [
@@ -773,18 +946,24 @@ dependencies = [
  "hex",
  "http-body-util",
  "jsonwebtoken",
  "mw-gate",
  "mw-okf",
  "mw-test-support",
+ "postgres",
+ "r2d2",
+ "r2d2_postgres",
  "rusqlite",
+ "rustls",
+ "rustls-native-certs",
  "serde",
  "serde_json",
- "sha2",
+ "sha2 0.10.9",
  "tempfile",
  "tokio",
+ "tokio-postgres-rustls",
  "tower 0.4.13",
 ]
 
 [[package]]
 name = "mw-test-support"
 version = "0.1.0"
@@ -807,13 +986,13 @@ checksum = "e661dda6640fad38e827a6d4a310ff4763082116fe217f279885c97f511bb0b7"
 dependencies = [
  "lazy_static",
  "libm",
  "num-integer",
  "num-iter",
  "num-traits",
- "rand",
+ "rand 0.8.8",
  "smallvec",
  "zeroize",
 ]
 
 [[package]]
 name = "num-conv"
@@ -847,40 +1026,87 @@ source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "071dfc062690e90b734c0b2273ce72ad0ffa95f0c74596bc250dcfd960262841"
 dependencies = [
  "autocfg",
  "libm",
 ]
 
+[[package]]
+name = "objc2-core-foundation"
+version = "0.3.2"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "2a180dd8642fa45cdb7dd721cd4c11b1cadd4929ce112ebd8b9f5803cc79d536"
+dependencies = [
+ "bitflags",
+]
+
+[[package]]
+name = "objc2-system-configuration"
+version = "0.3.2"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "7216bd11cbda54ccabcab84d523dc93b858ec75ecfb3a7d89513fa22464da396"
+dependencies = [
+ "objc2-core-foundation",
+]
+
 [[package]]
 name = "once_cell"
 version = "1.21.4"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "9f7c3e4beb33f85d45ae3e3a1792185706c8e16d043238c593331cc7cd313b50"
 
+[[package]]
+name = "openssl-probe"
+version = "0.2.1"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "7c87def4c32ab89d880effc9e097653c8da5d6ef28e6b539d313baaacfbafcbe"
+
 [[package]]
 name = "p256"
 version = "0.13.2"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "c9863ad85fa8f4460f9c48cb909d38a0d689dba1f6f6988a5e3e0d31071bcd4b"
 dependencies = [
  "ecdsa",
  "elliptic-curve",
  "primeorder",
- "sha2",
+ "sha2 0.10.9",
 ]
 
 [[package]]
 name = "p384"
 version = "0.13.1"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "fe42f1670a52a47d448f14b6a5c61dd78fce51856e68edaa38f7ae3a46b8d6b6"
 dependencies = [
  "ecdsa",
  "elliptic-curve",
  "primeorder",
- "sha2",
+ "sha2 0.10.9",
+]
+
+[[package]]
+name = "parking_lot"
+version = "0.12.5"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "93857453250e3077bd71ff98b6a65ea6621a19bb0f559a85248955ac12c45a1a"
+dependencies = [
+ "lock_api",
+ "parking_lot_core",
+]
+
+[[package]]
+name = "parking_lot_core"
+version = "0.9.12"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "2621685985a2ebf1c516881c026032ac7deafcda1a2c9b7850dc81e3dfcb64c1"
+dependencies = [
+ "cfg-if",
+ "libc",
+ "redox_syscall",
+ "smallvec",
+ "windows-link",
 ]
 
 [[package]]
 name = "pem"
 version = "3.0.6"
 source = "registry+https://github.com/rust-lang/crates.io-index"
@@ -912,12 +1138,31 @@ source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "b4c5cc86750666a3ed20bdaf5ca2a0344f9c67674cae0515bec2da16fbaa47db"
 dependencies = [
  "fixedbitset",
  "indexmap",
 ]
 
+[[package]]
+name = "phf"
+version = "0.13.1"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "c1562dc717473dbaa4c1f85a36410e03c047b2e7df7f45ee938fbef64ae7fadf"
+dependencies = [
+ "phf_shared",
+ "serde",
+]
+
+[[package]]
+name = "phf_shared"
+version = "0.13.1"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "e57fef6bc5981e38c2ce2d63bfa546861309f875b8a75f092d1d54ae2d64f266"
+dependencies = [
+ "siphasher",
+]
+
 [[package]]
 name = "pin-project"
 version = "1.1.13"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "2466b2336ed02bcdca6b294417127b90ec92038d1d5c4fbeac971a922e0e0924"
 dependencies = [
@@ -965,12 +1210,55 @@ dependencies = [
 [[package]]
 name = "pkg-config"
 version = "0.3.34"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "f6b464fbc74e149a392436b17d523f769e057cb6877f6a5c4618bc6f11800548"
 
+[[package]]
+name = "postgres"
+version = "0.19.14"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "33ad20e0aa0b24f5a394eab4f78c781d248982b22b25cecc7e3aa46a681605bd"
+dependencies = [
+ "bytes",
+ "fallible-iterator 0.2.0",
+ "futures-util",
+ "log",
+ "tokio",
+ "tokio-postgres",
+]
+
+[[package]]
+name = "postgres-protocol"
+version = "0.6.12"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "08808e3c483c46e999108051c78334f473d5adb59d78bb80a1268c7e6aa6c514"
+dependencies = [
+ "base64",
+ "byteorder",
+ "bytes",
+ "fallible-iterator 0.2.0",
+ "hmac 0.13.0",
+ "md-5",
+ "memchr",
+ "rand 0.10.2",
+ "sha2 0.11.0",
+ "stringprep",
+]
+
+[[package]]
+name = "postgres-types"
+version = "0.2.14"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "851ca9db4932932d69f3ea811b1abe63087a0f740a47692619dd40d4899b68be"
+dependencies = [
+ "bytes",
+ "fallible-iterator 0.2.0",
+ "postgres-protocol",
+]
+
 [[package]]
 name = "powerfmt"
 version = "0.2.0"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "439ee305def115ba05938db6eb1644ff94165c5ab5e9420d1c1bcedbba909391"
 
@@ -1013,66 +1301,127 @@ dependencies = [
 [[package]]
 name = "r-efi"
 version = "6.0.0"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "f8dcc9c7d52a811697d2151c701e0d08956f92b0e24136cf4cf27b57a6a0d9bf"
 
+[[package]]
+name = "r2d2"
+version = "0.8.10"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "51de85fb3fb6524929c8a2eb85e6b6d363de4e8c48f9e2c2eac4944abc181c93"
+dependencies = [
+ "log",
+ "parking_lot",
+ "scheduled-thread-pool",
+]
+
+[[package]]
+name = "r2d2_postgres"
+version = "0.18.2"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "efd4b47636dbca581cd057e2f27a5d39be741ea4f85fd3c29e415c55f71c7595"
+dependencies = [
+ "postgres",
+ "r2d2",
+]
+
 [[package]]
 name = "rand"
 version = "0.8.8"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "e058c7de0b26af77780c769414d6257830bb240f3c38477dbc2c16e5f54d6d4c"
 dependencies = [
  "libc",
  "rand_chacha",
- "rand_core",
+ "rand_core 0.6.4",
+]
+
+[[package]]
+name = "rand"
+version = "0.10.2"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "c7f5fa3a058cd35567ef9bfa5e75732bee0f9e4c55fa90477bef2dfcdbc4be80"
+dependencies = [
+ "chacha20",
+ "getrandom 0.4.3",
+ "rand_core 0.10.1",
 ]
 
 [[package]]
 name = "rand_chacha"
 version = "0.3.1"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "e6c10a63a0fa32252be49d21e7709d4d4baf8d231c2dbce1eaa8141b9b127d88"
 dependencies = [
  "ppv-lite86",
- "rand_core",
+ "rand_core 0.6.4",
 ]
 
 [[package]]
 name = "rand_core"
 version = "0.6.4"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "ec0be4795e2f6a28069bec0b5ff3e2ac9bafc99e6a9a7dc3547996c5c816922c"
 dependencies = [
  "getrandom 0.2.17",
 ]
 
+[[package]]
+name = "rand_core"
+version = "0.10.1"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "63b8176103e19a2643978565ca18b50549f6101881c443590420e4dc998a3c69"
+
+[[package]]
+name = "redox_syscall"
+version = "0.5.18"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "ed2bf2547551a7053d6fdfafda3f938979645c44812fbfcda098faae3f1a362d"
+dependencies = [
+ "bitflags",
+]
+
 [[package]]
 name = "rfc6979"
 version = "0.4.0"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "f8dd2a808d456c4a54e300a23e9f5a67e122c3024119acbfd73e3bf664491cb2"
 dependencies = [
- "hmac",
+ "hmac 0.12.1",
  "subtle",
 ]
 
+[[package]]
+name = "ring"
+version = "0.17.14"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "a4689e6c2294d81e88dc6261c768b63bc4fcdb852be6d1352498b114f61383b7"
+dependencies = [
+ "cc",
+ "cfg-if",
+ "getrandom 0.2.17",
+ "libc",
+ "untrusted",
+ "windows-sys 0.52.0",
+]
+
 [[package]]
 name = "rsa"
 version = "0.9.10"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "b8573f03f5883dcaebdfcf4725caa1ecb9c15b2ef50c43a07b816e06799bb12d"
 dependencies = [
- "const-oid",
- "digest",
+ "const-oid 0.9.6",
+ "digest 0.10.7",
  "num-bigint-dig",
  "num-integer",
  "num-traits",
  "pkcs1",
  "pkcs8",
- "rand_core",
+ "rand_core 0.6.4",
  "signature",
  "spki",
  "subtle",
  "zeroize",
 ]
 
@@ -1080,13 +1429,13 @@ dependencies = [
 name = "rusqlite"
 version = "0.31.0"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "b838eba278d213a8beaf485bd313fd580ca4505a00d5871caeb1457c55322cae"
 dependencies = [
  "bitflags",
- "fallible-iterator",
+ "fallible-iterator 0.3.0",
  "fallible-streaming-iterator",
  "hashlink",
  "libsqlite3-sys",
  "smallvec",
 ]
 
@@ -1106,13 +1455,59 @@ source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "891efababe418670775f199f0d233d84843c227a0949a883ce15b37c78d6629d"
 dependencies = [
  "bitflags",
  "errno",
  "libc",
  "linux-raw-sys",
- "windows-sys",
+ "windows-sys 0.61.2",
+]
+
+[[package]]
+name = "rustls"
+version = "0.23.45"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "0d41d731c7d2f962d1ccc364cec258de3c0e93b38c2fb3ba97ac74513048d634"
+dependencies = [
+ "once_cell",
+ "ring",
+ "rustls-pki-types",
+ "rustls-webpki",
+ "subtle",
+ "zeroize",
+]
+
+[[package]]
+name = "rustls-native-certs"
+version = "0.8.4"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "dab5152771c58876a2146916e53e35057e1a4dfa2b9df0f0305b07f611fdea4d"
+dependencies = [
+ "openssl-probe",
+ "rustls-pki-types",
+ "schannel",
+ "security-framework",
+]
+
+[[package]]
+name = "rustls-pki-types"
+version = "1.15.1"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "2f4925028c7eb5d1fcdaf196971378ed9d2c1c4efc7dc5d011256f76c99c0a96"
+dependencies = [
+ "zeroize",
+]
+
+[[package]]
+name = "rustls-webpki"
+version = "0.103.15"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "f3c3cf1d8b1e7d4927e2d154c3fcb02979afb9939629c62cd9048d4f07b60ac2"
+dependencies = [
+ "ring",
+ "rustls-pki-types",
+ "untrusted",
 ]
 
 [[package]]
 name = "rustversion"
 version = "1.0.23"
 source = "registry+https://github.com/rust-lang/crates.io-index"
@@ -1121,12 +1516,36 @@ checksum = "cf54715a573b99ac80df0bc206da022bcd442c974952c7b9720069370852e21f"
 [[package]]
 name = "ryu"
 version = "1.0.23"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "9774ba4a74de5f7b1c1451ed6cd5285a32eddb5cccb8cc655a4e50009e06477f"
 
+[[package]]
+name = "schannel"
+version = "0.1.29"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "91c1b7e4904c873ef0710c1f407dde2e6287de2bebc1bbbf7d430bb7cbffd939"
+dependencies = [
+ "windows-sys 0.61.2",
+]
+
+[[package]]
+name = "scheduled-thread-pool"
+version = "0.2.7"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "3cbc66816425a074528352f5789333ecff06ca41b36b0b0efdfbb29edc391a19"
+dependencies = [
+ "parking_lot",
+]
+
+[[package]]
+name = "scopeguard"
+version = "1.2.0"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "94143f37725109f92c262ed2cf5e59bce7498c01bcc1502d7b9afe439a4e9f49"
+
 [[package]]
 name = "sec1"
 version = "0.7.3"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "d3e97a565f76233a6003f9f5c54be1d9c5bdfa3eccfb189469f11ec4901c47dc"
 dependencies = [
@@ -1135,12 +1554,35 @@ dependencies = [
  "generic-array",
  "pkcs8",
  "subtle",
  "zeroize",
 ]
 
+[[package]]
+name = "security-framework"
+version = "3.7.0"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "b7f4bc775c73d9a02cde8bf7b2ec4c9d12743edf609006c7facc23998404cd1d"
+dependencies = [
+ "bitflags",
+ "core-foundation",
+ "core-foundation-sys",
+ "libc",
+ "security-framework-sys",
+]
+
+[[package]]
+name = "security-framework-sys"
+version = "2.17.0"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "6ce2691df843ecc5d231c0b14ece2acc3efb62c0a398c7e1d875f3983ce020e3"
+dependencies = [
+ "core-foundation-sys",
+ "libc",
+]
+
 [[package]]
 name = "semver"
 version = "1.0.28"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "8a7852d02fc848982e0c167ef163aaff9cd91dc640ba85e263cb1ce46fae51cd"
 
@@ -1214,14 +1656,25 @@ dependencies = [
 name = "sha2"
 version = "0.10.9"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "a7507d819769d01a365ab707794a4084392c824f54a7a6a7862f8c3d0892b283"
 dependencies = [
  "cfg-if",
- "cpufeatures",
- "digest",
+ "cpufeatures 0.2.17",
+ "digest 0.10.7",
+]
+
+[[package]]
+name = "sha2"
+version = "0.11.0"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "446ba717509524cb3f22f17ecc096f10f4822d76ab5c0b9822c5f9c284e825f4"
+dependencies = [
+ "cfg-if",
+ "cpufeatures 0.3.1",
+ "digest 0.11.3",
 ]
 
 [[package]]
 name = "shlex"
 version = "2.0.1"
 source = "registry+https://github.com/rust-lang/crates.io-index"
@@ -1230,14 +1683,14 @@ checksum = "f8fadd59c855ef2080decdef8ff161eb6661b86933c9d82e5ba29dc602a55aba"
 [[package]]
 name = "signature"
 version = "2.2.0"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "77549399552de45a898a580c1b41d445bf730df867cc44e6c0233bbc4b8329de"
 dependencies = [
- "digest",
- "rand_core",
+ "digest 0.10.7",
+ "rand_core 0.6.4",
 ]
 
 [[package]]
 name = "simple_asn1"
 version = "0.6.4"
 source = "registry+https://github.com/rust-lang/crates.io-index"
@@ -1246,12 +1699,18 @@ dependencies = [
  "num-bigint",
  "num-traits",
  "thiserror",
  "time",
 ]
 
+[[package]]
+name = "siphasher"
+version = "1.0.3"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "8ee5873ec9cce0195efcb7a4e9507a04cd49aec9c83d0389df45b1ef7ba2e649"
+
 [[package]]
 name = "slab"
 version = "0.4.12"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "0c790de23124f9ab44544d7ac05d60440adc586479ce501c1d6d7da3cd8c9cf5"
 
@@ -1265,13 +1724,13 @@ checksum = "ba467056f1b547ed52077911161fc86985becbc60e8e1857c8a144dab0def891"
 name = "socket2"
 version = "0.6.5"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "c3d1e2c7f27f8d4cb10542a02c49005dbd6e93095799d6f3be745fae9f8fedd4"
 dependencies = [
  "libc",
- "windows-sys",
+ "windows-sys 0.61.2",
 ]
 
 [[package]]
 name = "spin"
 version = "0.9.9"
 source = "registry+https://github.com/rust-lang/crates.io-index"
@@ -1284,12 +1743,23 @@ source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "d91ed6c858b01f942cd56b37a94b3e0a1798290327d1236e4d9cf4eaca44d29d"
 dependencies = [
  "base64ct",
  "der",
 ]
 
+[[package]]
+name = "stringprep"
+version = "0.1.5"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "7b4df3d392d81bd458a8a621b8bffbd2302a12ffe288a9d931670948749463b1"
+dependencies = [
+ "unicode-bidi",
+ "unicode-normalization",
+ "unicode-properties",
+]
+
 [[package]]
 name = "subtle"
 version = "2.6.1"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "13c2bddecc57b384dee18652358fb23172facb8a2c51ccc10d74c157bdea3292"
 
@@ -1328,13 +1798,13 @@ source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "32497e9a4c7b38532efcdebeef879707aa9f794296a4f0244f6f69e9bc8574bd"
 dependencies = [
  "fastrand",
  "getrandom 0.4.3",
  "once_cell",
  "rustix",
- "windows-sys",
+ "windows-sys 0.61.2",
 ]
 
 [[package]]
 name = "thiserror"
 version = "2.0.20"
 source = "registry+https://github.com/rust-lang/crates.io-index"
@@ -1381,24 +1851,52 @@ source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "7e689342a48d2ea927c87ea50cabf8594854bf940e9310208848d680d668ed85"
 dependencies = [
  "num-conv",
  "time-core",
 ]
 
+[[package]]
+name = "tinyvec"
+version = "1.13.3"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "fd3ca314f692efd6c868f8408f53fe444634a845f96c028b97d35f6a1f79f0ee"
+
+[[package]]
+name = "tls_codec"
+version = "0.4.2"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "0de2e01245e2bb89d6f05801c564fa27624dbd7b1846859876c7dad82e90bf6b"
+dependencies = [
+ "tls_codec_derive",
+ "zeroize",
+]
+
+[[package]]
+name = "tls_codec_derive"
+version = "0.4.2"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "2d2e76690929402faae40aebdda620a2c0e25dd6d3b9afe48867dfd95991f4bd"
+dependencies = [
+ "proc-macro2",
+ "quote",
+ "syn 2.0.119",
+]
+
 [[package]]
 name = "tokio"
 version = "1.53.1"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "202caea871b69668250d242070849eb495be178ed697a3e98aebce5bc81a0bed"
 dependencies = [
+ "bytes",
  "libc",
  "mio",
  "pin-project-lite",
  "socket2",
  "tokio-macros",
- "windows-sys",
+ "windows-sys 0.61.2",
 ]
 
 [[package]]
 name = "tokio-macros"
 version = "2.7.2"
 source = "registry+https://github.com/rust-lang/crates.io-index"
@@ -1406,12 +1904,77 @@ checksum = "78773a2a397f451582ce068015985c33193cf6dea8b74d2a639fe457b2f07b0e"
 dependencies = [
  "proc-macro2",
  "quote",
  "syn 3.0.6",
 ]
 
+[[package]]
+name = "tokio-postgres"
+version = "0.7.18"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "a528f7d280f6d5b9cd149635c8705b0dd049754bc67d81d31fa25169a93809d3"
+dependencies = [
+ "async-trait",
+ "byteorder",
+ "bytes",
+ "fallible-iterator 0.2.0",
+ "futures-channel",
+ "futures-util",
+ "log",
+ "parking_lot",
+ "percent-encoding",
+ "phf",
+ "pin-project-lite",
+ "postgres-protocol",
+ "postgres-types",
+ "rand 0.10.2",
+ "socket2",
+ "tokio",
+ "tokio-util",
+ "whoami",
+]
+
+[[package]]
+name = "tokio-postgres-rustls"
+version = "0.13.0"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "27d684bad428a0f2481f42241f821db42c54e2dc81d8c00db8536c506b0a0144"
+dependencies = [
+ "const-oid 0.9.6",
+ "ring",
+ "rustls",
+ "tokio",
+ "tokio-postgres",
+ "tokio-rustls",
+ "x509-cert",
+]
+
+[[package]]
+name = "tokio-rustls"
+version = "0.26.5"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "b0c85f2c3ef0b1cd58b36682f4b17aaa995f0e5db534d85692b4903abce21f67"
+dependencies = [
+ "rustls",
+ "tokio",
+]
+
+[[package]]
+name = "tokio-util"
+version = "0.7.19"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "494815d09bf52b5548659851081238f0ca39ff638363907596da739561c62c52"
+dependencies = [
+ "bytes",
+ "futures-core",
+ "futures-sink",
+ "libc",
+ "pin-project-lite",
+ "tokio",
+]
+
 [[package]]
 name = "tower"
 version = "0.4.13"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "b8fa9be0de6cf49e536ce1851f987bd21a43b771b09473c3549a6c853db37c1c"
 dependencies = [
@@ -1475,18 +2038,45 @@ dependencies = [
 [[package]]
 name = "typenum"
 version = "1.20.1"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "b6f5e870be6c3b371b77fe0ee0bafb859fa4964b4404c27de1d380043c4dda20"
 
+[[package]]
+name = "unicode-bidi"
+version = "0.3.18"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "5c1cb5db39152898a79168971543b1cb5020dff7fe43c8dc468b0885f5e29df5"
+
 [[package]]
 name = "unicode-ident"
 version = "1.0.26"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "d245f478577f809a851594d02313b640fb437e0bb33866753cff937863096954"
 
+[[package]]
+name = "unicode-normalization"
+version = "0.1.25"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "5fd4f6878c9cb28d874b009da9e8d183b5abc80117c40bbd187a1fde336be6e8"
+dependencies = [
+ "tinyvec",
+]
+
+[[package]]
+name = "unicode-properties"
+version = "0.1.4"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "7df058c713841ad818f1dc5d3fd88063241cc61f49f5fbea4b951e8cf5a8d71d"
+
+[[package]]
+name = "untrusted"
+version = "0.9.0"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "8ecb6da28b8a351d773b68d5825ac39017e680750f980f3a1a85cd8dd28a47c1"
+
 [[package]]
 name = "vcpkg"
 version = "0.2.15"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "accd4ea62f7bb7a82fe23066fb0957d48ef677f6eeb8215f372f52e48bb32426"
 
@@ -1499,12 +2089,39 @@ checksum = "0b928f33d975fc6ad9f86c8f283853ad26bdd5b10b7f1542aa2fa15e2289105a"
 [[package]]
 name = "wasi"
 version = "0.11.1+wasi-snapshot-preview1"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "ccf3ec651a847eb01de73ccad15eb7d99f80485de043efb2f370cd654f4ea44b"
 
+[[package]]
+name = "wasi"
+version = "0.14.7+wasi-0.2.4"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "883478de20367e224c0090af9cf5f9fa85bed63a95c1abf3afc5c083ebc06e8c"
+dependencies = [
+ "wasip2",
+]
+
+[[package]]
+name = "wasip2"
+version = "1.0.4+wasi-0.2.12"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "b67efb37e106e55ce722a510d6b5f9c17f083e5fc79afc2badeb12cc313d9487"
+dependencies = [
+ "wit-bindgen",
+]
+
+[[package]]
+name = "wasite"
+version = "1.0.2"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "66fe902b4a6b8028a753d5424909b764ccf79b7a209eac9bf97e59cda9f71a42"
+dependencies = [
+ "wasi 0.14.7+wasi-0.2.4",
+]
+
 [[package]]
 name = "wasm-bindgen"
 version = "0.2.128"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "aecb87a33d3b0c5e3b7aa46336eaf486cffafbd281b195e4c8b80d50df2351bf"
 dependencies = [
@@ -1544,27 +2161,141 @@ version = "0.2.128"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "81941cd78d0c92026c33e5e01312845a4cb1e9af3407f9134b100dd03144103e"
 dependencies = [
  "unicode-ident",
 ]
 
+[[package]]
+name = "web-sys"
+version = "0.3.105"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "9fbddc4a036f00ec4f18c83445bd3115cb306a91da554919a099d9222fe4a7f8"
+dependencies = [
+ "js-sys",
+ "wasm-bindgen",
+]
+
+[[package]]
+name = "whoami"
+version = "2.1.3"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "626c4bac6755d76ffc12cb01b2eac751db1996b9e0041de9aa02c8c211ddc82c"
+dependencies = [
+ "libc",
+ "libredox",
+ "objc2-system-configuration",
+ "wasite",
+ "web-sys",
+]
+
 [[package]]
 name = "windows-link"
 version = "0.2.1"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "f0805222e57f7521d6a62e36fa9163bc891acd422f971defe97d64e70d0a4fe5"
 
+[[package]]
+name = "windows-sys"
+version = "0.52.0"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "282be5f36a8ce781fad8c8ae18fa3f9beff57ec1b52cb3de0789201425d9a33d"
+dependencies = [
+ "windows-targets",
+]
+
 [[package]]
 name = "windows-sys"
 version = "0.61.2"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "ae137229bcbd6cdf0f7b80a31df61766145077ddf49416a728b02cb3921ff3fc"
 dependencies = [
  "windows-link",
 ]
 
+[[package]]
+name = "windows-targets"
+version = "0.52.6"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "9b724f72796e036ab90c1021d4780d4d3d648aca59e491e6b98e725b84e99973"
+dependencies = [
+ "windows_aarch64_gnullvm",
+ "windows_aarch64_msvc",
+ "windows_i686_gnu",
+ "windows_i686_gnullvm",
+ "windows_i686_msvc",
+ "windows_x86_64_gnu",
+ "windows_x86_64_gnullvm",
+ "windows_x86_64_msvc",
+]
+
+[[package]]
+name = "windows_aarch64_gnullvm"
+version = "0.52.6"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "32a4622180e7a0ec044bb555404c800bc9fd9ec262ec147edd5989ccd0c02cd3"
+
+[[package]]
+name = "windows_aarch64_msvc"
+version = "0.52.6"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "09ec2a7bb152e2252b53fa7803150007879548bc709c039df7627cabbd05d469"
+
+[[package]]
+name = "windows_i686_gnu"
+version = "0.52.6"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "8e9b5ad5ab802e97eb8e295ac6720e509ee4c243f69d781394014ebfe8bbfa0b"
+
+[[package]]
+name = "windows_i686_gnullvm"
+version = "0.52.6"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "0eee52d38c090b3caa76c563b86c3a4bd71ef1a819287c19d586d7334ae8ed66"
+
+[[package]]
+name = "windows_i686_msvc"
+version = "0.52.6"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "240948bc05c5e7c6dabba28bf89d89ffce3e303022809e73deaefe4f6ec56c66"
+
+[[package]]
+name = "windows_x86_64_gnu"
+version = "0.52.6"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "147a5c80aabfbf0c7d901cb5895d1de30ef2907eb21fbbab29ca94c5b08b1a78"
+
+[[package]]
+name = "windows_x86_64_gnullvm"
+version = "0.52.6"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "24d5b23dc417412679681396f2b49f3de8c1473deb516bd34410872eff51ed0d"
+
+[[package]]
+name = "windows_x86_64_msvc"
+version = "0.52.6"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "589f6da84c646204747d1270a2a5661ea66ed1cced2631d546fdfb155959f9ec"
+
+[[package]]
+name = "wit-bindgen"
+version = "0.57.1"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "1ebf944e87a7c253233ad6766e082e3cd714b5d03812acc24c318f549614536e"
+
+[[package]]
+name = "x509-cert"
+version = "0.2.5"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "1301e935010a701ae5f8655edc0ad17c44bad3ac5ce8c39185f75453b720ae94"
+dependencies = [
+ "const-oid 0.9.6",
+ "der",
+ "spki",
+ "tls_codec",
+]
+
 [[package]]
 name = "zerocopy"
 version = "0.8.57"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "d35102a9f36d089ccae9e4c6802bc118be4487b80aaffc0ab4e0cf5ce92d2873"
 dependencies = [
@@ -1584,12 +2315,26 @@ dependencies = [
 
 [[package]]
 name = "zeroize"
 version = "1.9.0"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "e13c156562582aa81c60cb29407084cdb54c4164760106ab78e6c5b0858cf64e"
+dependencies = [
+ "zeroize_derive",
+]
+
+[[package]]
+name = "zeroize_derive"
+version = "1.5.0"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "3c50655cbb0fe3fc43170059e702f1ce5e19b84cec58dc87b037a09935c2f328"
+dependencies = [
+ "proc-macro2",
+ "quote",
+ "syn 2.0.119",
+]
 
 [[package]]
 name = "zmij"
 version = "1.0.23"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "29666d0abbfad1e3dc4dcf6144730dd3a3ab225bbbdac83319345b1b44ccfc1b"

## FILE: server/Cargo.toml

diff --git a/server/Cargo.toml b/server/Cargo.toml
index 9c80f97..43756f6 100644
--- a/server/Cargo.toml
+++ b/server/Cargo.toml
@@ -10,25 +10,46 @@ publish = false
 name = "server"
 
 [[bin]]
 name = "mw-server"
 path = "src/main.rs"
 
+[features]
+default = ["postgres"]
+# The PostgreSQL backend is compiled by default so its tests compile and skip cleanly
+# when MW_TEST_DATABASE_URL is unset. Build with --no-default-features to omit it and
+# every dependency it pulls (including the rustls TLS stack).
+postgres = [
+    "dep:postgres",
+    "dep:r2d2",
+    "dep:r2d2_postgres",
+    "dep:tokio-postgres-rustls",
+    "dep:rustls",
+    "dep:rustls-native-certs",
+]
+
 [dependencies]
 mw-okf = { path = "../engine/okf" }
 mw-gate = { path = "../engine/gate" }
 axum.workspace = true
 tokio.workspace = true
 rusqlite.workspace = true
 serde.workspace = true
 serde_json.workspace = true
 sha2.workspace = true
 hex.workspace = true
 anyhow.workspace = true
 jsonwebtoken = { version = "=10.3.0", features = ["rust_crypto"] }
+postgres = { version = "0.19", optional = true }
+r2d2 = { version = "0.8", optional = true }
+r2d2_postgres = { version = "0.18", optional = true }
+tokio-postgres-rustls = { version = "0.13", optional = true }
+rustls = { version = "0.23", default-features = false, features = ["ring", "std", "tls12"], optional = true }
+rustls-native-certs = { version = "0.8", optional = true }
 
 [dev-dependencies]
 mw-test-support = { path = "../engine/test-support" }
 tower.workspace = true
 http-body-util.workspace = true
 tempfile.workspace = true
 serde_json.workspace = true
+postgres = { version = "0.19" }

## FILE: server/src/auth.rs

diff --git a/server/src/auth.rs b/server/src/auth.rs
index 91d7b49..bebaff1 100644
--- a/server/src/auth.rs
+++ b/server/src/auth.rs
@@ -390,17 +390,18 @@ pub fn parse_identity_from_jwt(token: &str, config: &AuthConfig) -> Option<Ident
     let mut validation = Validation::new(header.alg);
     // 60 seconds of clock skew, so a service and an identity provider whose clocks differ
     // by seconds do not lock users out. Validation::new already requires `exp` and
     // rejects a malformed or absent expiry, so a token cannot shed its expiry by giving it
     // the wrong JSON type.
     validation.leeway = 60;
-    // Enforce `nbf` exactly like `exp`: a future not-before is refused, and because `nbf`
-    // is required, a token whose `nbf` has the wrong JSON type is refused rather than
-    // treated as absent (the same type-confusion that motivated requiring `exp`).
+    // `nbf` is OPTIONAL in RFC 7519, so it is enforced WHEN PRESENT and not demanded. An
+    // earlier version required it, which refused every token from an identity provider that
+    // does not emit one - over-rejection, not a security gain. The risk worth closing is a
+    // wrongly-TYPED `nbf` being treated as absent, and validate_nbf handles that by refusing
+    // a non-numeric value, so absence stays legitimate: no not-before restriction.
     validation.validate_nbf = true;
-    validation.required_spec_claims.insert("nbf".to_string());
     // A subject is mandatory: the audit log records the verified `sub` as the actor, so a
     // token without one (or with a wrong-typed one) must be refused rather than accepted as
     // an identity with an empty subject that then breaks every write.
     validation.required_spec_claims.insert("sub".to_string());
 
     if let Some(iss) = issuer {

## FILE: server/src/main.rs

diff --git a/server/src/main.rs b/server/src/main.rs
index b0525ef..aa408e2 100644
--- a/server/src/main.rs
+++ b/server/src/main.rs
@@ -1,22 +1,23 @@
 // SPDX-License-Identifier: AGPL-3.0-or-later
 use std::net::SocketAddr;
 use std::path::PathBuf;
-use std::sync::Arc;
 
 use server::auth::AuthConfig;
-use server::store::sqlite::SqliteStore;
+use server::store::{self, StoreConfig};
 use server::{app, AppState};
 
 #[tokio::main]
 async fn main() -> anyhow::Result<()> {
     let port: u16 = std::env::var("MW_PORT")
         .ok()
         .and_then(|p| p.parse().ok())
         .unwrap_or(8080);
-    let db_path = std::env::var("MW_DB").unwrap_or_else(|_| "modelwrite.db".to_string());
+    // MW_DATABASE_URL selects the PostgreSQL backend; MW_DB (default modelwrite.db) is a
+    // path to a SQLite file. Both open behind the same Store trait, so nothing else changes.
+    let config = StoreConfig::from_env()?;
     let evidence_dir = std::env::var("MW_EVIDENCE_DIR")
         .map(PathBuf::from)
         .unwrap_or_else(|_| PathBuf::from("docs/evidence"));
 
     // Authentication is opt-in. With no token configured the service runs in OPEN mode:
     // every request is accepted as an anonymous admin. That keeps pilots and air-gapped
@@ -28,16 +29,22 @@ async fn main() -> anyhow::Result<()> {
              every request is accepted as an anonymous admin. Set MW_AUTH_TOKEN to \
              require a shared bearer token, or MW_AUTH_JWKS to the path of a JWKS \
              file to require signed JWTs."
         );
     }
 
-    let store = Arc::new(SqliteStore::open(std::path::Path::new(&db_path))?);
+    let store = store::open_store(&config)?;
     let addr = SocketAddr::from(([127, 0, 0, 1], port));
     let listener = tokio::net::TcpListener::bind(addr).await?;
-    println!("mw-server listening on http://{} (db {})", addr, db_path);
+    // Never print a connection URL: it can carry a password. Report the backend and, for
+    // SQLite, the path.
+    let db_desc = match &config {
+        StoreConfig::Sqlite(path) => path.display().to_string(),
+        StoreConfig::Postgres(_) => "postgres".to_string(),
+    };
+    println!("mw-server listening on http://{} (db {})", addr, db_desc);
     axum::serve(
         listener,
         app(AppState {
             store,
             evidence_dir,
             auth,

## FILE: server/src/store/mod.rs

diff --git a/server/src/store/mod.rs b/server/src/store/mod.rs
index c97c37a..9414cd9 100644
--- a/server/src/store/mod.rs
+++ b/server/src/store/mod.rs
@@ -1,10 +1,14 @@
 // SPDX-License-Identifier: AGPL-3.0-or-later
+use std::sync::Arc;
+
 use serde::Serialize;
 use sha2::{Digest, Sha256};
 
+#[cfg(feature = "postgres")]
+pub mod postgres;
 pub mod sqlite;
 
 #[derive(Debug, Clone, PartialEq)]
 pub struct Project {
     pub name: String,
     pub created_at: String,
@@ -328,6 +332,49 @@ pub trait Store: Send + Sync {
     /// construction rather than by convention, so a written entry can never be rewritten.
     fn append_audit(&self, entry: &AuditEntry) -> Result<i64, StoreError>;
 
     /// The audit entries for a project, newest first, at most `limit` rows (capped at 1000).
     fn audit(&self, project: &str, limit: i64) -> Result<Vec<AuditEntry>, StoreError>;
 }
+
+/// Which backend the store should open. `Sqlite` takes a filesystem path; `Postgres` takes
+/// a libpq-style connection URL. Chosen from the environment by [`StoreConfig::from_env`]:
+/// `MW_DATABASE_URL` (when set) selects Postgres, otherwise `MW_DB` (default `modelwrite.db`)
+/// selects SQLite.
+#[derive(Debug, Clone, PartialEq)]
+pub enum StoreConfig {
+    Sqlite(std::path::PathBuf),
+    Postgres(String),
+}
+
+impl StoreConfig {
+    /// Read the backend choice from the environment. `MW_DATABASE_URL` takes precedence and
+    /// selects Postgres; otherwise `MW_DB` is a filesystem path for SQLite, defaulting to
+    /// `modelwrite.db`.
+    pub fn from_env() -> Result<Self, StoreError> {
+        if let Ok(url) = std::env::var("MW_DATABASE_URL") {
+            if !url.trim().is_empty() {
+                return Ok(StoreConfig::Postgres(url));
+            }
+        }
+        let path = std::env::var("MW_DB").unwrap_or_else(|_| "modelwrite.db".to_string());
+        Ok(StoreConfig::Sqlite(std::path::PathBuf::from(path)))
+    }
+}
+
+/// Open a store of the configured backend, behind the shared [`Store`] trait, so nothing
+/// above the store changes when the backend does.
+pub fn open_store(config: &StoreConfig) -> Result<Arc<dyn Store>, StoreError> {
+    match config {
+        StoreConfig::Sqlite(path) => sqlite::SqliteStore::open(path)
+            .map(|store| Arc::new(store) as Arc<dyn Store>)
+            .map_err(|e| StoreError::Backend(e.to_string())),
+        #[cfg(feature = "postgres")]
+        StoreConfig::Postgres(url) => postgres::PostgresStore::open(url)
+            .map(|store| Arc::new(store) as Arc<dyn Store>),
+        #[cfg(not(feature = "postgres"))]
+        StoreConfig::Postgres(_) => Err(StoreError::Backend(
+            "this build was compiled without the postgres backend; rebuild with the postgres feature"
+                .to_string(),
+        )),
+    }
+}

## FILE: server/src/store/postgres.rs

diff --git a/server/src/store/postgres.rs b/server/src/store/postgres.rs
new file mode 100644
index 0000000..b174e87
--- /dev/null
+++ b/server/src/store/postgres.rs
@@ -0,0 +1,889 @@
+// SPDX-License-Identifier: AGPL-3.0-or-later
+use postgres::config::SslMode;
+use postgres::NoTls;
+use r2d2_postgres::PostgresConnectionManager;
+use tokio_postgres_rustls::MakeRustlsConnect;
+
+use super::{
+    now_epoch, AuditEntry, Commit, CommitGuard, GateRun, Lock, Project, Store, StoreError,
+};
+
+/// The schema, ported from the SQLite reference implementation. TEXT stays TEXT, the
+/// INTEGER seconds columns become BIGINT, the audit id becomes BIGSERIAL (a monotonic
+/// insertion key, so the log is ordered by insertion rather than wall-clock time), and the
+/// implicit SQLite rowid that ordered commits becomes an explicit BIGSERIAL id for the
+/// same reason. Every CHECK constraint is carried over, and the append-only property of the
+/// audit table is enforced by triggers exactly as it is on SQLite.
+const SCHEMA: &str = "
+CREATE TABLE IF NOT EXISTS projects (
+    name TEXT PRIMARY KEY,
+    created_at TEXT NOT NULL
+);
+CREATE TABLE IF NOT EXISTS blobs (
+    hash TEXT PRIMARY KEY,
+    bytes BYTEA NOT NULL
+);
+CREATE TABLE IF NOT EXISTS commits (
+    id BIGSERIAL NOT NULL,
+    hash TEXT PRIMARY KEY,
+    project TEXT NOT NULL,
+    branch TEXT NOT NULL,
+    parents TEXT NOT NULL,
+    okf_hash TEXT NOT NULL,
+    author TEXT NOT NULL,
+    message TEXT NOT NULL,
+    created_at TEXT NOT NULL
+);
+CREATE INDEX IF NOT EXISTS commits_by_project_branch ON commits (project, branch);
+CREATE TABLE IF NOT EXISTS branches (
+    project TEXT NOT NULL,
+    name TEXT NOT NULL,
+    tip TEXT NOT NULL,
+    PRIMARY KEY (project, name)
+);
+CREATE TABLE IF NOT EXISTS gate_runs (
+    id BIGSERIAL PRIMARY KEY,
+    project TEXT NOT NULL,
+    branch TEXT NOT NULL,
+    reference_hash TEXT NOT NULL,
+    candidate_hash TEXT NOT NULL,
+    passed BOOLEAN NOT NULL,
+    evidence TEXT NOT NULL,
+    created_at TEXT NOT NULL
+);
+CREATE TABLE IF NOT EXISTS locks (
+    id TEXT PRIMARY KEY,
+    project TEXT NOT NULL,
+    branch TEXT NOT NULL,
+    element TEXT NOT NULL,
+    holder TEXT NOT NULL,
+    acquired_at BIGINT NOT NULL,
+    expires_at BIGINT NOT NULL
+);
+CREATE INDEX IF NOT EXISTS locks_element ON locks(project, element);
+CREATE TABLE IF NOT EXISTS audit (
+    id BIGSERIAL PRIMARY KEY,
+    project TEXT NOT NULL,
+    at BIGINT NOT NULL,
+    actor TEXT NOT NULL,
+    mechanism TEXT NOT NULL,
+    action TEXT NOT NULL,
+    subject TEXT NOT NULL,
+    detail TEXT NOT NULL,
+    CHECK (length(actor) > 0),
+    CHECK (length(mechanism) > 0),
+    CHECK (length(action) > 0)
+);
+CREATE OR REPLACE FUNCTION audit_append_only() RETURNS trigger AS $function$
+BEGIN
+    RAISE EXCEPTION 'audit entries are append-only';
+END;
+$function$ LANGUAGE plpgsql;
+DROP TRIGGER IF EXISTS audit_no_update ON audit;
+CREATE TRIGGER audit_no_update
+BEFORE UPDATE ON audit
+FOR EACH ROW
+EXECUTE FUNCTION audit_append_only();
+DROP TRIGGER IF EXISTS audit_no_delete ON audit;
+CREATE TRIGGER audit_no_delete
+BEFORE DELETE ON audit
+FOR EACH ROW
+EXECUTE FUNCTION audit_append_only();
+";
+
+type PlainPool = r2d2::Pool<PostgresConnectionManager<NoTls>>;
+type TlsPool = r2d2::Pool<PostgresConnectionManager<MakeRustlsConnect>>;
+
+enum Pool {
+    Plain(PlainPool),
+    Tls(TlsPool),
+}
+
+impl Pool {
+    fn get_conn(&self) -> Result<PooledClient, StoreError> {
+        match self {
+            Pool::Plain(pool) => pool.get().map(PooledClient::Plain).map_err(backend),
+            Pool::Tls(pool) => pool.get().map(PooledClient::Tls).map_err(backend),
+        }
+    }
+}
+
+enum PooledClient {
+    Plain(r2d2::PooledConnection<PostgresConnectionManager<NoTls>>),
+    Tls(r2d2::PooledConnection<PostgresConnectionManager<MakeRustlsConnect>>),
+}
+
+impl PooledClient {
+    fn client(&mut self) -> &mut postgres::Client {
+        match self {
+            PooledClient::Plain(conn) => conn,
+            PooledClient::Tls(conn) => conn,
+        }
+    }
+}
+
+pub struct PostgresStore {
+    pool: Pool,
+}
+
+fn backend<E: std::fmt::Display>(error: E) -> StoreError {
+    StoreError::Backend(error.to_string())
+}
+
+fn rustls_connector() -> Result<MakeRustlsConnect, StoreError> {
+    let mut roots = rustls::RootCertStore::empty();
+    let loaded = rustls_native_certs::load_native_certs();
+    for certificate in loaded.certs {
+        roots.add(certificate).map_err(backend)?;
+    }
+    let config = rustls::ClientConfig::builder()
+        .with_root_certificates(roots)
+        .with_no_client_auth();
+    Ok(MakeRustlsConnect::new(config))
+}
+
+impl PostgresStore {
+    pub fn open(url: &str) -> Result<Self, StoreError> {
+        let config: postgres::Config = url.parse().map_err(backend)?;
+        let pool = match config.get_ssl_mode() {
+            SslMode::Disable | SslMode::Prefer => {
+                let manager = PostgresConnectionManager::new(config, NoTls);
+                Pool::Plain(r2d2::Pool::new(manager).map_err(backend)?)
+            }
+            SslMode::Require => {
+                let manager = PostgresConnectionManager::new(config, rustls_connector()?);
+                Pool::Tls(r2d2::Pool::new(manager).map_err(backend)?)
+            }
+            _ => {
+                return Err(StoreError::Backend(
+                    "unsupported sslmode in the connection string".to_string(),
+                ))
+            }
+        };
+        {
+            let mut conn = pool.get_conn()?;
+            conn.client().batch_execute(SCHEMA).map_err(backend)?;
+        }
+        Ok(Self { pool })
+    }
+
+    fn with_client<T>(
+        &self,
+        f: impl FnOnce(&mut postgres::Client) -> Result<T, StoreError>,
+    ) -> Result<T, StoreError> {
+        let mut conn = self.pool.get_conn()?;
+        f(conn.client())
+    }
+
+    fn with_tx<T>(
+        &self,
+        f: impl FnOnce(&mut postgres::Transaction<'_>) -> Result<T, StoreError>,
+    ) -> Result<T, StoreError> {
+        let mut conn = self.pool.get_conn()?;
+        let mut tx = conn.client().transaction().map_err(backend)?;
+        let result = f(&mut tx);
+        if result.is_ok() {
+            tx.commit().map_err(backend)?;
+        }
+        result
+    }
+}
+
+type CommitRow = (
+    String,
+    String,
+    String,
+    String,
+    String,
+    String,
+    String,
+    String,
+);
+
+fn parse_parents(hash: &str, raw: &str) -> Result<Vec<String>, StoreError> {
+    serde_json::from_str(raw).map_err(|e| {
+        StoreError::Backend(format!("corrupt parents column for commit {}: {}", hash, e))
+    })
+}
+
+fn insert_audit<G: postgres::GenericClient>(
+    client: &mut G,
+    entry: &AuditEntry,
+) -> Result<i64, StoreError> {
+    let row = client
+        .query_one(
+            "INSERT INTO audit (project, at, actor, mechanism, action, subject, detail) VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING id",
+            &[
+                &entry.project,
+                &entry.at,
+                &entry.actor,
+                &entry.mechanism,
+                &entry.action,
+                &entry.subject,
+                &entry.detail,
+            ],
+        )
+        .map_err(backend)?;
+    Ok(row.get(0))
+}
+
+fn enforce_guard<G: postgres::GenericClient>(
+    client: &mut G,
+    project: &str,
+    guard: &CommitGuard<'_>,
+) -> Result<(), StoreError> {
+    for element in guard.elements {
+        let held: Option<(String, i64)> = client
+            .query_opt(
+                "SELECT holder, expires_at FROM locks WHERE project = $1 AND element = $2 AND expires_at > $3 AND holder != $4 LIMIT 1",
+                &[&project, &element, &guard.now, &guard.holder],
+            )
+            .map_err(backend)?
+            .map(|row| (row.get(0), row.get(1)));
+        if let Some((holder, expires_at)) = held {
+            return Err(super::lock_refusal(element, &holder, expires_at));
+        }
+    }
+    Ok(())
+}
+
+impl Store for PostgresStore {
+    fn create_project(
+        &self,
+        name: &str,
+        audit: Option<&AuditEntry>,
+    ) -> Result<Project, StoreError> {
+        let created_at = now_epoch();
+        self.with_tx(|tx| {
+            let inserted = tx
+                .execute(
+                    "INSERT INTO projects (name, created_at) VALUES ($1, $2) ON CONFLICT (name) DO NOTHING",
+                    &[&name, &created_at],
+                )
+                .map_err(backend)?;
+            if inserted == 0 {
+                return Err(StoreError::Conflict(format!(
+                    "project {} already exists",
+                    name
+                )));
+            }
+            if let Some(audit) = audit {
+                insert_audit(tx, audit)?;
+            }
+            Ok(())
+        })?;
+        Ok(Project {
+            name: name.to_string(),
+            created_at,
+        })
+    }
+
+    fn project(&self, name: &str) -> Result<Option<Project>, StoreError> {
+        self.with_client(|client| {
+            client
+                .query_opt(
+                    "SELECT name, created_at FROM projects WHERE name = $1",
+                    &[&name],
+                )
+                .map_err(backend)
+                .map(|row| {
+                    row.map(|row| Project {
+                        name: row.get(0),
+                        created_at: row.get(1),
+                    })
+                })
+        })
+    }
+
+    fn list_projects(&self) -> Result<Vec<Project>, StoreError> {
+        self.with_client(|client| {
+            let rows = client
+                .query("SELECT name, created_at FROM projects ORDER BY name", &[])
+                .map_err(backend)?;
+            rows.into_iter()
+                .map(|row| {
+                    Ok(Project {
+                        name: row.get(0),
+                        created_at: row.get(1),
+                    })
+                })
+                .collect()
+        })
+    }
+
+    fn put_blob(&self, bytes: &[u8]) -> Result<String, StoreError> {
+        let hash = super::blob_hash(bytes);
+        self.with_client(|client| {
+            client
+                .execute(
+                    "INSERT INTO blobs (hash, bytes) VALUES ($1, $2) ON CONFLICT (hash) DO NOTHING",
+                    &[&hash, &bytes],
+                )
+                .map_err(backend)?;
+            Ok(())
+        })?;
+        Ok(hash)
+    }
+
+    fn blob(&self, hash: &str) -> Result<Option<Vec<u8>>, StoreError> {
+        self.with_client(|client| {
+            match client
+                .query_opt("SELECT bytes FROM blobs WHERE hash = $1", &[&hash])
+                .map_err(backend)?
+            {
+                Some(row) => Ok(Some(row.get(0))),
+                None => Ok(None),
+            }
+        })
+    }
+
+    #[allow(clippy::too_many_arguments)]
+    fn commit_model(
+        &self,
+        project: &str,
+        branch: &str,
+        okf_hash: &str,
+        author: &str,
+        message: &str,
+        guard: Option<CommitGuard<'_>>,
+        audit: Option<&AuditEntry>,
+    ) -> Result<Commit, StoreError> {
+        self.with_tx(|tx| {
+            if let Some(guard) = guard.as_ref() {
+                enforce_guard(tx, project, guard)?;
+            }
+
+            tx.execute(
+                "INSERT INTO branches (project, name, tip) VALUES ($1, $2, $3) ON CONFLICT (project, name) DO NOTHING",
+                &[&project, &branch, &""],
+            )
+            .map_err(backend)?;
+
+            let tip: Option<String> = tx
+                .query_opt(
+                    "SELECT tip FROM branches WHERE project = $1 AND name = $2 FOR UPDATE",
+                    &[&project, &branch],
+                )
+                .map_err(backend)?
+                .map(|row| row.get::<_, String>(0))
+                .filter(|tip| !tip.is_empty());
+
+            if let Some(guard) = guard.as_ref() {
+                if guard.expected_tip != tip.as_deref() {
+                    return Err(StoreError::Conflict(format!(
+                        "branch {} moved while the commit was being prepared; re-read and retry",
+                        branch
+                    )));
+                }
+            }
+
+            let parents: Vec<String> = tip.into_iter().collect();
+            let created_at = now_epoch();
+            let hash = super::commit_hash(project, branch, &parents, okf_hash, author, message);
+            let parents_json = serde_json::to_string(&parents).map_err(backend)?;
+
+            tx.execute(
+                "INSERT INTO commits (hash, project, branch, parents, okf_hash, author, message, created_at) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)",
+                &[&hash, &project, &branch, &parents_json, &okf_hash, &author, &message, &created_at],
+            )
+            .map_err(backend)?;
+            tx.execute(
+                "INSERT INTO branches (project, name, tip) VALUES ($1, $2, $3) ON CONFLICT (project, name) DO UPDATE SET tip = EXCLUDED.tip",
+                &[&project, &branch, &hash],
+            )
+            .map_err(backend)?;
+            if let Some(audit) = audit {
+                insert_audit(tx, audit)?;
+            }
+            Ok(Commit {
+                hash,
+                project: project.to_string(),
+                branch: branch.to_string(),
+                parents,
+                okf_hash: okf_hash.to_string(),
+                author: author.to_string(),
+                message: message.to_string(),
+                created_at,
+            })
+        })
+    }
+
+    #[allow(clippy::too_many_arguments)]
+    fn commit_merge(
+        &self,
+        project: &str,
+        branch: &str,
+        parents: &[String],
+        okf_hash: &str,
+        author: &str,
+        message: &str,
+        guard: Option<CommitGuard<'_>>,
+        audit: Option<&AuditEntry>,
+    ) -> Result<Commit, StoreError> {
+        if parents.len() != 2 {
+            return Err(StoreError::Backend(format!(
+                "a merge commit needs exactly two parents, got {}",
+                parents.len()
+            )));
+        }
+        self.with_tx(|tx| {
+            let current_tip: Option<String> = tx
+                .query_opt(
+                    "SELECT tip FROM branches WHERE project = $1 AND name = $2 FOR UPDATE",
+                    &[&project, &branch],
+                )
+                .map_err(backend)?
+                .map(|row| row.get(0));
+            if current_tip.as_deref() != Some(parents[0].as_str()) {
+                return Err(StoreError::Conflict(format!(
+                    "branch {} moved while the merge was being prepared (expected {}, found {})",
+                    branch,
+                    parents[0],
+                    current_tip.as_deref().unwrap_or("nothing")
+                )));
+            }
+
+            if let Some(guard) = guard.as_ref() {
+                enforce_guard(tx, project, guard)?;
+            }
+
+            for parent in parents {
+                let exists: bool = tx
+                    .query_opt(
+                        "SELECT 1 FROM commits WHERE project = $1 AND hash = $2",
+                        &[&project, &parent],
+                    )
+                    .map_err(backend)?
+                    .is_some();
+                if !exists {
+                    return Err(StoreError::NotFound(format!("parent commit {}", parent)));
+                }
+            }
+
+            let parents: Vec<String> = parents.to_vec();
+            let created_at = now_epoch();
+            let hash = super::commit_hash(project, branch, &parents, okf_hash, author, message);
+            let parents_json = serde_json::to_string(&parents).map_err(backend)?;
+
+            tx.execute(
+                "INSERT INTO commits (hash, project, branch, parents, okf_hash, author, message, created_at) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)",
+                &[&hash, &project, &branch, &parents_json, &okf_hash, &author, &message, &created_at],
+            )
+            .map_err(backend)?;
+            tx.execute(
+                "INSERT INTO branches (project, name, tip) VALUES ($1, $2, $3) ON CONFLICT (project, name) DO UPDATE SET tip = EXCLUDED.tip",
+                &[&project, &branch, &hash],
+            )
+            .map_err(backend)?;
+            if let Some(audit) = audit {
+                insert_audit(tx, audit)?;
+            }
+            Ok(Commit {
+                hash,
+                project: project.to_string(),
+                branch: branch.to_string(),
+                parents,
+                okf_hash: okf_hash.to_string(),
+                author: author.to_string(),
+                message: message.to_string(),
+                created_at,
+            })
+        })
+    }
+
+    fn commit(&self, project: &str, hash: &str) -> Result<Option<Commit>, StoreError> {
+        let row: Option<CommitRow> = self.with_client(|client| {
+            client
+                .query_opt(
+                    "SELECT hash, project, branch, parents, okf_hash, author, message, created_at FROM commits WHERE project = $1 AND hash = $2",
+                    &[&project, &hash],
+                )
+                .map_err(backend)
+                .map(|row| {
+                    row.map(|row| {
+                        (
+                            row.get(0),
+                            row.get(1),
+                            row.get(2),
+                            row.get(3),
+                            row.get(4),
+                            row.get(5),
+                            row.get(6),
+                            row.get(7),
+                        )
+                    })
+                })
+        })?;
+        match row {
+            None => Ok(None),
+            Some((hash, project, branch, parents, okf_hash, author, message, created_at)) => {
+                Ok(Some(Commit {
+                    parents: parse_parents(&hash, &parents)?,
+                    hash,
+                    project,
+                    branch,
+                    okf_hash,
+                    author,
+                    message,
+                    created_at,
+                }))
+            }
+        }
+    }
+
+    fn commits_on(&self, project: &str, branch: &str) -> Result<Vec<Commit>, StoreError> {
+        let rows: Vec<CommitRow> = self.with_client(|client| {
+            let rows = client
+                .query(
+                    "SELECT hash, project, branch, parents, okf_hash, author, message, created_at FROM commits WHERE project = $1 AND branch = $2 ORDER BY id",
+                    &[&project, &branch],
+                )
+                .map_err(backend)?;
+            rows.into_iter()
+                .map(|row| {
+                    Ok((
+                        row.get(0),
+                        row.get(1),
+                        row.get(2),
+                        row.get(3),
+                        row.get(4),
+                        row.get(5),
+                        row.get(6),
+                        row.get(7),
+                    ))
+                })
+                .collect()
+        })?;
+        let mut commits = Vec::with_capacity(rows.len());
+        for (hash, project, branch, parents, okf_hash, author, message, created_at) in rows {
+            commits.push(Commit {
+                parents: parse_parents(&hash, &parents)?,
+                hash,
+                project,
+                branch,
+                okf_hash,
+                author,
+                message,
+                created_at,
+            });
+        }
+        Ok(commits)
+    }
+
+    fn branch_tip(&self, project: &str, branch: &str) -> Result<Option<String>, StoreError> {
+        self.with_client(|client| {
+            client
+                .query_opt(
+                    "SELECT tip FROM branches WHERE project = $1 AND name = $2",
+                    &[&project, &branch],
+                )
+                .map_err(backend)
+                .map(|row| row.map(|row| row.get(0)))
+        })
+    }
+
+    fn create_branch(
+        &self,
+        project: &str,
+        name: &str,
+        from: &str,
+        audit: Option<&AuditEntry>,
+    ) -> Result<(), StoreError> {
+        if self.commit(project, from)?.is_none() {
+            return Err(StoreError::NotFound(format!("commit {}", from)));
+        }
+        self.with_tx(|tx| {
+            let inserted = tx
+                .execute(
+                    "INSERT INTO branches (project, name, tip) VALUES ($1, $2, $3) ON CONFLICT (project, name) DO NOTHING",
+                    &[&project, &name, &from],
+                )
+                .map_err(backend)?;
+            if inserted == 0 {
+                return Err(StoreError::Conflict(format!(
+                    "branch {} already exists",
+                    name
+                )));
+            }
+            if let Some(audit) = audit {
+                insert_audit(tx, audit)?;
+            }
+            Ok(())
+        })
+    }
+
+    fn delete_branch(
+        &self,
+        project: &str,
+        name: &str,
+        audit: Option<&AuditEntry>,
+    ) -> Result<(), StoreError> {
+        if self.project(project)?.is_none() {
+            return Err(StoreError::NotFound(format!("project {}", project)));
+        }
+        self.with_tx(|tx| {
+            let removed = tx
+                .execute(
+                    "DELETE FROM branches WHERE project = $1 AND name = $2",
+                    &[&project, &name],
+                )
+                .map_err(backend)?;
+            if removed == 0 {
+                return Err(StoreError::NotFound(format!("branch {}", name)));
+            }
+            if let Some(audit) = audit {
+                insert_audit(tx, audit)?;
+            }
+            Ok(())
+        })
+    }
+
+    fn list_branches(&self, project: &str) -> Result<Vec<(String, String)>, StoreError> {
+        self.with_client(|client| {
+            let rows = client
+                .query(
+                    "SELECT name, tip FROM branches WHERE project = $1 ORDER BY name",
+                    &[&project],
+                )
+                .map_err(backend)?;
+            rows.into_iter()
+                .map(|row| Ok((row.get(0), row.get(1))))
+                .collect()
+        })
+    }
+
+    fn record_gate_run(&self, run: &GateRun, audit: Option<&AuditEntry>) -> Result<(), StoreError> {
+        self.with_tx(|tx| {
+            tx.execute(
+                "INSERT INTO gate_runs (project, branch, reference_hash, candidate_hash, passed, evidence, created_at) VALUES ($1, $2, $3, $4, $5, $6, $7)",
+                &[
+                    &run.project,
+                    &run.branch,
+                    &run.reference_hash,
+                    &run.candidate_hash,
+                    &run.passed,
+                    &run.evidence,
+                    &run.created_at,
+                ],
+            )
+            .map_err(backend)?;
+            if let Some(audit) = audit {
+                insert_audit(tx, audit)?;
+            }
+            Ok(())
+        })
+    }
+
+    fn gate_runs(&self, project: &str) -> Result<Vec<GateRun>, StoreError> {
+        self.with_client(|client| {
+            let rows = client
+                .query(
+                    "SELECT project, branch, reference_hash, candidate_hash, passed, evidence, created_at FROM gate_runs WHERE project = $1 ORDER BY id",
+                    &[&project],
+                )
+                .map_err(backend)?;
+            rows.into_iter()
+                .map(|row| {
+                    Ok(GateRun {
+                        project: row.get(0),
+                        branch: row.get(1),
+                        reference_hash: row.get(2),
+                        candidate_hash: row.get(3),
+                        passed: row.get(4),
+                        evidence: row.get(5),
+                        created_at: row.get(6),
+                    })
+                })
+                .collect()
+        })
+    }
+
+    fn append_audit(&self, entry: &AuditEntry) -> Result<i64, StoreError> {
+        self.with_client(|client| insert_audit(client, entry))
+    }
+
+    fn audit(&self, project: &str, limit: i64) -> Result<Vec<AuditEntry>, StoreError> {
+        let limit = limit.clamp(1, 1000);
+        self.with_client(|client| {
+            let rows = client
+                .query(
+                    "SELECT id, project, at, actor, mechanism, action, subject, detail FROM audit WHERE project = $1 ORDER BY id DESC LIMIT $2",
+                    &[&project, &limit],
+                )
+                .map_err(backend)?;
+            rows.into_iter()
+                .map(|row| {
+                    Ok(AuditEntry {
+                        id: row.get(0),
+                        project: row.get(1),
+                        at: row.get(2),
+                        actor: row.get(3),
+                        mechanism: row.get(4),
+                        action: row.get(5),
+                        subject: row.get(6),
+                        detail: row.get(7),
+                    })
+                })
+                .collect()
+        })
+    }
+
+    #[allow(clippy::too_many_arguments)]
+    fn acquire_locks(
+        &self,
+        project: &str,
+        branch: &str,
+        elements: &[String],
+        holder: &str,
+        ttl_seconds: i64,
+        now: i64,
+        audit: Option<&AuditEntry>,
+    ) -> Result<Vec<Lock>, StoreError> {
+        self.with_tx(|tx| {
+            tx.execute("DELETE FROM locks WHERE expires_at <= $1", &[&now])
+                .map_err(backend)?;
+
+            for element in elements {
+                let conflict: Option<(String, i64)> = tx
+                    .query_opt(
+                        "SELECT holder, expires_at FROM locks WHERE project = $1 AND element = $2 AND holder != $3",
+                        &[&project, &element, &holder],
+                    )
+                    .map_err(backend)?
+                    .map(|row| (row.get(0), row.get(1)));
+                if let Some((other, expires_at)) = conflict {
+                    return Err(super::lock_refusal(element, &other, expires_at));
+                }
+            }
+
+            let mut locks = Vec::with_capacity(elements.len());
+            for element in elements {
+                let existing: Option<(String, String, i64)> = tx
+                    .query_opt(
+                        "SELECT id, branch, acquired_at FROM locks WHERE project = $1 AND element = $2 AND holder = $3",
+                        &[&project, &element, &holder],
+                    )
+                    .map_err(backend)?
+                    .map(|row| (row.get(0), row.get(1), row.get(2)));
+
+                let expires_at = now + ttl_seconds;
+                let (id, acquired_at) = match existing {
+                    Some((id, _branch, acquired_at)) => {
+                        tx.execute(
+                            "UPDATE locks SET branch = $1, expires_at = $2 WHERE id = $3",
+                            &[&branch, &expires_at, &id],
+                        )
+                        .map_err(backend)?;
+                        (id, acquired_at)
+                    }
+                    None => {
+                        let id = super::lock_id(project, branch, element, holder, now);
+                        tx.execute(
+                            "INSERT INTO locks (id, project, branch, element, holder, acquired_at, expires_at) VALUES ($1, $2, $3, $4, $5, $6, $7)",
+                            &[&id, &project, &branch, &element, &holder, &now, &expires_at],
+                        )
+                        .map_err(backend)?;
+                        (id, now)
+                    }
+                };
+
+                locks.push(Lock {
+                    id,
+                    project: project.to_string(),
+                    branch: branch.to_string(),
+                    element: element.clone(),
+                    holder: holder.to_string(),
+                    acquired_at,
+                    expires_at,
+                });
+            }
+
+            if let Some(audit) = audit {
+                insert_audit(tx, audit)?;
+            }
+            Ok(locks)
+        })
+    }
+
+    fn release_locks(
+        &self,
+        project: &str,
+        holder: &str,
+        ids: &[String],
+        audit: Option<&AuditEntry>,
+    ) -> Result<usize, StoreError> {
+        self.with_tx(|tx| {
+            let mut released = 0usize;
+            for id in ids {
+                released += tx
+                    .execute(
+                        "DELETE FROM locks WHERE project = $1 AND holder = $2 AND id = $3",
+                        &[&project, &holder, &id],
+                    )
+                    .map_err(backend)? as usize;
+            }
+
+            if released > 0 {
+                if let Some(audit) = audit {
+                    insert_audit(tx, audit)?;
+                }
+            }
+            Ok(released)
+        })
+    }
+
+    fn locks(&self, project: &str, now: i64) -> Result<Vec<Lock>, StoreError> {
+        self.with_client(|client| {
+            let rows = client
+                .query(
+                    "SELECT id, project, branch, element, holder, acquired_at, expires_at FROM locks WHERE project = $1 AND expires_at > $2 ORDER BY element",
+                    &[&project, &now],
+                )
+                .map_err(backend)?;
+            rows.into_iter()
+                .map(|row| {
+                    Ok(Lock {
+                        id: row.get(0),
+                        project: row.get(1),
+                        branch: row.get(2),
+                        element: row.get(3),
+                        holder: row.get(4),
+                        acquired_at: row.get(5),
+                        expires_at: row.get(6),
+                    })
+                })
+                .collect()
+        })
+    }
+
+    fn holders_of(
+        &self,
+        project: &str,
+        elements: &[String],
+        now: i64,
+    ) -> Result<Vec<Lock>, StoreError> {
+        self.with_client(|client| {
+            let mut locks = Vec::new();
+            for element in elements {
+                let rows = client
+                    .query(
+                        "SELECT id, project, branch, element, holder, acquired_at, expires_at FROM locks WHERE project = $1 AND element = $2 AND expires_at > $3",
+                        &[&project, &element, &now],
+                    )
+                    .map_err(backend)?;
+                for row in rows {
+                    locks.push(Lock {
+                        id: row.get(0),
+                        project: row.get(1),
+                        branch: row.get(2),
+                        element: row.get(3),
+                        holder: row.get(4),
+                        acquired_at: row.get(5),
+                        expires_at: row.get(6),
+                    });
+                }
+            }
+            Ok(locks)
+        })
+    }
+}

## FILE: server/src/store/sqlite.rs

diff --git a/server/src/store/sqlite.rs b/server/src/store/sqlite.rs
index bc00570..1dbc1af 100644
--- a/server/src/store/sqlite.rs
+++ b/server/src/store/sqlite.rs
@@ -85,20 +85,42 @@ CREATE TRIGGER IF NOT EXISTS audit_no_delete
 BEFORE DELETE ON audit
 BEGIN
     SELECT RAISE(ABORT, 'audit entries are append-only');
 END;
 ";
 
+/// Bring a database created by an earlier version up to the current schema.
+///
+/// `CREATE TABLE IF NOT EXISTS` is not a migration: a table that already exists is left
+/// exactly as it was, so a column added to the CREATE statement never reaches an existing
+/// database. Without this, an installation that upgraded would keep an audit table with no
+/// `mechanism` column and EVERY write would fail - the kind of failure that is discovered
+/// during a customer upgrade rather than in a test. Migrations run in order and are
+/// idempotent, so starting the service twice is harmless.
+fn migrate(connection: &Connection) -> anyhow::Result<()> {
+    let has_mechanism: bool = connection
+        .prepare("SELECT 1 FROM pragma_table_info('audit') WHERE name = 'mechanism'")?
+        .exists([])?;
+    if !has_mechanism {
+        // The default is the honest one for rows written before the field existed: those
+        // rows came from a build that had no authentication, so nobody was verified.
+        connection
+            .execute_batch("ALTER TABLE audit ADD COLUMN mechanism TEXT NOT NULL DEFAULT 'open'")?;
+    }
+    Ok(())
+}
+
 pub struct SqliteStore {
     connection: std::sync::Mutex<Connection>,
 }
 
 impl SqliteStore {
     pub fn open(path: &Path) -> anyhow::Result<Self> {
         let connection = Connection::open(path)?;
         connection.execute_batch(SCHEMA)?;
+        migrate(&connection)?;
         Ok(Self {
             connection: std::sync::Mutex::new(connection),
         })
     }
 
     fn with<T>(&self, f: impl FnOnce(&Connection) -> rusqlite::Result<T>) -> Result<T, StoreError> {

## FILE: server/tests/postgres.rs

diff --git a/server/tests/postgres.rs b/server/tests/postgres.rs
new file mode 100644
index 0000000..93ebb4c
--- /dev/null
+++ b/server/tests/postgres.rs
@@ -0,0 +1,623 @@
+// SPDX-License-Identifier: AGPL-3.0-or-later
+#![cfg(feature = "postgres")]
+
+use postgres::NoTls;
+use server::store::postgres::PostgresStore;
+use server::store::{AuditEntry, CommitGuard, GateRun, Store, StoreError};
+
+/// Every test in this file is skipped - not failed, and not passed - when
+/// MW_TEST_DATABASE_URL is unset, so the local suite (no PostgreSQL) stays green without
+/// pretending the backend was exercised. A test that cannot open the configured database
+/// panics: a misconfigured URL must fail loudly, not quietly skip.
+fn require_store() -> Option<PostgresStore> {
+    let url = std::env::var("MW_TEST_DATABASE_URL").ok()?;
+    if url.trim().is_empty() {
+        return None;
+    }
+    match PostgresStore::open(&url) {
+        Ok(store) => Some(store),
+        Err(error) => panic!(
+            "could not open the configured PostgreSQL database: {}",
+            error
+        ),
+    }
+}
+
+/// A project name unique to this test run, so tests can share one database without
+/// colliding, and a re-run starts clean.
+fn unique_project() -> String {
+    use std::sync::atomic::{AtomicU64, Ordering};
+    static COUNTER: AtomicU64 = AtomicU64::new(0);
+    let nanos = std::time::SystemTime::now()
+        .duration_since(std::time::UNIX_EPOCH)
+        .unwrap_or_default()
+        .as_nanos();
+    let n = COUNTER.fetch_add(1, Ordering::Relaxed);
+    format!("pgtest_{}_{}", nanos, n)
+}
+
+#[test]
+fn blobs_are_content_addressed() {
+    let Some(store) = require_store() else {
+        eprintln!("skipped: MW_TEST_DATABASE_URL is not set");
+        return;
+    };
+    let a = store.put_blob(b"model-one").unwrap();
+    let b = store.put_blob(b"model-one").unwrap();
+    let c = store.put_blob(b"model-two").unwrap();
+    assert_eq!(a, b, "identical bytes must share an address");
+    assert_ne!(a, c);
+    assert_eq!(store.blob(&a).unwrap().unwrap(), b"model-one");
+}
+
+#[test]
+fn commits_land_on_a_branch_and_move_its_tip() {
+    let Some(store) = require_store() else {
+        eprintln!("skipped: MW_TEST_DATABASE_URL is not set");
+        return;
+    };
+    let project = unique_project();
+    store.create_project(&project, None).unwrap();
+    let first = store
+        .commit_model(&project, "main", "okf1", "alex", "first commit", None, None)
+        .unwrap();
+    assert_eq!(
+        store.branch_tip(&project, "main").unwrap().unwrap(),
+        first.hash
+    );
+
+    let second = store
+        .commit_model(
+            &project,
+            "main",
+            "okf2",
+            "alex",
+            "second commit",
+            None,
+            None,
+        )
+        .unwrap();
+    assert_eq!(
+        store.branch_tip(&project, "main").unwrap().unwrap(),
+        second.hash
+    );
+    assert_eq!(store.commits_on(&project, "main").unwrap().len(), 2);
+    assert!(first.parents.is_empty(), "the first commit has no parent");
+    assert_eq!(second.parents, vec![first.hash.clone()]);
+}
+
+#[test]
+fn duplicate_projects_and_branches_are_conflicts() {
+    let Some(store) = require_store() else {
+        eprintln!("skipped: MW_TEST_DATABASE_URL is not set");
+        return;
+    };
+    let project = unique_project();
+    store.create_project(&project, None).unwrap();
+    match store.create_project(&project, None) {
+        Err(StoreError::Conflict(_)) => {}
+        other => panic!("expected a conflict, got {:?}", other),
+    }
+    let commit = store
+        .commit_model(&project, "main", "okf1", "alex", "first commit", None, None)
+        .unwrap();
+    store
+        .create_branch(&project, "review", &commit.hash, None)
+        .unwrap();
+    match store.create_branch(&project, "review", &commit.hash, None) {
+        Err(StoreError::Conflict(_)) => {}
+        other => panic!("expected a conflict, got {:?}", other),
+    }
+    match store.create_branch(&project, "other", "missing-commit", None) {
+        Err(StoreError::NotFound(_)) => {}
+        other => panic!("expected not found, got {:?}", other),
+    }
+}
+
+#[test]
+fn concurrent_commits_to_one_branch_form_a_linear_chain() {
+    let Some(store) = require_store() else {
+        eprintln!("skipped: MW_TEST_DATABASE_URL is not set");
+        return;
+    };
+    let project = unique_project();
+    store.create_project(&project, None).unwrap();
+    let store = std::sync::Arc::new(store);
+
+    let mut handles = Vec::new();
+    for i in 0..8 {
+        let store = store.clone();
+        let project = project.clone();
+        handles.push(std::thread::spawn(move || {
+            store
+                .commit_model(
+                    &project,
+                    "main",
+                    &format!("okf-{}", i),
+                    "alex",
+                    "concurrent",
+                    None,
+                    None,
+                )
+                .expect("commit model");
+        }));
+    }
+    for handle in handles {
+        handle.join().expect("worker thread");
+    }
+
+    let history = store.commits_on(&project, "main").unwrap();
+    assert_eq!(history.len(), 8, "every commit must land");
+
+    let mut children: std::collections::HashMap<String, Vec<String>> =
+        std::collections::HashMap::new();
+    for commit in &history {
+        for parent in &commit.parents {
+            children
+                .entry(parent.clone())
+                .or_default()
+                .push(commit.hash.clone());
+        }
+    }
+    for (parent, kids) in &children {
+        assert_eq!(
+            kids.len(),
+            1,
+            "commit {} is the parent of {} commits, so the history forked",
+            parent,
+            kids.len()
+        );
+    }
+
+    let tip = store.branch_tip(&project, "main").unwrap().unwrap();
+    let mut seen: Vec<String> = Vec::new();
+    let mut cursor = Some(tip);
+    while let Some(hash) = cursor {
+        assert!(
+            !seen.contains(&hash),
+            "the chain revisits {}, so it is not a chain",
+            hash
+        );
+        let commit = history
+            .iter()
+            .find(|c| c.hash == hash)
+            .expect("the tip and its ancestors must all be in the history");
+        cursor = commit.parents.first().cloned();
+        seen.push(hash);
+    }
+    assert_eq!(
+        seen.len(),
+        8,
+        "walking back from the tip must reach all eight commits"
+    );
+}
+
+#[test]
+fn a_merge_refuses_when_the_branch_moved_under_it() {
+    let Some(store) = require_store() else {
+        eprintln!("skipped: MW_TEST_DATABASE_URL is not set");
+        return;
+    };
+    let project = unique_project();
+    store.create_project(&project, None).unwrap();
+    let root = store
+        .commit_model(&project, "main", "okf-root", "alex", "root", None, None)
+        .unwrap();
+    store
+        .create_branch(&project, "feature", &root.hash, None)
+        .unwrap();
+    let their_side = store
+        .commit_model(
+            &project,
+            "feature",
+            "okf-feature",
+            "alex",
+            "feature",
+            None,
+            None,
+        )
+        .unwrap();
+
+    let concurrent = store
+        .commit_model(
+            &project,
+            "main",
+            "okf-concurrent",
+            "alex",
+            "concurrent",
+            None,
+            None,
+        )
+        .unwrap();
+
+    let refused = store.commit_merge(
+        &project,
+        "main",
+        &[root.hash.clone(), their_side.hash.clone()],
+        "okf-merged",
+        "alex",
+        "merge",
+        None,
+        None,
+    );
+    match refused {
+        Err(StoreError::Conflict(_)) => {}
+        other => panic!("expected a conflict, got {:?}", other.map(|c| c.hash)),
+    }
+
+    assert_eq!(
+        store.branch_tip(&project, "main").unwrap().unwrap(),
+        concurrent.hash
+    );
+    let merges: Vec<_> = store
+        .commits_on(&project, "main")
+        .unwrap()
+        .into_iter()
+        .filter(|c| c.parents.len() == 2)
+        .collect();
+    assert!(merges.is_empty(), "no merge commit may be written");
+}
+
+#[test]
+fn a_guarded_commit_is_refused_inside_the_transaction() {
+    let Some(store) = require_store() else {
+        eprintln!("skipped: MW_TEST_DATABASE_URL is not set");
+        return;
+    };
+    let project = unique_project();
+    store.create_project(&project, None).unwrap();
+    let root = store
+        .commit_model(&project, "main", "okf-root", "alex", "root", None, None)
+        .unwrap();
+    let root_hash = root.hash.clone();
+
+    store
+        .acquire_locks(
+            &project,
+            "main",
+            &["b1".to_string()],
+            "alex",
+            600,
+            1000,
+            None,
+        )
+        .unwrap();
+
+    let touched = vec!["b1".to_string()];
+    let refused = store.commit_model(
+        &project,
+        "main",
+        "okf-sam",
+        "sam",
+        "sam edits a locked element",
+        Some(CommitGuard {
+            holder: "sam",
+            elements: &touched,
+            now: 1000,
+            expected_tip: Some(&root_hash),
+        }),
+        None,
+    );
+    match refused {
+        Err(StoreError::Locked {
+            element, holder, ..
+        }) => {
+            assert_eq!(element, "b1");
+            assert_eq!(holder, "alex");
+        }
+        other => panic!("expected a conflict, got {:?}", other.map(|c| c.hash)),
+    }
+    assert_eq!(store.commits_on(&project, "main").unwrap().len(), 1);
+
+    let allowed = store.commit_model(
+        &project,
+        "main",
+        "okf-sam",
+        "sam",
+        "sam edits after the lease lapsed",
+        Some(CommitGuard {
+            holder: "sam",
+            elements: &touched,
+            now: 2000,
+            expected_tip: Some(&root_hash),
+        }),
+        None,
+    );
+    assert!(allowed.is_ok(), "an expired lease must not block a commit");
+
+    let elsewhere = vec!["b3".to_string()];
+    store
+        .acquire_locks(
+            &project,
+            "main",
+            &["b2".to_string()],
+            "alex",
+            600,
+            1000,
+            None,
+        )
+        .unwrap();
+    let tip_now = store.branch_tip(&project, "main").unwrap();
+    let unrelated = store.commit_model(
+        &project,
+        "main",
+        "okf-other",
+        "sam",
+        "sam edits something else",
+        Some(CommitGuard {
+            holder: "sam",
+            elements: &elsewhere,
+            now: 1000,
+            expected_tip: tip_now.as_deref(),
+        }),
+        None,
+    );
+    assert!(unrelated.is_ok(), "only the guarded elements are protected");
+}
+
+#[test]
+fn a_guard_computed_against_an_old_tip_is_refused() {
+    let Some(store) = require_store() else {
+        eprintln!("skipped: MW_TEST_DATABASE_URL is not set");
+        return;
+    };
+    let project = unique_project();
+    store.create_project(&project, None).unwrap();
+    let root = store
+        .commit_model(&project, "main", "okf-root", "alex", "root", None, None)
+        .unwrap();
+
+    store
+        .commit_model(&project, "main", "okf-other", "alex", "moved", None, None)
+        .unwrap();
+
+    let touched = vec!["b1".to_string()];
+    let stale = store.commit_model(
+        &project,
+        "main",
+        "okf-sam",
+        "sam",
+        "sam commits against a stale view",
+        Some(CommitGuard {
+            holder: "sam",
+            elements: &touched,
+            now: 1000,
+            expected_tip: Some(&root.hash),
+        }),
+        None,
+    );
+    match stale {
+        Err(StoreError::Conflict(message)) => {
+            assert!(
+                message.contains("moved"),
+                "the refusal must say the branch moved: {}",
+                message
+            );
+        }
+        other => panic!("expected a conflict, got {:?}", other.map(|c| c.hash)),
+    }
+    assert_eq!(
+        store.commits_on(&project, "main").unwrap().len(),
+        2,
+        "nothing may be written"
+    );
+}
+
+#[test]
+fn audit_rows_ride_each_mutation_transaction() {
+    let Some(store) = require_store() else {
+        eprintln!("skipped: MW_TEST_DATABASE_URL is not set");
+        return;
+    };
+    let project = unique_project();
+    let entry = |action: &str| AuditEntry {
+        id: 0,
+        project: project.clone(),
+        at: 1,
+        actor: "alex".to_string(),
+        mechanism: "jwt".to_string(),
+        action: action.to_string(),
+        subject: "s".to_string(),
+        detail: "d".to_string(),
+    };
+
+    store
+        .create_project(&project, Some(&entry("project.create")))
+        .unwrap();
+    let root = store
+        .commit_model(&project, "main", "okf-root", "alex", "root", None, None)
+        .unwrap();
+    store
+        .create_branch(
+            &project,
+            "feature",
+            &root.hash,
+            Some(&entry("branch.create")),
+        )
+        .unwrap();
+    store
+        .acquire_locks(
+            &project,
+            "main",
+            &["b1".to_string()],
+            "alex",
+            600,
+            1000,
+            Some(&entry("lock.acquire")),
+        )
+        .unwrap();
+    let ids: Vec<String> = store
+        .locks(&project, 1000)
+        .unwrap()
+        .into_iter()
+        .map(|l| l.id)
+        .collect();
+    store
+        .release_locks(&project, "alex", &ids, Some(&entry("lock.release")))
+        .unwrap();
+    store
+        .record_gate_run(
+            &GateRun {
+                project: project.clone(),
+                branch: "main".to_string(),
+                reference_hash: "r".to_string(),
+                candidate_hash: "c".to_string(),
+                passed: true,
+                evidence: "{}".to_string(),
+                created_at: "1".to_string(),
+            },
+            Some(&entry("gate.run")),
+        )
+        .unwrap();
+    store
+        .delete_branch(&project, "feature", Some(&entry("branch.delete")))
+        .unwrap();
+
+    let actions: Vec<String> = store
+        .audit(&project, 1000)
+        .unwrap()
+        .into_iter()
+        .map(|e| e.action)
+        .collect();
+    for action in [
+        "project.create",
+        "branch.create",
+        "lock.acquire",
+        "lock.release",
+        "gate.run",
+        "branch.delete",
+    ] {
+        assert!(
+            actions.contains(&action.to_string()),
+            "missing audit action {}",
+            action
+        );
+    }
+}
+
+#[test]
+fn the_audit_table_refuses_update_and_delete() {
+    let Some(store) = require_store() else {
+        eprintln!("skipped: MW_TEST_DATABASE_URL is not set");
+        return;
+    };
+    let project = unique_project();
+    store.create_project(&project, None).unwrap();
+    let id = store
+        .append_audit(&AuditEntry {
+            id: 0,
+            project: project.clone(),
+            at: 1,
+            actor: "a".to_string(),
+            mechanism: "open".to_string(),
+            action: "x".to_string(),
+            subject: "s".to_string(),
+            detail: "d".to_string(),
+        })
+        .unwrap();
+
+    // A second connection, raw SQL, so the trigger is tested against the database rather
+    // than against the store's own (deliberately update-free) interface.
+    let url = std::env::var("MW_TEST_DATABASE_URL").unwrap();
+    let mut conn = postgres::Client::connect(&url, NoTls).expect("connect raw client");
+    assert!(
+        conn.execute(
+            "UPDATE audit SET detail = 'rewritten' WHERE id = $1",
+            &[&id]
+        )
+        .is_err(),
+        "UPDATE on the audit table must be refused by the trigger"
+    );
+    assert!(
+        conn.execute("DELETE FROM audit WHERE id = $1", &[&id])
+            .is_err(),
+        "DELETE on the audit table must be refused by the trigger"
+    );
+}
+
+#[test]
+fn a_mutation_rolls_back_when_its_audit_entry_cannot_be_written() {
+    let Some(store) = require_store() else {
+        eprintln!("skipped: MW_TEST_DATABASE_URL is not set");
+        return;
+    };
+    let project = unique_project();
+    let unwritable = AuditEntry {
+        id: 0,
+        project: project.clone(),
+        at: 0,
+        actor: String::new(),
+        mechanism: "open".to_string(),
+        action: "project.create".to_string(),
+        subject: project.clone(),
+        detail: "an entry that names nobody is not a record".to_string(),
+    };
+
+    let refused = store.create_project(&project, Some(&unwritable));
+    assert!(
+        refused.is_err(),
+        "an unwritable audit entry must fail the mutation it describes"
+    );
+    assert!(
+        store.project(&project).unwrap().is_none(),
+        "the project must NOT survive: the mutation rolled back with its record"
+    );
+}
+
+#[test]
+fn an_expired_lease_stops_blocking() {
+    let Some(store) = require_store() else {
+        eprintln!("skipped: MW_TEST_DATABASE_URL is not set");
+        return;
+    };
+    let project = unique_project();
+
+    // A acquires b1 at now = 1000 with ttl 30, so the lease expires at 1030.
+    store
+        .acquire_locks(
+            &project,
+            "main",
+            &["b1".to_string()],
+            "alex",
+            30,
+            1000,
+            None,
+        )
+        .unwrap();
+
+    match store.acquire_locks(&project, "main", &["b1".to_string()], "bob", 30, 1000, None) {
+        Err(StoreError::Locked { holder, .. }) => {
+            assert_eq!(holder, "alex", "the refusal must name the holder");
+        }
+        other => panic!("expected a lock refusal at now=1000, got {:?}", other),
+    }
+
+    let acquired = store
+        .acquire_locks(&project, "main", &["b1".to_string()], "bob", 30, 1031, None)
+        .unwrap();
+    assert_eq!(acquired.len(), 1);
+    assert_eq!(acquired[0].holder, "bob");
+}
+
+#[test]
+fn deleting_a_branch_leaves_its_commits_readable() {
+    let Some(store) = require_store() else {
+        eprintln!("skipped: MW_TEST_DATABASE_URL is not set");
+        return;
+    };
+    let project = unique_project();
+    store.create_project(&project, None).unwrap();
+    let commit = store
+        .commit_model(&project, "main", "okf", "alex", "commit", None, None)
+        .unwrap();
+    store
+        .create_branch(&project, "review", &commit.hash, None)
+        .unwrap();
+
+    store.delete_branch(&project, "review", None).unwrap();
+
+    // Deleting a branch removes the pointer, never the commits it pointed at.
+    let still = store.commit(&project, &commit.hash).unwrap();
+    assert!(still.is_some(), "the commit must survive its branch");
+    assert_eq!(still.unwrap().hash, commit.hash);
+}

## FILE: server/tests/store.rs

diff --git a/server/tests/store.rs b/server/tests/store.rs
index 291b405..be9d922 100644
--- a/server/tests/store.rs
+++ b/server/tests/store.rs
@@ -1,7 +1,7 @@
-// SPDX-License-Identifier: AGPL-3.0-or-later
+﻿// SPDX-License-Identifier: AGPL-3.0-or-later
 use server::store::{commit_hash, sqlite::SqliteStore, AuditEntry, GateRun, Store, StoreError};
 
 fn store() -> (SqliteStore, tempfile::TempDir) {
     let dir = tempfile::tempdir().unwrap();
     let store = SqliteStore::open(&dir.path().join("mw.db")).unwrap();
     (store, dir)
@@ -533,6 +533,43 @@ fn a_mutation_rolls_back_when_its_audit_entry_cannot_be_written() {
     );
     assert!(
         store.project("coffee").unwrap().is_none(),
         "the project must NOT survive: the mutation rolled back with its record"
     );
 }
+
+#[test]
+fn an_older_database_gains_the_mechanism_column_instead_of_failing() {
+    // CREATE TABLE IF NOT EXISTS is not a migration: a table that already exists keeps its
+    // old shape, so a column added to the schema never reaches an installation that
+    // upgrades. Without a migration path every audit write on such a database fails and
+    // every mutation becomes a 500 - a failure discovered during a customer upgrade rather
+    // than in a test. This builds the OLD audit table by hand, then opens it.
+    use server::store::{AuditEntry, Store};
+
+    let dir = tempfile::tempdir().unwrap();
+    let path = dir.path().join("old.db");
+    {
+        let connection = rusqlite::Connection::open(&path).unwrap();
+        let old_audit = "CREATE TABLE audit (id INTEGER PRIMARY KEY AUTOINCREMENT, project TEXT NOT NULL, at INTEGER NOT NULL, actor TEXT NOT NULL, action TEXT NOT NULL, subject TEXT NOT NULL, detail TEXT NOT NULL)";
+        connection.execute_batch(old_audit).unwrap();
+    }
+
+    let store = SqliteStore::open(&path).expect("an older database must open, not fail");
+    store.create_project("coffee", None).unwrap();
+    let entry = AuditEntry {
+        id: 0,
+        project: "coffee".to_string(),
+        at: 1,
+        actor: "alex".to_string(),
+        mechanism: "static".to_string(),
+        action: "commit.create".to_string(),
+        subject: "main".to_string(),
+        detail: "after the migration".to_string(),
+    };
+    store
+        .append_audit(&entry)
+        .expect("the migrated table must accept a write");
+    let rows = store.audit("coffee", 10).unwrap();
+    assert_eq!(rows.len(), 1);
+    assert_eq!(rows[0].mechanism, "static");
+}
