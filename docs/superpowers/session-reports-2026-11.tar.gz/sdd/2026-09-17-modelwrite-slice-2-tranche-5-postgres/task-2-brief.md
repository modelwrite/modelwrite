## Global Constraints

- Rust stable; edition 2021; rust-version 1.75.
- Every source file begins with: // SPDX-License-Identifier: AGPL-3.0-or-later
- Cargo is not on PATH in fresh shells: begin every shell command sequence with $env:Path = "$env:USERPROFILE\\.cargo\\bin;" + $env:Path
- Use --no-fail-fast when running a test suite.
- Stage and commit only the paths a task owns. Never amend or rewrite a commit.
- The PostgreSQL backend must honour EVERY invariant the SQLite backend enforces, in the database rather than in a process mutex: the tip read and the commit write in ONE transaction, the lock check inside the write transaction, the audit insert inside the mutation's transaction, and parents verified before a merge commit cites them. The SQLite tests that assert these are the specification; where a test is backend-specific, write the Postgres equivalent rather than skipping it.
- Postgres tests SKIP when MW_TEST_DATABASE_URL is unset, and the report must state how many tests were skipped and that they were.
- The audit table's append-only property is enforced by a trigger on Postgres too, not by convention.
- The CLI must never print a token, and must exit non-zero on a failed command with a message a person can act on.
- No test may bind a port outside the ephemeral range, and no test may depend on the network.

## Task 2: The CLI

**Files:**
- Create: cli/Cargo.toml, cli/src/main.rs, cli/src/http.rs, cli/src/offline.rs
- Modify: Cargo.toml (workspace members)
- Test: cli/tests/cli.rs (argument parsing and the offline path; the HTTP path tested against an in-process server)

**Interfaces:**
- Produces a binary named `mw` with commands: `project create|list`, `commit --branch --message --file --holder`, `log --branch`, `branch list|create|delete`, `merge --branch --other --holder`, `reset --branch --to --holder`, `gate --reference --candidate`, `lock acquire|release|list`, `audit --limit`. Global flags: `--server <url>` with `--token <env:VAR>`, or `--db <path>` for offline use.

**Steps:**

- [ ] **Step 1: The skeleton and argument parsing by hand**, so the CLI adds no dependency: a small parser that produces a typed Command, with a unit test per command and a clear error for an unknown flag.

- [ ] **Step 2: The offline path** opens the store directly and performs the same operations, so an air-gapped user can commit and inspect history with no server at all.

- [ ] **Step 3: The HTTP path** is a minimal HTTP/1.1 client over std::net::TcpStream: request line, headers, content-length body, and response parsing with status and body. It refuses an https:// URL with a message explaining that TLS belongs at the proxy.

- [ ] **Step 4: The token comes from an environment variable named by the flag**, never from the command line, because a token in a command line is a token in the shell history and in the process list.

- [ ] **Step 5: Tests**: each command parses; a failed command exits non-zero; offline commit then log round-trips; the HTTP path is exercised against the in-process router bound to an ephemeral port; a token is never echoed in output or in an error.

- [ ] **Step 6: Commit** with `feat: add the modelwrite command line`.

---

