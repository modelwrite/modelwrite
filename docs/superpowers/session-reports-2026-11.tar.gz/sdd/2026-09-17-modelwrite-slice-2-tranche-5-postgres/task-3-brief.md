## Global Constraints

- Rust stable; edition 2021; rust-version 1.75.
- Every source file begins with: // SPDX-License-Identifier: AGPL-3.0-or-later
- Cargo is not on PATH in fresh shells: begin every shell command sequence with $env:Path = "$env:USERPROFILE\\.cargo\\bin;" + $env:Path
- Use --no-fail-fast when running a test suite.
- Stage and commit only the paths a task owns. Never amend or rewrite a commit.
- The PostgreSQL backend must honour EVERY invariant the SQLite backend enforces, in the database rather than in a process mutex: the tip read and the commit write in ONE transaction, the lock check inside the write transaction, the audit insert inside the mutation's transaction, and parents verified before a merge commit cites them. The SQLite tests that assert these are the specification; where a test is backend-specific, write the Postgres equivalent rather than skipping it.
- Postgres tests SKIP when MW_TEST_DATABASE_URL is unset, and the report must state how many tests were skipped and that they were.
- The audit table's append-only property is enforced by a trigger on Postgres too, not by convention.
- The CLI must never print a token, and must exit non-zero on a failed command with a message a person can act on.
- No test may bind a port outside the ephemeral range, and no test may depend on the network.

## Task 3: Deployment

**Files:**
- Create: deploy/Dockerfile, deploy/docker-compose.yml, deploy/helm/modelwrite/Chart.yaml, values.yaml, templates/deployment.yaml, templates/service.yaml, templates/configmap.yaml, templates/secret.yaml.example
- Create: deploy/README.md
- Modify: README.md (a quick start that uses them)

**Interfaces:**
- Produces: a container image that runs the service as a non-root user with a read-only root filesystem where possible; a compose file that brings up the service with a local volume for trials; a Helm chart with values for the database URL, the auth configuration, resources, and persistence; and a README that states the open-mode warning in bold, explains the air-gapped install path (image transfer, mounted JWKS file, local Postgres or none), and lists what the chart does NOT do (no TLS termination, no backups, no HA).

**Steps:**

- [ ] **Step 1: The image**: a multi-stage build, the binary copied into a slim runtime, a non-root user, and an entrypoint that refuses to start when neither auth configuration nor an explicit MW_ALLOW_OPEN=yes is present. **A production service should not be able to run unauthenticated by accident.**

- [ ] **Step 2: compose** for a trial: service plus a Postgres container, a named volume, and the environment variables documented inline.

- [ ] **Step 3: The Helm chart**, with values documented in values.yaml, secrets referenced rather than inlined, a liveness and readiness probe against /health, and resource requests and limits.

- [ ] **Step 4: Validate what can be validated here.** There is no Docker on this machine, so nothing can be built or run. Verify the YAML parses, the Helm templates are well-formed YAML, and that the Kubernetes API fields used are real for the target version. Say plainly in the report that the image was never built and the chart never installed.

- [ ] **Step 5: Commit** with `feat: add container, compose and Helm deployment`.

---

