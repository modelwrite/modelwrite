## Global Constraints

- Rust stable; edition 2021; rust-version 1.75.
- Every source file begins with: // SPDX-License-Identifier: AGPL-3.0-or-later
- Cargo is not on PATH in fresh shells: begin every shell command sequence with $env:Path = "$env:USERPROFILE\\.cargo\\bin;" + $env:Path
- Use --no-fail-fast when running a test suite.
- Stage and commit only the paths a task owns. Never amend or rewrite a commit.
- The PostgreSQL backend must honour EVERY invariant the SQLite backend enforces, in the database rather than in a process mutex: the tip read and the commit write in ONE transaction, the lock check inside the write transaction, the audit insert inside the mutation's transaction, and parents verified before a merge commit cites them. The SQLite tests that assert these are the specification; where a test is backend-specific, write the Postgres equivalent rather than skipping it.
- Postgres tests SKIP when MW_TEST_DATABASE_URL is unset, and the report must state how many tests were skipped and that they were.
- The audit table's append-only property is enforced by a trigger on Postgres too, not by convention.
- The CLI must never print a token, and must exit non-zero on a failed command with a message a person can act on.
- No test may bind a port outside the ephemeral range, and no test may depend on the network.

## Task 4: CI proves the parts this machine cannot

**Files:**
- Modify: .github/workflows/ci.yml
- Modify: deploy/README.md (what CI proves)

**Interfaces:**
- Produces a CI job with a postgres service container that sets MW_TEST_DATABASE_URL and runs the Postgres tests for real, plus a job that lints the Helm chart and validates the compose file with a YAML parser, and a job that builds the container image.

**Steps:**

- [ ] **Step 1: The Postgres job**, with a service container, a health check, and the same workspace tests run against it so the skipped-locally tests actually execute.

- [ ] **Step 2: The deployment job** that parses every YAML file in deploy/ and fails on a syntax error, and builds the image.

- [ ] **Step 3: Prove it** by pushing and reading the CI result, then recording the run id and the outcome in the ledger. A green CI run is the only evidence that the Postgres and container paths work at all.

- [ ] **Step 4: Commit** with `ci: exercise PostgreSQL and the container image`.

---

