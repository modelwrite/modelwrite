## Global Constraints

- Rust stable; edition 2021; rust-version 1.75.
- Every source file begins with: // SPDX-License-Identifier: AGPL-3.0-or-later
- Cargo is not on PATH in fresh shells: begin every shell command sequence with $env:Path = "$env:USERPROFILE\\.cargo\\bin;" + $env:Path
- Use --no-fail-fast when running a test suite.
- Stage and commit only the paths a task owns. Never amend or rewrite a commit.
- The PostgreSQL backend must honour EVERY invariant the SQLite backend enforces, in the database rather than in a process mutex: the tip read and the commit write in ONE transaction, the lock check inside the write transaction, the audit insert inside the mutation's transaction, and parents verified before a merge commit cites them. The SQLite tests that assert these are the specification; where a test is backend-specific, write the Postgres equivalent rather than skipping it.
- Postgres tests SKIP when MW_TEST_DATABASE_URL is unset, and the report must state how many tests were skipped and that they were.
- The audit table's append-only property is enforced by a trigger on Postgres too, not by convention.
- The CLI must never print a token, and must exit non-zero on a failed command with a message a person can act on.
- No test may bind a port outside the ephemeral range, and no test may depend on the network.

## Task 1: The PostgreSQL store behind the same trait

**Files:**
- Modify: server/Cargo.toml (the postgres driver, feature-gated off by default)
- Create: server/src/store/postgres.rs
- Modify: server/src/store/mod.rs (a constructor that picks the backend from configuration)
- Test: server/tests/postgres.rs (skipped without MW_TEST_DATABASE_URL)

**Interfaces:**
- Produces: `PostgresStore::open(url: &str) -> Result<Self, StoreError>` implementing the whole Store trait, and `pub fn open_store(config: &StoreConfig) -> Result<Arc<dyn Store>, StoreError>` where `StoreConfig` is `Sqlite(PathBuf)` or `Postgres(String)` chosen from `MW_DB` (a path) or `MW_DATABASE_URL`.

**Steps:**

- [ ] **Step 1: Add the driver.** Choose the rustls-based driver so the image does not need OpenSSL, and record the choice and version in the report. Feature-gate it so a build without Postgres still works if that proves simpler.

- [ ] **Step 2: The schema, as SQL that enforces the invariants.** Port the SQLite schema to Postgres types (TEXT stays TEXT, INTEGER becomes BIGINT, the audit id becomes BIGSERIAL), keeping every constraint and adding: a foreign key from commits to their parents is impossible in a single column, so instead keep the explicit parent check; a trigger that raises on UPDATE and DELETE of the audit table; and the CHECK constraints that reject an audit entry naming nobody.

- [ ] **Step 3: Implement the trait.** Every method that mutates must use ONE database transaction, and the tip read must happen inside it. Where the SQLite backend relies on a process-wide mutex for serialisation, Postgres must rely on the transaction and on row locks: use `SELECT ... FOR UPDATE` on the branch row where a tip is read before a write, so two concurrent commits to one branch serialise in the database rather than in a mutex.

- [ ] **Step 4: Tests** in server/tests/postgres.rs, mirroring the SQLite store tests: the eight-thread linearity test, the merge refusal when the branch moved, the lock lease boundary with an injected clock, the audit rollback when the entry cannot be written, and branch deletion leaving commits readable.

- [ ] **Step 5: Run what can be run, and say what could not.** Locally there is no PostgreSQL, so the tests skip. Verify the code compiles, lints and that the skip path works. Expected: the local suite is green with the Postgres tests reported as skipped.

- [ ] **Step 6: Commit** with `feat: add a PostgreSQL backend behind the store trait`.

---

