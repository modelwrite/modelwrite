# Requirements Import Report — SysML v1 XMI binding

Status: DONE_WITH_CONCERNS
Commit: 4dc40ee — `binding-xmi: carry Requirements and Satisfy/Allocate traceability`

## One-line test summary

`cargo test --workspace --no-fail-fast` green, `cargo fmt --all -- --check` clean, `cargo clippy --workspace --all-targets -- -D warnings` clean. The real MagicDraw import now carries 25/25 requirements and 23/23 Satisfy+Allocate links.

## Before / after — real MagicDraw model (`real-world/mdzip/model.xmi`)

| metric | before | after |
|---|---|---|
| structure elements (blocks) | 34 | 34 |
| requirements carried | 0 | 25 |
| graph nodes | 34 | 59 (34 blocks + 25 requirements) |
| graph edges — Satisfy | 0 | 20 |
| graph edges — Allocate | 0 | 3 |
| graph edges — Refine / Verify | 0 | 4 / 1 |
| graph edges — total | 0 | 28 |
| content losses | 348 | 270 |
| blocking (Lossy + Unmappable) | 407 | 357 |
| declarations | 1 | 1 |

## MagicDraw XMI shape (so the next person does not re-derive it)

- A **Requirement** is a `uml:Class` (either `packagedElement` or `nestedClassifier`) with NO Block stereotype. Its stereotype is applied by a SIBLING of `uml:Model` at the document root, not by a child of the class and not by an `xmi:Extension`:

  ```xml
  <sysml:Requirement xmi:id="<class-id>_" base_Class="<class-id>" Id="1.1" Text="The boiler shall heat..."/>
  ```

  - `base_Class` → the requirement's element id (the `uml:Class` `xmi:id`), carried as OKF `Requirement.id` and graph-node id.
  - `Id` → `reqId` (the requirement's own id, e.g. "1.1").
  - `Text` → `reqText` (the body; empty for container/folder requirements).
  - the class's `name` attribute → the requirement's `name`.

- **Stereotype application in general** is a sibling `<sysml:... base_...=.../>` element at the root (after `</uml:Model>`): `sysml:Block base_Class`, `sysml:Requirement base_Class Id Text`, `sysml:Satisfy base_Abstraction`, `sysml:Allocate base_Abstraction`, `sysml:Refine`, `sysml:Verify`, etc. It is never an attribute and never an `xmi:Extension`.

- A **Satisfy/Allocate/Refine/Verify** link is a `uml:Abstraction` (NOT `uml:Dependency`) whose client/supplier are CHILD ELEMENTS carrying `xmi:idref`, not attributes:

  ```xml
  <packagedElement xmi:type="uml:Abstraction" xmi:id="...">
    <client xmi:idref="<block-id>"/>
    <supplier xmi:idref="<requirement-id>"/>
  </packagedElement>
  <sysml:Satisfy xmi:id="..._application" base_Abstraction="<abstraction-id>"/>
  ```

  - Satisfy: `client` = the satisfying BLOCK, `supplier` = the satisfied REQUIREMENT.
  - Allocate: `client` = source block, `supplier` = target block (block→block in this model).
  - The reader emits each as `kind="dependency"`, `label` = the stereotype name, `source` = client, `target` = supplier.

## Direction decision (important — read this)

The task wording said "source=the requirement, target=the block", but the authoritative OKF shape in this repo is the reverse. Verified against three independent authorities:

- `sample/corpus/coffee-machine/okf/expected/coffee_machine_model.json` (golden) — Satisfy edges are source=block, target=requirement (e.g. "Boiler → Heater Initialization").
- `engine/graph/src/lib.rs` `requirement_coverage` — counts `req_ids.contains(target)`, i.e. the requirement MUST be the edge TARGET for Satisfy/Refine/Verify to count.
- `server/src/ui/model.rs` `allocations()` — reads `edge.target` as the requirement and `edge.source` as the allocated element.

So edges are emitted source=client, target=supplier (the existing reader's own convention). source=requirement/target=block would report 0 coverage and show nothing in the UI. Flagging so a reviewer can confirm this is the intended direction.

## Remaining losses (270 content losses, all still named — nothing silent)

Now carried: 25 requirements, 20 Satisfy, 3 Allocate (plus the 4 Refine + 1 Verify already in the subset).

The 270 remaining content losses are constructs still outside the sysml-v1-xmi subset, each named as Unmappable:

- `uml:Port`, `uml:Operation`, `uml:Association`, `uml:Signal`/`uml:SignalEvent`, `uml:UseCase`, `uml:Actor`, `uml:Activity`, `uml:StateMachine`, `uml:Diagram`, and their stereotype applications (InterfaceBlock, ConstraintBlock, ValueType, ProxyPort, FlowProperty, PartProperty, DiagramInfo, auxiliaryResource).
- Unmapped attributes on carried elements: `visibility`, `association`, `classifierBehavior`, `direction`, etc.
- MagicDraw serialization metadata: `xmi:Documentation` and `xmi:Extension` elements (diagram/model-extension metadata) are currently reported as Unmappable content losses rather than declarations.

## Concerns

1. **Direction**: I implemented source=block → target=requirement for Satisfy, contradicting the task's literal "source=requirement, target=block", because the literal reading breaks the repo's own coverage/UI/golden-corpus. See "Direction decision" above.
2. **Workspace run**: `cargo test --workspace` first failed with "Access is denied" removing `target/debug/mw-server.exe` (a leftover running `mw-server.exe`, PID 234224, started 19/09/2026 09:14, no args). I stopped that stale process and re-ran; the full suite then passed green.
3. **xmi:Extension/xmi:Documentation metadata** still counts as content loss (see above); out of scope for this task but a candidate future "declaration" classification.
