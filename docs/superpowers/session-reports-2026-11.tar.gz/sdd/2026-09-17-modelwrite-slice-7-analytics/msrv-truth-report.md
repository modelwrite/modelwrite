# MSRV truth report — modelwrite build configuration

status: DONE
commits: 0520a07
declared floor now:
  - engine/* : 1.75  (workspace.package rust-version; now TRUE)
  - server, cli : 1.88  (unchanged; was already true)

## Decision: (A) MAKE IT TRUE

The engine layer's 1.75 floor is a property the project's own planning docs
mandate ("engine crates stay at rust-version 1.75 ... MUST STAY THERE" — see
docs/superpowers/plans/2026-09-17-modelwrite-slice-4-interoperability.md and
slice-5/6/7). It was NOT necessary to raise it. The only dependency that
violated it was indexmap (petgraph's transitive dep via mw-graph), and the fix
is a small pin, not a far-out-of-date one:

  indexmap  2.14.2 (rust-version 1.85, edition2024)  -> pinned to  2.11.4 (rust-version 1.63)
  hashbrown 0.17.1 (rust-version 1.85.0)             -> resolved to 0.16.1 (rust-version 1.65.0)

indexmap 2.11.4 is the last release with MSRV <= 1.75 (2.12.0 jumped to 1.82,
2.14.0 to 1.85). After the pin, the engine closure's highest transitive MSRV is
1.71 (serde_derive / serde_json / syn / proc-macro2 / quote / ryu / zmij), so
1.75 genuinely builds. Raising the floor (option B) was unnecessary and would
have contradicted the planning docs.

## What changed

- Cargo.toml : added `indexmap = "=2.11.4"` to [workspace.dependencies] with a
  comment explaining the MSRV pin.
- engine/graph/Cargo.toml : added `indexmap.workspace = true` (a direct dep on
  the pin, so the transitive resolution is forced; documented in a comment).
- Cargo.lock : indexmap 2.14.2 -> 2.11.4, hashbrown 0.17.1 -> 0.16.1.
- .github/workflows/ci.yml : the msrv job now builds each layer at its OWN
  declared floor instead of collapsing both to 1.88.

## THE EXACT COMMANDS AND OUTPUT THAT PROVE IT

### BEFORE — the declared 1.75 was false (engine did not build at 1.75)

    cargo +1.75.0 check -p mw-graph

output (tail):

    error: failed to download `indexmap v2.14.2`
    ...
    feature `edition2024` is required

      The package requires the Cargo feature called `edition2024`, but that feature is not stabilized in this version of
      Cargo (1.75.0 (1d8b05cdd 2023-11-20)).
      ...

### BEFORE — the un-pinned engine floor was exactly 1.85 (not higher)

(verified by temporarily stashing this change and building the committed lockfile)

    cargo +1.85.0 build -p mw-graph --locked

output (tail):

    Compiling indexmap v2.14.2
    Compiling petgraph v0.6.5
    Compiling mw-graph v0.1.0 (...)
        Finished `dev` profile [unoptimized + debuginfo] target(s) in 10.37s
    BEFORE_STATE_185_BUILD_EXIT: 0

The stash was popped cleanly; all working-tree state (including another task's
in-progress engine/analytics files) was restored.

### AFTER — the declared 1.75 floor is now TRUE (engine builds at 1.75)

    cargo +1.75.0 build -p mw-okf -p mw-test-support -p mw-graph -p mw-gate -p mw-binding -p mw-binding-xmi -p mw-agent -p mw-capi -p mw-mcp -p mw-analytics --locked

output (tail):

    Compiling mw-graph v0.1.0 (...)
    Compiling mw-binding v0.1.0 (...)
    Compiling mw-gate v0.1.0 (...)
    Compiling mw-analytics v0.1.0 (...)
    Compiling mw-mcp v0.1.0 (...)
    Compiling mw-binding-xmi v0.1.0 (...)
    Compiling mw-agent v0.1.0 (...)
    Compiling mw-capi v0.1.0 (...)
        Finished dev [unoptimized + debuginfo] target(s) in 10.41s
    ENGINE_BUILD_EXIT: 0

### AFTER — the server floor (1.88) still holds

    cargo +1.88.0 build -p mw-server -p mw-cli --locked

output (tail):

        Finished `dev` profile [unoptimized + debuginfo] target(s) in 27.87s
    SERVER_BUILD_EXIT: 0

### REGRESSION — full test suite still green

    cargo +stable test --workspace

result: 362 passed, 0 failed, 21 ignored (the PostgreSQL suite), exit 0.

### LINT — the pin introduces no clippy warning (CI runs `-D warnings`)

    cargo +stable clippy -p mw-graph --all-targets -- -D warnings

result: `Finished` (exit 0, no warnings). The pinned indexmap is a direct
dependency of mw-graph but is not referenced in code; clippy does not flag it.

## CI (from now on)

The msrv job builds the engine layer with toolchain 1.75.0 and the server layer
with 1.88.0, both `--locked`. The next dependency that raises either floor will
fail that job instead of drifting silently.

## Concerns

1. The indexmap pin is carried as a direct dependency of mw-graph that is not
   referenced in code (the standard idiom for pinning a transitive dep). A
   future "remove unused dependency" cleanup could drop it and silently re-break
   the 1.75 floor — but the msrv CI job now builds at 1.75 and would catch that.
   The inline comments in both Cargo.toml files name the reason.

2. indexmap 2.11.4 is three minor releases behind 2.14.2. This is a deliberate,
   minimal MSRV pin (2.12 was the first 1.82+ release), not a "far out of date"
   choice. Revisit if the 1.75 floor is ever dropped.

3. Another task is concurrently editing engine/analytics/ (modified
   src/lib.rs, untracked src/cost.rs and tests/cost.rs). I did not touch or
   commit any of it; commit 0520a07 stages only the four build-config files.
