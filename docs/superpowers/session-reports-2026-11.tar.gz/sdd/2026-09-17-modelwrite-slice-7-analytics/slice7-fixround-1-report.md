# Slice 7 analytics — fix round 1 report

**Status:** DONE_WITH_CONCERNS

## Commits

- `1348b39` — fix(analytics): surface unmatched cost records; resolve trust via the registry

9 files changed, 761 insertions(+), 260 deletions(-), all under engine/analytics/. No commit was
amended; nothing outside engine/analytics/ was staged (the concurrent server-endpoint task's
server/, Cargo.toml and Cargo.lock changes were left untouched).

## One-line test summary

cargo test --workspace --no-fail-fast → **404 passed, 0 failed, 21 ignored** (the PostgreSQL
suite, which CI runs). The analytics crate runs 79 tests: compliance 14, confidence 14, cost 21,
dataset 21, money 9. Baseline was 372 passed / 21 ignored.

## What changed for each finding

### IMPORTANT 1 — a present cost becomes an omitted row

cost_by_requirement now (a) trims every requirement cell before keying, so a near-miss key like
'REQ-1 ' joins to the model's 'REQ-1' instead of leaving it falsely Uncosted; and (b) after the
output loop, any record key still present names a requirement no queried model contains and is
surfaced as a typed error CostError::UnmatchedRequirements (all keys, sorted), rather than
silently discarded. A dataset row for an unknown requirement can no longer vanish while its real
model requirement reads Uncosted. I chose the typed error over explicit unmatched result entries
because it matches the module's existing 'clear error, never a partial result' contract
(MissingColumn already refuses the whole join) and makes the refusal fail-fast.

### IMPORTANT 2 — the weakest-link rule was self-attested

Trust is now resolved from the registry, never from the caller:

- Value fields are private; the public Value::new(value, source, trust, captured_at) is gone. The
  only public constructor is Value::from_registry(value, source_id, captured_at, &Registry), which
  reads the trust from the registered source and refuses an unregistered source with
  RegistryError::UnregisteredSource. A crate-private Value::stamped is used inside the pipeline
  after the registry has been consulted. Deserialize was dropped from Value so a serialized blob
  cannot stamp its own trust.
- cost_by_requirement(models, &Registry, datasets) resolves each dataset's trust from
  registry.source(dataset.source.id), erroring with CostError::UnregisteredSource if absent. The
  dataset's carried trust is ignored at query time, so a dataset claiming Measured for a source the
  registry knows as Estimated is CORRECTED to Estimated.
- Registry::register_dataset re-stamps the dataset's source from the registry, closing the last
  path that let a caller hand in a trust-upgraded dataset.

What remains reachable and why: Dataset::from_csv_at stays public (the registry's snapshot builds
through it, and tests need the stamped form); Source fields stay public because a source's trust is
legitimately declared at Registry::register. Neither lets a query grade its own input.

### M4 — registry collided on content hash alone

Datasets are keyed by (source_id, content_hash); Registry::dataset and Registry::bytes now take
both. Two sources sharing byte-identical input no longer overwrite each other's provenance.

### M5 — FusedValue did not name the weak source

FusedValue now carries trusts: BTreeMap<String, TrustLevel>, so a serialized finding says WHICH
source was weak, not just that some source was.

### M6 — ModelCompliance was indistinguishable across versions

ModelCompliance now carries model_hash (okf canonical hash) and exported_at.

### M7 — Satisfied/NotSatisfied read like the gate's pass/fail

Renamed to Compliance::Covered / Uncovered / Unknown (and ModelCompliance.covered / uncovered /
unknown, covered_count / uncovered_count). The module doc now states the vocabulary is deliberately
NOT the gate's: Covered/Uncovered name graph coverage only, while the gate has its own pass/fail
meaning (round-trip fidelity, validation, integration, strict coverage).

### M8 — empty captured_at rendered as a blank

The unstamped Dataset::from_csv is removed (it was the only path that left captured_at empty).
from_csv_at is now the sole direct constructor. Additionally the query path refuses a dataset with
an empty captured_at (CostError::UnstampedSource), so a figure can never carry an absence where
its provenance belongs.

### M9 — blank lines and opaque row-too-short errors

Blank rows (including a trailing blank line, which parses to ['']) are skipped, and MalformedCost
now carries row (1-based CSV row number) in its error and Display.

## Tests changed and why

- an_empty_model_list_is_an_empty_result_not_a_panic → an_empty_model_list_with_no_records_is_an_empty_result
  (now uses a header-only dataset). Expectation changed: an empty model list WITH a record is now an
  error (an_empty_model_list_with_records_is_an_error_not_a_silent_drop), because that record is
  exactly the 'present value rendering as absence' the slice forbids.
- from_csv_at_stamps_the_read_time: dropped the from_csv assertion — the unstamped constructor no
  longer exists (M8).
- a_cost_that_is_not_a_number_is_a_typed_error: pattern now matches row and asserts row == 2.
- Every cost_by_requirement test now constructs a registry and passes it; every confidence test now
  builds values through Value::from_registry; compliance tests renamed Satisfied/NotSatisfied →
  Covered/Uncovered; dataset registry.dataset/bytes calls now pass source id + hash.
- New tests (each fails without its fix): a_dataset_record_for_an_unknown_requirement_is_surfaced_not_dropped,
  a_requirement_cell_is_trimmed_before_joining, a_query_resolves_trust_from_the_registry_not_the_dataset,
  an_unregistered_source_cannot_be_queried, a_value_cannot_be_built_for_an_unregistered_source,
  two_sources_sharing_bytes_do_not_overwrite_each_other, a_fused_value_names_which_source_was_the_weak_one,
  a_model_compliance_row_carries_the_models_hash_and_export_time, two_versions_of_a_project_are_distinguishable_by_hash,
  a_dataset_with_no_read_time_is_refused, a_trailing_blank_line_is_skipped_not_an_error,
  a_row_too_short_reports_its_row_number.

## Verification

- cargo test --workspace --no-fail-fast → 404 passed, 0 failed, 21 ignored.
- cargo fmt -p mw-analytics -- --check → clean.
- cargo clippy --workspace --all-targets -- -D warnings → clean (exit 0).
- cargo +1.75.0 build -p mw-okf -p mw-test-support -p mw-graph -p mw-gate -p mw-binding -p mw-binding-xmi -p mw-agent -p mw-capi -p mw-mcp -p mw-analytics --locked → success.

## Concerns

1. **Task summary vs listed findings mismatch.** The brief says 'three Important and six Minor' but
   lists only two Important (plus M4–M9). I closed the two listed Important findings. If a third
   Important exists it is not in my brief and remains unaddressed; the pre-existing (concurrently
   committed, 5a4da7e) exact-decimal Money refactor may already be that third item's fix.
2. **Concurrent server-endpoint task.** A separate task was actively editing server/ while I worked
   (its server/src/analytics_api.rs, server/tests/analytics_api.rs, server/Cargo.toml,
   server/src/lib.rs, Cargo.lock are uncommitted). cargo fmt --all -- --check fails on ITS in-flight
   server/src/analytics_api.rs, not on any file I own; my crate is fmt-clean. The full workspace
   suite was green (404/0/21) at the moment I captured it; I did not touch any server file.
