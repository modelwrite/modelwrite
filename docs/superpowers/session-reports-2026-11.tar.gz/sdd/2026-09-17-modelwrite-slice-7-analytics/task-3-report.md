# Task 3 report - which products meet which specifications, and what is UNKNOWN

**Status:** DONE_WITH_CONCERNS

## What was built

`engine/analytics/src/compliance.rs` plus `engine/analytics/tests/compliance.rs`:

- `Compliance::{Satisfied, NotSatisfied, Unknown}` - the THREE states. Satisfied is
  present-and-covered, NotSatisfied is present-and-uncovered, Unknown is ABSENT from the
  model. Absence is never a blank and never omitted, because a blank reads exactly like a pass.
- `classify(requirement: &str, model: &OkfRoot) -> Compliance` - matches the requirement by
  its `id` (the key the engine's coverage uses), then uses the engine's own
  `graph::requirement_coverage` for Satisfied vs NotSatisfied. Unknown is a requirement the
  model does not contain at all.
- `ModelCompliance { model, satisfied, not_satisfied, unknown }` - one product's row: every
  requirement of the specification lands in exactly one bucket, so the three counts always sum
  to the specification's size.
- `Report { specification_size, models }` and `portfolio_report(requirement_set, models)` -
  the portfolio answer: every model classified against the same specification, grouped by state.

Coverage is the ENGINE's, never a reimplementation: `classify` calls
`graph::requirement_coverage`, so there is no second source of truth. A model with no graph
section is handled without panicking (present requirements read NotSatisfied, matching the
gate's own reading). No new external dependency: `mw-okf` and `mw-graph` are workspace
members, and `serde_json`/`mw-test-support` are dev-dependencies for the tests.

## Verification

- `cargo test --workspace --no-fail-fast` -> **362 passed, 0 failed, 21 ignored** (exit 0).
  - New: 12 tests in `engine/analytics/tests/compliance.rs`.
  - `mw-analytics` now runs 43 tests total: 20 dataset + 11 confidence + 12 compliance.
  - The 21 ignored are the pre-existing PostgreSQL integration suite, skipped locally as before.
- `cargo fmt --all` -> clean (exit 0); `cargo fmt --all -- --check` -> clean (exit 0).
- `cargo clippy --workspace --all-targets -- -D warnings` -> clean (exit 0, no warnings).

## Acceptance checklist (self-review, each as a test)

- [x] Absence is UNKNOWN, never Satisfied and never omitted (`a_requirement_absent_from_a_model_is_unknown_never_satisfied_and_never_omitted`, `a_requirement_absent_from_every_model_still_appears_as_unknown`).
- [x] Present but uncovered is NotSatisfied, distinct from Satisfied and Unknown (`a_requirement_present_but_uncovered_is_not_satisfied`, `the_three_states_are_distinct`).
- [x] The counts sum to the specification's size, so a dropped row cannot hide (`counts_sum_to_the_specification_size`, `coverage_agrees_with_the_engine_on_the_real_corpus`).
- [x] Coverage agrees with the engine's own function on the real corpus (`coverage_agrees_with_the_engine_on_the_real_corpus`).
- [x] No path panics: empty requirement set and empty model list are explicit empty reports; a graph-less model does not panic (`a_model_without_a_graph_does_not_panic`, `an_empty_requirement_set_is_an_explicit_empty_report_not_a_panic`, `an_empty_model_list_is_an_empty_report_not_a_panic`).

## Commits

- `e0a22b5` feat(analytics): portfolio compliance - which products meet which specifications

Staged only: `engine/analytics/src/compliance.rs`, `engine/analytics/src/lib.rs`,
`engine/analytics/Cargo.toml`, `engine/analytics/tests/compliance.rs`, `Cargo.lock`. No
commit was amended or rewritten.

## Concerns

1. The workspace's declared 1.75 MSRV floor is not actually checkable today: `cargo +1.75.0
   check -p mw-analytics` (and identically `-p mw-graph`, which this task did not touch) fails
   because the lockfile resolves `indexmap 2.14.2`, which requires `edition2024` (not stable
   in Cargo 1.75), as a transitive dependency of `petgraph 0.6.5` via `mw-graph`. This
   predates this task and is a workspace-level dependency-resolution drift, not a property of
   this task's code: `compliance.rs` uses only pre-1.75 language/API features, and the
   analytics crate's `rust-version` remains `workspace` (1.75). Fixing it would require
   pinning `indexmap` in the workspace root (or enabling
   `resolver.incompatible-rust-versions`), which is outside this task's file scope.

## Deviations / design notes

1. `portfolio_report` returns a per-model report: one `ModelCompliance` per product, each
   grouping the whole specification into `satisfied`/`not_satisfied`/`unknown`, and each
   summing to `specification_size`. This is the reading of "which products meet which
   specifications": every product gets a row whose three counts add up, so a missing requirement
   can never hide.
2. A model with no graph section is classified NotSatisfied for present requirements (nothing
   can cover them) - the same reading the gate records for a graph-less candidate. This is
   guarded so `classify` never panics inside the engine's coverage helper.
3. Requirements are matched by `id`, the exact key the engine's coverage uses, so a spec
   entry, a graph edge and a coverage report all name the same thing.
