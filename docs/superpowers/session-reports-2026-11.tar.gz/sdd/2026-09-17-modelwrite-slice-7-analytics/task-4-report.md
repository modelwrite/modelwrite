# Task 4 report - cost joins, labelled

**Status:** DONE_WITH_CONCERNS

## What was built

engine/analytics/src/cost.rs plus engine/analytics/tests/cost.rs:

- ColumnMapping { requirement_id, cost } - a named-column mapping declared per dataset. The
  names are the dataset's own header cells, because no two organisations store cost the same
  way: one says "requirement_id"/"unit_cost", another "req"/"amount".
- cost_by_requirement(models, datasets) -> Result<Vec<CostedRequirement>, CostError> - joins
  every distinct requirement of the models (first-seen order) to the cost records in the
  datasets, returning one row per requirement. A requirement with no record in any dataset is
  Cost::Uncosted - it still appears, and it is never zero.
- Cost::Uncosted | Cost::Costed(FusedValue<i64>) - Uncosted is a state, never a number; a
  costed requirement carries the sum, the weakest-link trust, the full set of contributing
  sources, and each source's read time.
- CostError::{MissingColumn, MalformedCost, Fusion} - a dataset missing a declared column is
  a clear error (never a silent zero or a partial result); a cost cell that is absent or not
  a whole number is a typed error.

The fusion rule is reused, not restated: a requirement priced by more than one dataset is
fused with confidence::sum, so its trust is the weakest link and every source and date is
named. Cost never lives in a model; the join pulls cost from the dataset's own Source
(id, trust) and captured_at, so every figure carries its provenance.

## Verification

- cargo test --workspace --no-fail-fast -> 372 passed, 0 failed, 21 ignored (exit 0).
  - New: 10 tests in engine/analytics/tests/cost.rs.
  - mw-analytics runs 53 tests total: 20 dataset + 11 confidence + 12 compliance + 10 cost.
  - The 21 ignored are the pre-existing PostgreSQL integration suite, skipped locally as before.
- cargo fmt --all -> clean; cargo fmt --all -- --check -> clean (exit 0).
- cargo clippy --workspace --all-targets -- -D warnings -> clean (exit 0, no warnings).

## Acceptance checklist (self-review, each as a test)

- [x] An uncosted requirement is UNCOSTED and not zero, and still appears
      (an_uncosted_requirement_is_uncosted_and_not_zero_and_still_appears).
- [x] A cost is attributed to its source and date (a_cost_is_attributed_to_its_source_and_date).
- [x] A dataset missing a declared column is a clear error
      (a_dataset_missing_a_declared_column_is_a_clear_error,
      a_dataset_missing_the_requirement_column_is_also_a_clear_error).
- [x] A fused cost's trust is the weakest of its inputs
      (a_fused_costs_trust_is_the_weakest_of_its_inputs).
- [x] The real coffee-machine corpus (25 requirements) joins against cost data, priced
      requirements costed and the rest uncosted (the_real_corpus_joins_against_cost_data).
- [x] No path panics: a malformed cost, a missing column, an empty model list, and a
      requirement present in several models are all handled as typed results
      (a_cost_that_is_not_a_number_is_a_typed_error,
      an_empty_model_list_is_an_empty_result_not_a_panic,
      a_requirement_in_many_models_appears_once).

## Commits

- 1846522 feat(analytics): cost joins, labelled - an uncosted requirement is never zero

Staged only: engine/analytics/src/cost.rs, engine/analytics/src/lib.rs,
engine/analytics/tests/cost.rs. No Cargo.toml or Cargo.lock change; no other path touched.

## Concerns

1. Cost values are parsed as i64 whole-number amounts, so a decimal cost ("12.50") is
   rejected as MalformedCost. This is a deliberate bound of the smallest useful join: no new
   external dependency is permitted, the workspace has no decimal type, and the existing
   Value<T>/FusedValue<T> shapes (which must be reused rather than replaced) derive Eq, so
   f64 is not reusable. If fractional currency is ever required, it needs a workspace decimal
   type or a fixed-point representation, which is outside this task's file scope.

## Deviations / design notes

1. cost_by_requirement returns Result<Vec<CostedRequirement>, CostError> rather than a bare
   Vec, because a dataset missing a declared column and a malformed cost are typed errors,
   never a silent zero or a partial result. The task's Vec signature is read as the shape of
   the answer; the error channel is how the "clear error" requirement is honoured.
2. Requirements are joined by their id - the exact key the graph coverage and compliance
   classify use - not by reqId or reqText. A spreadsheet that keys by "1.1" would need the
   mapping's requirement column to hold the model's id (or a future alias step).
3. When one requirement is priced by several datasets, the costs are summed (Task 2's fusion
   primitive), so the trust is the weakest link and all sources are named. Duplicate rows
   within one dataset would also be summed; this is treated as the caller's data, not
   silently deduplicated.
