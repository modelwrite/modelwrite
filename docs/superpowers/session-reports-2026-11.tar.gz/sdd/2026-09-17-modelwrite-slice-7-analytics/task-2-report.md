# Task 2 report - the fusion rule, enforced

**Status:** DONE

## What was built

`engine/analytics/src/confidence.rs`, the rule that governs every number the analytics
slice will ever report, plus `engine/analytics/tests/confidence.rs`:

- `Value<T> { value, source, trust, captured_at }` - a single number attributed to one source,
  carrying its trust level and read time from the moment it is read. `Value::new(...)` is the
  constructor; `Value::is_estimate()` reports whether it is an estimate.
- `fused_trust(values) -> Option<TrustLevel>` - the WEAKEST trust among the inputs
  (Estimated < Reported < Measured), via a fold that never averages and never rounds up.
  `None` for zero inputs, because a trust level for nothing would itself be a lie.
- `FusedValue<T> { value, trust, sources, captured_at }` - the result of fusing values:
  the number, the weakest trust, the complete set of contributing source ids, and each source's
  read time keyed by id. `FusedValue::is_estimate()` reports whether the answer is an estimate.
- `sum` / `max` / `min` over values, each returning `Result<FusedValue<T>, FusionError>`.
- `FusionError::NoSources` - fusing zero values is a typed error, never a zero, because a total
  of nothing is unknown and zero is a number somebody would act on.

The fused value carries BOTH the set of contributing sources (`sources: BTreeSet<String>`) and
each source's read time (`captured_at: BTreeMap<String, String>`), so a figure built partly from
a three-year-old cost still says which part is the old one. No new external dependency; serde
derives reuse the workspace `serde` (derive feature already enabled for `source.rs`). No path
panics: misuse is `FusionError`, and `split_first`/`ok_or` keep every indexing guarded.

## Verification

- `cargo test --workspace --no-fail-fast` -> **350 passed, 0 failed, 21 ignored** (exit 0).
  - New: 11 tests in `engine/analytics/tests/confidence.rs` (0 unit, 0 doc).
  - `mw-analytics` now runs 31 tests total: 20 in `dataset.rs` + 11 in `confidence.rs`.
  - The 21 ignored are the pre-existing PostgreSQL integration suite, skipped locally as before.
- `cargo fmt --all` -> clean (exit 0), and `cargo fmt --all -- --check` -> clean.
- `cargo clippy --workspace --all-targets -- -D warnings` -> clean (exit 0, no warnings).

## Acceptance checklist (self-review, each as a test)

- [x] A sum of one measured and one estimated value is ESTIMATED (`a_sum_of_one_measured_and_one_estimated_value_is_estimated`).
- [x] A sum of measured values is MEASURED (`a_sum_of_measured_values_is_measured`).
- [x] Every fused value names all its sources (`every_fused_value_names_all_its_sources`).
- [x] A fused value with no sources is an error rather than a zero (`a_fused_value_with_no_sources_is_an_error_not_a_zero`).
- [x] `captured_at` survives fusion (`captured_at_survives_fusion`).
- [x] A majority of measured values does NOT mask one estimate (`a_majority_of_measured_values_does_not_mask_one_estimate`).
- [x] Reported is weaker than Measured, and `fused_trust` returns the weakest (`reported_is_weaker_than_measured`, `fused_trust_is_the_weakest_of_its_inputs`).
- [x] Comparison (`max`/`min`) also carries the weakest trust and all sources, and comparison over nothing is an error.

## Commits

- `2d4d7d8` feat(analytics): the fusion rule - weakest-link confidence and traceable sources

Staged only the files this task owns: `engine/analytics/src/confidence.rs`,
`engine/analytics/src/lib.rs`, `engine/analytics/tests/confidence.rs`. `Cargo.lock` was
unchanged (no new dependency). No commit was amended or rewritten.

## Concerns

None blocking.

## Deviations / design notes

1. `fused_trust` returns `Option<TrustLevel>` rather than a bare `TrustLevel`: the spec's
   `-> TrustLevel` cannot be satisfied for zero inputs without either panicking (forbidden:
   "no path panics") or fabricating a level (forbidden: "a fused value with no sources is an
   error"). `None` is the honest empty result, and `sum`/`max`/`min` map it to
   `FusionError::NoSources`, which is exactly what the acceptance test asserts.
2. `Value.source` is the source id (`String`), and `FusedValue` carries both a
   `BTreeSet<String>` of source ids and a `BTreeMap<String, String>` of read times. A source
   is "named" by its id; the full `Source` (kind, description, declared trust) remains in the
   Task 1 registry, resolvable by id, so nothing is lost. Keeping `trust` as a distinct field on
   `Value` (as the interface specifies) would be redundant if `source` were the whole
   `Source`, so the id is the correct granularity.
3. `max` and `min` are provided alongside `sum` to cover the interface's "sum or comparison":
   a comparison (most/least expensive) must obey the same weakest-link and set-of-sources rule.
   They are exercised by tests so they are not dead code.
