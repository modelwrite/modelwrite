# Task 1 report - the source registry and the dataset snapshot

**Status:** DONE

## What was built

A new engine crate, `engine/analytics` (`mw-analytics`), at the 1.75 rust-version floor:

- `SourceKind::{Model, Structured, Text}` - what kind of data a source supplies.
- `TrustLevel::{Measured, Reported, Estimated}` - how much the data is trusted.
- `Source { id, kind, trust, description }` - a declared source; its trust level is fixed at registration.
- `Dataset { source, captured_at, rows, bytes, content_hash }` - a content-addressed snapshot built from CSV bytes.
- `Registry` - declares sources, REFUSES a dataset whose source was never declared, and fetches a snapshot back by its content hash.

The content hash is sha256 over the exact bytes handed in, hex-encoded - the same discipline
`engine/okf` uses, reusing the workspace's existing `sha2` and `hex` crates. The CSV is
parsed by hand (RFC-4180 quoting, embedded commas/newlines, escaped quotes); malformed input is
a typed `CsvError`, never a panic. No new external dependency was added.

## Governance review follow-up (folded in)

1. **Retain AND expose.** A snapshot now retains the exact input bytes (`Dataset.bytes`) and the
   registry exposes them by content hash via `Registry::bytes(content_hash) -> Option<&[u8]>` and
   `Registry::dataset(content_hash) -> Option<&Dataset>`. A hash alone is a promise, not a
   snapshot; the bytes are now reachable. Proven by tests that round-trip the bytes exactly,
   including CRLF line endings that parsing otherwise normalises away.
2. **Prove it through the thing named.** Every test drives the public method it names - `snapshot`,
   `register_dataset`, `bytes`, `dataset` - not a stand-in. The trust test exercises `snapshot`
   (the query path) and observes the trust that registration fixed; the fetch test exercises
   `Registry::bytes` against the recorded content hash.
3. **No assertion weakened.** These are additions only. One clippy-cleanup changed
   `Some(&bytes[..])` to `Some(bytes)` - the identical assertion, both `Option<&[u8]>`, made to
   satisfy `clippy::redundant_slicing` on the installed 1.98 toolchain; no test's meaning changed.

## Verification

- `cargo test --workspace --no-fail-fast` -> **334 passed, 0 failed, 17 ignored** (exit 0).
  - New: 20 tests in `engine/analytics/tests/dataset.rs` (0 unit, 0 doc).
  - The 17 ignored are the pre-existing PostgreSQL integration suite, skipped locally as before.
- `cargo fmt --all` -> clean (exit 0).
- `cargo clippy --workspace --all-targets -- -D warnings` -> clean (no warnings).

## Acceptance checklist (self-review)

- [x] A CSV becomes a dataset with a stable content hash (hardcoded sha256 constant proves stability across runs, not a re-derivation).
- [x] The same bytes produce the same hash; different bytes produce different hashes.
- [x] An unregistered source is REFUSED (both `Registry::snapshot` and `Registry::register_dataset`).
- [x] The trust level travels with the data: a snapshot is requested by source id alone and carries the trust declared at registration, never a query-time value.
- [x] Malformed input (unterminated quote, stray quote, characters after a closing quote, non-UTF-8) is a clean typed error, no panics.
- [x] A snapshot's bytes are fetchable by content hash and round-trip byte-for-byte.

## Commits

- `bb15cec` feat(analytics): the source registry and the content-addressed dataset snapshot
- `cf41ad5` fix(analytics): snapshots retain their bytes and are fetchable by content hash

Each commit staged only the files this task owns: `engine/analytics/`, and (for the first commit)
`Cargo.toml` and `Cargo.lock`. No commit was amended or rewritten.

## Concerns

None blocking. Note: the working tree contains concurrent uncommitted changes in `cli/` and
`server/` from other slice-7 tasks; they were observed, left untouched, and not staged or
committed by this task.

## Deviations / design notes

1. The plan names `Dataset::from_csv(source, bytes)`. That two-argument form exists and is
   implemented, but a snapshot must also record WHEN the source was read, so the full form is
   `Dataset::from_csv_at(source, captured_at, bytes)` and `Registry::snapshot(source_id, captured_at, bytes)`
   stamps it. `from_csv` leaves `captured_at` empty; this is documented on the methods.
   Reason: the design spec requires a snapshot to be reproducible and traceable, and with no
   network/clock the read time must be supplied by the caller, not fabricated.
2. The registry also stores snapshots keyed by content hash (re-reading identical bytes is
   idempotent). This is a small, natural home for the dataset layer and does not change the
   refusal behaviour.
