# Cost decimal report - exact money, no floating point

**Status:** DONE

## What was built

engine/analytics/src/money.rs (new) and engine/analytics/tests/money.rs (new), wired into
cost.rs and lib.rs:

- Money { minor_units: i128, scale: u32 } - an exact decimal amount as a scaled integer:
  value = minor_units * 10^-scale. No floating point anywhere. The stored form is canonical
  (trailing zeros are reduced), so equality and ordering are value equality, and the fewest
  decimal places that express a value are kept (12.50 -> 12.5, 12 -> 12, -3.25 -> -3.25).
- Money::parse - reads an optional sign, an integer part, and an optional decimal point with
  a fractional part. Leading/trailing whitespace is ignored; currency symbols, thousands
  separators and any other character are refused. Whole numbers parse at scale zero; negative
  amounts (credits) parse under the same rules.
- Add, Ord/PartialOrd, Display (canonical decimal), FromStr, and Serialize/Deserialize (as an
  exact decimal string, never a JSON number that a reader would turn back into a float).

cost.rs now parses each cost cell as Money and sums with confidence::sum, so Cost::Costed is
FusedValue<Money> rather than FusedValue<i64>. A decimal ("12.50"), a whole number ("12") and
a negative credit ("-3.25") all parse; a value that is genuinely not money is still a typed
CostError::MalformedCost naming the offending text. The uncosted rule is untouched: an
uncosted requirement is still Cost::Uncosted, never zero, and still appears in the result.

## How exactness is represented

A money amount is a pair of integers: minor_units and scale. 0.1 is minor_units=1, scale=1;
0.2 is minor_units=2, scale=1; their sum aligns both to scale 1 and adds the integers, giving
minor_units=3, scale=1 = 0.3, exactly. There is no f64 anywhere: not in storage, not in
parsing (digits accumulate with checked i128 arithmetic), not in addition (aligned integer
add), and not in the serialized form (a decimal string). The test
one_tenth_plus_two_tenths_is_exactly_three_tenths asserts Money(0.1) + Money(0.2) ==
Money(0.3), and a_binary_float_is_not_exact_where_money_is proves the defect the type exists
to avoid is real: (0.1 + 0.2) as f64 drifts off 0.3.

## Verification

- cargo test --workspace --no-fail-fast -> 384 passed, 0 failed, 21 ignored (exit 0).
  - engine/analytics now runs 65 tests: dataset 20, confidence 11, compliance 12, cost 13,
    money 9.
  - New in this change: 9 money tests + 3 cost tests (decimal parse, negative credit, exact
    decimal fusion).
  - The 21 ignored are the pre-existing PostgreSQL suite, skipped locally as before.
- cargo fmt --all -> clean (exit 0).
- cargo clippy --workspace --all-targets -- -D warnings -> clean (exit 0).
- cargo +1.75.0 check -p mw-analytics --all-targets -> clean (exit 0), so the crate still
  builds at the 1.75 MSRV.

## Acceptance checklist (self-review, each as a test)

- [x] 0.1 + 0.2 is exactly 0.3, and a float would fail it
      (one_tenth_plus_two_tenths_is_exactly_three_tenths,
      a_binary_float_is_not_exact_where_money_is, decimal_costs_fuse_exactly).
- [x] "12.50", "12" and "-3.25" all parse (decimal_whole_and_negative_amounts_all_parse,
      a_decimal_cost_is_read_exactly, a_negative_cost_is_a_credit).
- [x] UNCOSTED is still not zero and still appears
      (an_uncosted_requirement_is_uncosted_and_not_zero_and_still_appears - unchanged).
- [x] Garbage is still a typed error naming the text
      (garbage_is_not_money, a_cost_that_is_not_a_number_is_a_typed_error - unchanged).
- [x] A scaled integer, not a float (amounts_are_scaled_integers_not_floats: 12.50 is
      minor_units 125, scale 1).

## Commits

- 5a4da7e feat(analytics): exact decimal money for costs - scaled integers, no float

Staged only engine/analytics/: src/money.rs (new), tests/money.rs (new), src/cost.rs,
src/lib.rs, tests/cost.rs. No Cargo.toml or Cargo.lock change; no new dependency; no other
path touched.

## Concerns / notes

1. Bounds are deliberate and safe for money: parse refuses more than 9 fractional digits and
   an amount whose magnitude exceeds 1e18 units, as MalformedCost. Both bounds exist so that
   aligning two values to a common scale and summing them can never overflow i128 - the
   overflow headroom is about 1e11 fused sources - and no realistic money amount is anywhere
   near either bound.
2. Money serializes as its exact decimal string (for example "12.5"), not as a JSON number.
   A JSON number is read back as a binary float, which would re-introduce exactly the defect
   this type exists to remove. The previous i64 serialized as a JSON number; there are no
   consumers of the analytics output shape yet, so the change is safe and deliberate.
3. Whole-number costs that Task 4 already handled still work: "100" parses to minor_units
   100, scale 0, and sums exactly as before, so none of Task 4's tests were weakened - only
   their value comparisons were updated to compare Money to Money.
