# Task 5 report - the analytics endpoint: the crate, reachable through the store

**Status:** DONE

## What was built

A read-only analytics endpoint that wires the analytics crate to a real model in the store
through the EXISTING load path. Before this task the crate was imported only by its own
tests; the guarantee "analytics never writes to a model" was vacuous because nothing could
call the code. Now there is a route.

- `GET /projects/:project/analytics` (server/src/analytics_api.rs, registered in lib.rs).
- Takes `Identity` FIRST, then checks `Permission::Read` and `may_reach(project)` BEFORE
  any store access - the same order as every other handler. A caller without Read gets a 403,
  never an empty report.
- Resolves the model to read via an optional `commit` hash, else `branch` (default
  `main`) resolved to its tip, then loads it with `api::load_model` - the shared
  commit-row-then-blob-then-parse path, not a second reader.
- Answers the portfolio-compliance question: `analytics::portfolio_report` over the caller's
  `requirements` specification, serialized verbatim from the crate, so a requirement ABSENT
  from the model lands in the explicit `unknown` bucket (Covered / Uncovered / Unknown).
- Answers the cost question: `analytics::cost_by_requirement` over the model's own
  requirements. With no dataset every requirement is the explicit string "Uncosted"; with an
  inline `costCsv` the source is declared in a registry, snapshotted with a read time, and
  every costed figure is labelled with value, trust, sources and read times.

## The surface I chose, and why

The smallest surface that wires BOTH public report functions to a real model while keeping
the two guarantee-critical states explicit: one GET endpoint answering compliance (always)
and cost (always - "no estimates" is a truthful UNCOSTED, not a blank). A specification must
be caller-supplied, because "which products meet which specification" is meaningless without
a specification, and importing one is a later tranche (the design spec's own open question).
Cost data is supplied inline in the request rather than fetched, because there is no
persisted source registry in the server yet. Identity-first and read-only, so it is a plain
Read handler.

## Verification

- `cargo test --workspace --no-fail-fast` -> **404 passed, 0 failed, 21 ignored** (exit 0).
  The 21 ignored are the PostgreSQL suite, skipped locally as before.
- Per binary: mw-analytics 79 (compliance 14, confidence 14, cost 21, dataset 21, money 9);
  mw-server 203 (18 lib unit + 185 integration across 17 files, including 6 new
  analytics_api tests; the 21 ignored postgres tests live here); cli 36; okf 17; binding-xmi
  19; agent 14; mcp 13; binding 7; graph 7; gate 5; capi 4; the rest 0.
- `cargo fmt --all` -> clean (exit 0).
- `cargo clippy --workspace --all-targets -- -D warnings` -> clean (exit 0, no warnings).

## How read-only is PROVEN (not commented)

`a_real_model_reports_compliance_and_uncosted_and_writes_nothing` commits the real
coffee-machine corpus through the HTTP write path, then takes a `Fingerprint` of the store
BEFORE the analytics request: every commit (`commits_on`), every audit entry (`audit`),
and every blob (read from the same SQLite file via a second read connection, because the
trait exposes no blob enumeration - the file IS the record). It runs the analytics request,
asserts the answer, then asserts `fingerprint(after) == fingerprint(before)`. The
no-Read test repeats the fingerprint around the refused request to prove the refusal path
also touches nothing. No write method exists on the endpoint's code path; the test asserts
the observable state, which is what "read-only" actually means.

## Self-review checklist

- [x] The endpoint answers over a real model from the corpus (committed via the write path,
      15 covered / 10 uncovered / 1 absent requirement, counts sum to 26).
- [x] A requirement ABSENT from the model appears as Unknown: `unknown == ["REQ-ABSENT-FROM-MODEL"]`.
- [x] An uncosted requirement is the explicit string "Uncosted" - never zero, never omitted.
- [x] A caller without Read is refused (403), and a scoped caller is refused for an
      out-of-scope project (403) - before the store is touched.
- [x] NOTHING IS WRITTEN, proven by asserting commits, audit entries and blobs are unchanged.
- [x] A missing project, commit or branch is a 404 that names only what the caller asked for
      (asserted to contain no internal detail).

## Commits

- `eeab3c9` feat(server): read-only analytics endpoint - compliance and cost over the store

Staged only: `server/src/analytics_api.rs`, `server/tests/analytics_api.rs`,
`server/src/lib.rs`, `server/Cargo.toml`, `Cargo.lock` (the one-line
`mw-analytics` dependency edge). Nothing else was staged or amended.

## Concerns

1. A CONCURRENT TASK refactored engine/analytics WHILE this task ran: the compliance labels
   were renamed Satisfied/NotSatisfied -> Covered/Uncovered, cost moved to a Registry-based
   trust resolution with an exact-decimal `Money` type, and `cost_by_requirement` gained a
   registry argument. I checked the current names and adapted to the settled API rather than
   assuming the plan's names; the final code compiles against HEAD `1348b39`.
2. The server has no persisted source registry, so the cost source's trust is declared
   inline in the request and registered into a per-request `Registry`. That honours the
   crate's "trust is fixed at declaration, resolved from the registry" rule within a request,
   but trust is still effectively caller-declared until a durable registry exists (a later
   tranche, per the design spec).
3. The specification is one comma-separated query parameter. A requirement id that itself
   contains a comma cannot be expressed through this surface; the corpus ids are comma-free.
   This is a documented boundary of the smallest useful surface, not an omission of the
   UNKNOWN guarantee (absence is still reported explicitly).
