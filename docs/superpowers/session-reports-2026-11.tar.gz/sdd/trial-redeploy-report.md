# idc-1 trial — redeploy (195cbf8) — report

**Status:** DONE_WITH_CONCERNS

## Commit deployed

- **Commit built from:** `195cbf84090a68d994900baa2b3acae7ba998479`
  (`ui: the wordmark links to the website rather than to the project list`)
- **Previous:** `d66261e8483a98f64322aab1236d7afe5ea41519`
- **Image:** `modelwrite/modelwrite:idc-1-trial`, id `73211ddac82b`
  (~149 MB disk usage, 37.9 MB content), rebuilt on the host with
  `--cpuset-cpus=0-3` (bounded to CPUs 0-3). Source checkout `/opt/modelwrite/src`
  is at detached HEAD `195cbf8`. No registry pull.

## What was done

1. `git fetch` + checkout of `origin/slice-2-repository` in `/opt/modelwrite/src` →
   `195cbf8`. (An untracked `docs/deploy/seed-trial.mjs` left by a prior agent was moved
   to `/tmp/seed-trial.mjs.untracked-bak`; it was byte-identical to the committed copy, so
   no work was lost.)
2. `docker build --cpuset-cpus=0-3 -f deploy/Dockerfile -t modelwrite/modelwrite:idc-1-trial .`
   — full recompile of `mw-server` (cargo `Finished release` in 46.1s; confirmed the new
   source compiled, not a cache hit).
3. Restarted ONLY `modelwrite.service`. cloudflared, haproxy, the reset timer/units, the
   seed, the backup policy, and every other unit were left untouched.

## Acceptance proof (public internet, from the workstation, no token)

```
$ curl -sS -i https://trial.modelwrite.org/ui
HTTP/1.1 200 OK
content-type: text/html; charset=utf-8
```

Brand anchor (verbatim, from the served HTML):

```html
<a class="brand" href="https://modelwrite.org" target="_blank" rel="noopener">modelwrite</a>
```

The old `class="brand" href="/ui"` is gone. The page still renders: `<!DOCTYPE html>`,
`<title>modelwrite — projects</title>`, and all six project names present in the body.

## Open state + model count after redeploy

```
$ curl -sS https://trial.modelwrite.org/health
{"authMode":"open","status":"ok"}          [http=200]

$ curl -sS https://trial.modelwrite.org/projects   (no token)
[ six models: cafe-stand, coffee-machine, floor-robot, microduck,
  purchasing-terminal, sandwich-toaster ]  [http=200]
```

Still OPEN, still the six-model baseline.

## Screenshot

`e2e/shoot.js` could not be run: `@playwright/test` is not installed in this checkout.
This model (deepseek-v4-pro) has no image input, so I relied on the markup above.

## Doc correction (JOB 2)

The hourly-reset report's claim ("docs say MW_AUTH_TOKEN blanked but it is not — the env
still has a non-empty token line") was **already stale when I arrived**. Actual state:

- `/opt/modelwrite/deploy/modelwrite.env`: `MW_AUTH_TOKEN=` is **blank** (the line is
  present but empty), `MW_ALLOW_OPEN=yes`, `MW_BIND=0.0.0.0`. The 64-char token value is
  preserved in a `#   MW_AUTH_TOKEN=…` comment line in the same file, and in
  `.superpowers/sdd/idc-1-trial-deploy-2-report.md`. The running container carries the
  blank token + open (verified via `docker inspect`).

So the docs' "MW_AUTH_TOKEN= (blanked)" was already true. What was NOT exact, and what I
fixed in both `docs/deploy/idc-1-trial.md` (committed `e67b7d1`, pushed) and
`/opt/modelwrite/README.md`:

- "restore the MW_AUTH_TOKEN line" → the line already exists (blank); re-enabling auth is
  the one-line change: set `MW_AUTH_TOKEN=<token value>` (from the comment line / deploy-2
  report) and delete `MW_ALLOW_OPEN=yes`, then `sudo systemctl restart modelwrite`. A
  non-empty token switches open → static; the `MW_ALLOW_OPEN` gate only applies while auth
  is open.
- "the old token is recorded in the deployment report only" → it is also in the env file's
  own comment line (and the deploy-2 report), never in this repo.
- Added the load-bearing caveat: do NOT delete the blank `MW_AUTH_TOKEN=` line, because
  `deploy/capture-seed.py` reads it and raises `MW_AUTH_TOKEN not found` if it is absent
  (`reset-trial.sh` and `seed-from-manifest.py` tolerate absence; `capture-seed.py`
  does not).

I made **no change to modelwrite.env** — the deployed state (blank token + open) is already
the simplest true state and must stay open.

## Concerns

1. **Concurrent actor, again.** While I was redeploying, another actor committed and pushed
   `cc8ae57` ("docs(deploy): document hourly reset change-detection skip and FORCE=1
   force-reset") — it added a change-detection guard (`deploy/trial-changed.py`) + FORCE=1
   to `reset-trial.sh`, a component this task was told to leave exactly as-is. I did not
   touch it; my doc commit `e67b7d1` sits cleanly on top of `cc8ae57` (my edits are in
   the Env/Auth/Source-pinned sections; theirs in the Hourly-reset section). Ownership of
   this hostname/timer/workspace still needs to be one agent.
2. Screenshot not captured (see above); proof is the markup.
