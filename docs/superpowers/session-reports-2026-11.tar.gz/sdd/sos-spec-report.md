# System-of-systems spec — report

**Status:** DONE_WITH_CONCERNS

**Commit:** 9e0900da23e84b0d8448f9e4bd067592f39f1874 — `docs: the full system-of-systems specification`

**Slice order (first to last):** S0 platform-model primitive → S1 compositional gate → S2 defence concepts I (nested platforms, security-boundary annotations) → S3 defence concepts II (redaction-preserving references, fleet baselines). The primitive is ordered before the gate, and the gate before the defence concepts, exactly as the brief required.

**Concerns:**

1. Slice numbering S0..S3 is internal to the composition workstream. The master roadmap in 2026-09-17-modelwrite-platform-design.md already uses S0..S7, so this workstream needs a final slot when it enters the roadmap; the spec states this in §6 rather than claiming a roadmap number.
2. The seed note was untracked (never committed); this commit is its first entry into the repository, as the full spec.
3. Committed on the currently checked-out branch `slice-2-repository`, not main — the task did not specify a branch.
4. Four open decisions remain in §9 (role vocabulary shape; was-gated check behind an export boundary; per-hull full model vs delta; was-gated recursion depth for nested platforms), left open deliberately to match the interoperability spec's "Open decisions" style.
