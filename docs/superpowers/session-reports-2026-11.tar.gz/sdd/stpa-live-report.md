# STPA live report — idc-1 showcase

## Status

DONE. The STPA/STAMP completeness work (commit 0b369b5) is live on
https://trial.modelwrite.org and a seeded 'fire-suppression' project makes it
visible. The showcase serves the new image, the seed replays cleanly with SEVEN
projects, the two STPA URLs render the five checks and the control structure, and
the hourly reset skip-guard still skips when the trial is clean.

## Commit deployed

- Image built on idc-1 from commit 55f653ceaf2222c7314d818f2d72bbc27330bf72
  ('docs: STPA completeness is in progress, not deployed', on top of
  '0b369b5 STPA/STAMP completeness check (T1-T3)') with:
  docker build --cpuset-cpus=0-3 -f deploy/Dockerfile -t modelwrite/modelwrite:idc-1-trial .
- New image id d767a42f08f7 (149 MB). Old image 50c8623ed6ac kept as the
  previous/revert image.
- Restarted modelwrite.service (3102) only. modelwrite-app.service (3103),
  cloudflared and haproxy were not touched.
- Seed/doc changes committed and pushed: fe20d91
  ('deploy(idc-1): seed defective fire-suppression STPA example as seventh project')
  — docs/deploy/seed-trial.mjs, sample/stpa/fire-suppression-defective.json,
  docs/deploy/idc-1-trial.md.

## Seed proof

The forced reset (sudo env FORCE=1 /opt/modelwrite/deploy/reset-trial.sh) replayed
the seven-project manifest into a fresh database and verified EVERY commit hash
against its expectedHash. Verbatim verify lines:

  commit coffee-machine/main -> 8e373a72c8b5a2b7c38b57a2b26dd749ead41d631450bd9e459958615f9ba498
  commit sandwich-toaster/main -> 3082f48039afa052f9a619c6d07bb8b181be35dda0b96fd92098c15f1ff77d71
  commit purchasing-terminal/main -> caeecbeac90554eac71c84e1d1041d79d614f0f5efc36b65d625021a40a2d0ce
  commit floor-robot/main -> 18dce0588f0065ffbc7b4f3e891fc5cbeaef2dbd48d81d45d1c68387893ec44c
  commit microduck/main -> 44949abc083ddd59ebe66d6dd806bd6a9e2eb5fa274b92e6de357fc0f3da04ca
  commit fire-suppression/main -> c661ab075e995f117e2dce212e1ae861402befd246a201e5a79c52e49f6ce1e1
  commit cafe-stand/main -> dd905e708e8c21a6ea0660a4ea08e2b0814d1a3fe3dc32e16481942681d208f1
  createBranch cafe-stand/with-microduck from dd905e708e8c21a6ea0660a4ea08e2b0814d1a3fe3dc32e16481942681d208f1 -> 201
  commit cafe-stand/with-microduck -> 33e1914b17bc6218fd84ff17c97b0d9a870e31de7c05753241006dcc05080ecb
  verify /projects -> ['cafe-stand','coffee-machine','fire-suppression','floor-robot','microduck','purchasing-terminal','sandwich-toaster']
  seed replay verified: seven models present
  fresh DB verified: all seven models present

The six original hashes are unchanged; only fire-suppression is new
(c661ab075e995f117e2dce212e1ae861402befd246a201e5a79c52e49f6ce1e1).

## URL check 1 — STPA completeness screen

https://trial.modelwrite.org/ui/projects/fire-suppression/stpa (HTTP 200, public, no token):

  Unanalysed control actions (1)
  Control loops with no feedback (1)
  Hazards with no constraint (1) · constraints reaching no element (1)
  UCAs with no loss scenario (1)
  Trend across baselines (1)
  5 findings found.

Page title 'modelwrite — fire-suppression — STPA'; heading 'STPA completeness
branch main · commit c661ab07'.

## URL check 2 — control-structure diagram

https://trial.modelwrite.org/ui/projects/fire-suppression/diagram?view=control
(HTTP 200, public, no token). The control structure renders:

  Fire Suppression Controller   (Controller)
  Suppressant Discharge System  (ControlledProcess)
  Discharge suppressant         (ControlAction)

There is deliberately NO feedback node — the seeded fixture is the DEFECTIVE one,
so the missing feedback loop is the very defect the STPA screen's 'Control loops
with no feedback (1)' check names. Page title 'modelwrite — fire-suppression — diagram'.

## Reset proof

Ran sudo /opt/modelwrite/deploy/reset-trial.sh twice with no intervening changes;
both runs hit the change-detection skip-guard (no restart, no backup):

  === RUN 1 ===
  [2026-09-21T09:32:28+00:00] no changes since the last reset, skipping (service not restarted, no backup taken)
  === RUN 2 ===
  [2026-09-21T09:32:28+00:00] no changes since the last reset, skipping (service not restarted, no backup taken)

## Concerns

1. Fixture summary fix was required for determinism. The committed fixture had an
   empty "summary": {}. On the FIRST commit the store re-derives the summary via
   derived_okf_hash, which re-serialises the document in struct field order; the
   capture/replay round-trip commits through the serde_json::Value (BTreeMap) path,
   which serialises alphabetically. The two byte orders give different content
   addresses, so the replayed hash drifted (the reset caught it: 00a7d96c... !=
   dfe72915...). I fixed the fixture by giving it its correct derived summary
   (blocks 8 / requirements 1 / signals 1 / graphNodes 10 / graphEdges 6), which is
   how every other corpus model is stored. After that the seed reproduces
   byte-for-byte (c661ab07...). This is a data fix to the fixture, not a database
   hack, and it does not change the STPA findings (those are computed from the graph,
   not the summary).

2. The same empty-summary issue exists in sample/stpa/fire-suppression-correct.json.
   It is not seeded, so I left it untouched, but it would drift identically if anyone
   ever seeds it.

3. Latent platform inconsistency. derived_okf_hash (struct-order re-serialisation)
   and the ordinary commit path (serde_json::Value BTreeMap order) produce different
   byte orders for the same logical document whenever the summary must be re-derived.
   Worth a follow-up, but out of scope here — I did not touch platform code.

4. README says 'not deployed'. The other task's commit 55f653c titles it
   'STPA completeness is in progress, not deployed', which is now stale. I own the
   deployment/seed docs, not README.md or website/, so I left that line alone.

5. Host deploy scripts changed (not in the repo): capture-seed.py,
   seed-from-manifest.py, reset-trial.sh now expect seven projects, and
   capture-seed.py reads MW_BASE_URL. These live only at /opt/modelwrite/deploy/ (and
   seed/seed.mjs, seed/models/, seed/README.md at /opt/modelwrite/seed/), matching the
   repo docs/deploy/seed-trial.mjs.

