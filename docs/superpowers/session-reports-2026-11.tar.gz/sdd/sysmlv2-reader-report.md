# SysML v2 textual-notation reader - report

## Status
DONE

## Commits
- ece7092 feat(binding): add the SysML v2 textual-notation reader (ImportOnly viewer, stated subset)

## One-line test summary
cargo test --workspace --no-fail-fast green (all suites 0 failed, 10 new
binding-sysmlv2 tests), cargo fmt --all clean, cargo clippy --workspace
--all-targets -- -D warnings clean, cargo +1.75.0 build -p mw-binding-sysmlv2
succeeds.

## The subset (carried into OKF)
- package (outermost -> project; nested -> members promoted, package named Lossy)
- part def / attribute def / item def (with abstract/individual modifiers) ->
  block element, stereotype names the keyword
- specialization (:> / specializes) -> generalization edge
- features inside a definition: attribute / part / item / ref -> OKF Attribute;
  part/item add a "part" edge, ref a "reference" edge; multiplicity folded into
  the type string; in/out direction dropped and named
- doc comments -> documentation
- requirement <'id'> name { doc; subject; assert constraint } -> requirement
  (name, reqId, documentation, subject edges, constraint-as-attribute)
- satisfy <req> by <subject> -> dependency edge labelled "satisfy"
- import -> declaration; // and /* */ comments -> trivia

## What is outside the subset (named Unmappable, never silent)
calc def/calc, state def/state/transition/action def, actor/usecase/
association/boundary/include, enum def/enum, variation/variant, timeslice,
SYSMOD/custom #... extensions, top-level part/attribute usages, :>> redefinition
bindings, feature redefinitions. A malformed document is a clean
BindingError::Import (never a panic).

## Verbatim measurement (real bundled example, Drone_BaseArchitecture.sysml)
blocks (definitions)     : 1
requirements             : 4
graph nodes              : 5
graph edges              : 1
declarations recognised  : 1
content losses           : 6
lossy drops              : 0
1 element(s) imported; 6 content loss(es) named below; 1 declaration(s) recognised.

[Unmappable] part drone :: top-level usage owned by a package; outside the subset — only definitions and requirements are carried
[Unmappable] #derivation connection :: extension (SYSMOD/custom) declaration; outside the subset
[Unmappable] subject drone : Drone_SystemArchitecture::drone :: redefinition subject type does not resolve to a carried element
[Unmappable] subject battery : Drone_SystemArchitecture::drone.battery :: redefinition subject type does not resolve to a carried element
[Unmappable] subject battery : Drone_SystemArchitecture::drone.battery :: redefinition subject type does not resolve to a carried element
[Unmappable] satisfy Drone_StakeholderRequirements::longDistance by drone :: satisfy relationship: an endpoint is outside the carried subset

(Second real example, InternetModel_v1.sysml: 9 blocks, 0 requirements, 7 graph
edges, 0 content losses, 2 lossy drops - the in/out directions.)

## ImportOnly vs ImportAndExport
ImportOnly (a viewer). The notation is large and this is a stated first subset.
The metadata (BindingInfo.direction) and the export method both say so; the
round-trip harness refuses it outright with BindingError::Viewer.

## Concerns
- The shared summarize_import helper counts only structure blocks as
  "elements imported", so the one-line summary undercounts requirements (4 in
  the Drone model). The test prints the full breakdown (blocks/requirements/
  graph/declarations/losses) so the numbers are not lost; a future change to the
  helper could count requirements too, but engine/binding is out of scope here.
- A package-level doc comment is dropped (named Lossy) because OKF has no
  package element to hold it.
- Top-level part usages are reported rather than carried (OKF has no clean slot
  for a package-owned usage); this is the biggest single gap in the Drone model.
