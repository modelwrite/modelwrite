# Open MBSE examples - report

## Status

DONE_WITH_CONCERNS

## Commits

- `14ef7e4` Add open MBSE example corpus and measure the TMT vendor model (branch slice-2-repository)

## One-line test summary

`cargo test --workspace --no-fail-fast` and `cargo clippy --workspace --all-targets -- -D warnings`
both exit 0 (full suite green); `mw-binding-xmi` runs 34 tests including the new
`real_tmt.rs` (2 tests: import + round-trip over the 36 MB TMT 2022x XMI).

## TMT measurement (Open-MBEE TMT.mdzip, 2022x, upstream b2a33b7)

Reproduce: `cargo test -p mw-binding-xmi --test real_tmt -- --nocapture`

| Metric | Value |
|---|---|
| structure elements (blocks) | 362 |
| requirements | 7 |
| interfaces / signals / activities | 0 / 0 / 0 |
| graph nodes | 369 (362 blocks + 7 requirements) |
| graph edges | 633 (261 part, 45 reference, 327 dependency/association) |
| declarations recognised | 2 231 |
| content losses | 45 725 (all Unmappable) |
| lossy id/name drops | 2 828 |
| blocking (lossy + unmappable) | 48 553 |
| round-trip (engine diff) | equal - LOSSLESS after the two fixes below |

Top content losses by construct (the biggest remaining gaps):

| Construct | Count |
|---|---|
| uml:InstanceSpecification | 6 559 |
| uml:Class (attribute-level: isActive, classifierBehavior, ...) | 5 788 |
| TMT_Requirement (custom profile) | 4 277 |
| ObjectProperties | 4 268 |
| HierarchyElement | 4 231 |
| uml:Property (attribute 'visibility', ...) | 3 679 |
| uml:SignalEvent | 1 161 |
| client / supplier (unnamed) | 1 016 + 1 016 |
| uml:Dependency | 1 000 |
| uml:Association | 952 |
| uml:Comment | 850 |

The number is the finding: the reader carries 362 blocks, 7 requirements and 633
traceability/structural edges, and names 45 725 content losses without dropping one in
silence. This is a content-rich vendor model, and it imports - but most of it (Instance
Specifications, Activities, States, Ports, custom TMT profile stereotype applications,
and 6 559 object instances) is outside the carried subset and is reported as unmappable.

## Reader defects the real TMT export exposed (both fixed)

1. **Duplicate element names broke part/reference edge round-trip.** The export rebuilt a
   PartProperty/ReferenceProperty by resolving the attribute's type through a global
   name->id map. The TMT model has 22 duplicated block names (Motor x4, Clock x5, Lens x2,
   Stimulus x2, Enclosure x2, ...), so the map returned the wrong id and the round trip
   failed with 'cannot reconstruct a part/reference edge'. Fixed in
   `engine/binding-xmi/src/lib.rs`: part/reference edges are now matched to their attribute
   by the TARGET'S NAME and the precise edge target id is written as the type.

2. **Text newlines were corrupted by XML attribute-value normalisation.** `escape()` did not
   encode LF/CR/TAB, so a requirement body or block documentation carrying a trailing newline
   (the TMT model has several) came back with the newline turned into a space. Fixed in
   `engine/binding-xmi/src/lib.rs`: `escape()` now emits `&#10;`/`&#13;`/`&#9;`.

Both fixes are regression-pinned: the new `real_tmt.rs` round-trip test, and the existing
`real_magicdraw.rs`, `xmi.rs` (including `export_refuses_a_part_edge_with_no_matching_attribute`
and `association_part_and_port_edges_round_trip_through_export`) all still pass.

## Bundled vs fetched

### Bundled (sample/examples/, bundle-safe licences only)

| Example | Licence | Commit | What was taken |
|---|---|---|---|
| sysml-v1/openmbee-tmt | Apache-2.0 + Caltech BSD COPYRIGHT | b2a33b7 | extracted tmt-2022x.model.xmi (36 MB) + LICENSE + COPYRIGHT |
| sysml-v1/gaphor-examples | Apache-2.0 | 968f6bb | examples/*.gaphor (11 models) + LICENSES/Apache-2.0.txt |
| sysml-v2/gfse-models | BSD-3-Clause | ebbb0c3 | models/ (202 KB; CI build dir skipped) |
| sysml-v2/mbse4u-batmobile | Apache-2.0 | f6cdf35 | .sysml + .ipynb + LICENSE |
| sysml-v2/airbus-apollo-11 | MPL-2.0 | 6e9c93f | full layered model (426 KB, 28 .sysml) + LICENSE.md |

### Fetched (NOT bundled - EPL-2.0 or too large; `pwsh ./Get-OpenMbseExamples.ps1`)

| Example | Licence | Why fetched |
|---|---|---|
| sysml-v2/omg-sysml-v2-release | EPL-2.0 | not AGPL-compatible |
| arcadia-capella/eclipse-capella-samples | EPL-2.0 | not AGPL-compatible |
| arcadia-capella/dbinfrago-ife-variant | EPL-2.0 (model) | not AGPL-compatible |
| sysml-v2/mbse4u-sysmlv2-book | Apache-2.0 | bundle-safe but ~90 MB Cameo .mdszip; kept out of git |

## Migration demonstration

The MagicDraw coffee machine (SysML v1 XMI, the existing corpus) was imported end to end
through the running server's import API and committed as project `coffee-machine-xmi`
(commit 8854e37c, okfHash fb9c049e): the source XMI was retained content-addressed, the
loss report named 252 blocking losses (accepted by name, recorded in provenance), and the
model is openable at `/ui/projects/coffee-machine-xmi`.

## Concerns

1. **The TMT model cannot be committed through the workbench import page today.** Its XMI is
   36 MB, but the server sets no body-limit layer, so axum's 2 MB default applies to the
   import endpoint. The measurement here is offline (a test reading the file directly).
   Raising the import body limit is a server change (out of scope for this task).
2. **SysML v2 (.sysml) and Gaphor (.gaphor) are bundled but not importable.** Both need a
   new binding of their own; the README says so plainly.
3. The 36 MB XMI is committed as a binary blob (`.gitattributes` now marks `*.xmi binary`),
   which is the honest cost of keeping a content-rich vendor model in the corpus.
