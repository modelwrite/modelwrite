# Seamless XMI import - report

## Status

DONE

## Commits

- 'seamless-xmi-import' (staged scope: engine/binding/, engine/binding-xmi/, real-world/)

## What changed

1. Declarations are no longer losses. A profile application, a package
   import, an ecore:EAnnotation, and root metadata (xmi:version) are now
   recorded as DECLARATIONS - an Exact verdict whose note begins with the
   'declaration:' marker - so they never appear in blocking() and never
   render as a loss. LossReport::declarations(), LossReport::content_losses()
   (Unmappable) and LossReport::lossy() (Lossy) expose the three kinds at a
   glance.
2. A human-first summary (ImportSummary + ImportVerdict + summarize_import)
   reports elements imported, declarations recognised, content losses, lossy
   id/name drops, and a verdict - with the detailed list left underneath.
3. No-content is stated plainly: a document with no elements renders
   'This document declares profiles and imports but contains no elements'.
4. pathmap:// is named. Every profile application and package import names
   its pathmap:// reference and says it is Eclipse-internal and cannot
   resolve outside the IDE.
5. Tests pin all of it against real-world/LandingGear.uml, plus a new
   fixture proving a real dropped element stays a visible content loss.

## Shape justification (why 'declaration' is Exact, not a new verdict)

MappingVerdict is exhaustively matched in engine/agent/src/losses.rs and
server/src/ui/import.rs, and Mapping/LossReport are built by struct literal in
engine/agent/tests and server/tests - all off-limits for this task. A new
variant or a new field would break those crates and fail cargo test --workspace.
So declarations reuse the one verdict that is already non-blocking (Exact) and
carry an explicit 'declaration:' note marker, which declarations() keys on.
Nothing about a dropped element is hidden: content losses remain Lossy/Unmappable
and still block.

## Before - verbatim report for real-world/LandingGear.uml

    === REAL MODEL: LandingGear.uml ===
    structure elements : 0
    interfaces         : 0
    signals            : 0
    requirements       : 0
    graph nodes/edges  : 0/0
    lossless           : false
    mappings           : 14
    --- every mapping, by verdict ---
      [Unmappable] uml:Model _l8EicCmtEeuNYs26IwK2fw attribute 'version (namespace http://www.omg.org/spec/XMI/20131001)' :: unmapped attribute on a recognised XMI element
      [Lossy] uml:Model _l8EicCmtEeuNYs26IwK2fw :: uml:Model xmi:id dropped: OKF has no project id slot; the name is carried as project
      [Unmappable] uml:PackageImport _l_qpACmtEeuNYs26IwK2fw :: unknown XMI element: outside the sysml-v1-xmi subset
      [Unmappable] uml:PackageImport _l_4EYCmtEeuNYs26IwK2fw :: unknown XMI element: outside the sysml-v1-xmi subset
      [Unmappable] uml:ProfileApplication _l9RcUCmtEeuNYs26IwK2fw :: unknown XMI element: outside the sysml-v1-xmi subset
      [Unmappable] uml:ProfileApplication _l_lJcCmtEeuNYs26IwK2fw :: unknown XMI element: outside the sysml-v1-xmi subset
      [Unmappable] uml:ProfileApplication _l_nlsCmtEeuNYs26IwK2fw :: unknown XMI element: outside the sysml-v1-xmi subset
      [Unmappable] uml:ProfileApplication _l_oMwCmtEeuNYs26IwK2fw :: unknown XMI element: outside the sysml-v1-xmi subset
      [Unmappable] uml:ProfileApplication _l_oMwimtEeuNYs26IwK2fw :: unknown XMI element: outside the sysml-v1-xmi subset
      [Unmappable] uml:ProfileApplication _l_oz0SmtEeuNYs26IwK2fw :: unknown XMI element: outside the sysml-v1-xmi subset
      [Unmappable] uml:ProfileApplication _l_oz0ymtEeuNYs26IwK2fw :: unknown XMI element: outside the sysml-v1-xmi subset
      [Unmappable] uml:ProfileApplication _l_pa4SmtEeuNYs26IwK2fw :: unknown XMI element: outside the sysml-v1-xmi subset
      [Unmappable] uml:ProfileApplication _l_pa4ymtEeuNYs26IwK2fw :: unknown XMI element: outside the sysml-v1-xmi subset
      [Unmappable] uml:ProfileApplication _l_qB8SmtEeuNYs26IwK2fw :: unknown XMI element: outside the sysml-v1-xmi subset
    === SUMMARY: 0 exact-ish, 1 lossy, 13 unmappable ===
    VERDICT: the import is LOSSY and every departure from the source is named above.

## After - verbatim report for real-world/LandingGear.uml

    === IMPORT SUMMARY (read this first) ===
    This document declares profiles and imports but contains no elements - 13 declaration(s) recognised, no content lost.
      elements imported       : 0
      declarations recognised : 13
      content losses          : 0
      lossy id/name drops     : 1
      verdict                 : LOSSLESS - no model content was lost
    --- detailed mappings ---
      [Exact] uml:Model _l8EicCmtEeuNYs26IwK2fw attribute 'version (namespace http://www.omg.org/spec/XMI/20131001)' :: declaration: root metadata (XMI schema version) recognised and not carried - it carries no model content
      [Lossy] uml:Model _l8EicCmtEeuNYs26IwK2fw :: uml:Model xmi:id dropped: OKF has no project id slot; the name is carried as project
      [Exact] uml:PackageImport _l_qpACmtEeuNYs26IwK2fw :: declaration: package import recognised and not carried - it carries no model content (reference pathmap://UML_LIBRARIES/UMLPrimitiveTypes.library.uml#_0); pathmap:// is Eclipse-internal and cannot resolve outside the IDE
      [Exact] uml:PackageImport _l_4EYCmtEeuNYs26IwK2fw :: declaration: package import recognised and not carried - it carries no model content (reference pathmap://SysML14_LIBRARIES/SysML-Standard-Library.uml#SysML.package_packagedElement_Libraries); pathmap:// is Eclipse-internal and cannot resolve outside the IDE
      [Exact] uml:ProfileApplication _l9RcUCmtEeuNYs26IwK2fw :: declaration: profile application recognised and not carried - it carries no model content (reference pathmap://SysML14_PROFILES/SysML.profile.uml#SysML); pathmap:// is Eclipse-internal and cannot resolve outside the IDE
      [Exact] uml:ProfileApplication _l_lJcCmtEeuNYs26IwK2fw :: declaration: profile application recognised and not carried - it carries no model content (reference pathmap://SysML14_PROFILES/SysML.profile.uml#SysML.package_packagedElement_Activities); pathmap:// is Eclipse-internal and cannot resolve outside the IDE
      [Exact] uml:ProfileApplication _l_nlsCmtEeuNYs26IwK2fw :: declaration: profile application recognised and not carried - it carries no model content (reference pathmap://SysML14_PROFILES/SysML.profile.uml#SysML.package_packagedElement_Allocations); pathmap:// is Eclipse-internal and cannot resolve outside the IDE
      [Exact] uml:ProfileApplication _l_oMwCmtEeuNYs26IwK2fw :: declaration: profile application recognised and not carried - it carries no model content (reference pathmap://SysML14_PROFILES/SysML.profile.uml#SysML.package_packagedElement_Blocks); pathmap:// is Eclipse-internal and cannot resolve outside the IDE
      [Exact] uml:ProfileApplication _l_oMwimtEeuNYs26IwK2fw :: declaration: profile application recognised and not carried - it carries no model content (reference pathmap://SysML14_PROFILES/SysML.profile.uml#SysML.package_packagedElement_ConstraintBlocks); pathmap:// is Eclipse-internal and cannot resolve outside the IDE
      [Exact] uml:ProfileApplication _l_oz0SmtEeuNYs26IwK2fw :: declaration: profile application recognised and not carried - it carries no model content (reference pathmap://SysML14_PROFILES/SysML.profile.uml#SysML.package_packagedElement_DeprecatedElements); pathmap:// is Eclipse-internal and cannot resolve outside the IDE
      [Exact] uml:ProfileApplication _l_oz0ymtEeuNYs26IwK2fw :: declaration: profile application recognised and not carried - it carries no model content (reference pathmap://SysML14_PROFILES/SysML.profile.uml#SysML.package_packagedElement_ModelElements); pathmap:// is Eclipse-internal and cannot resolve outside the IDE
      [Exact] uml:ProfileApplication _l_pa4SmtEeuNYs26IwK2fw :: declaration: profile application recognised and not carried - it carries no model content (reference pathmap://SysML14_PROFILES/SysML.profile.uml#SysML.package_packagedElement_Ports_u0026Flows); pathmap:// is Eclipse-internal and cannot resolve outside the IDE
      [Exact] uml:ProfileApplication _l_pa4ymtEeuNYs26IwK2fw :: declaration: profile application recognised and not carried - it carries no model content (reference pathmap://SysML14_PROFILES/SysML.profile.uml#SysML.package_packagedElement_Requirements); pathmap:// is Eclipse-internal and cannot resolve outside the IDE
      [Exact] uml:ProfileApplication _l_qB8SmtEeuNYs26IwK2fw :: declaration: profile application recognised and not carried - it carries no model content (reference pathmap://UML_PROFILES/Standard.profile.uml#_0); pathmap:// is Eclipse-internal and cannot resolve outside the IDE

## How a real content loss stays visible

A new fixture engine/binding-xmi/fixtures/declaration-with-content.xmi carries one
block, one uml:ProfileApplication, one uml:PackageImport, and one uml:StateMachine
(an element the reader cannot carry). The test
'content_losses_stay_visible_beside_declarations' asserts the summary reports
content_losses == 1 and verdict == ContentLosses, and that the StateMachine is
still named Unmappable - distinct from the two Exact declarations. Narrowing what
counts as a loss did not hide the signal.

## Test summary (cargo test --workspace --no-fail-fast)

414 passed, 0 failed, 24 ignored (postgres, need MW_TEST_DATABASE_URL), 0 measured.
Per crate: agent 14, analytics 79, binding 7, binding-xmi 21, capi 4, cli 36,
gate 5, graph 7, mcp 13, okf 17, server 211, test-support 0, doc-tests 0.

## Verification

- cargo fmt --all clean.
- cargo clippy --workspace --all-targets -- -D warnings clean.
- cargo +1.75.0 build -p mw-okf -p mw-test-support -p mw-graph -p mw-gate -p mw-binding
  -p mw-binding-xmi -p mw-agent -p mw-capi -p mw-mcp -p mw-analytics --locked clean (engine MSRV 1.75).

## Concerns

1. Exact is repurposed to mean 'recognised declaration (carries no content,
   deliberately not carried)' inside an import report, while in the mapping
   table it still means 'carried exactly'. This is forced by the off-limits
   exhaustive matches on MappingVerdict in engine/agent and server; the
   'declaration:' note marker keeps the two senses distinguishable.
2. The task brief said '11 uml:ProfileApplication'; the actual file has ten
   (plus two package imports and one xmi:version = 13 declarations). The
   real-world/README.md count was corrected to 'ten'.
