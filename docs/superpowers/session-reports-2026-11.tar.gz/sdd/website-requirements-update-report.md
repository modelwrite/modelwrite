# Website Requirements Update — Report

## Status
DONE

## Commits
- `7ced50b` — `website: update MagicDraw measurement (25 reqs, 28 trace links, 270 losses)`
  (branch `slice-2-repository`, pushed to `origin`; site redeploys on merge to `main`)

## Numbers verified
Command:
```
cargo test -p mw-binding-xmi --test real_magicdraw -- --nocapture
```
Result: `test result: ok. 1 passed; 0 failed; 0 ignored`.

Measured output:
- structure elements : 34
- requirements       : 25   (previously 0)
- interfaces         : 0
- signals            : 0
- activities         : 0
- graph nodes/edges  : 59 / 28
- graph edge breakdown: 20 Satisfy + 3 Allocate + 4 Refine + 1 Verify
  (confirmed by test assertions `satisfy == 20`, `allocate == 3`, `edges.len() == 28`)
- CONTENT LOSSES     : 270  (previously 348), all Unmappable and named
- declarations       : 1
- blocking           : 357
- lossless           : false

The remaining 270 losses are Ports, Operations, Associations, visibility and other
attributes — corroborated by the printed loss list.

## Concerns
- `README.md` was not changed: it contains no stale measurement numbers or related
  claims, so there was nothing to update there.
- The test's own header comment (`engine/binding-xmi/tests/real_magicdraw.rs`, lines
  7–10) still describes the source as "20 Satisfy and 3 Allocate links" without
  mentioning the 4 Refine and 1 Verify links its assertion (line 90) confirms. Left
  untouched because `engine/` is out of scope for this change. Informational only.
- The edge breakdown is verified via the test's own assertions plus a grep showing the
  source XMI contains exactly 28 `uml:Abstraction` elements (the SysML traceability
  stereotype carrier). No independent per-label XMI count was needed; the passing test
  is authoritative.
