# Slice 6 (governance) — fix round 1 report

## Status

DONE

## Commits

- `(this commit)` fix(governance): retained artifacts are fetchable and binding provenance is substantiated

## Test summary

`cargo test --workspace --no-fail-fast` → **339 passed, 21 ignored, 0 failed**.

Per binary (passed): agent 14, analytics 20, binding 7, binding-xmi 19, capi 4, cli 36,
gate 5, graph 7, mcp 13, okf 17, server 197 (18 unit + 179 integration), test-support 0.

The 21 ignored are all in `server/tests/postgres.rs` (the PostgreSQL suite, which CI runs
for real with `--include-ignored` and `MW_TEST_DATABASE_URL`). `cargo fmt --all -- --check`
clean; `cargo clippy --workspace --all-targets -- -D warnings` clean.

## What a reader can now check

- **The retained source artifact is fetchable** — `GET /projects/:project/import/:artifactHash/artifact`
  returns the exact retained bytes (Content-Type `application/octet-stream`), Read-permission
  and project-scoped: the import record for (project, artifactHash) must exist, so a hash alone
  cannot reach another project's artifact. A reader re-hashes the body and compares it to the
  `artifactHash` the import provenance names. The offline CLI gains `mw --db <path> artifact
  <project> --hash <hash>`, which returns the artifact as UTF-8 text beside its hash (the
  current bindings read text; a non-text artifact is served raw by the route).
- **Provenance is reachable from the commit alone** — `GET /projects/:project/commits/:hash/record`
  returns the commit record (hash, parents, author, message, provenance) for one hash. The
  existing `get_commit` model response is unchanged.
- **The provenance binding is substantiated, not asserted** — a caller-supplied
  `binding_id`/`binding_version` that disagrees with the import record is refused with a
  structured `Conflict`, in BOTH backends, so no route can land an Imported commit whose
  provenance names a binding the record does not.

## What the provenance refuses now

`store.commit_model` (in both `sqlite.rs` and `postgres.rs`) now reads
`binding_id` and `binding_version` from the SAME import record as the loss report and
refuses a mismatch with `Conflict`, before the unaccepted-loss check and before any commit
row is written. This closes the "copies a claim it does not check" gap: the two fields the
provenance carries are taken from the authoritative record, not from the caller.

## Tests changed and why

- `server/tests/governance.rs`
  - **Renamed** `the_store_refuses_an_unsubstantiated_import_so_the_cli_inherits_the_rule` →
    `..._so_any_commit_path_inherits_the_rule`, and rewrote its comment: the old name
    named the offline CLI as the subject, but the CLI has no import command and the test drives
    `store.commit_model` directly. (Minor 4 — chose the reword option; see below.)
  - **Added** `a_provenance_binding_that_disagrees_with_the_record_is_refused_by_the_commit_path`
    (Important 2).
- `server/tests/provenance.rs` — **added** `the_retained_artifact_is_fetchable_by_its_hash`
  (Important 1) and `provenance_is_reachable_by_commit_hash_alone` (Minor 5).
- `server/tests/postgres.rs` — **added four ignored tests** (Minor 3):
  `an_imported_commit_whose_artifact_is_missing_is_refused`,
  `an_imported_commit_with_unaccepted_losses_is_refused`,
  `a_provenance_binding_that_disagrees_with_the_record_is_refused`, and
  `an_older_database_gains_the_provenance_column_instead_of_failing`.
- `server/tests/auth.rs` — added `get_commit_record` and `get_artifact` to the
  route-denial table (Read/scope refused before the store is touched).
- `cli/tests/cli.rs` — **added** `offline_artifact_fetches_the_retained_source_bytes`.
- `cli/src/main.rs` — added the `artifact` command parser plus a `artifact_parses` unit
  test.
- `task-2-report.md` — rewrote the one line that described the store test as "(the CLI's
  offline write path)" to say it drives `store.commit_model` directly.

## Which option I chose for Minor 4, and why

**Reword.** The convergence-point proof is valid and worth keeping; only its name overstated
the subject. Adding a real offline import command would have meant re-implementing the binding
registry and fidelity harness in the CLI's offline path (or reaching through `import_core`)
to produce a second import surface this slice never asked for, for a finding whose fix was
"reword OR add". I reworded the test, its comment, the file header, and the task-2 report to
state plainly that it drives `store.commit_model` directly, and that any route reaching it
inherits the rule.

## Concerns

1. The offline `artifact` command returns the artifact as UTF-8 text, not raw bytes; a
   future binary source format would need the server route (which serves raw bytes). This is
   documented in the command's comment, and the route is the byte-exact path.
2. The 21 ignored tests are PostgreSQL-only and skip without `MW_TEST_DATABASE_URL`
   (unchanged behaviour; four are new).
3. The workspace run includes the concurrent task's `engine/analytics` crate (20 tests),
   which was committed before this fix round; I did not touch it, `Cargo.toml` or
   `Cargo.lock`.
