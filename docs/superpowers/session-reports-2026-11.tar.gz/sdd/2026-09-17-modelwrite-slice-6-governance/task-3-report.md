# Task 3 report: A model knows which checks have been run on it

Status: DONE

## Commits

- `30b1e46` feat: a model knows which checks have been run on it

## Test summary

`cargo test --workspace --no-fail-fast` -> **312 passed, 17 ignored (the PostgreSQL suite), 0 failed**.
Per binary: agent 14, binding 6, binding-xmi 18, capi 4, cli 34, gate 5, graph 7, mcp 13,
okf 17, server 194 (18 unit + 176 integration, including 3 new gate_api tests + 1 new ignored
postgres test), test-support 0.

## What was built

The gate run record already carried the candidate commit hash; what was missing was the way to
ADDRESS a model and ask what had been checked about IT. This task adds that read path.

- `server/src/store/mod.rs` - a new `Store` method, `gate_runs_for_commit(project, hash)`,
  with a doc comment stating the invariant: the answer is scoped to a commit, never a branch or
  a project, so a later commit does not inherit an earlier verdict.
- `server/src/store/sqlite.rs` and `server/src/store/postgres.rs` - the two implementations,
  filtering `gate_runs` by `project AND candidate_hash` in oldest-first order. Both were
  required because the postgres backend is a default feature and its tests compile on every run.
- `server/src/gate_api.rs` - `commit_checks`, the handler behind
  `GET /projects/:project/commits/:hash/checks`. It (1) requires Write OR Review, exactly like
  the project-wide `gate-runs` listing; (2) returns 404 for a missing commit, so "this model
  does not exist" is never blurred into "nobody checked it"; (3) returns a `checked` flag -
  `false` means UNCHECKED explicitly, never a bare empty list that reads like a pass. The run
  shape is factored into a shared `gate_run_json` helper so the per-commit answer and the
  project-wide listing can never disagree, and both render the recorded evidence (the
  authority), never a re-run.
- `server/src/lib.rs` - the route, registered next to `get_commit`.

## Acceptance proof

New tests in `server/tests/gate_api.rs` drive the live router:

- `a_gate_run_appears_on_the_candidate_commit_and_not_on_another` - gating candidate against
  reference puts the run (verdict + evidence) on the CANDIDATE's checks and NOT on the
  reference's, so a verdict never follows a branch to a commit it never checked.
- `a_commit_nobody_has_checked_says_unchecked_not_an_empty_list` - a commit with no runs
  returns `checked: false` explicitly.
- `checks_for_a_missing_commit_is_not_found` - a missing commit is a 404, not a silent
  unchecked.

`server/tests/auth.rs` gained a `get_commit_checks` case in the route-denial table (a viewer,
who holds neither Write nor Review, is refused 403 before the store is touched). A matching
ignored PostgreSQL store test (`a_gate_run_is_queryable_by_its_candidate_commit`) pins the
backend query in CI.

## Deviation

The brief lists "record the candidate commit on a run" as part of the work, but the
`candidate_hash` column already existed in both backends and `run_gate` already wrote it.
The genuine gap was the read side (no per-commit query, no endpoint, no explicit "unchecked"
answer), which is what this task added. Consequently NO schema change was required - the
"schema change in BOTH backends" constraint did not apply, and no migration or
`ADD COLUMN` was written in either backend.

## Verification

- `cargo fmt --all` clean.
- `cargo clippy --workspace --all-targets -- -D warnings` clean.

## Concerns

None.
