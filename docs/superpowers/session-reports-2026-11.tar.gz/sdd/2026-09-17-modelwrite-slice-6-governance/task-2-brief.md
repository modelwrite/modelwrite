## Global Constraints

- Rust stable; engine crates at rust-version 1.75, server at 1.88.
- Every source file begins with: // SPDX-License-Identifier: AGPL-3.0-or-later
- Cargo is not on PATH in fresh shells: begin every shell command sequence with $env:Path = "$env:USERPROFILE\\.cargo\\bin;" + $env:Path
- Use --no-fail-fast when running a test suite.
- Stage and commit only the paths a task owns. Never amend or rewrite a commit.
- **A CLAIM MUST BE CHECKABLE OR IT MUST BE LABELLED AS UNCHECKED.** The platform may say "this was measured", "this was asserted by a binding", or "this is unknown". It must never blur the three.
- **PROVENANCE IS PERMANENT AND ADDITIVE.** Governance adds records; it never rewrites history to make a story tidier.
- No path panics; a missing record is a 404 or an explicit "unknown", never a silent empty success.

## Task 2: The migration rules are a property of the repository, not of one endpoint

**Files:** modify server/src/api.rs or the shared commit core; test server/tests/migration.rs or a new server/tests/governance.rs.

**Interfaces:** a commit declaring `imported` provenance must name the artifact it came from, and the artifact must exist; a commit whose document contains losses that were never accepted cannot be marked imported. The rule is enforced by the commit path, so a migration performed by ANY route - the endpoint, the CLI, or a future one - meets it.

**Ruling:** the honest boundary found in Slice 4 was that the four rules held on the import path only. This task closes it by moving the enforcement from the endpoint to the commit, and a test must prove a NON-import route cannot produce an imported commit without provenance.

---

