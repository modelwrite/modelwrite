## Global Constraints

- Rust stable; engine crates at rust-version 1.75, server at 1.88.
- Every source file begins with: // SPDX-License-Identifier: AGPL-3.0-or-later
- Cargo is not on PATH in fresh shells: begin every shell command sequence with $env:Path = "$env:USERPROFILE\\.cargo\\bin;" + $env:Path
- Use --no-fail-fast when running a test suite.
- Stage and commit only the paths a task owns. Never amend or rewrite a commit.
- **A CLAIM MUST BE CHECKABLE OR IT MUST BE LABELLED AS UNCHECKED.** The platform may say "this was measured", "this was asserted by a binding", or "this is unknown". It must never blur the three.
- **PROVENANCE IS PERMANENT AND ADDITIVE.** Governance adds records; it never rewrites history to make a story tidier.
- No path panics; a missing record is a 404 or an explicit "unknown", never a silent empty success.

## Task 4: The mapping table is read rather than described

**Files:** modify engine/binding (reconcile or correct the doc), engine/binding-xmi; test engine/binding/tests or binding-xmi/tests.

**Interfaces:** either the gate CONSULTS `mapping_table()` when checking an import, or the trait documentation states plainly that the table is declaration rather than gate input - and either way a test pins which it is. The doc currently claims the gate reads it, and nothing does.

**Acceptance:** a reader of the trait can tell whether the table is enforced or declarative, and the claim matches the code.

---

