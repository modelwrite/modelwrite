## Global Constraints

- Rust stable; engine crates at rust-version 1.75, server at 1.88.
- Every source file begins with: // SPDX-License-Identifier: AGPL-3.0-or-later
- Cargo is not on PATH in fresh shells: begin every shell command sequence with $env:Path = "$env:USERPROFILE\\.cargo\\bin;" + $env:Path
- Use --no-fail-fast when running a test suite.
- Stage and commit only the paths a task owns. Never amend or rewrite a commit.
- **A CLAIM MUST BE CHECKABLE OR IT MUST BE LABELLED AS UNCHECKED.** The platform may say "this was measured", "this was asserted by a binding", or "this is unknown". It must never blur the three.
- **PROVENANCE IS PERMANENT AND ADDITIVE.** Governance adds records; it never rewrites history to make a story tidier.
- No path panics; a missing record is a 404 or an explicit "unknown", never a silent empty success.

## Task 1: A commit knows how it arrived

**Files:** modify server/src/store/{mod.rs,sqlite.rs,postgres.rs} (commit provenance), server/src/api.rs (commit_json), server/src/binding_api.rs (write it on import); test server/tests/provenance.rs.

**Interfaces:** a commit carries an OPTIONAL provenance recording how it was produced: `authored` for a normal commit or edit, `imported` with the artifact hash, binding id and version, and the accepted losses, for a migration. It is written in the SAME transaction as the commit. `GET /projects/:project/commits/:hash` returns it, and a commit with none says so plainly rather than omitting the field.

**Acceptance:** a commit made by the editor records `authored`; a commit made by an import records `imported` with its artifact hash and binding; a reader can tell them apart from the commit alone; an existing commit with no provenance reads as unknown rather than as authored.

---

