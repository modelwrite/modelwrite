# Task 1 report: A commit knows how it arrived

Status: DONE_WITH_CONCERNS

## What was implemented

Commit provenance, end to end, written in the same transaction as the commit and readable
from the commit alone:

- `server/src/store/mod.rs`: added a `CommitProvenance` enum (`Authored` /
  `Imported { artifact_hash, binding_id, binding_version, accepted_losses }` /
  `Unknown`) with `column_value()` and `parse_column()`; added a `provenance` field
  to `Commit`; extended `ImportProvenance` with `binding_id` / `binding_version`.
- `server/src/store/sqlite.rs` and `server/src/store/postgres.rs`: added a nullable
  `provenance` column to the `commits` table (schema + migration in BOTH backends); the
  column is written in the SAME transaction as the commit (`authored` for a normal
  commit/merge/reset, `imported` for an import); a NULL column reads as `Unknown`.
- `server/src/api.rs`: `commit_json` now emits `provenance` (a `kind` of authored /
  imported / unknown, plus artifactHash / bindingId / bindingVersion / acceptedLosses for an
  import). A commit with none reads `unknown`, never `authored`.
- `server/src/binding_api.rs`: `import_core` passes binding id/version into the import
  provenance; the import response no longer hand-builds provenance (commit_json supplies it).
- `server/src/merge_api.rs`, `server/src/ui/review.rs`, `server/src/ui/import.rs`:
  boxed `Commit` in `MergeOutcome`, `MergeOutcomeKind` and `ImportOutcome` — the new
  provenance field grew `Commit`, tipping three enums past clippy's `large_enum_variant`.
- `server/tests/store.rs`: updated the `ImportProvenance` construction for the new fields.
- `server/tests/provenance.rs` (new): 4 tests — a normal commit records `authored`; an
  import records `imported` with its artifact hash and binding; a commit written before
  provenance reads `unknown` (not authored); and the three kinds are distinguishable from
  the commit alone.

## Verification

- New tests: `server/tests/provenance.rs` passes 4/4.
- At verification time the FULL workspace was green: `cargo test --workspace --no-fail-fast`
  = 301 passed, 16 ignored (the PostgreSQL suite), 0 failed; `cargo fmt --all -- --check`
  clean; `cargo clippy --workspace --all-targets -- -D warnings` clean.

## Concerns (this is what blocked the commit step)

While I was finishing, the other slice-6 tasks began modifying the SAME shared working tree
(overlapping files). The tree is now in a transiently broken, entangled state that is not this
task's doing:

- `server/src/auth.rs`: `agent_token` now returns `Result` ("an agent proposes and a
  human commits") but the agent test files were mid-update, so `cargo test/clippy --workspace`
  fails with E0308 (`expected AuthConfig, found Result<AuthConfig, Error>`) in
  `server/tests/agent_contract.rs` / `agent_audit.rs`.
- `server/src/binding_api.rs`: Task 2's `resolve_acceptances` landed alongside my
  provenance changes; it carries 3 clippy lints (`map_clone` x2, `explicit_auto_deref`)
  that fail `-D warnings`.
- `server/src/ui/import.rs`, `server/Cargo.toml`, `docs/agents/mcp-agent.md` also now
  carry other tasks' in-progress changes.

My brief owns `binding_api.rs`, but it now contains another task's in-progress (non-clean)
changes, and the full workspace is red through no fault of this task. Committing now would
entangle other tasks' incomplete work and produce a non-green commit, violating "stage and
commit only the paths a task owns" and "everything must stay green". I therefore did NOT
commit.

Intended commit message: `feat: a commit knows how it arrived`

## Deviation

- No commit was made (reason above). All code for this task is complete, correct, and
  clippy-clean; it is ready to commit as soon as the concurrent tasks settle and the tree is
  green again. Files changed for THIS task: server/src/store/{mod,sqlite,postgres}.rs,
  server/src/api.rs, server/src/binding_api.rs, server/src/merge_api.rs,
  server/src/ui/{import,review}.rs, server/tests/store.rs, server/tests/provenance.rs.
