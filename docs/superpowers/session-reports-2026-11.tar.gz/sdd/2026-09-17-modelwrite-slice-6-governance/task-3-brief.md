## Global Constraints

- Rust stable; engine crates at rust-version 1.75, server at 1.88.
- Every source file begins with: // SPDX-License-Identifier: AGPL-3.0-or-later
- Cargo is not on PATH in fresh shells: begin every shell command sequence with $env:Path = "$env:USERPROFILE\\.cargo\\bin;" + $env:Path
- Use --no-fail-fast when running a test suite.
- Stage and commit only the paths a task owns. Never amend or rewrite a commit.
- **A CLAIM MUST BE CHECKABLE OR IT MUST BE LABELLED AS UNCHECKED.** The platform may say "this was measured", "this was asserted by a binding", or "this is unknown". It must never blur the three.
- **PROVENANCE IS PERMANENT AND ADDITIVE.** Governance adds records; it never rewrites history to make a story tidier.
- No path panics; a missing record is a 404 or an explicit "unknown", never a silent empty success.

## Task 3: A model knows which checks have been run on it

**Files:** modify server/src/gate_api.rs (record the candidate commit on a run), server/src/store/*, server/src/gate_api.rs or a new endpoint; test.

**Interfaces:** a gate run records the CANDIDATE COMMIT it was run against, so `GET /projects/:project/commits/:hash/checks` answers what has been run on this model and what it said, and a commit with no runs says so rather than returning an empty list that looks like a pass.

**Acceptance:** running the gate on a commit makes it appear in that commit's checks with its verdict and evidence; a commit nobody has checked says so explicitly.

---

