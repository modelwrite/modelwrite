# SDD ledger - plan: docs/superpowers/plans/2026-09-17-modelwrite-slice-6-governance.md

Working branch: slice-2-repository (pull request #2).

## Why this slice

Governance here does not mean process for its own sake. It means that every claim the platform makes about a model can be CHECKED from the repository, a year later, by somebody who was not there. Four tasks, and every one was FOUND by a review during Slices 2 to 5 rather than invented: a migrated commit cannot be told from an authored one; the migration rules hold on the import path only; a binding mapping table is dead data whose documentation overstates it; and there is no way to ask which checks have been run on a model.

## Rulings

Ruling: A CLAIM MUST BE CHECKABLE OR IT MUST BE LABELLED AS UNCHECKED. The platform may say this was measured, this was asserted by a binding, or this is unknown. It must never blur the three. Cost if wrong: some screens have to say 'unknown' where a nicer product would show a plausible number. That is the trade this whole platform exists to make - every defect worth remembering from Slices 2 to 5 was a blurred category rather than a crash.
Ruling: provenance is permanent and additive. Governance adds records; it never rewrites history to make a story tidier.
Ruling: the migration rules move from the ENDPOINT to the COMMIT, so a migration performed by any route - the endpoint, the CLI, or one not yet written - meets them. This closes the honest boundary Slice 4 recorded.

## Environment facts

- Baseline: 297 workspace tests passing, 16 ignored locally (the PostgreSQL suite, which CI runs for real), fmt and clippy clean, CI green on four jobs.
- Provenance was already made atomic in the Slice 4 fix round: it is written in the same transaction as the commit. Task 1 builds on that rather than redoing it.
- The gate run record, the audit log and the imports table already exist. This slice CONNECTS them to the commits they describe; it does not invent a new store.

## Progress

Task 1: dispatched
