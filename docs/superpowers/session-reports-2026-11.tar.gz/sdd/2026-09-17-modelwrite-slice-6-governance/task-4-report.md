# Task 4 report: The mapping table is declaration, not gate input

Status: DONE

## Commits

- `72f48fd` fix(binding): the mapping table is declaration, not gate input

## Test summary

`cargo test --workspace --no-fail-fast` -> **314 passed, 17 ignored (the PostgreSQL suite), 0 failed**.
Per binary: agent 14, binding 7, binding-xmi 19, capi 4, cli 34, gate 5, graph 7, mcp 13,
okf 17, server 194, test-support 0.

## Which answer, and why

I chose **(B) MAKE IT HONEST**. Option (A) - making the gate consult the table - would mean
inventing a rule the gate cannot actually apply. The gate (`engine/gate::run`) operates on
two `OkfRoot`s (reference vs candidate) and has no `Binding` in scope; the code path that
checks an import is `server/src/binding_api.rs::import_core`, and it enforces the per-import
`LossReport` (`loss_report.blocking()`), never `mapping_table()`. Enforcing the table
would additionally require cross-checking the table's category-shaped subjects against the
loss report's instance-shaped subjects - the very mismatch this task also flags - which is a
new behaviour built to justify a sentence. The controller ruling says that is exactly the
wrong move. So the honest fix is to make the documentation match the code that already
exists.

## What changed

- `engine/binding/src/lib.rs` - the trait's `mapping_table` doc no longer claims "data the
  gate reads; a binding that declares nothing understands nothing". It now states plainly:
  the table is DECLARATION, published so a person can read the boundary before migrating; the
  gate does not read it and nothing here is enforced; what the gate enforces is the per-import
  `LossReport` returned from `import`, whose blocking entries name - per instance - what was
  actually lost or left unmapped.
- `engine/binding-xmi/src/model.rs` - the module doc no longer claims "the gate and the
  workbench read this data". The `mapping_table` doc now also spells out the relationship a
  reader needs: a row's `subject` is a CATEGORY (`uml:Package (packagedElement)`), a loss
  report's `subject` is an INSTANCE (`uml:Package pkg-structure (Structure)`), and the
  leading construct name (`uml:Package`) is the shared key for matching one to the other.

## How the choice is pinned

- `engine/binding/tests/declaration.rs` (new) - `the_mapping_table_is_declaration_and_does_not_change_import_behaviour`.
  Two bindings that differ ONLY in their declared table (empty vs one row) produce the SAME
  loss report on import, so the declaration cannot be what import behaves on; a binding that
  declares nothing still imports and still reports its loss.
- `engine/binding-xmi/tests/xmi.rs` (extended) - `every_reported_instance_relates_to_a_declared_construct`.
  Every blocking loss on the coffee-grinder fixture's real loss report traces, by its leading
  construct name, to a construct the table declares - pinning that a reader can relate the two
  shapes the documentation describes.

## Verification

- `cargo fmt --all` clean.
- `cargo clippy --workspace --all-targets -- -D warnings` clean.
- `cargo +1.75.0 check -p mw-binding -p mw-binding-xmi --all-targets` clean (engine crates
  still build at rust-version 1.75).

## Concerns

- The historical spec `docs/superpowers/specs/2026-09-17-modelwrite-standards-interoperability.md`
  still contains the line "This is data, not prose: the gate reads it." `docs/` is explicitly
  out of scope for this task and for governance provenance (specs and plans are historical
  records, not code claims), so it was left untouched. The authoritative claim now lives in
  the trait and the binding, which are what a reader of the code consults.
- Nothing in `server/` or `engine/gate` changed, so no `Cargo.lock` change was required.
