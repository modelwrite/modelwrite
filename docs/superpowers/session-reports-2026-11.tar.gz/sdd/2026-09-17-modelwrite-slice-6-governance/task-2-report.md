# Task 2 report: The migration rules are a property of the repository, not of one endpoint

Status: DONE

## Commits

- `70908ad` feat: the migration rules are a property of the repository, not of one endpoint

## Test summary

`cargo test --workspace --no-fail-fast` -> **309 passed, 16 ignored (the PostgreSQL suite), 0 failed**.
Per binary: agent 14, binding 6, binding-xmi 18, capi 4, cli 34, gate 5, graph 7, mcp 13,
okf 17, server 191 (18 unit + 173 integration, including 5 new governance tests).

## Where the enforcement lives

In the store's `commit_model` - the one function that writes a commit row and accepts an
`ImportProvenance` - in BOTH backends (`server/src/store/sqlite.rs` and
`server/src/store/postgres.rs`), inside the commit transaction. Before a commit that declares
itself imported is written it must pass three checks, in order:

1. the named artifact blob exists (`SELECT 1 FROM blobs WHERE hash = ...`),
2. an import record for (project, artifact) exists, and
3. every blocking loss in that record's loss report is accepted by name.

The loss-report parsing / acceptance comparison is a single shared helper,
`store::unaccepted_losses` (`server/src/store/mod.rs`), so the two backends cannot drift on
the wording of the refusal. A missing artifact or record is a structured `NotFound`; an
unaccepted loss is a structured `Conflict` - never a panic and never a 500.

Putting the check in `commit_model` (not in `commit_core`, and not in the import endpoint) is
what makes it a property of the repository rather than of a feature: `commit_model` is the
single convergence point every commit write reaches - the plain commit route, the editor, the
import endpoint, `reset_branch`, and the offline CLI all call it. The CLI in particular writes
commits by calling `commit_model` directly and never goes through `commit_core`, so a check in
`commit_core` would have been the "looks global but is only reached by today's callers" failure
mode this task exists to close.

## How it is proven not to be import-only

New tests in `server/tests/governance.rs` drive the commit path WITHOUT touching the import
endpoint:

- `an_imported_commit_whose_artifact_is_missing_is_refused_by_the_commit_path` - calls
  `commit_core` (the shared core the plain commit route uses) with an import whose record
  exists but whose artifact blob was never retained; refused as `NotFound`.
- `a_commit_with_unaccepted_losses_cannot_be_marked_imported_by_the_commit_path` - calls
  `commit_core` with a provenance that accepts none of the report's blocking losses; refused
  as `Conflict`.
- `the_store_refuses_an_unsubstantiated_import_so_any_commit_path_inherits_the_rule` - calls
  `store.commit_model` directly (the shared convergence point every commit write reaches),
  proving any route that reaches it - the import endpoint, a future import command, or a
  direct caller - meets the same rule. It does not drive the offline CLI: the CLI has no
  import command and writes only Authored commits.
- `an_imported_commit_with_substantiated_provenance_lands_through_the_commit_path` - positive
  control: accepting the one blocking loss by entry identity lands with `Imported` provenance.
- `an_authored_commit_is_not_held_to_migration_rules` - a non-import commit needs no artifact
  and no loss report and still lands as `Authored`.

## Verification

- `cargo fmt --all` clean.
- `cargo clippy --workspace --all-targets -- -D warnings` clean.

## Concerns

None.
