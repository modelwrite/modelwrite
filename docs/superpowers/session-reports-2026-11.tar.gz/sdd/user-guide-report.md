# User guide report

Status: DONE_WITH_CONCERNS

## Commits

- 54c1f53 Add modelwrite user guide (docs/guide) - 8 files, 585 insertions
  (README.md plus the seven pages below; no other paths staged)

## Page list

- docs/guide/README.md - front door: three-sentence definition, two audiences, the not-does list (linked to limits), the four URLs, the five-minute tour, index.
- docs/guide/concepts.md - OKF, binding vs standard, commit and content addressing, version is a branch, the gate, provenance, composition, analyses and findings.
- docs/guide/tasks.md - eight numbered tasks with exact clicks and exact request bodies.
- docs/guide/agents.md - MCP client JSON, the two env vars, the 13-tool list, the read-and-propose rule, what an agent can do.
- docs/guide/faq.md - CATIA, simulation, trial safety, old models, AI changes, licence.
- docs/guide/limits.md - the standing limits, each with a one-line consequence, plus two "also true today".
- docs/guide/troubleshooting.md - lock, refused migration, stale page, diagram zoom, 401/403/422.
- README.md - added a short Documentation section cross-linking docs/guide/README.md.

## What was verified against the running system (read-only)

Exercised http://127.0.0.1:8080 with curl:

- /health -> {"authMode":"open","status":"ok"}; /version -> 0.1.0.
- / -> 307 redirect to /ui; /ui -> 200.
- /projects -> six models: cafe-stand, coffee-machine, floor-robot, microduck,
  purchasing-terminal, sandwich-toaster.
- coffee-machine /overview -> renders h1 Overview, the Coverage/Elements/Requirements/
  Versions cards, View diagram, Add element, New version, coverage-summary.
- cafe-stand /composition -> renders Subsystems (coffee-machine, sandwich-toaster,
  purchasing-terminal), resolves/revision, the Measured and asserted boundary, the
  Process view, the "first-class cross-model edge" note and allocatedTo.
- coffee-machine /import -> renders Import/Binding/Source artifact/sysml-v1-xmi/
  content-addressed/loss report/byte-for-byte.
- coffee-machine /checks and /compare?from=main&to=main -> 200.
- coffee-machine /branches -> main tip d427e847bf4d875d06fc7f2a5b47bb0a3dc53855a61850195c4ec78e7d45fc36;
  /commits -> one commit, provenance authored.
- coffee-machine /overview assist panel -> "Live reasoner" and the assist form present.

## What was taken from the code (not exercised live)

- Every click path in tasks.md: server/src/ui/*.rs (pages, model, create, edit, import,
  version, gate, review, composition, assist, proposals, diagram, layout) and the route
  table in server/src/lib.rs.
- The gate endpoint and the checked flag: server/src/gate_api.rs; the gate's four checks
  (fidelity, validation, integration, coverage): engine/gate/src/lib.rs.
- The MCP contract (13 tools, two env vars, read-and-propose): docs/agents/mcp-tools.json,
  docs/agents/mcp-agent.md, server/tests/agent_contract.rs, engine/mcp.
- Provenance Authored/Imported/Accepted/Unknown: server/src/store/mod.rs.
- Binding identity sysml-v1-xmi@2.4 and its stated subset: engine/binding-xmi/src/lib.rs,
  server/src/binding_registry.rs.
- Licence split (AGPL engine, Apache-2.0 interchange designated but not yet in crate
  metadata): Cargo.toml, README.md, NOTICE.md.
- The standing limits: real-world/README.md (Papyrus skeleton, zero elements),
  docs/superpowers/specs/2026-09-17-modelwrite-standards-interoperability.md,
  docs/superpowers/specs/2026-09-20-modelwrite-analyses-and-simulations.md,
  docs/superpowers/specs/2026-09-19-modelwrite-system-of-systems.md.

## Could not verify

- Write paths (create project, import, accept a proposal, record a gate run) were not
  exercised against the live trial: it is shared and ephemeral, six models are deployed,
  and other tasks depend on it. These are code-verified instead.
- The assist-to-accept flow end to end against the live reasoner (would call an external
  model and write to the trial).
- Public DNS for trial.modelwrite.org and modelwrite.org: the local origin 127.0.0.1:8080
  is what was exercised; the URLs themselves come from the repo's own docs and config.

## Concerns

1. Write paths are code-verified, not live-exercised (see above). The guide says so rather
   than hiding it.
2. On this Windows case-insensitive filesystem, docs/guide/agents.md is picked up by the
   agent harness as AGENTS.md (agent instructions) and injected into agent context under
   docs/guide/. On GitHub (case-sensitive) it stays agents.md and this does not apply.
