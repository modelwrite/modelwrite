# System-of-systems S1 — the compositional gate — report

**Status:** DONE_WITH_CONCERNS

**Commit:** b598867 — `feat(sos): add the compositional gate (S1)`

**One-line test summary:** 498 passed, 0 failed, 24 ignored (5 new S1 tests + 1 S0 test updated), `cargo fmt --all` clean, `cargo clippy --workspace --all-targets -- -D warnings` clean.

## What S1 proves (and only this)

The compositional gate is the single-model gate lifted one level (§4). It runs ON TOP of the unchanged single-model gate over the platform model's own document, plus three bounded cross-model checks — none of which imports a subsystem's graph. It measures, per reference:

1. **Resolution at the pinned revision.** The named project exists, the pinned revision is a commit of it, and every bound element (the `bounds` field newly added to `SubsystemReference`) exists within that revision. The project/revision lookup reuses S0's `check_reference`; the bound-element lookup reads the subsystem's stored, content-addressed revision. A missing project, a stale hash, or a bound element that names nothing is a NAMED failure.
2. **Every integrated revision was itself gated.** The pinned revision carries a passing gate record (`store.gate_runs_for_commit(...).any(passed)`). It is a lookup of the record, never a re-run of the subsystem's gate. An un-gated revision is a NAMED failure — the platform refuses to bless the integration, and names which reference.
3. **Platform coverage, computed locally.** Every platform requirement has either a local satisfying element or a typed cross-model reference whose bound element closes the trace. The existing `graph::requirement_coverage` is reused verbatim — a bound element's id appears as a graph node, and the Satisfy edge from it to the requirement is exactly what the single-model machinery already reads. Requirements covered ONLY cross-model are reported in a `crossModelOnly` list, distinct from `local`.

The `composition` section is merged into the gate evidence, and any composition failure is merged into the verdict (`passed`/`failures`) exactly like a single-model failure. The offline CLI gate mirrors the server gate byte-for-byte, so composition is not server-only.

## The measured-vs-asserted boundary the gate carries (as data)

The gate report carries the boundary as data under `evidence.composition.boundary`, never as prose. The exact strings are:

- **measured** (three entries):
  - `every subsystem reference resolves at its pinned revision`
  - `every integrated revision was itself gated`
  - `every platform requirement is covered within the platform model`
- **asserted** (one entry):
  - `the combined system-of-systems, as a whole, has the global graph property (connected, coverage-complete, orphan-free); proving it would require importing every subsystem, which is the copy R1 forbids`

Each resolution and was-gated finding also carries `kind: "measured"`, so a report cannot blur a proof and a claim the way a column of green ticks would (§4.2).

## Concerns

1. **Offline CLI gate now runs composition (outside the S1 ownership list).** `cli/src/offline.rs` is not in the "you own" set, but the existing `offline_gate_matches_the_server_verdict_on_the_corpus_pair` test asserts the offline gate and the server gate return byte-identical evidence. S1 adds the `composition` section to the server gate, so the offline gate had to add the same section to keep that invariant. The offline store answers resolution and was-gated, so this is a genuine mirror, not a stub. Flagged because it is an edit outside the stated ownership boundary.
2. **Offline commit does not enforce reference resolution (pre-existing S0 gap, now more visible).** The server's `commit_core` refuses a platform model whose reference does not resolve (422); the offline CLI reimplements commit with `okf::validate::validate` only and does not run `check_reference`. The offline GATE now catches a stale reference via the composition resolution check, so nothing invalid can pass the gate, but the offline commit-vs-gate asymmetry remains and is flagged rather than patched in this slice.
3. **S0 test assertion mechanically updated.** Adding `bounds` to `SubsystemReference` changed the serialised reference to include `"bounds": []`; `server/tests/references.rs`'s listing assertion was updated to match, and `the_single_model_gate_is_unchanged_by_references` now gates the radar revision first so the was-gated check passes. No single-model gate behaviour changed.
4. **Bound elements are open ids.** `bounds` is a `Vec<String>` of element ids with only a non-empty check in validation; the existence check is the gate's measured resolution check. No closed vocabulary was invented.

## Verification

- `cargo test --workspace --no-fail-fast` (with `CARGO_TARGET_DIR=target-tests`): **498 passed, 0 failed, 24 ignored**.
- `cargo fmt --all --check`: clean.
- `cargo clippy --workspace --all-targets -- -D warnings`: clean.

## Files

- `engine/okf/src/types.rs` — `bounds` field on `SubsystemReference`.
- `engine/okf/src/validate.rs` — empty bound-element-id check.
- `engine/okf/tests/okf_validation.rs`, `engine/okf/tests/okf_diff.rs` — struct literals.
- `server/src/composition.rs` (new) — the compositional gate: resolution, was-gated, coverage split, boundary.
- `server/src/gate_api.rs` — run composition and merge into evidence.
- `server/src/lib.rs` — register the `composition` module.
- `server/tests/composition.rs` (new) — the 5 S1 scenarios.
- `server/tests/references.rs` — S0 assertion + gated-radar update.
- `cli/src/offline.rs` — offline gate mirrors the server's composition section.

