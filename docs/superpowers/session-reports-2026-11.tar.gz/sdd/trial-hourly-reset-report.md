# idc-1 trial — hourly reset + change-detection guard — report

**Status:** DONE_WITH_CONCERNS

## Schedule

- `modelwrite-trial-reset.timer`: `OnCalendar=hourly`, `Persistent=true` (was nightly
  18:00 UTC). Enabled; NEXT at the top of each hour.
- `modelwrite-trial-reset.service` (Type=oneshot) runs
  `/opt/modelwrite/deploy/reset-trial.sh`.

## Backup naming and retention

- Naming: `/opt/modelwrite/backups/<YYYY-MM-DD>T<HHMMSS>.db` (`date +%FT%H%M%S`) — every
  reset is a distinct file. Fixed-width/zero-padded, so lexicographic sort == chronological
  (the `sorted(...)[:-keep]` prune still works; proven below).
- Retention: **48** (two days). Measured first: one backup = 217088 B (~212 KB); `df -h`
  shows 1.4T with 909G avail. 48 × 212 KB ≈ 10.2 MB ≈ 0.000001% of free space — cannot fill
  the disk (even 100× growth ≈ 1 GB).

## Change-detection guard (skip when unchanged)

`/opt/modelwrite/deploy/trial-changed.py` runs FIRST in reset-trial.sh:

- Expected state is DERIVED from the seed manifest by replaying its operations in memory
  (per project: existence, branch list, every branch tip hash).
- Actual state is read DIRECTLY from SQLite (read-only, `mode=ro`) via the `projects` and
  `branches` tables — no server started. Fields compared: the full
  `{project -> {branch -> tip}}` map (covers project existence + branch list + every tip;
  a tip is content-addressed so matching tips imply matching history/content).
- Match => log "no changes since the last reset, skipping (service not restarted, no backup
  taken)" and exit 0 (NO stop, NO backup, NO rebuild).
- Differ => full reset. Cannot determine (missing manifest / unreadable DB / query error) =>
  fail CLOSED and reset. A changed-then-changed-back state skips (correct, not a bug).
- `FORCE=1` bypasses the guard: `sudo env FORCE=1 /opt/modelwrite/deploy/reset-trial.sh`.

## Reset script (minimise window + trap)

Builds the FRESH DB off to the side and verifies it while the live service keeps serving,
then stops + backs up + swaps + restarts (~11 s down window). `trap on_fail ERR` ->
`systemctl start` survived (a failed reset leaves the service up on the last good DB).

## Verbatim proof (guard)

1. Skip on no-change (reset run twice; second run):
   journal: "[22:04:27] no changes since the last reset, skipping (service not restarted, no backup taken)"
   backup count before/after: 6 -> 6; ActiveEnterTimestamp before/after: 22:04:00 -> 22:04:00 (unchanged);
   systemctl start exit: 0 (unit Deactivated successfully, not failed).
2. Change (createProject visitor-probe) -> full reset:
   journal: "[22:03:48] changes detected (state differs from seed) - running full reset"
   -> new backup 2026-09-20T220400.db -> six models (visitor-probe gone).
3. Branch-only change (createBranch cafe-stand/visitor-branch, which a count would MISS) -> NOT skip:
   branches 8 -> 7 after; journal: "[22:04:48] changes detected (state differs from seed) - running full reset";
   six models.
4. Broken guard (manifest hidden) -> NOT skip, falls through:
   journal: "[22:05:47] cannot determine state ([Errno 2] No such file or directory: '/opt/modelwrite/seed/manifest.json') - running full reset"
   then "=== reset start ===" -> replay FileNotFoundError -> "RESET FAILED - restarting..." -> service active, six models.
   Standalone: `trial-changed.py /no/such/manifest.json db` -> same "cannot determine state" message, exit 2.
   FORCE=1: "FORCE=1 set - bypassing change-detection guard, forcing full reset" -> full reset.

## Verbatim proof (original hourly-reset task)

- Timer: `systemctl list-timers` NEXT=22:00:00 UTC; `systemctl cat` shows `OnCalendar=hourly`
  + `Persistent=true`; enabled.
- Two distinct backups (double hand run): `2026-09-20T214840.db` and `2026-09-20T214857.db`.
- Six models + references: `/projects` -> six models; `/projects/cafe-stand/commits/dd905e70.../references/resolve`
  -> `{"resolves":true,...}` (4 refs resolves:true; all 7 seed hashes matched).
- Prune: 50 dummies added (54 total) -> exact prune code deleted the 6 oldest -> 48 left, all
  4 real backups intact -> dummies removed.
- Open from workstation: `https://trial.modelwrite.org/health` -> `{"authMode":"open","status":"ok"}`
  [http=200]; `/projects` (no token) -> six models [http=200].

## Concerns

1. **Concurrent actor overlapped** (the brief's "another task"): it rewrote both READMEs
   (hourly + open + 48 + reorder) and committed/pushed them (c82a52c, 9b65512). I verified
   its docs match my implementation and left them; my timer/script/seed/guard changes are
   sha-verified as current host state.
2. **Docs say "MW_AUTH_TOKEN blanked" but it is not** — env still has a non-empty token line
   (98 B); `MW_ALLOW_OPEN=yes` is what opens it. Other task in-flight; I did not touch
   modelwrite.env. Reset works now and after token removal (seed-from-manifest.py hardened).
3. Timer restart fired once immediately (Persistent catch-up) — benign, also validated the flow.
4. Revert paths left: deploy/reset-trial.sh.bak-prehourly, seed-from-manifest.py.bak-prehourly,
   reset-trial.sh.bak-preguard.
5. The 22:00 auto-reset ran the pre-guard script (my deploy landed seconds after 22:00); from
   22:03 onward every reset uses the guard.
