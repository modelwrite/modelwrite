# Docs and site update — report

## Status

DONE. README.md brought current, three live screenshots added to the site, the
Install section's crates.io claim corrected, and the two unreferenced workbench
PNGs removed. Committed and pushed to `slice-2-repository` and advanced `main`
(Pages deploys from main).

## Commits

- `8b5b4d3` — docs: bring README and site current; add live workbench screenshots
  (mine; 8 files, +158 / −52).
- `55f653c` — docs: STPA completeness is in progress, not deployed (README wording fix, mine; advanced main to include the STPA task's `0b369b5`, which I verified compiles with `cargo check --workspace` → exit 0).

While I worked, two other tasks landed in this shared tree (not mine):

- `7901598` — feat(website): examples page generated from the licence table (examples task)
- `c03c0bf` — docs: correct the corpus README's stale SysML v2 claim (examples task)
- `0b369b5` — STPA/STAMP completeness check (T1-T3): vocabulary pack, control-structure view, five engine checks and screen (STPA task; landed AFTER my first commit)

## URLs (verified live from this workstation)

- `https://trial.modelwrite.org/health` → 200 `{"authMode":"open","status":"ok"}`; `/projects` returns the six seeded models.
- `https://app.modelwrite.org/health` → 200 `{"authMode":"session","status":"ok"}`.
- `https://modelwrite.org` → TLS failure (SEC_E_WRONG_PRINCIPAL). Known apex issue; left untouched per instructions.
- Website deploys from `main` via GitHub Pages (advanced to my commits).

## Verified numbers (and how)

- **Test suite**: `cargo test --workspace --no-fail-fast` → **628 passed, 0 failed, 25 ignored**, exit 0
  (clean run, separate `CARGO_TARGET_DIR=target-tests` to avoid a stale `mw-server.exe` lock; summed 88 test-binary result lines, then re-ran to confirm exit 0).
- **Crates on crates.io**: **12 crates at 0.2.0** (checked each against `https://crates.io/api/v1/crates/<name>`):
  mw-okf, mw-graph, mw-gate, mw-binding, mw-binding-xmi, mw-agent, mw-capi, mw-mcp, mw-analytics,
  mw-test-support, mw-server, mw-cli. **mw-binding-sysmlv2 is 0.1.0 and NOT published (404)**.
- **Reader numbers** (fresh `--nocapture` runs):
  - coffee-machine (`real_magicdraw`): 41 structure elements, 25 requirements, 66/95 nodes/edges, 252 blocking.
  - TMT (`real_tmt`): 362 blocks, 7 requirements, 369/633 nodes/edges, 45,725 content losses, 48,553 blocking.
- **Screenshot DOM state at capture time** (curl of the live site):
  - health view: "1 issue found", Orphaned (0), **Isolated groups (1) = Cafe Stand, Provisioning Bay, Service Window**, Dangling (0), Uncovered (0).
  - compare main vs with-microduck: cross-model edge "CS-4 · Floor Kept Clear → satisfied by → **Cup Collector (floor-robot)** vs **Gripper Arm (microduck)**", marked changed.
  - diagram?view=process: "Take Payment" present, inline <svg>.

## Screenshots added (website/shots/, each chosen by the claim it proves)

1. `model-health.png` (1440×960, 66 KB) — **model-health view answers "what is broken in my model" on one screen**: it names the isolated group (Cafe Stand, Provisioning Bay, Service Window).
2. `variant-impact.png` (832×943, 93 KB) — **the two-robot trade study is proved**: CS-4 · Floor Kept Clear satisfied by Cup Collector (floor-robot) on main and Gripper Arm (microduck) on with-microduck.
3. `process-diagram.png` (1216×705, 48 KB) — **the engineering-grade process diagram**: orthogonally routed, shared trunks, separate Satisfy lane, crossing jumps.

**STPA completeness screen (4th requested): SKIPPED** — at capture time the STPA work was uncommitted and
the live trial (pinned to `47efbf1`) has no STPA screen. The STPA task committed `0b369b5` after my work;
it is still not deployed, and the README marks it "in progress, not deployed".

Also: `website/workbench-overview.png` and `website/workbench-requirements.png` were **unreferenced
(0 matches) and predate the draughting redesign** — **removed**.

## Deferrals

- **STPA on the site**: not described as shipped (it is not deployed). README has a clearly-marked "in progress, not deployed" line.
- **Examples page link**: already added by the examples task (nav + hero button + footer) in `7901598`
  before I touched index.html, so I did not duplicate it.
- **STPA task's files**: not touched or staged by me (I only committed README.md, website/index.html,
  website/shots/, e2e/shoot-site.js, and the two PNG deletions).

## Concerns

1. **Visual selection was by criteria, not by eye** (this model has no image input). I verified each
   screenshot is a non-blank PNG of the right size/dimensions and that the live DOM contained the claim at
   capture time; the owner should eyeball them and swap any that misrepresent the product.
2. **docs/guide/limits.md and docs/guide/README.md are stale**: both still say SysML v2 has no reader /
   "does not yet read SysML v2 textual notation", which contradicts the landed `mw-binding-sysmlv2`. Out of
   my scope (the guide is not mine to edit); flagged for the owner.
3. **Website licence wording** (FAQ, licence, architecture "Interchange: Apache-2.0"): says importers/exporters
   ARE Apache-2.0 (present tense). That is the CONTRIBUTING policy; the binding crates are currently
   AGPL-3.0-or-later workspace crates and only `spec/analytics/` is Apache-2.0 today. Left as-is per
   "keep the FAQ"; the README states the verified split (AGPL implementation, Apache-2.0 schema).
4. A stale local `mw-server.exe` (PID 205708, started 20/09) locks `target/debug/`; the test suite needed a
   separate `CARGO_TARGET_DIR` to run. Not touched.
