# entry_identity injectivity — SDD report

## Status
DONE

## Commits
- `d66261e` fix(binding-xmi): name idref-only unknown elements by their reference
  (branch `slice-2-repository`; files: `engine/binding-xmi/src/lib.rs`,
  `engine/binding-xmi/tests/xmi.rs`, `engine/binding-xmi/fixtures/idref-element.xmi`,
  `engine/agent/tests/losses.rs`, `server/tests/acceptance_from_artifact.rs`)

## One-line test summary
`cargo test --workspace --no-fail-fast` exits 0 — 574 passed, 0 failed, 25 ignored
(24 PostgreSQL + 1); `cargo fmt --all --check` and
`cargo clippy --workspace --all-targets -- -D warnings` both clean.

## The cause of each collision

There is ONE colliding `(subject, verdict)` pair, not four pairs: the arithmetic in the
finding (252 blocking, 248 unique = 4 surplus) is right, but the shape is **five entries
collapsing to one identity**, not four pairs of two.

All five are `<useCase xmi:idref='...'/>` owned-member reference elements of the Class
`Coffee Machine System`. MagicDraw serialises the class's five use cases twice: once as
`packagedElement xmi:type='uml:UseCase' xmi:id='...' name='...'`, and once as a bare
`<useCase xmi:idref='...'/>` reference child of the class. The reference form carries
**no `xmi:type` and no `xmi:id`** — only the `xmi:idref` of the use case it points at
(five distinct ids: Select Coffee, Make Coffee, Refill Water Tank, Refill Coffee Beans,
Remove Waste).

The unknown-element fallback in the XMI binding named an unknown element by
`{tag} {xmi:id}`, and when `xmi:id` was absent it used the literal placeholder
`<no xmi:id>`, dropping the `xmi:idref` that actually distinguishes them. So five
genuinely distinct losses (five references to five different use cases) all became
`useCase <no xmi:id> [unmappable]`.

The same under-specification produced two harmless singletons — `client <no xmi:id>` and
`supplier <no xmi:id>` — reference elements with no id/idref-agnostic naming; they also
now name their idref.

## The fix (at the SUBJECT level, not the key)

The collision is under-specification of the loss subject, not a defect in the key itself.
Per the brief, the right fix is to name a distinguishable subject, which also improves what
a human reads. In `engine/binding-xmi/src/lib.rs` the unknown-element fallback now names an
element by its `xmi:id`, then its `xmi:idref` (`idref=...`), then its `name`, then
`<no xmi:id>` as the last resort.

`entry_identity` is unchanged — it remains `subject [verdict]`, the ONE acceptance key.
No second key was added. The fix is entirely in how the loss report names subjects, so the
agent-proposal identity and the server acceptance key stay the same single string.

## Injectivity evidence (the real model)

- `engine/agent/tests/losses.rs::the_real_model_names_every_blocking_loss_with_a_unique_identity`
  imports `real-world/mdzip/model.xmi`, asserts 252 blocking entries, and that the 252
  `entry_identity` values are 252 unique values.
- `server/tests/acceptance_from_artifact.rs::the_coffee_machine_xmi_import_accepts_from_hash`
  now asserts `unique_count == blocking_count` (252 == 252) before accepting.
- `server/tests/acceptance_from_artifact.rs::accepting_one_use_case_reference_does_not_accept_its_twins`
  accepts exactly ONE useCase reference and asserts the other FOUR stay blocking (the
  acceptance refuses, nothing commits) — an acceptance of one no longer accepts its former
  twins.

The commit-path guarantee is intact: the acceptance of one useCase reference still refuses
the import with the other four (and the other 247) named as unaccepted, so the commit path
refuses unless every blocking entry is matched by its identity.

## Concerns

1. The finding's "4 pairs" is a miscount of the grouping: it is one identity shared by five
   entries (four surplus). Same defect, same fix, but worth correcting in any follow-on note.
2. The new subject form `useCase idref=<MagicDraw-id>` is injective and stable but still
   id-soup; resolving the idref to the use case's `name` ("Select Coffee") would read
   better. That is a readability improvement, not an injectivity requirement, and I left it
   out to keep the change minimal and single-pass.
3. The two `client`/`supplier` `<no xmi:id>` singletons also change subject (to
   `idref=...`). No test asserted the old strings; it is a strict improvement, but it is a
   behaviour change to those two report lines.
