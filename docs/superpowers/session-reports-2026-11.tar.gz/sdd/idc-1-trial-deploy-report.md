# idc-1 trial deploy — report

**Status:** BLOCKED

## The blocker
The container image `ghcr.io/modelwrite/modelwrite` is **private**. Neither the workstation's
`gh` token nor its git-credential-manager token has the `read:packages` scope, so the image
cannot be pulled, its digest cannot be pinned, and nothing can be deployed to idc-1.

## Verbatim evidence
- The publish workflow strips the `v` from the tag, so the correct tag is `0.2.0` (it also pushes `0.2`, `0`, `latest`).
- `docker pull ghcr.io/modelwrite/modelwrite:0.2.0` (anonymous) → `Error response from daemon: error from registry: unauthorized`
- `gh auth status` → `Token scopes: 'gist', 'read:org', 'repo', 'workflow'` (no `read:packages`)
- `gh api orgs/modelwrite/packages/container/modelwrite/versions` → `{"message":"You need at least read:packages scope to get a package's versions.","status":"403"}`
- `docker login ghcr.io -u alexkovaceski --password-stdin` (gh token) → `Login Succeeded`; then:
  - `docker pull ...:0.2.0` → `403 Forbidden`
  - `docker pull ...:latest` → `403 Forbidden`
- Same result (`Login Succeeded` + `403 Forbidden`) with the git-credential-manager token (`git:https://github.com`).

## Unblock (pick ONE)
1. **Make the package public** — GitHub → modelwrite org → Packages → modelwrite → Package settings → Change visibility → Public.
2. **Add the scope** — `gh auth refresh -h github.com -s read:packages` (interactive OAuth), then `docker login ghcr.io` again on idc-1.

## Contract fields
- **URL:** not deployed.
- **Token:** not created (no running service).
- **Image digest:** not pinned (blocked on pull).
- **Unit name:** not installed (planned: `modelwrite.service` + env file `/etc/modelwrite/modelwrite.env`).

## What still needs doing (after unblock)
1. Pin the digest (`docker inspect ghcr.io/modelwrite/modelwrite:0.2.0 --format '{{index .RepoDigests 0}}'`).
2. Pick the public hostname and create the Cloudflare DNS record + cloudflared ingress (below).
3. Deploy, seed, verify from outside, write both READMEs, commit the repo doc.

## Recon already done (unblock → deploy is mechanical)

### Exposure convention on idc-1
- **haproxy** (`/etc/haproxy/haproxy.cfg`) is model-fleet only (ports 8002–8201); not used for trials.
- **caddy** (`surveillance-caddy`, host :8080→:80, config `/tank/projects/_infra/Caddyfile`) does path-prefix routing for the AML/surveillance stack only.
- **The axoquant trials are reached by HOSTNAME via a cloudflared tunnel → loopback port.** Exact analogue for a "trial": `trial.podataka.com → http://localhost:3101` in `/etc/cloudflared/hatch-config.yml` (`cloudflared-hatch.service`). `insights` uses its own tunnel (`insights-tunnel.service`) routing `insights*.axoquant.com → 127.0.0.1:8101`.
- So modelwrite should bind loopback on a free non-80xx port (80xx = model fleet) and get a hostname routed via cloudflared. `sudo` works; `~/.cloudflared/cert.pem` exists, so `cloudflared tunnel route dns <tunnel> <hostname>` could create the CNAME — but that edits production Cloudflare DNS and needs a hostname decision.

### Auth semantics (server/src/auth.rs)
- `MW_AUTH_TOKEN` = shared bearer token, stored as SHA-256, compared constant-time.
- A correct static token → `Identity { subject: "admin", roles: ["admin"], projects: ["*"] }` → full read/write/admin.
- In static mode **every request** (JSON API and `/ui` pages) requires `Authorization: Bearer <token>`, else 401. `/health` and `/version` are public.
- There is **no browser login form**: the UI renders a 401 page — "Present your credentials with the request (for example an `Authorization: Bearer` header) and reload." A human visitor must set the header (curl/CLI works; a browser needs a header-setting extension). Decide this before calling the trial public.

### Seeding plan (exact)
HTTP API over the running server (same path as `e2e/seed.js` and `server/tests/impact.rs`):
1. `POST /projects {name}` × 6: coffee-machine, sandwich-toaster, purchasing-terminal, floor-robot, microduck, cafe-stand.
2. `POST /projects/:p/commits {branch:"main", author, message, okf}` per subsystem:
   - coffee-machine ← `sample/corpus/coffee-machine/okf/expected/coffee_machine_model.json`
   - sandwich-toaster, purchasing-terminal, floor-robot, microduck ← `e2e/models/*.json`
3. cafe-stand main: commit `e2e/models/cafe-stand.json`, adding to the floor-robot reference `crossModelEdges: [{ "from": "req-floor-clear", "relation": "satisfiedBy", "to": "collector" }]`.
4. `POST /projects/cafe-stand/branches {name:"with-microduck", from: <main hash>}`.
5. cafe-stand with-microduck: same document, floor-care reference re-pinned to microduck (`project:"microduck"`, revision = microduck's commit hash, `bounds:["gripper-arm","gripper-camera","microduck"]`) and `crossModelEdges: [{ "from": "req-floor-clear", "relation": "satisfiedBy", "to": "gripper-arm" }]`.

cafe-stand.json's four references carry pinned content hashes (sha256 over the stored OKF bytes):
purchasing-terminal@86a14a81…, coffee-machine@d427e847…, sandwich-toaster@6cc2b58d…, floor-robot@9dcccb6d… (microduck@dddf2978… per S2).
Committing the repo's exact JSON must reproduce those; verify reference resolution before calling it seeded.

### Verification plan (from workstation over Tailscale, idc-1 = 100.86.3.50)
UI loads, six models listed, cafe-stand composition shows FOUR resolving references, compare main vs with-microduck shows Cup Collector (floor-robot) vs Gripper Arm (microduck), and an unauthenticated write (no token) is 401.

## Concerns
1. **Image is private** — the only hard blocker (needs the visibility change or a `read:packages` token).
2. **No browser login form** — the token must be sent as a header; a bare "visitor" URL is not enough for a non-technical viewer.
3. **Public hostname needs a Cloudflare DNS change + tunnel ingress** (I have sudo + cert.pem, but this touches production DNS and needs a hostname decision).
