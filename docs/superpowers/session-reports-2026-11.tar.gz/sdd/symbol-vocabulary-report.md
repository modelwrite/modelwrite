# Symbol vocabulary report

## Status

DONE_WITH_CONCERNS

## Commits

- `Add diagram symbol vocabulary: kind glyphs and MIL-STD-2525D/APP-6D frames`

## One-line test summary

`cargo test --workspace --no-fail-fast` (exit 0, 0 failures), `cargo clippy --workspace --all-targets -- -D warnings` (exit 0), `cargo fmt --all` (clean), and 27/27 Playwright tests pass (24 existing + 3 new), all run against `CARGO_TARGET_DIR=target-tests`.

## What was built

1. **A symbol boundary** - `engine/graph/src/symbol.rs` exposes `symbol(kind, stereotypes) -> Symbol`, returning `Kind(Glyph)`, `MilStd2525{affiliation, dimension}`, or `Unmappable{declared}`. An explicit `KIND_GLYPHS` table maps (kind) to a hand-drawn glyph; an unknown kind returns a neutral default, never nothing.
2. **A glyph per kind** (hand-drawn, monochrome `currentColor`, 24px viewBox): block (cube), requirement (document), activity (play triangle), signal (lightning bolt), interface (ball-and-socket), actor (head+shoulders), state (circle), stateMachine (two states + transition), usecase (ellipse), plus the neutral square default.
3. **MIL-STD-2525 / APP-6 frames** - affiliation (friend/hostile/neutral/unknown) crossed with dimension (land / sea surface / subsurface / air / space), filled with the standard colour and hand-drawn per the standard's monochrome shape convention (rectangle/diamond/square/clover for ground, arch/peaked/rectangle for air, orbit oval for space), plus generic platform glyphs (wheeled vehicle, ship hull, submarine, aircraft planform, satellite). The SIDC is declared via a `sidc:` / `symbol:` stereotype, never guessed.
4. **Unmappable report** - a node that declares a symbol this build cannot draw is flagged (`data-mw-unmappable`) and listed in a visible `.symbol-report` block, never silently boxed.
5. **NOTICE** entry documenting hand-drawn geometry and citing milsymbol v3.0.4 (MIT) as the reference.

## Glyph inventory

block, requirement, activity, signal, interface, actor, state, stateMachine, usecase - each hand-drawn; plus a neutral default square for unknown kinds.

## 2525 version

MIL-STD-2525D / APP-6D (numeric 20-character SIDC).

## Unknown-symbol behaviour

An unknown kind draws the neutral default glyph with its text label intact. A declared-but-unknown SIDC (e.g. `sidc:10399000012000000000`) is reported - the node carries `data-mw-unmappable` and the page renders a "Unmapped symbols" list naming the node and its declaration - and the node still renders with its kind glyph and label, never a silent generic box.

## Concerns

1. **No visual read performed.** The `deepseek-v4-pro` model does not declare image input, so `read_image` failed. Per the task's fallback, I verified with geometry assertions instead: on both the cafe-stand process diagram (10 nodes) and the coffee-machine structure diagram (99 nodes), every node emits a glyph with non-empty path data and 0 glyphs fall outside their node box. Legibility/noise could not be eyeballed.
2. **One 3px text overflow** on the 99-node structure diagram (a long signal id). The name is left-aligned after the glyph, and `truncate_label`'s fixed 7.4px/char estimate undershoots wide glyphs by ~3px on that one node. Cosmetic only.
3. The "unknown kind degrades to neutral" path is not reachable through the API (the OKF validator rejects unknown kinds), so it is covered by the Rust unit test and the server test (which seed via the store directly) rather than by Playwright.
