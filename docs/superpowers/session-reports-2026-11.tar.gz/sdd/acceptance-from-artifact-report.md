# Acceptance from the retained artifact — SDD report

## Status
DONE

## Commits
- `06267a5` feat(import): resume a refused migration from its retained artifact by hash
  (branch `slice-2-repository`; files: `server/src/binding_api.rs`,
  `server/src/lib.rs`, `server/src/ui/import.rs`, `server/tests/acceptance_from_artifact.rs`)

## One-line test summary
`cargo test --workspace --no-fail-fast` exits 0 (all pass); the new
`acceptance_from_artifact` suite is 6/6; `cargo clippy --workspace --all-targets -- -D warnings`
and `cargo fmt --all` are clean.

## The verbatim acceptance round-trip (hash in, commit out)
Model used: the **coffee-machine XMI** (`real-world/mdzip/model.xmi`, the MagicDraw export,
193 KB — the smaller of the two real models offered; TMT was not needed).

1. Import refused as Blocking; the JSON refusal names the retained hash:
   `artifactHash = ebd70f759768edb39eb6b914e201a44ff6a64e05435a0fb1e882679f5684c2dc`
2. Acceptance request carries **only** the hash (in the path) and the accepted loss names —
   no artifact, no binding, nothing else:
   `POST /projects/coffee/import/ebd70f.../accept` with `acceptLosses: [248 entry identities]`
3. Migration completes from the retained bytes:
   `commit = 9c477ff2ae3635da58a91c95929f852d73b8d877f5b804356076d87725daeb04`
4. The commit's provenance names the hash and the accepted losses
   (`kind: "imported"`, `artifactHash: ebd70f75...`, `acceptedLosses: [...248]`).
5. Byte identity: `store.blob(ebd70f75...)` equals the source bytes, and
   `GET /projects/coffee/import/ebd70f75.../artifact` returns them unchanged.

## Concerns
1. **Entry-identity collisions on the real model (248 vs 252).** The coffee-machine loss
   report has 252 blocking entries but only 248 unique entry identities — 4 pairs share the
   same `subject [verdict]` pair, so `entry_identity` (documented as "names exactly one
   entry") is not actually injective on this model. The acceptance correctly covers all 252
   entries via the 248 identities (nothing is silently dropped, and the commit refuses unless
   every blocking entry is matched), but it is worth a separate look at the XMI binding's loss
   subjects for the real model, since the same collision would collapse decisions in the
   agent loss resolver.
2. **Missing-artifact status code differs from the proposal path.** This direct acceptance
   returns 500 (named) for a record whose blob is gone, while `accept_proposal_core` returns
   404. Both name the hash; I left the proposal path untouched (it is out of this task's
   scope) rather than churn it.

## What still requires a re-upload
Nothing. A NEW import (a different or fresh artifact) still uploads/pastes through the normal
import forms. Finishing a refused import never requires re-upload: the paste form, the file
upload form, and the JSON API all accept from the retained hash.
