# Website reality update — report

**Status: DONE_WITH_CONCERNS**

## Commits (pushed to origin/slice-2-repository)

- `bbe763c` docs: publish the first real MagicDraw import measurement
- `b1e0a88` docs: anchor install wording on publish = false in the manifests

Push confirmed: `3e18b78..b1e0a88  slice-2-repository -> slice-2-repository`.
Only `website/index.html` and `README.md` were modified (verified by
`git diff --cached --stat` before each commit).

## Numbers verified

### Import result (the measurement)
Command (Rust PATH prepended):
`cargo test -p mw-binding-xmi --test real_magicdraw -- --nocapture`

- structure elements = **34**
- requirements = **0**
- interfaces = 0
- signals = 0
- activities = 0
- graph nodes/edges = **34 / 0**
- declarations = 1
- CONTENT LOSSES = **348**
- blocking = 407
- lossless = false
- SUMMARY line: "348 content losses (348 unmappable), 1 declarations"

### Source model counts
Command: PowerShell regex counts over `real-world/mdzip/model.xmi`.

- **148** = `<packagedElement` opening-tag count
- **57** = `<ownedAttribute` opening-tag count
- **34** = `<sysml:Block ..._application base_Class=` count (Block stereotype applications)
- **25** = `<sysml:Requirement ` count (Requirement stereotype applications)
- **20** = `<sysml:Satisfy ..._application base_Abstraction=` count (Satisfy links)
- **3** = `<sysml:Allocate ..._application base_Abstraction=` count (Allocate links)
- **193,076** = file length in bytes (`Get-Item real-world/mdzip/model.xmi`), i.e. "193 KB"

Cross-check that ties the counts together: the 28 uml:Abstraction packagedElements =
20 Satisfy + 3 Allocate + 4 Refine + 1 Verify; the 66 total uml:Class =
34 Block + 25 Requirement + 6 InterfaceBlock + 1 ConstraintBlock. The import's 34
structure elements are exactly the 34 Block classes (the binding maps only
Block-stereotyped classes to structure).

### Packaging
- `server/Cargo.toml` and `cli/Cargo.toml` both declare `publish = false`
  (read from the manifests; service crate = `mw-server`, CLI crate = `mw-cli`
  → `mw` binary).

## Limitation wording (as published, "What it does not do")

1. "The first real vendor model has been tested — and the result is measured, not
   reassuring. The MagicDraw SysML model in
   sample/corpus/coffee-machine/legacy/CoffeeMachine-SysML-Model.mdzip (a 193 KB XMI
   in its com.nomagic.magicdraw.uml_model.model entry) contains 148 packagedElement
   and 57 ownedAttribute elements: 34 Blocks, 25 Requirements, 20 Satisfy links and
   3 Allocate links. Importing it produces 34 structure elements (the Blocks), zero
   requirements, zero graph edges, and 348 content losses — every one Unmappable and
   named. Requirements, Satisfy and Allocate links, Ports, Operations and
   Associations are all reported as unmappable: named, never dropped in silence, but
   not carried. Reproduce it with
   cargo test -p mw-binding-xmi --test real_magicdraw -- --nocapture."

2. "Real vendor migration is not ready. The reader carries a subset: the first real
   model tested lost every requirement (25) and every traceability link (20 Satisfy
   and 3 Allocate), and produced no graph edges. Migrating a MagicDraw or CATIA
   Magic model without those losses is not yet supported."

## "Install and run" (added)

- website `#run` retitled "Install and run": crates build from source
  (`cargo build --workspace`, `cargo run -p mw-server`), image builds from
  `deploy/Dockerfile` (`docker build -f deploy/Dockerfile -t modelwrite/modelwrite:0.1.0 .`),
  compose trial, open-mode warning retained. States the crates are not on crates.io
  (`publish = false`), so no `cargo install`.
- README gained an "## Install and run" section with the same honest framing.

## Concerns

1. **Deploy trigger (main concern):** the site redeploys only on push to `main`
   (`.github/workflows/pages.yml` triggers on `main`). I committed and pushed to
   `slice-2-repository` (the checked-out branch; the task brief said "branch main"
   but the checkout is `slice-2-repository`). The live site will NOT update until
   these commits reach `main` via the repo's normal PR merge flow.
2. **The brief's source counts were substring counts, not element counts.** The
   brief said "55 Blocks, 45 Requirements, 27 Satisfy links, 9 Allocate links";
   the actual stereotype-application counts are 34 / 25 / 20 / 3 (verified above).
   I published the verified counts. The repo's own test doc comment
   (`engine/binding-xmi/tests/real_magicdraw.rs`) still says "55 Blocks and 45
   Requirements" — I could not correct it (engine/ is out of scope).
3. **Concurrent commit landed mid-task:** `3e18b78` "ci: ship modelwrite as an npm
   package and a ghcr image" (authored by the repo owner) appeared on the branch
   while I worked and is already on origin. It adds npm + ghcr packaging
   scaffolding. My "Install and run" wording is anchored on the verifiable
   `publish = false` (crates.io) and does not promise a published package, but a
   follow-up pass may be warranted once the npm package / ghcr image actually publish.
