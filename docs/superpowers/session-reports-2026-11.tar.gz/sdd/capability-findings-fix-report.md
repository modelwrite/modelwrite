# Capability Findings Fix Report

Status: DONE_WITH_CONCERNS

## Commits
- `77f7967` fix(assist, commit): gate the propose loop and derive the OKF summary

## One-line test summary
Full workspace green: `cargo test --workspace --no-fail-fast` exits 0 (0 failed blocks), `cargo fmt --all -- --check` clean, `cargo clippy --workspace --all-targets -- -D warnings` clean.

## The review-artifact change (F1)
The assist propose loop now runs the SAME validator and gate the platform gate runs, over the
candidate document, and carries the result in a new `ReviewArtifact.check` field
(`agent::ProposalCheck`). Before accepting, a human now sees, in the review artifact and on the
assist review page:

- `passed`: whether the candidate would fail the gate's integration checks (no isolated nodes,
  one connected component, no validation errors) - round-trip is deliberately excluded because a
  proposal is supposed to differ from the current model;
- `validationErrors`: a candidate that cannot commit at all;
- `isolatedNodes`: the candidate's graph nodes with no edges, each invisible to coverage and
  traceability;
- `componentCount`: the candidate's connected-component count;
- `uncoveredRequirements` and `priorUncoveredRequirements`: the candidate's uncovered
  requirements and the current model's, so a coverage regression reads as a delta.

A new element is still attached to the graph as a node (visible and countable), and a change with
no relationship to express is therefore REPORTED as isolated, never buried.

## The summary decision (F3)
REGENERATE (the honest fix). `okf::summary::derive/recompute` is now the one place the derived
counts are decided, and the shared commit core (`server/src/api.rs::commit_core`) recomputes the
summary from the document's sections before validating and storing - so a client-supplied count
that disagrees with the document can no longer be persisted. The assist candidate and the merge
path use the same `okf::summary::recompute`. The demo seed models' summaries were regenerated so
the deployed data is self-consistent.

## The orphan decision (F1, live data)
REMOVE. The cafe-stand Menu block (`menu-block`) was created by the capability test's own
assist->accept exercise in the running trial's scratch SQLite database (`trial.db`, gitignored).
It is NOT in the tracked deployed seed model (`e2e/models/cafe-stand.json`), whose graph (13
nodes, 15 edges) has no isolated node. There is therefore no orphan to remove from tracked/deployed
data. I chose REMOVE rather than ATTACH because the Menu block was an arbitrary test element, not
part of the cafe-stand design, and it exists only in scratch state. The code fix now reports an
isolated node to the human before acceptance, so a future accept cannot silently reintroduce one.

## Concerns
1. The running trial server's scratch `trial.db` still holds the Menu orphan until it is
   re-seeded from the corrected seed; I did not modify the live database because it is gitignored
   scratch state and the trial server must not be stopped.
2. The offline CLI (`cli/src/offline.rs`) writes through `store.commit_model` directly rather
   than through `commit_core`, so it does not inherit the summary regeneration; it was outside
   the assigned scope (the shared commit core in `server/src/api.rs`).
3. The cafe-stand seed graphs as 2 connected components (blocks vs activities/requirements) with no
   isolated node; this is a pre-existing modeling choice, not the orphan defect, and is now
   surfaced by the propose gate rather than hidden.
