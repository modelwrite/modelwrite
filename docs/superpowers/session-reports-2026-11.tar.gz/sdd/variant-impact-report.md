# Variant impact report

## Status

DONE_WITH_CONCERNS

## Commits

- `38e7c4d` (full `38e7c4d1db361b08f55ee7b996bb702413ac99fd`) — "Add variant impact panel to the compare view"
  - `server/src/ui/review.rs` — the impact panel (references side by side, requirement states, summary, boundary)
  - `server/src/ui/layout.rs` — the impact panel styles
  - `e2e/tests/impact-panel.spec.js` — 3 new Playwright tests

## One-line test summary

Rust `cargo test --workspace --no-fail-fast` = 546 passed / 0 failed; `cargo clippy --workspace --all-targets -- -D warnings` clean; `cargo fmt --all -- --check` clean; Playwright = 30 passed / 0 failed (27 existing + 3 new).

## What the panel shows for main vs with-microduck

The compare page (`/ui/projects/cafe-stand/compare?from=main&to=with-microduck`) now renders a **Variant impact** section above Diff/Gate:

- **References** (role keyed, side by side): four roles — payment → purchasing-terminal, beverage → coffee-machine, food → sandwich-toaster, and **floor-care** which is marked **changed** (floor-robot on main, microduck on with-microduck, each with its pinned short revision and full hash on hover).
- **Requirements**: all four platform requirements (CS-1 Service Time, CS-2 One Payment, CS-3 No Provision Before Payment, CS-4 Floor Kept Clear) render with state **both** — computed by the engine's `graph::requirement_coverage` over each version's own graph. The two versions' platform graphs are identical, so no requirement is "only A" / "only B" / "neither" in this pair.
- **Summary**: "Requirements CS-1, CS-2, CS-3 and CS-4 are satisfied in both versions."

So the real trade study's impact is carried by the *reference* change (which subsystem is responsible for CS-4's floor-care), not by a difference in which platform requirements are covered — and the panel says exactly that rather than inventing a coverage difference.

## Boundary wording

Rendered in the panel under "What this panel proves — and what it does not":

- **Computed** (measured): "the platform model's own requirement coverage on each side, from the engine's `requirement_coverage` over that version's graph"; and "the subsystem reference differences, shown role → project@revision and marked where they change".
- **Not computed — asserted, not proved**: "coverage proved inside a referenced subsystem: a platform requirement satisfied by an activity allocated to a role is not proved to be satisfied by the bound element inside that subsystem"; and "where a difference in a requirement's state is explained by a changed reference, it is explained by the change but not proved by it".
- Fidelity note: "An activity's link to a specific element inside a subsystem is carried by its `allocatedTo` attribute (a role name), not a first-class cross-model edge, so coverage inside the referenced subsystems is not computed here."

## Concerns

1. **Visual verification was by DOM inspection, not image reading.** The `deepseek-v4-pro` model does not declare image input, so `read_image` on the captured screenshot was refused. Per the task's fallback I verified by dumping the full server-rendered `#impact` section (the page is server-rendered, so the HTML is the DOM) and confirmed the references table, the changed-role marker, the four per-requirement states, the summary line and the boundary text — no visual claim was made beyond that.
2. **The deployment's cafe-stand activities are stripped of `allocatedTo`.** In the trial DB the six base activities (including `act-clear-floor`) carry no `allocatedTo` attribute (only the with-microduck branch's added `act-pick-floor` does), so that field is effectively absent in the live data. The panel does not depend on `allocatedTo` — it uses only the typed references plus the engine's coverage — but the boundary wording describes the `allocatedTo` mechanism, which the live fixture mostly does not actually populate.
