﻿### Task 5: engine/graph â€” graph analysis and coverage

**Files:**
- Create: engine/graph/Cargo.toml
- Create: engine/graph/src/lib.rs
- Test: engine/graph/tests/graph_stats.rs
- Modify: Cargo.toml (add engine/graph to workspace members)

**Interfaces:**
- Consumes: okf::types::OkfRoot; test_support::load_okf_expected().
- Produces:
  - graph::graph_stats(root: &OkfRoot) -> GraphStats with fields node_count: usize, edge_count: usize, isolated: Vec<String>, component_count: usize, component_sizes: Vec<usize> (descending).
  - graph::requirement_coverage(root: &OkfRoot) -> CoverageReport with fields total, satisfied, refined, verified, allocated, covered (usize) and uncovered: Vec<String> (sorted).

- [ ] **Step 1: Write engine/graph/Cargo.toml**

```toml
[package]
name = "mw-graph"
version = "0.1.0"
edition.workspace = true
rust-version.workspace = true
license.workspace = true
publish = false

[lib]
name = "graph"

[dependencies]
mw-okf = { path = "../okf" }
petgraph.workspace = true
serde.workspace = true

[dev-dependencies]
mw-test-support = { path = "../test-support" }
serde_json.workspace = true
```

- [ ] **Step 2: Add engine/graph to the workspace members in the root Cargo.toml**

Change the members line to:

```toml
members = ["engine/okf", "engine/test-support", "engine/graph"]
```

- [ ] **Step 3: Write engine/graph/src/lib.rs**

```rust
// SPDX-License-Identifier: AGPL-3.0-or-later
use std::collections::{HashMap, HashSet};

use okf::types::OkfRoot;
use petgraph::unionfind::UnionFind;
use serde::Serialize;

#[derive(Debug, Clone, Serialize)]
pub struct GraphStats {
    pub node_count: usize,
    pub edge_count: usize,
    pub isolated: Vec<String>,
    pub component_count: usize,
    pub component_sizes: Vec<usize>,
}

pub fn graph_stats(root: &OkfRoot) -> GraphStats {
    let graph = root.graph.as_ref().expect("graph required; validate first");
    let node_count = graph.nodes.len();
    let edge_count = graph.edges.len();
    let index: HashMap<&str, usize> = graph
        .nodes
        .iter()
        .enumerate()
        .map(|(i, n)| (n.id.as_str(), i))
        .collect();
    let mut uf = UnionFind::new(node_count);
    let mut degree = vec![0usize; node_count];
    for e in &graph.edges {
        if let (Some(&a), Some(&b)) = (index.get(e.source.as_str()), index.get(e.target.as_str())) {
            degree[a] += 1;
            degree[b] += 1;
            uf.union(a, b);
        }
    }
    let isolated: Vec<String> = graph
        .nodes
        .iter()
        .enumerate()
        .filter(|(i, _)| degree[*i] == 0)
        .map(|(_, n)| n.id.clone())
        .collect();
    let mut sizes: HashMap<usize, usize> = HashMap::new();
    for i in 0..node_count {
        *sizes.entry(uf.find(i)).or_insert(0) += 1;
    }
    let mut component_sizes: Vec<usize> = sizes.into_values().collect();
    component_sizes.sort_unstable_by(|a, b| b.cmp(a));
    let component_count = component_sizes.len();
    GraphStats {
        node_count,
        edge_count,
        isolated,
        component_count,
        component_sizes,
    }
}

#[derive(Debug, Clone, Serialize)]
pub struct CoverageReport {
    pub total: usize,
    pub satisfied: usize,
    pub refined: usize,
    pub verified: usize,
    pub allocated: usize,
    pub covered: usize,
    pub uncovered: Vec<String>,
}

/// Requirement coverage read from dependency edges whose label is exactly
/// Satisfy, Refine, Verify or Allocate.
pub fn requirement_coverage(root: &OkfRoot) -> CoverageReport {
    let req_ids: HashSet<&str> = root.requirements.iter().map(|r| r.id.as_str()).collect();
    let graph = root.graph.as_ref().expect("graph required; validate first");
    let mut satisfied = 0usize;
    let mut refined = 0usize;
    let mut verified = 0usize;
    let mut allocated = 0usize;
    let mut covered: HashSet<&str> = HashSet::new();
    for e in &graph.edges {
        if e.kind != "dependency" {
            continue;
        }
        let s = e.source.as_str();
        let t = e.target.as_str();
        match e.label.as_str() {
            "Satisfy" => {
                if req_ids.contains(t) {
                    satisfied += 1;
                    covered.insert(t);
                }
            }
            "Refine" => {
                if req_ids.contains(t) {
                    refined += 1;
                    covered.insert(t);
                }
            }
            "Verify" => {
                if req_ids.contains(t) {
                    verified += 1;
                    covered.insert(t);
                }
            }
            "Allocate" if req_ids.contains(t) || req_ids.contains(s) => {
                allocated += 1;
                // Count only endpoints that really are requirements: an allocate edge can
                // connect a function to a part, and inserting a non-requirement id would
                // inflate the covered count reported in the gate evidence.
                if req_ids.contains(t) {
                    covered.insert(t);
                }
                if req_ids.contains(s) {
                    covered.insert(s);
                }
            }
            _ => {}
        }
    }
    let mut uncovered: Vec<String> = root
        .requirements
        .iter()
        .filter(|r| !covered.contains(r.id.as_str()))
        .map(|r| r.id.clone())
        .collect();
    uncovered.sort();
    CoverageReport {
        total: req_ids.len(),
        satisfied,
        refined,
        verified,
        allocated,
        covered: covered.len(),
        uncovered,
    }
}
```

- [ ] **Step 4: Write engine/graph/tests/graph_stats.rs**

```rust
// SPDX-License-Identifier: AGPL-3.0-or-later
use graph::{graph_stats, requirement_coverage};
use okf::types::OkfRoot;

fn expected() -> OkfRoot {
    serde_json::from_str(&test_support::load_okf_expected()).expect("corpus fixture parses")
}

fn okf(text: &str) -> OkfRoot {
    serde_json::from_str(text).expect("test OKF parses")
}

const TINY: &str = r#"{
  "project": "tiny",
  "exportedAt": "2026-09-17T00:00:00Z",
  "summary": {},
  "stateMachine": {"name": "tiny sm", "regions": []},
  "requirements": [
    {"id": "r1", "name": "R1", "kind": "requirement", "stereotypes": ["Requirement"], "attributes": [], "documentation": "", "reqId": "1.1", "reqText": "covered"},
    {"id": "r2", "name": "R2", "kind": "requirement", "stereotypes": ["Requirement"], "attributes": [], "documentation": "", "reqId": "1.2", "reqText": "uncovered"}
  ],
  "graph": {
    "nodes": [
      {"id": "p1", "kind": "block", "name": "P1"},
      {"id": "r1", "kind": "requirement", "name": "R1"},
      {"id": "r2", "kind": "requirement", "name": "R2"}
    ],
    "edges": [
      {"source": "p1", "target": "r1", "kind": "dependency", "label": "Satisfy"}
    ]
  }
}"#;

#[test]
fn corpus_is_fully_integrated() {
    let stats = graph_stats(&expected());
    assert_eq!(stats.node_count, 99);
    assert_eq!(stats.edge_count, 165);
    assert!(stats.isolated.is_empty(), "isolated: {:?}", stats.isolated);
    assert_eq!(stats.component_count, 1);
    assert_eq!(stats.component_sizes, vec![99]);
}

#[test]
fn isolated_node_is_detected() {
    let stats = graph_stats(&okf(TINY));
    assert_eq!(stats.isolated, vec!["r2"]);
}

#[test]
fn two_components_are_counted() {
    let stats = graph_stats(&okf(TINY));
    assert_eq!(stats.component_count, 2);
    assert_eq!(stats.component_sizes, vec![2, 1]);
}

#[test]
fn coverage_counts_traceability() {
    let cov = requirement_coverage(&okf(TINY));
    assert_eq!(cov.total, 2);
    assert_eq!(cov.satisfied, 1);
    assert_eq!(cov.covered, 1);
    assert_eq!(cov.uncovered, vec!["r2"]);
}

/// The reference model carries 20 Satisfy, 3 Refine, 1 Verify and 3 Allocate edges,
/// and 15 of its 25 requirements are covered by at least one of them. Pinning the
/// coverage keeps this measured claim honest: it is the number the gate reports.
#[test]
fn corpus_coverage_is_pinned() {
    let cov = requirement_coverage(&expected());
    assert_eq!(cov.total, 25);
    assert_eq!(cov.satisfied, 20);
    assert_eq!(cov.refined, 3);
    assert_eq!(cov.verified, 1);
    assert_eq!(cov.allocated, 0);
    assert_eq!(cov.covered, 15);
    assert_eq!(cov.uncovered.len(), 10);
}
```

- [ ] **Step 5: Run the tests**

Run: cargo test -p mw-graph
Expected: all 4 tests pass. If corpus_is_fully_integrated fails, stop and report the actual isolated nodes and component sizes; do not change the assertions to match.

- [ ] **Step 6: Format, lint and commit**

```powershell
cargo fmt --all
cargo clippy -p mw-graph --all-targets -- -D warnings
git add Cargo.toml engine/graph
git commit -m "feat: add graph crate with integration and coverage analysis"
```

---


