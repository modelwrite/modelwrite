# Task 3 Report: Port the coffee-machine corpus into sample/

**Status:** DONE

**Commits:**
- `4bcb0f9` chore: port coffee-machine corpus into sample/ (5 files changed, 1014 insertions)

**One-line verification summary:** corpus pinned: 99 nodes, 165 edges, 25 requirements

**Verification command (Step 3, executed verbatim):**

```
python -c "import json,pathlib; d=json.loads(pathlib.Path('sample/corpus/coffee-machine/okf/expected/coffee_machine_model.json').read_text(encoding='utf-8')); assert d['summary']['graphNodes']==99 and d['summary']['graphEdges']==165, d['summary']; assert len(d['requirements'])==25 and d['summary']['blocks']==49 and d['summary']['signals']==9 and d['summary']['activities']==8; print('corpus pinned: 99 nodes, 165 edges, 25 requirements')"
```

**Command output:**

```
corpus pinned: 99 nodes, 165 edges, 25 requirements
```

**File sizes copied (all byte-identical to collateral sources):**

| Fixture | Size (bytes) | SHA256 |
| --- | --- | --- |
| sample/corpus/coffee-machine/okf/expected/coffee_machine_model.json | 64,282 | B8180568A4206065DD04B7E5311621EB41203DEE2B5FBF9BDFE63BCE76607E6A |
| sample/corpus/coffee-machine/legacy/CoffeeMachine-SysML-Model.mdzip | 216,922 | 8E0703D88C0343E5E39DB7611976FAE44A168AF534DE2C61B8B7E860DF055A40 |
| sample/demo/CoffeeMachine-Showcase-standalone.html | 141,712 | 40EFAAD872CA993CB5085FF1168B0F248CDDE5E29AADC65843B24946E322C083 |

**Self-review:**
- All three fixtures plus the two README files exist at their exact paths from the brief.
- `CoffeeMachine-SysML-Model.mdzip` and `CoffeeMachine-Showcase-standalone.html` are byte-identical to their collateral sources (size + SHA256 match).
- `coffee_machine_model.json` is byte-identical to the copy inside the app archive (verified by re-extraction, then cleaned up).
- The temporary extraction directory `.tmp-corpus` (and the transient `.tmp-verify` used for hash comparison) are removed.
- `git status --porcelain -- collateral` is empty: nothing under collateral/ changed.

**Concerns:**
- None blocking. Note for transparency: `git status` shows an unrelated working-tree modification to `docs/superpowers/plans/2026-09-17-modelwrite-p0-p1-engine-core.md` (a BOM removal on line 1 and a test-count edit). It is outside `sample/` and `collateral/` and was not produced by any step of this task (this task only read from `collateral/` and wrote under `sample/`).
