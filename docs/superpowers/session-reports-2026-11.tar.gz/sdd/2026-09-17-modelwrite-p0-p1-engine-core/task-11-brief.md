﻿### Task 11: Wrap-up â€” README, evidence index, full verification

**Files:**
- Modify: README.md (replace the stub with the full quickstart)

**Interfaces:**
- Consumes: everything built in Tasks 1 through 10.
- Produces: a repository that passes the complete verification sequence below; the final commit of Phase 0 + Phase 1.

- [ ] **Step 1: Replace README.md with the full quickstart**

```markdown
# Modelwrite

**The model you can prove.**

Modelwrite is an open-source MBSE platform that turns legacy SysML models
into portable, provable data â€” the Open Knowledge Format (OKF) â€” and
automates the skilled work of building and reviewing models with grounded
AI.

## What is in this repository

- engine/ â€” the Rust engine (AGPL-3.0-or-later): okf types, validation,
  hashing and diffing; graph analysis; the round-trip fidelity gate with
  evidence records; the C ABI; the MCP server
- judge/ â€” the gate-as-judge harness for scoring model migrations
- agents/ â€” rule packs for AI coding agents working against OKF
- sample/ â€” the coffee-machine corpus: the legacy CATIA Magic model, its
  OKF export, and the corrupted fixture the gate must reject
- docs/ â€” the OKF 1.0 spec, the design documents, and the evidence annex

## Quickstart

Requirements: Rust (stable, via rustup) and Python 3.12+ for the judge
harness.

cargo build --workspace
cargo test --workspace

Run the gate on the corpus:

cargo run -p mw-gate -- --reference sample/corpus/coffee-machine/okf/expected/coffee_machine_model.json --candidate sample/corpus/coffee-machine/okf/expected/coffee_machine_model.json

Expected output: GATE PASS.

## Licence

The engine is AGPL-3.0-or-later. Importers and exporters will ship under
Apache-2.0 as they land. See NOTICE.md for attribution.
```

- [ ] **Step 2: Run the complete verification sequence**

```powershell
cargo fmt --all -- --check
cargo clippy --workspace --all-targets -- -D warnings
cargo test --workspace
python -m unittest discover -s judge/tests -p "test_*.py" -v
cargo run -p mw-gate -- --reference sample/corpus/coffee-machine/okf/expected/coffee_machine_model.json --candidate sample/corpus/coffee-machine/okf/expected/coffee_machine_model.json
```

Expected: every command exits 0; the final line is GATE PASS. Record the command output in the task completion report.

- [ ] **Step 3: Final review of the working tree**

```powershell
git status --short
git log --oneline
```

Expected: a clean tree and one commit per task (11 commits). If anything is uncommitted, commit it with an appropriate conventional message before finishing.

- [ ] **Step 4: Commit the wrap-up**

```powershell
git add README.md
git commit -m "docs: add quickstart README"
```

Note for the executor: pushing to the GitHub remote happens once the remote URL is confirmed; CI (Task 9) first runs on that push.

---


