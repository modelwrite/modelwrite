# Task 7 Report: engine/capi — the C ABI

## Status

DONE

## Commits

- `f98ec36` feat: add C ABI for validation and the gate

## Test summary

mw-capi: 4 passed (tests/capi.rs: version_returns_string, validate_returns_json_report, gate_returns_evidence, validate_rejects_garbage), 0 failed; lib unittests 0; doc-tests 0.

## Files

- `engine/capi/Cargo.toml` — crate manifest (cdylib, staticlib, rlib).
- `engine/capi/src/lib.rs` — four exported symbols.
- `engine/capi/tests/capi.rs` — 4 integration tests.
- `engine/include/modelwrite.h` — C header.
- `Cargo.toml` — workspace members gains `engine/capi`.
- `Cargo.lock` — gains `mw-capi`.

## Exact commands and results

### Test

Command:

```
cargo test -p mw-capi --no-fail-fast
```

Result: 4 passed, 0 failed (exit 0). Per-binary: lib unittests 0, integration tests 4, doc-tests 0.

### Format

Command:

```
cargo fmt --all
```

Result: clean (exit 0).

### Lint

Command:

```
cargo clippy -p mw-capi --all-targets -- -D warnings
```

Result: clean (exit 0).

### Commit

Command:

```
git add Cargo.toml Cargo.lock engine/capi engine/include
git commit -m "feat: add C ABI for validation and the gate"
```

Result: `f98ec36`, 6 files changed, 197 insertions(+), 1 deletion(-). Working tree clean afterward.

## Deviations

Two deviations, both forced by the installed toolchain's clippy (Rust 1.98) with `-D warnings`, and both recorded per the task instruction to restructure rather than allow the lint. Behaviour is unchanged; the C ABI and header are unchanged.

1. **Unused import removed.** The brief's `lib.rs` imports `CStr` (`use std::ffi::{c_char, CStr, CString};`), but `CStr` is only used in the integration tests, never in `lib.rs`. `cargo test` and clippy both flag it as unused. I changed the import to `use std::ffi::{c_char, CString};`.

2. **Pointer-dereferencing FFI functions marked `unsafe`.** Clippy's `not_unsafe_ptr_arg_deref` lint (deny-by-default in this toolchain, introduced after the brief was written) rejects a public function that dereferences a raw pointer argument without being marked `unsafe`. It fired on `modelwrite_validate` (the `from_raw_parts(json, len)`) and `modelwrite_free_string` (the `CString::from_raw(ptr)`). I applied the lint's canonical fix — marking `modelwrite_validate`, `modelwrite_gate`, and `modelwrite_free_string` as `pub unsafe extern "C" fn` — and updated the integration tests to call those three inside `unsafe {}` blocks. `modelwrite_version` takes no pointer and stays a safe `fn`. The `unsafe` keyword is a Rust-only safety annotation erased at the ABI boundary: the four symbol names, parameter types/order, return types, and calling convention are byte-for-byte identical, so the C header is untouched and the stable contract holds. The brief's guards (`is_null()`/length checks before `from_raw_parts`, the `from_utf8` check, and the `!ptr.is_null()` check before `CString::from_raw`) are all preserved.

## Self-review

- SPDX headers present on `engine/capi/src/lib.rs`, `engine/capi/tests/capi.rs`, and `engine/include/modelwrite.h` (the manifest carries no SPDX header, matching every other engine crate manifest).
- No extra files: git status shows exactly the six staged paths (`Cargo.toml`, `Cargo.lock`, and the four new files under `engine/capi` and `engine/include`); no `target/` under `engine/capi`.
- No assertion weakened: all four test assertions are verbatim from the brief.
- Fixtures untouched: `sample/corpus/...` does not appear in git status.
- No unsafe block dereferences a null or non-UTF-8 pointer without the brief's guard: `modelwrite_validate` guards `is_null() || len == 0` before `from_raw_parts` and handles `from_utf8` via `Err(_) => err_string(...)`; `modelwrite_gate` guards both pointers/lengths and parses via `.ok()?` (no panic); `modelwrite_free_string` guards `!ptr.is_null()`.

## Concerns

None.
