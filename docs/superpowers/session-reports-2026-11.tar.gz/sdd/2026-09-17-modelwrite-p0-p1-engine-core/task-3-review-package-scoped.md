﻿# Task 3 review package (scoped: large verbatim copies excluded)

## Commits

4bcb0f9 chore: port coffee-machine corpus into sample/

## Copy facts (contents excluded)

- sample/corpus/coffee-machine/okf/expected/coffee_machine_model.json
  bytes: 64282, sha256: B8180568A4206065DD04B7E5311621EB41203DEE2B5FBF9BDFE63BCE76607E6A
- sample/corpus/coffee-machine/legacy/CoffeeMachine-SysML-Model.mdzip
  bytes: 216922, sha256: 8E0703D88C0343E5E39DB7611976FAE44A168AF534DE2C61B8B7E860DF055A40
  matches collateral source: True
- sample/demo/CoffeeMachine-Showcase-standalone.html
  bytes: 141712, sha256: 40EFAAD872CA993CB5085FF1168B0F248CDDE5E29AADC65843B24946E322C083
  matches collateral source: True

## Fixture summary (from the copied OKF)

- graphNodes 99
- graphEdges 165
- requirements 25
- blocks 49
- signals 9
- activities 8

## Full diff (-U10) of the written files

diff --git a/sample/README.md b/sample/README.md
new file mode 100644
index 0000000..c7deb74
--- /dev/null
+++ b/sample/README.md
@@ -0,0 +1,16 @@
+# Sample
+
+The coffee-machine corpus: a complete SysML model and its OKF export,
+shared as the regression fixture for the whole project.
+
+- corpus/coffee-machine/okf/expected/ — the exported model (OKF), the
+  reference snapshot the gate must accept unchanged.
+- corpus/coffee-machine/okf/corrupted/ — a deliberately broken copy the
+  gate must reject (created by scripts/make_corrupted.py in Task 6).
+- corpus/coffee-machine/legacy/ — the CATIA Magic project (.mdzip).
+- demo/ — the standalone portal showcase from the knowledge pack.
+- scripts/ — fixture generators; never hand-edit a fixture.
+
+The corpus originates from the MEMKO MBSEF-SEng coffee machine course work
+by Alex Kovaceski (September 2026) and is shared with the permission of
+the author. See NOTICE.md.
diff --git a/sample/corpus/coffee-machine/README.md b/sample/corpus/coffee-machine/README.md
new file mode 100644
index 0000000..ce0ab7a
--- /dev/null
+++ b/sample/corpus/coffee-machine/README.md
@@ -0,0 +1,20 @@
+# Coffee machine corpus
+
+Model: bean-to-cup coffee machine, SysML v1, built in CATIA Magic
+(Magic Systems of Systems Architect 2026x) during the MEMKO MBSEF-SEng
+course.
+
+Known-good numbers (pinned by tests and by the evidence annex):
+
+- graph nodes: 99
+- graph edges: 165
+- requirements: 25
+- blocks: 49
+- signals: 9
+- activities: 8
+- connected components: 1
+- isolated nodes: 0
+
+Workflow: edit the legacy model in CATIA Magic, re-run the exporter, and
+place the fresh export at okf/expected/coffee_machine_model.json. The gate
+CI job proves the refresh loses nothing.
