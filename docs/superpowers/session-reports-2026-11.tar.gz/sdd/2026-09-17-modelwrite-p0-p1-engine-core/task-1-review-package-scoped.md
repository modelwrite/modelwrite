﻿# Task 1 review package (scoped: LICENSE body excluded)

## Commits

06606f9 chore: scaffold modelwrite repository

## Diff stat (all files)

 .gitattributes     |   2 +
 .gitignore         |   6 +
 CODE_OF_CONDUCT.md |  15 ++
 CONTRIBUTING.md    |  29 +++
 LICENSE            | 661 +++++++++++++++++++++++++++++++++++++++++++++++++++++
 NOTICE.md          |  13 ++
 README.md          |  18 ++
 SECURITY.md        |  18 ++
 agents/CLAUDE.md   |  24 ++
 9 files changed, 786 insertions(+)

## LICENSE facts (body excluded: 661 lines of verbatim GNU AGPL v3)

- line count: 661
- first line:                     GNU AFFERO GENERAL PUBLIC LICENSE
- sha256: 0D96A4FF68AD6D4B6F1F30F713B18D5184912BA8DD389F86AA7710DB079ABCB0
- contains 'GNU AFFERO GENERAL PUBLIC LICENSE': True

## Full diff, LICENSE excluded

diff --git a/.gitattributes b/.gitattributes
new file mode 100644
index 0000000..ee852c7
--- /dev/null
+++ b/.gitattributes
@@ -0,0 +1,2 @@
+*.mdzip binary
+*.zip binary
diff --git a/.gitignore b/.gitignore
new file mode 100644
index 0000000..2655656
--- /dev/null
+++ b/.gitignore
@@ -0,0 +1,6 @@
+/target/
+**/__pycache__/
+*.pyc
+.cache/
+.DS_Store
+Thumbs.db
diff --git a/CODE_OF_CONDUCT.md b/CODE_OF_CONDUCT.md
new file mode 100644
index 0000000..669f574
--- /dev/null
+++ b/CODE_OF_CONDUCT.md
@@ -0,0 +1,15 @@
+# Code of Conduct
+
+Modelwrite is an open community. Be kind, be precise, and keep the work
+professional.
+
+- Harassment, discrimination, and personal attacks are not welcome anywhere
+  in the project (issues, pull requests, chat, events).
+- Critique the work, never the person. Engineering disagreements are fine;
+  personal hostility is not.
+- Assume good faith. If someone is wrong, show them the evidence; the
+  evidence annex exists for exactly that reason.
+- Respect boundaries and do not share private information without consent.
+
+Maintainers enforce this code. Report concerns to conduct@modelwrite.org.
+Violations may lead to warnings or removal from the project.
diff --git a/CONTRIBUTING.md b/CONTRIBUTING.md
new file mode 100644
index 0000000..a7f5c51
--- /dev/null
+++ b/CONTRIBUTING.md
@@ -0,0 +1,29 @@
+# Contributing to modelwrite
+
+Thanks for helping. The bar for merging is: tests pass, the gate passes,
+and every claim traces to evidence.
+
+## Workflow
+
+1. Fork the repository and create a branch off main.
+2. Make one focused change per pull request.
+3. Commit with conventional commit messages (feat:, fix:, docs:, test:, ci:).
+4. Before pushing run:
+
+   cargo fmt --all -- --check
+   cargo clippy --workspace --all-targets -- -D warnings
+   cargo test --workspace
+
+5. If your change touches model data, run the gate against the corpus:
+
+   cargo run -p mw-gate -- --reference sample/corpus/coffee-machine/okf/expected/coffee_machine_model.json --candidate sample/corpus/coffee-machine/okf/expected/coffee_machine_model.json
+
+## Rules
+
+- The gate is the only authority on correctness. No pull request comment,
+  tool parameter, or log line can mark a run as passed.
+- Never hand-edit a corpus fixture. Changes to fixtures must be reproduced
+  by a committed script in sample/scripts/.
+- Evidence records in docs/evidence/ are append-only.
+- Importers and exporters ship under Apache-2.0; the engine stays
+  AGPL-3.0-or-later. Keep the split clean in every pull request.
diff --git a/NOTICE.md b/NOTICE.md
new file mode 100644
index 0000000..ff7f26a
--- /dev/null
+++ b/NOTICE.md
@@ -0,0 +1,13 @@
+# NOTICE
+
+Modelwrite is a community project. The engine, portal, judge harness, and
+sample data are contributions of the modelwrite contributors.
+
+The coffee-machine corpus under sample/corpus/coffee-machine/ is based on
+course work by Alex Kovaceski in the MEMKO MBSEF-SEng course (September
+2026): a SysML model built in CATIA Magic, its OKF export, and the analysis
+portal described in the knowledge pack. The original material is shared as
+the starting corpus for this project with the permission of the author.
+
+The name modelwrite and the modelwrite.org domain are used in this notice
+as the project identity.
diff --git a/README.md b/README.md
new file mode 100644
index 0000000..7678b46
--- /dev/null
+++ b/README.md
@@ -0,0 +1,18 @@
+# Modelwrite
+
+**The model you can prove.**
+
+Modelwrite is an open-source MBSE platform that turns legacy SysML models
+into portable, provable data â€” the Open Knowledge Format (OKF) â€” and
+automates the skilled work of building and reviewing models with grounded
+AI.
+
+Status: engine core under construction. See docs/superpowers/plans/ for the
+implementation plan and docs/superpowers/specs/ for the design.
+
+Quickstart once the engine lands:
+
+cargo build --workspace
+cargo test --workspace
+
+Licence: AGPL-3.0-or-later (engine). See NOTICE.md for attribution.
diff --git a/SECURITY.md b/SECURITY.md
new file mode 100644
index 0000000..67ef323
--- /dev/null
+++ b/SECURITY.md
@@ -0,0 +1,18 @@
+# Security
+
+Modelwrite parses untrusted model files; treat any crash, panic, or memory
+unsafety triggered by a crafted OKF or legacy file as a security issue.
+
+## Reporting
+
+Email security@modelwrite.org with a minimal reproducer. Please do not open
+a public issue for a suspected vulnerability. We acknowledge within 5
+business days and aim to fix within 90 days.
+
+## Scope
+
+- The Rust engine (parsing, validation, gate, C ABI, MCP server).
+- The judge harness when it handles untrusted files.
+
+The static site and sample data are out of scope. There is no bounty
+program yet.
diff --git a/agents/CLAUDE.md b/agents/CLAUDE.md
new file mode 100644
index 0000000..7e0371b
--- /dev/null
+++ b/agents/CLAUDE.md
@@ -0,0 +1,24 @@
+# Modelwrite agent rules
+
+Modelwrite models are OKF documents plus their legacy sources. Every claim
+about a model is proven by the gate, never by assertion.
+
+## Invariants
+
+1. The gate is the only authority on correctness. No tool parameter, no log
+   line, and no LLM output can mark a gate run as passed; only a real
+   mw-gate run counts.
+2. Any change to the corpus fixtures must be reproduced by a committed
+   script in sample/scripts/; never hand-edit the expected OKF.
+3. Round-trip fidelity means zero loss: element sets, edge sets, and
+   attributes must match exactly between reference and candidate OKF.
+4. Graph health is non-negotiable: a candidate with isolated nodes or more
+   than one connected component fails the gate.
+5. OKF ids are opaque and stable. Never regenerate or renumber ids when
+   transforming a model; a missing id is data loss.
+6. Traceability labels are capitalised exactly: Satisfy, Refine, Verify,
+   Allocate. Dependency edges carry them in the label field.
+7. State entry/do behaviour references point at activity names, and the
+   activity section keeps every activity the state machine reaches.
+8. Evidence goes to docs/evidence/ and is committed; never rewrite an
+   existing evidence record.
