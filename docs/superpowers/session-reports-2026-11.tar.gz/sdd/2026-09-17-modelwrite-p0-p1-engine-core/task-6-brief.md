﻿### Task 6: engine/gate â€” the round-trip fidelity gate

**Files:**
- Create: engine/gate/Cargo.toml
- Create: engine/gate/src/lib.rs
- Create: engine/gate/src/main.rs (binary mw-gate)
- Create: sample/scripts/make_corrupted.py
- Create: sample/corpus/coffee-machine/okf/corrupted/coffee_machine_model.json (generated)
- Create: docs/evidence/README.md
- Create: docs/evidence/2026-09-17-roundtrip-self-pass.json (generated)
- Create: docs/evidence/2026-09-17-roundtrip-corrupted-fail.json (generated)
- Test: engine/gate/tests/gate.rs
- Modify: Cargo.toml (add engine/gate to workspace members)

**Interfaces:**
- Consumes: okf::{validate, diff, hash}; graph::{graph_stats, requirement_coverage}; test_support.
- Produces:
  - gate::run(reference: &OkfRoot, candidate: &OkfRoot, strict_coverage: bool) -> GateOutcome with fields passed: bool, failures: Vec<String>, evidence: serde_json::Value.
  - gate::write_evidence(path: &std::path::Path, evidence: &serde_json::Value) -> anyhow::Result<()>.
  - Binary mw-gate with flags: --reference FILE, --candidate FILE, --evidence FILE (optional), --json (print evidence JSON to stdout), --strict-coverage (optional). Exit code 0 on pass, 1 on gate failure, 2 on usage or I/O errors.

- [ ] **Step 1: Write engine/gate/Cargo.toml**

```toml
[package]
name = "mw-gate"
version = "0.1.0"
edition.workspace = true
rust-version.workspace = true
license.workspace = true
publish = false

[lib]
name = "gate"

[[bin]]
name = "mw-gate"
path = "src/main.rs"

[dependencies]
mw-okf = { path = "../okf" }
mw-graph = { path = "../graph" }
anyhow.workspace = true
serde_json.workspace = true

[dev-dependencies]
mw-test-support = { path = "../test-support" }
```

- [ ] **Step 2: Add engine/gate to the workspace members in the root Cargo.toml**

```toml
members = ["engine/okf", "engine/test-support", "engine/graph", "engine/gate"]
```

- [ ] **Step 3: Write engine/gate/src/lib.rs**

```rust
// SPDX-License-Identifier: AGPL-3.0-or-later
use graph::{graph_stats, requirement_coverage};
use okf::{diff, hash, types::OkfRoot, validate};
use serde_json::json;

pub struct GateOutcome {
    pub passed: bool,
    pub failures: Vec<String>,
    pub evidence: serde_json::Value,
}

/// The provable gate: round-trip fidelity plus graph health, with evidence
/// recorded for every run. The evidence is deterministic: given the same
/// inputs, the record reproduces exactly.
pub fn run(reference: &OkfRoot, candidate: &OkfRoot, strict_coverage: bool) -> GateOutcome {
    let mut failures: Vec<String> = Vec::new();

    let d = diff::diff(reference, candidate);
    if !d.equal {
        failures.push(format!(
            "roundtrip: {} missing elements, {} extra elements, {} missing edges, {} extra edges, {} changed attributes",
            d.missing_elements.len(),
            d.extra_elements.len(),
            d.missing_edges.len(),
            d.extra_edges.len(),
            d.changed_attributes.len()
        ));
    }

    let v = validate::validate(candidate);
    if !v.valid {
        for e in &v.errors {
            failures.push(format!("validation: {}", e));
        }
    }

    let stats = graph_stats(candidate);
    if !stats.isolated.is_empty() {
        failures.push(format!("integration: {} isolated nodes", stats.isolated.len()));
    }
    if stats.component_count != 1 {
        failures.push(format!("integration: {} connected components", stats.component_count));
    }

    let cov = requirement_coverage(candidate);
    if strict_coverage && !cov.uncovered.is_empty() {
        failures.push(format!("coverage: {} uncovered requirements", cov.uncovered.len()));
    }

    let evidence = json!({
        "gateVersion": env!("CARGO_PKG_VERSION"),
        "okfVersion": "1.0",
        "referenceHash": hash::canonical_hash(reference),
        "candidateHash": hash::canonical_hash(candidate),
        "roundtrip": {
            "equal": d.equal,
            "missingElements": d.missing_elements,
            "extraElements": d.extra_elements,
            "missingEdges": d.missing_edges,
            "extraEdges": d.extra_edges,
            "changedAttributes": d.changed_attributes
        },
        "integration": {
            "isolated": stats.isolated,
            "componentCount": stats.component_count,
            "componentSizes": stats.component_sizes
        },
        "coverage": {
            "total": cov.total,
            "satisfied": cov.satisfied,
            "refined": cov.refined,
            "verified": cov.verified,
            "allocated": cov.allocated,
            "covered": cov.covered,
            "uncovered": cov.uncovered
        },
        "strictCoverage": strict_coverage,
        "validationErrors": v.errors,
        "validationWarnings": v.warnings,
        "passed": failures.is_empty(),
        "failures": failures
    });

    GateOutcome {
        passed: failures.is_empty(),
        failures,
        evidence,
    }
}

pub fn write_evidence(path: &std::path::Path, evidence: &serde_json::Value) -> anyhow::Result<()> {
    let text = serde_json::to_string_pretty(evidence)?;
    std::fs::write(path, text)?;
    Ok(())
}
```

- [ ] **Step 4: Write engine/gate/src/main.rs**

```rust
// SPDX-License-Identifier: AGPL-3.0-or-later
use std::path::PathBuf;
use std::process::ExitCode;

use okf::types::OkfRoot;

fn main() -> ExitCode {
    let mut reference: Option<PathBuf> = None;
    let mut candidate: Option<PathBuf> = None;
    let mut evidence: Option<PathBuf> = None;
    let mut json_output = false;
    let mut strict_coverage = false;
    let mut args = std::env::args().skip(1);
    while let Some(a) = args.next() {
        match a.as_str() {
            "--reference" => reference = args.next().map(PathBuf::from),
            "--candidate" => candidate = args.next().map(PathBuf::from),
            "--evidence" => evidence = args.next().map(PathBuf::from),
            "--json" => json_output = true,
            "--strict-coverage" => strict_coverage = true,
            _ => {
                eprintln!("unknown argument: {}", a);
                return ExitCode::from(2);
            }
        }
    }
    let (Some(reference), Some(candidate)) = (reference, candidate) else {
        eprintln!("usage: mw-gate --reference FILE --candidate FILE [--evidence FILE] [--json] [--strict-coverage]");
        return ExitCode::from(2);
    };
    let read = |p: &PathBuf| -> anyhow::Result<OkfRoot> {
        let text = std::fs::read_to_string(p)?;
        Ok(serde_json::from_str(&text)?)
    };
    let (reference, candidate) = match (read(&reference), read(&candidate)) {
        (Ok(r), Ok(c)) => (r, c),
        (Err(e), _) | (_, Err(e)) => {
            eprintln!("failed to read input: {:#}", e);
            return ExitCode::from(2);
        }
    };
    let outcome = gate::run(&reference, &candidate, strict_coverage);
    if let Some(path) = &evidence {
        if let Err(e) = gate::write_evidence(path, &outcome.evidence) {
            eprintln!("failed to write evidence: {:#}", e);
            return ExitCode::from(2);
        }
    }
    if json_output {
        println!("{}", serde_json::to_string(&outcome.evidence).expect("evidence serializes"));
    } else if outcome.passed {
        println!("GATE PASS");
    } else {
        println!("GATE FAIL");
        for f in &outcome.failures {
            println!("- {}", f);
        }
    }
    if outcome.passed {
        ExitCode::SUCCESS
    } else {
        ExitCode::from(1)
    }
}
```

---
- [ ] **Step 5: Write sample/scripts/make_corrupted.py**

```python
# SPDX-License-Identifier: AGPL-3.0-or-later
"""Produce the corrupted OKF fixture the gate must reject.

Deterministic breakage, applied to the reference corpus:
- every edge touching requirement 3.1.5 is removed, isolating that node;
- requirement 1.1 is deleted entirely (a lost element).
"""
import json
import sys
from pathlib import Path


def main() -> int:
    src = Path("sample/corpus/coffee-machine/okf/expected/coffee_machine_model.json")
    dst = Path("sample/corpus/coffee-machine/okf/corrupted/coffee_machine_model.json")
    data = json.loads(src.read_text(encoding="utf-8"))
    target = next(r["id"] for r in data["requirements"] if r["reqId"] == "3.1.5")
    before = len(data["graph"]["edges"])
    data["graph"]["edges"] = [
        e for e in data["graph"]["edges"]
        if e["source"] != target and e["target"] != target
    ]
    removed = before - len(data["graph"]["edges"])
    data["requirements"] = [r for r in data["requirements"] if r["reqId"] != "1.1"]
    dst.parent.mkdir(parents=True, exist_ok=True)
    dst.write_text(json.dumps(data, indent=2), encoding="utf-8")
    print(f"wrote {dst}: removed {removed} edges around REQ 3.1.5, deleted REQ 1.1")
    return 0


if __name__ == "__main__":
    sys.exit(main())
```

- [ ] **Step 6: Generate the corrupted fixture**

```powershell
python sample/scripts/make_corrupted.py
```

Expected: the script prints how many edges it removed around REQ 3.1.5 (a positive number) and that it deleted REQ 1.1. The corrupted file uses the same filename in a different directory so the judge harness can pair it with the reference.

- [ ] **Step 7: Write engine/gate/tests/gate.rs**

```rust
// SPDX-License-Identifier: AGPL-3.0-or-later
use okf::types::OkfRoot;

fn expected() -> OkfRoot {
    serde_json::from_str(&test_support::load_okf_expected()).expect("corpus fixture parses")
}

fn okf(text: &str) -> OkfRoot {
    serde_json::from_str(text).expect("test OKF parses")
}

const TINY_GATE: &str = r#"{
  "project": "tiny",
  "exportedAt": "2026-09-17T00:00:00Z",
  "summary": {},
  "stateMachine": {"name": "tiny sm", "regions": []},
  "requirements": [
    {"id": "r1", "name": "R1", "kind": "requirement", "stereotypes": ["Requirement"], "attributes": [], "documentation": "", "reqId": "1.1", "reqText": "covered"},
    {"id": "r2", "name": "R2", "kind": "requirement", "stereotypes": ["Requirement"], "attributes": [], "documentation": "", "reqId": "1.2", "reqText": "uncovered"}
  ],
  "graph": {
    "nodes": [
      {"id": "p1", "kind": "block", "name": "P1"},
      {"id": "r1", "kind": "requirement", "name": "R1"},
      {"id": "r2", "kind": "requirement", "name": "R2"}
    ],
    "edges": [
      {"source": "p1", "target": "r1", "kind": "dependency", "label": "Satisfy"},
      {"source": "p1", "target": "r2", "kind": "reference", "label": ""}
    ]
  }
}"#;

#[test]
fn self_roundtrip_passes() {
    let r = expected();
    let outcome = gate::run(&r, &r, false);
    assert!(outcome.passed, "unexpected failures: {:?}", outcome.failures);
    assert_eq!(outcome.evidence["passed"], true);
    assert_eq!(outcome.evidence["referenceHash"], outcome.evidence["candidateHash"]);
}

#[test]
fn corrupted_corpus_fails() {
    let reference = expected();
    let candidate: OkfRoot =
        serde_json::from_str(&test_support::load_okf_broken()).expect("broken fixture parses");
    let outcome = gate::run(&reference, &candidate, false);
    assert!(!outcome.passed);
    assert!(outcome.failures.iter().any(|f| f.contains("missing elements")));
    assert!(outcome.failures.iter().any(|f| f.contains("isolated")));
}

#[test]
fn strict_coverage_fails_on_uncovered() {
    let r = okf(TINY_GATE);
    let lenient = gate::run(&r, &r, false);
    assert!(lenient.passed, "unexpected failures: {:?}", lenient.failures);
    let strict = gate::run(&r, &r, true);
    assert!(!strict.passed);
    assert!(strict.failures.iter().any(|f| f.contains("uncovered requirements")));
}
```

- [ ] **Step 8: Run the tests**

Run: cargo test -p mw-gate
Expected: all 3 tests pass.

- [ ] **Step 9: Record the first two evidence files**

```powershell
cargo run -p mw-gate -- --reference sample/corpus/coffee-machine/okf/expected/coffee_machine_model.json --candidate sample/corpus/coffee-machine/okf/expected/coffee_machine_model.json --evidence docs/evidence/2026-09-17-roundtrip-self-pass.json
cargo run -p mw-gate -- --reference sample/corpus/coffee-machine/okf/expected/coffee_machine_model.json --candidate sample/corpus/coffee-machine/okf/corrupted/coffee_machine_model.json --evidence docs/evidence/2026-09-17-roundtrip-corrupted-fail.json
```

Expected: the first command prints GATE PASS and exits 0; the second prints GATE FAIL with the roundtrip and integration failure lines and exits 1 (the non-zero exit is correct and expected here). Both evidence files exist; the first contains "passed": true, the second "passed": false.

- [ ] **Step 10: Write docs/evidence/README.md**

```markdown
# Evidence annex

Every public claim about modelwrite traces to a recorded gate run in this
directory. Records are append-only: never rewrite an existing record.

Naming: YYYY-MM-DD-<subject>.json

Each record is the deterministic output of mw-gate --evidence: given the
same reference and candidate, the record reproduces exactly (hashes and
all). Dates appear only in filenames, never inside records.

Index:

- 2026-09-17-roundtrip-self-pass.json â€” the corpus compared with itself:
  the gate passes. Proves the reference OKF is a fixed point of the gate.
- 2026-09-17-roundtrip-corrupted-fail.json â€” the corpus compared with the
  corrupted fixture: the gate fails on missing elements and isolated
  nodes. Proves the gate detects loss and fragmentation.
```

- [ ] **Step 11: Format, lint and commit**

```powershell
cargo fmt --all
cargo clippy -p mw-gate --all-targets -- -D warnings
git add Cargo.toml engine/gate sample docs/evidence
git commit -m "feat: add round-trip fidelity gate with evidence records"
```

---

