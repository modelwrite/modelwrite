﻿### Task 4: engine/okf â€” types, validation, hashing, diffing

**Files:**
- Create: Cargo.toml (workspace root; members okf and test-support)
- Create: engine/test-support/Cargo.toml
- Create: engine/test-support/src/lib.rs
- Create: engine/okf/Cargo.toml
- Create: engine/okf/src/lib.rs
- Create: engine/okf/src/types.rs
- Create: engine/okf/src/validate.rs
- Create: engine/okf/src/hash.rs
- Create: engine/okf/src/diff.rs
- Test: engine/okf/tests/okf_validation.rs
- Test: engine/okf/tests/okf_diff.rs

**Interfaces:**
- Consumes: the corpus fixture at sample/corpus/coffee-machine/okf/expected/coffee_machine_model.json (via test_support).
- Produces:
  - okf::types::OkfRoot and its item types (Element, Requirement, State, Region, StateMachine, Activity, ActivityNode, ActivityEdge, GraphNode, GraphEdge, Graph, Summary, Provenance, Attribute).
  - okf::validate::validate(root: &OkfRoot) -> ValidationReport with fields valid: bool, errors: Vec<String>, warnings: Vec<String>.
  - okf::hash::canonical_hash(root: &OkfRoot) -> String (sha256 hex).
  - okf::diff::diff(reference: &OkfRoot, candidate: &OkfRoot) -> DiffReport with fields equal, missing_elements, extra_elements, missing_edges, extra_edges, changed_attributes (all Vec<String>).
  - test_support::load_okf_expected() -> String, test_support::load_okf_broken() -> String, test_support::okf_expected() -> PathBuf, test_support::okf_broken() -> PathBuf.

- [ ] **Step 1: Write the workspace root Cargo.toml**

```toml
[workspace]
resolver = "2"
members = ["engine/okf", "engine/test-support"]

[workspace.package]
edition = "2021"
rust-version = "1.75"
license = "AGPL-3.0-or-later"
repository = "https://github.com/modelwrite/modelwrite"

[workspace.dependencies]
anyhow = "1.0"
hex = "0.4"
petgraph = "0.6"
serde = { version = "1.0", features = ["derive"] }
serde_json = "1.0"
sha2 = "0.10"
```

- [ ] **Step 2: Write engine/test-support/Cargo.toml**

```toml
[package]
name = "mw-test-support"
version = "0.1.0"
edition.workspace = true
rust-version.workspace = true
license.workspace = true
publish = false

[lib]
name = "test_support"

[dependencies]
```

- [ ] **Step 3: Write engine/test-support/src/lib.rs**

```rust
// SPDX-License-Identifier: AGPL-3.0-or-later
use std::path::PathBuf;

/// The repository root, two levels above this crate (engine/test-support).
pub fn repo_root() -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("../..")
}

pub fn okf_expected() -> PathBuf {
    repo_root().join("sample/corpus/coffee-machine/okf/expected/coffee_machine_model.json")
}

pub fn okf_broken() -> PathBuf {
    repo_root().join("sample/corpus/coffee-machine/okf/corrupted/coffee_machine_model.json")
}

pub fn load_okf_expected() -> String {
    std::fs::read_to_string(okf_expected()).expect("corpus fixture must exist")
}

pub fn load_okf_broken() -> String {
    std::fs::read_to_string(okf_broken()).expect("corrupted fixture must exist")
}
```

- [ ] **Step 4: Write engine/okf/Cargo.toml**

```toml
[package]
name = "mw-okf"
version = "0.1.0"
edition.workspace = true
rust-version.workspace = true
license.workspace = true
publish = false

[lib]
name = "okf"

[dependencies]
serde.workspace = true
serde_json.workspace = true
sha2.workspace = true
hex.workspace = true

[dev-dependencies]
mw-test-support = { path = "../test-support" }
```

- [ ] **Step 5: Write engine/okf/src/lib.rs**

```rust
// SPDX-License-Identifier: AGPL-3.0-or-later
pub mod diff;
pub mod hash;
pub mod types;
pub mod validate;
```

- [ ] **Step 6: Write engine/okf/src/types.rs**

```rust
// SPDX-License-Identifier: AGPL-3.0-or-later
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct Attribute {
    pub name: String,
    #[serde(rename = "type", default)]
    pub attr_type: String,
    #[serde(default)]
    pub aggregation: String,
    #[serde(default)]
    pub default: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct Element {
    pub id: String,
    #[serde(default)]
    pub name: String,
    #[serde(default)]
    pub kind: String,
    #[serde(default)]
    pub stereotypes: Vec<String>,
    #[serde(default)]
    pub attributes: Vec<Attribute>,
    #[serde(default)]
    pub documentation: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct Requirement {
    pub id: String,
    #[serde(default)]
    pub name: String,
    #[serde(default)]
    pub kind: String,
    #[serde(default)]
    pub stereotypes: Vec<String>,
    #[serde(default)]
    pub attributes: Vec<Attribute>,
    #[serde(default)]
    pub documentation: String,
    #[serde(rename = "reqId", default)]
    pub req_id: String,
    #[serde(rename = "reqText", default)]
    pub req_text: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct State {
    pub id: String,
    #[serde(default)]
    pub name: String,
    #[serde(default)]
    pub entry: Option<String>,
    #[serde(rename = "doActivity", default)]
    pub do_activity: Option<String>,
    #[serde(default)]
    pub exit: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct Region {
    #[serde(default)]
    pub states: Vec<State>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct StateMachine {
    pub name: String,
    #[serde(default)]
    pub regions: Vec<Region>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct ActivityNode {
    pub id: String,
    #[serde(rename = "type", default)]
    pub node_type: String,
    #[serde(default)]
    pub name: String,
    #[serde(default)]
    pub partition: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct ActivityEdge {
    #[serde(rename = "type", default)]
    pub edge_type: String,
    #[serde(default)]
    pub source: String,
    #[serde(default)]
    pub target: String,
    #[serde(default)]
    pub guard: String,
}

/// A swim-lane on an activity diagram. The fixture stores partitions as
/// objects with a name and an optional represented element, not as plain strings.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct Partition {
    pub name: String,
    #[serde(default)]
    pub represents: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct Activity {
    #[serde(default)]
    pub name: String,
    #[serde(default)]
    pub partitions: Vec<Partition>,
    #[serde(default)]
    pub nodes: Vec<ActivityNode>,
    #[serde(default)]
    pub edges: Vec<ActivityEdge>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct GraphNode {
    pub id: String,
    #[serde(default)]
    pub kind: String,
    #[serde(default)]
    pub name: String,
    #[serde(default)]
    pub stereotypes: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct GraphEdge {
    pub source: String,
    pub target: String,
    pub kind: String,
    #[serde(default)]
    pub label: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct Graph {
    pub nodes: Vec<GraphNode>,
    pub edges: Vec<GraphEdge>,
}

#[derive(Debug, Clone, Default, Serialize, Deserialize, PartialEq)]
pub struct Summary {
    #[serde(default)]
    pub blocks: u64,
    #[serde(default)]
    pub requirements: u64,
    #[serde(default)]
    pub interfaces: u64,
    #[serde(default)]
    pub signals: u64,
    #[serde(default)]
    pub activities: u64,
    #[serde(rename = "graphNodes", default)]
    pub graph_nodes: u64,
    #[serde(rename = "graphEdges", default)]
    pub graph_edges: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct Provenance {
    #[serde(rename = "sourceTool", default)]
    pub source_tool: String,
    #[serde(default)]
    pub exporter: String,
    #[serde(rename = "exporterVersion", default)]
    pub exporter_version: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct OkfRoot {
    #[serde(default)]
    pub okf: String,
    pub project: String,
    #[serde(rename = "exportedAt", default)]
    pub exported_at: String,
    #[serde(default)]
    pub summary: Summary,
    #[serde(default)]
    pub structure: Vec<Element>,
    #[serde(default)]
    pub interfaces: Vec<Element>,
    #[serde(default)]
    pub signals: Vec<Element>,
    #[serde(default)]
    pub requirements: Vec<Requirement>,
    #[serde(rename = "stateMachine", default)]
    pub state_machine: Option<StateMachine>,
    #[serde(default)]
    pub activities: Vec<Activity>,
    #[serde(default)]
    pub graph: Option<Graph>,
    #[serde(default)]
    pub provenance: Option<Provenance>,
}
```

---
- [ ] **Step 7: Write engine/okf/src/validate.rs**

```rust
// SPDX-License-Identifier: AGPL-3.0-or-later
use std::collections::HashSet;

use serde::Serialize;

use crate::types::OkfRoot;

pub const NODE_KINDS: &[&str] = &[
    "activity", "actor", "block", "interface", "requirement", "signal", "state",
    "stateMachine", "usecase",
];

pub const EDGE_KINDS: &[&str] = &[
    "association", "behavior", "contains", "dependency", "effect", "generalization",
    "include", "part", "reference", "subject", "transition", "triggers", "uses",
];

#[derive(Debug, Clone, Serialize)]
pub struct ValidationReport {
    pub valid: bool,
    pub errors: Vec<String>,
    pub warnings: Vec<String>,
}

pub fn validate(root: &OkfRoot) -> ValidationReport {
    let mut report = ValidationReport {
        valid: true,
        errors: Vec::new(),
        warnings: Vec::new(),
    };

    if !root.okf.is_empty() && root.okf != "1.0" {
        report.errors.push(format!("okf marker must be empty or 1.0, found {}", root.okf));
    } else if root.okf.is_empty() {
        report.warnings.push("legacy OKF without version marker; exporters should emit okf 1.0".to_string());
    }
    if root.project.is_empty() {
        report.errors.push("project name is empty".to_string());
    }
    if root.graph.is_none() {
        report.errors.push("graph section is missing".to_string());
    }
    if root.state_machine.is_none() {
        report.errors.push("stateMachine section is missing".to_string());
    }

    let mut seen: HashSet<String> = HashSet::new();
    let mut add_id = |id: &str, section: &str, errors: &mut Vec<String>| {
        if id.is_empty() {
            errors.push(format!("{}: empty element id", section));
        } else if !seen.insert(id.to_string()) {
            errors.push(format!("duplicate element id {} in {}", id, section));
        }
    };
    for el in &root.structure {
        add_id(&el.id, "structure", &mut report.errors);
    }
    for el in &root.interfaces {
        add_id(&el.id, "interfaces", &mut report.errors);
    }
    for el in &root.signals {
        add_id(&el.id, "signals", &mut report.errors);
    }
    for r in &root.requirements {
        add_id(&r.id, "requirements", &mut report.errors);
        if r.req_id.trim().is_empty() {
            report.errors.push(format!("requirement {} has an empty reqId", r.id));
        }
    }
    if let Some(sm) = &root.state_machine {
        if sm.name.is_empty() {
            report.errors.push("stateMachine has an empty name".to_string());
        }
        for region in &sm.regions {
            for s in &region.states {
                add_id(&s.id, "stateMachine", &mut report.errors);
            }
        }
    }

    if let Some(graph) = &root.graph {
        if graph.nodes.is_empty() {
            report.errors.push("graph has no nodes".to_string());
        }
        let node_ids: HashSet<&str> = graph.nodes.iter().map(|n| n.id.as_str()).collect();
        for n in &graph.nodes {
            if !NODE_KINDS.contains(&n.kind.as_str()) {
                report.errors.push(format!("unknown node kind {} on node {}", n.kind, n.id));
            }
        }
        for e in &graph.edges {
            if !EDGE_KINDS.contains(&e.kind.as_str()) {
                report.errors.push(format!("unknown edge kind {} from {} to {}", e.kind, e.source, e.target));
            }
            // Unresolved endpoints are warnings, not errors: the reference corpus proves
            // that real exporter output can carry edges whose element was never emitted as
            // a node (two satisfy links in the coffee-machine export). The platform must
            // hold, gate and reason about such a model while reporting the defect loudly;
            // refusing the document would make the corpus unusable as the proof fixture.
            if !node_ids.contains(e.source.as_str()) {
                report.warnings.push(format!("dangling edge endpoint {} (source of a {} edge)", e.source, e.kind));
            }
            if !node_ids.contains(e.target.as_str()) {
                report.warnings.push(format!("dangling edge endpoint {} (target of a {} edge)", e.target, e.kind));
            }
        }
    }

    let sm = &root.summary;
    if let Some(graph) = &root.graph {
        if sm.graph_nodes as usize != graph.nodes.len() || sm.graph_edges as usize != graph.edges.len() {
            report.warnings.push(format!("summary graph counts ({}/{}) do not match graph section ({}/{})", sm.graph_nodes, sm.graph_edges, graph.nodes.len(), graph.edges.len()));
        }
    }
    if sm.blocks as usize != root.structure.len() {
        report.warnings.push(format!("summary blocks {} do not match structure length {}", sm.blocks, root.structure.len()));
    }
    if sm.requirements as usize != root.requirements.len() {
        report.warnings.push(format!("summary requirements {} do not match requirements length {}", sm.requirements, root.requirements.len()));
    }
    if sm.signals as usize != root.signals.len() {
        report.warnings.push(format!("summary signals {} do not match signals length {}", sm.signals, root.signals.len()));
    }
    if sm.activities as usize != root.activities.len() {
        report.warnings.push(format!("summary activities {} do not match activities length {}", sm.activities, root.activities.len()));
    }
    if sm.interfaces as usize != root.interfaces.len() {
        report.warnings.push(format!("summary interfaces {} do not match interfaces length {}", sm.interfaces, root.interfaces.len()));
    }

    report.valid = report.errors.is_empty();
    report
}
```

- [ ] **Step 8: Write engine/okf/src/hash.rs**

```rust
// SPDX-License-Identifier: AGPL-3.0-or-later
use sha2::{Digest, Sha256};

use crate::types::OkfRoot;

/// Content fingerprint of an OKF snapshot: sha256 over the canonical
/// serialization. Field order is fixed by the type definitions, so a given
/// snapshot always hashes to the same value. It is a fingerprint, not a
/// semantic identity; the gate uses diffing for equality.
pub fn canonical_hash(root: &OkfRoot) -> String {
    let bytes = serde_json::to_vec(root).expect("OkfRoot serialization cannot fail");
    let digest = Sha256::digest(&bytes);
    hex::encode(digest)
}
```

- [ ] **Step 9: Write engine/okf/src/diff.rs**

```rust
// SPDX-License-Identifier: AGPL-3.0-or-later
use std::collections::{BTreeMap, BTreeSet};

use serde::Serialize;

use crate::types::OkfRoot;

#[derive(Debug, Clone, Serialize)]
pub struct DiffReport {
    pub equal: bool,
    pub missing_elements: Vec<String>,
    pub extra_elements: Vec<String>,
    pub missing_edges: Vec<String>,
    pub extra_edges: Vec<String>,
    pub changed_attributes: Vec<String>,
}

/// Every element id across all sections, plus every graph node id.
pub fn element_ids(root: &OkfRoot) -> BTreeSet<String> {
    let mut ids = BTreeSet::new();
    for el in &root.structure {
        ids.insert(el.id.clone());
    }
    for el in &root.interfaces {
        ids.insert(el.id.clone());
    }
    for el in &root.signals {
        ids.insert(el.id.clone());
    }
    for r in &root.requirements {
        ids.insert(r.id.clone());
    }
    if let Some(sm) = &root.state_machine {
        for region in &sm.regions {
            for s in &region.states {
                ids.insert(s.id.clone());
            }
        }
    }
    if let Some(graph) = &root.graph {
        for n in &graph.nodes {
            ids.insert(n.id.clone());
        }
    }
    ids
}

/// Every relationship as a canonical key. The key is a JSON array, so a field that
/// contains a separator character cannot alias two distinct edges.
pub fn edge_keys(root: &OkfRoot) -> BTreeSet<String> {
    let mut keys = BTreeSet::new();
    if let Some(graph) = &root.graph {
        for e in &graph.edges {
            let parts = [
                e.source.as_str(),
                e.target.as_str(),
                e.kind.as_str(),
                e.label.as_str(),
            ];
            if let Ok(key) = serde_json::to_string(&parts) {
                keys.insert(key);
            }
        }
    }
    keys
}

/// Canonical JSON per comparable unit, keyed by "<section>:<id>".
///
/// The universe covers the document-level fields, every element-bearing section, and
/// the activities section (which carries its own nodes and edges and is otherwise easy
/// to forget). Section scoping matters: the graph mirrors elements, so the same id
/// appears both as a section item and as a graph node, and keying by id alone would let
/// the graph entry mask a removal or a change in the section that owns the element.
pub fn attribute_keys(root: &OkfRoot) -> BTreeMap<String, String> {
    let mut map = BTreeMap::new();

    if let Ok(v) = serde_json::to_string(&root.project) {
        map.insert("doc:project".to_string(), v);
    }
    if let Ok(v) = serde_json::to_string(&root.okf) {
        map.insert("doc:okf".to_string(), v);
    }
    if let Ok(v) = serde_json::to_string(&root.exported_at) {
        map.insert("doc:exportedAt".to_string(), v);
    }
    if let Ok(v) = serde_json::to_string(&root.summary) {
        map.insert("doc:summary".to_string(), v);
    }
    if let Ok(v) = serde_json::to_string(&root.provenance) {
        map.insert("doc:provenance".to_string(), v);
    }
    if let Some(sm) = &root.state_machine {
        if let Ok(v) = serde_json::to_string(sm) {
            map.insert("doc:stateMachine".to_string(), v);
        }
    }

    let mut put = |section: &str, id: &str, json: String| {
        map.insert(format!("{}:{}", section, id), json);
    };
    for el in &root.structure {
        if let Ok(v) = serde_json::to_string(el) {
            put("structure", &el.id, v);
        }
    }
    for el in &root.interfaces {
        if let Ok(v) = serde_json::to_string(el) {
            put("interfaces", &el.id, v);
        }
    }
    for el in &root.signals {
        if let Ok(v) = serde_json::to_string(el) {
            put("signals", &el.id, v);
        }
    }
    for r in &root.requirements {
        if let Ok(v) = serde_json::to_string(r) {
            put("requirements", &r.id, v);
        }
    }
    if let Some(sm) = &root.state_machine {
        for region in &sm.regions {
            for s in &region.states {
                if let Ok(v) = serde_json::to_string(s) {
                    put("state", &s.id, v);
                }
            }
        }
    }
    for (i, a) in root.activities.iter().enumerate() {
        if let Ok(v) = serde_json::to_string(a) {
            put("activity", &i.to_string(), v);
        }
    }
    if let Some(graph) = &root.graph {
        for n in &graph.nodes {
            if let Ok(v) = serde_json::to_string(n) {
                put("graphnode", &n.id, v);
            }
        }
    }
    map
}

pub fn diff(reference: &OkfRoot, candidate: &OkfRoot) -> DiffReport {
    let ref_attrs = attribute_keys(reference);
    let cand_attrs = attribute_keys(candidate);
    let ref_edges = edge_keys(reference);
    let cand_edges = edge_keys(candidate);

    let mut missing_elements: Vec<String> = ref_attrs
        .keys()
        .filter(|k| !cand_attrs.contains_key(*k))
        .cloned()
        .collect();
    let mut extra_elements: Vec<String> = cand_attrs
        .keys()
        .filter(|k| !ref_attrs.contains_key(*k))
        .cloned()
        .collect();
    let mut changed_attributes: Vec<String> = ref_attrs
        .iter()
        .filter(|(k, v)| cand_attrs.get(*k).map(|c| c != *v).unwrap_or(false))
        .map(|(k, _)| k.clone())
        .collect();
    let mut missing_edges: Vec<String> = ref_edges.difference(&cand_edges).cloned().collect();
    let mut extra_edges: Vec<String> = cand_edges.difference(&ref_edges).cloned().collect();
```

- [ ] **Step 10: Write engine/okf/tests/okf_validation.rs**

```rust
// SPDX-License-Identifier: AGPL-3.0-or-later
use okf::{hash, types::OkfRoot, validate};

fn expected() -> OkfRoot {
    serde_json::from_str(&test_support::load_okf_expected()).expect("corpus fixture parses")
}

#[test]
fn corpus_fixture_validates() {
    let report = validate::validate(&expected());
    assert!(report.valid, "unexpected errors: {:?}", report.errors);
    assert_eq!(report.errors, Vec::<String>::new());
    // The reference export carries two edges whose source element was never emitted as
    // a node; they are warned about, so the finding is recorded rather than silently
    // accepted. See the corpus README.
    assert_eq!(
        report
            .warnings
            .iter()
            .filter(|w| w.contains("dangling edge endpoint"))
            .count(),
        2,
        "expected exactly two dangling edge endpoints in the legacy export"
    );
}

#[test]
fn corpus_fixture_has_expected_graph() {
    let root = expected();
    let graph = root.graph.as_ref().expect("graph present");
    assert_eq!(graph.nodes.len(), 99);
    assert_eq!(graph.edges.len(), 165);
    assert_eq!(root.requirements.len(), 25);
}

#[test]
fn rejects_duplicate_element_ids() {
    let mut root = expected();
    if root.structure.len() >= 2 {
        let dup = root.structure[1].id.clone();
        root.structure[0].id = dup;
    }
    let report = validate::validate(&root);
    assert!(!report.valid);
    assert!(report.errors.iter().any(|e| e.contains("duplicate element id")));
}

#[test]
fn warns_dangling_edge_endpoint() {
    let mut root = expected();
    if let Some(graph) = root.graph.as_mut() {
        let target = graph.nodes[0].id.clone();
        graph.edges.push(okf::types::GraphEdge {
            source: "missing-node".into(),
            target,
            kind: "part".into(),
            label: String::new(),
        });
    }
    let report = validate::validate(&root);
    // Unresolved endpoints are warnings, not errors (ruling B): a real exporter can
    // emit them, so the document stays valid and the defect is reported loudly.
    assert!(report.valid, "unexpected errors: {:?}", report.errors);
    assert!(report.warnings.iter().any(|w| w.contains("missing-node")));
}

#[test]
fn rejects_unknown_edge_kind() {
    let mut root = expected();
    if let Some(graph) = root.graph.as_mut() {
        let target = graph.nodes[0].id.clone();
        graph.edges.push(okf::types::GraphEdge {
            source: "missing-node".into(),
            target,
            kind: "not-a-kind".into(),
            label: String::new(),
        });
    }
    let report = validate::validate(&root);
    assert!(!report.valid);
    assert!(report.errors.iter().any(|e| e.contains("unknown edge kind")));
}

#[test]
fn rejects_empty_requirement_id() {
    let mut root = expected();
    root.requirements[0].req_id = String::new();
    let report = validate::validate(&root);
    assert!(!report.valid);
    assert!(report.errors.iter().any(|e| e.contains("empty reqId")));
}

#[test]
fn canonical_hash_is_stable() {
    let a = hash::canonical_hash(&expected());
    let b = hash::canonical_hash(&expected());
    assert_eq!(a, b);
    assert_eq!(a.len(), 64);
}
```

- [ ] **Step 11: Write engine/okf/tests/okf_diff.rs**

```rust
// SPDX-License-Identifier: AGPL-3.0-or-later
use okf::{diff, types::OkfRoot};

fn expected() -> OkfRoot {
    serde_json::from_str(&test_support::load_okf_expected()).expect("corpus fixture parses")
}

#[test]
fn identical_models_diff_equal() {
    let r = expected();
    assert!(diff::diff(&r, &r).equal);
}

#[test]
fn removed_requirement_is_missing_element() {
    let mut candidate = expected();
    candidate.requirements.pop();
    let d = diff::diff(&expected(), &candidate);
    assert!(!d.equal);
    assert_eq!(d.missing_elements.len(), 1);
}

#[test]
fn removed_edge_is_missing_edge() {
    let mut candidate = expected();
    candidate.graph.as_mut().expect("graph present").edges.pop();
    let d = diff::diff(&expected(), &candidate);
    assert!(!d.equal);
    assert_eq!(d.missing_edges.len(), 1);
}

#[test]
fn renamed_element_is_changed_attribute() {
    let mut candidate = expected();
    candidate.structure[0].name.push_str(" X");
    let d = diff::diff(&expected(), &candidate);
    assert!(!d.equal);
    assert_eq!(d.changed_attributes.len(), 1);
}

#[test]
fn activity_change_is_a_difference() {
    let mut candidate = expected();
    candidate.activities[0].name.push_str(" X");
    let d = diff::diff(&expected(), &candidate);
    assert!(!d.equal);
    assert_eq!(d.changed_attributes.len(), 1);
}

#[test]
fn document_level_change_is_a_difference() {
    let mut candidate = expected();
    candidate.project.push_str(" X");
    let d = diff::diff(&expected(), &candidate);
    assert!(!d.equal);
    assert_eq!(d.changed_attributes.len(), 1);
}
```

- [ ] **Step 12: Run the tests**

Run: cargo test -p mw-okf
Expected: all 13 tests pass (7 in tests/okf_validation.rs, 6 in tests/okf_diff.rs). If corpus_fixture_validates fails, stop and report the validation errors verbatim; do not weaken the validator to make the corpus pass.

- [ ] **Step 13: Format and lint**

Run: cargo fmt --all
Run: cargo clippy -p mw-okf --all-targets -- -D warnings
Expected: no output from fmt; clippy exits 0 with no warnings.

- [ ] **Step 14: Commit**

```powershell
git add Cargo.toml engine
git commit -m "feat: add okf crate with types, validation, hashing and diffing"
```

---

