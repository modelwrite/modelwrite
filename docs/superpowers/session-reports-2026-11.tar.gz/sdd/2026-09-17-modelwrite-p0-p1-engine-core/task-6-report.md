# Task 6 Report: engine/gate — the round-trip fidelity gate

## Status

DONE

## Commits

- `38022ae` feat: add round-trip fidelity gate with evidence records

## Test summary

mw-gate: 3 passed (tests/gate.rs: self_roundtrip_passes, corrupted_corpus_fails, strict_coverage_fails_on_uncovered), 0 failed; lib/main/bin unittests 0; doc-tests 0.

## Evidence runs

### Run 1 — corpus self-comparison (must PASS)

Command:

```
cargo run -p mw-gate -- --reference sample/corpus/coffee-machine/okf/expected/coffee_machine_model.json --candidate sample/corpus/coffee-machine/okf/expected/coffee_machine_model.json --evidence docs/evidence/2026-09-17-roundtrip-self-pass.json
```

Observed output:

```
GATE PASS
```

Exit code: 0.

### Run 2 — corpus vs corrupted fixture (must FAIL)

Command:

```
cargo run -p mw-gate -- --reference sample/corpus/coffee-machine/okf/expected/coffee_machine_model.json --candidate sample/corpus/coffee-machine/okf/corrupted/coffee_machine_model.json --evidence docs/evidence/2026-09-17-roundtrip-corrupted-fail.json
```

Observed output:

```
GATE FAIL
- roundtrip: 1 missing elements, 0 extra elements, 3 missing edges, 0 extra edges, 0 changed attributes
- integration: 1 isolated nodes
- integration: 3 connected components
```

Exit code: 1.

## Verification notes

- `cargo test -p mw-gate --no-fail-fast` → 3 passed, 0 failed.
- Evidence files: `docs/evidence/2026-09-17-roundtrip-self-pass.json` contains `"passed": true`; `docs/evidence/2026-09-17-roundtrip-corrupted-fail.json` contains `"passed": false`.
- `cargo fmt --all` → clean (exit 0).
- `cargo clippy -p mw-gate --all-targets -- -D warnings` → clean (exit 0).
- Reference fixture `sample/corpus/coffee-machine/okf/expected/coffee_machine_model.json` is untouched (not in git status).
- Evidence records contain no timestamps; the only "2026" occurrences are the `_2026x_1_12a70364_...` SysML element ids carried verbatim from the fixture, so the records are deterministic byte-for-byte for identical inputs.

## Concerns

None blocking. One observation for the record: the corrupted run reports `integration: 3 connected components` in addition to `1 isolated nodes`. This is correct and expected — requirement 3.1.5 is an articulation point: its three edges are the only links joining the safety-requirements subtree (9 nodes) to the rest of the model. Removing them isolates 3.1.5 and also severs the other 8 safety nodes into a separate component, so the model fragments into components of size 90, 8, and 1. This strengthens (does not contradict) the brief's prediction of a roundtrip failure plus an isolated-node failure.
