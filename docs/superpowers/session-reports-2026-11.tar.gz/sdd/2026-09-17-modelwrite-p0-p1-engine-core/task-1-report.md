# Task 1 Report: Repository scaffold

## Status

DONE_WITH_CONCERNS

## Commits

- `06606f9` chore: scaffold modelwrite repository

## Verification

cargo 1.98.1 / rustc 1.98.1 (stable, both >= 1.75); 9 files + 3 empty directories created; git status clean after commit.

## Versions obtained

- cargo 1.98.1 (797e8a9bc 2026-08-05)
- rustc 1.98.1 (48a229cea 2026-09-01)
- rustup 1.29.1 (d95a37b6a 2026-08-13)

## Files created

Tracked files (9, all committed in `06606f9`):

- `.gitignore`
- `.gitattributes`
- `LICENSE` (full GNU AGPL-3.0 text, 661 lines, 34,523 bytes, downloaded verbatim from https://www.gnu.org/licenses/agpl-3.0.txt)
- `CODE_OF_CONDUCT.md`
- `CONTRIBUTING.md`
- `SECURITY.md`
- `NOTICE.md`
- `README.md` (stub; to be completed in Task 11)
- `agents/CLAUDE.md` (the rule pack)

Empty directories created on disk (not tracked — git cannot track empty directories):

- `docs/okf/`
- `docs/evidence/`
- `sample/`

## Commands run

Install (Step 1 — brief URL replaced per controller ruling, see Deviations):

```powershell
Invoke-WebRequest -Uri https://static.rust-lang.org/rustup/dist/x86_64-pc-windows-msvc/rustup-init.exe -OutFile "$env:TEMP\rustup-init.exe"
& "$env:TEMP\rustup-init.exe" -y --default-toolchain stable --profile minimal
```

Verify toolchain (Step 2 — used full paths because fresh pwsh sessions in this harness do not inherit the registry PATH rustup just set):

```powershell
& "$env:USERPROFILE\.cargo\bin\cargo.exe" --version   # cargo 1.98.1 (797e8a9bc 2026-08-05)
& "$env:USERPROFILE\.cargo\bin\rustc.exe" --version   # rustc 1.98.1 (48a229cea 2026-09-01)
```

Download licence (Step 6):

```powershell
Invoke-WebRequest -Uri https://www.gnu.org/licenses/agpl-3.0.txt -OutFile LICENSE
```

Create empty directories:

```powershell
New-Item -ItemType Directory -Force -Path docs/okf
New-Item -ItemType Directory -Force -Path docs/evidence
New-Item -ItemType Directory -Force -Path sample
```

Commit (Step 13):

```powershell
git add -A
git commit -m "chore: scaffold modelwrite repository"
```

## Deviations from brief

1. **Step 1 URL**: Used `https://static.rust-lang.org/rustup/dist/x86_64-pc-windows-msvc/rustup-init.exe` instead of `https://win.rustup.rs` — per controller ruling, win.rustup.rs is unreachable from this machine. No winget fallback was needed.
2. **Step 3 (git init)**: Skipped — the repository already exists on branch `slice-1-engine-core` with baseline commits `5085dcd` and `0c58480`. No remote was added (URL not yet confirmed). Existing commits were not amended or rewritten.
3. **Step 12 README.md**: Contains the characters `â€”` (mojibake of an em dash, U+00E2 U+20AC U+201D) in the line "into portable, provable data â€” the Open Knowledge Format (OKF) â€” and". This was reproduced **verbatim** from the brief file (the brief itself contains this mojibake at byte level); the instruction was to use exact file contents verbatim. See Concerns.
4. **Empty directories**: `docs/okf/`, `docs/evidence/`, `sample/` exist on disk but are not present in the commit, because git does not track empty directories. This matches the controller's "9 files + 3 directories" expectation; the directories will become tracked once Tasks 2/3/6 add files into them.

## Concerns

1. **README mojibake (fix in Task 11)**: `README.md` carries `â€”` where an em dash (`—`) was intended. Since the README is a stub completed in Task 11, the fix belongs there. Reproduced verbatim per instruction; not "fixed" here to preserve exact-brief fidelity.
2. **cargo/rustc not on PATH inside this harness**: rustup updated the per-user registry PATH, but fresh pwsh sessions spawned by the harness do not see it (the harness parent predates the install). Later tasks (Task 4+) must either prepend `$env:Path = "$env:USERPROFILE\.cargo\bin;" + $env:Path` in each shell invocation or use full paths (`$env:USERPROFILE\.cargo\bin\cargo.exe`). A new OS-level shell outside the harness will have cargo on PATH normally.
3. **Empty directories untracked**: Tasks 2 (`docs/okf/`), 3 (`sample/`), and 6 (`docs/evidence/`) must add their content; the directories are ready but currently empty on disk only.
4. **collateral/ untouched**: confirmed no changes under `collateral/` (read-only source material preserved).
