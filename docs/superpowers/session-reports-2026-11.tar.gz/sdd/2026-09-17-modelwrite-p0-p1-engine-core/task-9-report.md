# Task 9 Report: CI workflow

**Status:** DONE

**Commit:** c3a6750 ci: add engine test and gate pipeline

**Verification summary:** Created .github/workflows/ci.yml (18 lines) with the exact content from the brief; verified line-for-line equality against the brief's YAML block; staged only .github (1 file changed, 18 insertions) and committed with the brief's message. Working tree is otherwise clean.

**Concerns:**
- The final step (python -m unittest discover -s judge/tests -p "test_*.py" -v) depends on Task 10 creating the judge harness at judge/tests. That directory does not exist yet, so this step will fail until Task 10 lands. Per the plan, Task 10 must complete before the repository is pushed to GitHub.
- GitHub Actions cannot be run locally; verification is by inspection (file content + line-for-line comparison + clean staging) only. CI first runs on push to GitHub.
- Concurrent workspace activity: after this commit, other plan agents committed on top of it (HEAD is now f880a42) and left engine files modified in the working tree. This commit c3a6750 is unaffected and contains only .github/workflows/ci.yml (verified by full hash); none of those later changes are part of this task.

**Self-review of workflow commands:** matches the completed tasks' commands - cargo fmt --all -- --check, cargo clippy --workspace --all-targets -- -D warnings, cargo test --workspace, the mw-gate corpus run (cargo run -p mw-gate -- --reference sample/corpus/coffee-machine/okf/expected/coffee_machine_model.json --candidate sample/corpus/coffee-machine/okf/expected/coffee_machine_model.json), and the judge unittest discovery (python -m unittest discover -s judge/tests -p "test_*.py" -v).

