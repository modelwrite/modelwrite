﻿# Task 4 re-review package (fix round 3: diff coverage)

## Commit

3b49775 fix: cover activities and document-level fields in the okf diff
b102653 feat: add graph crate with integration and coverage analysis
ada2a53 docs: make the okf diff cover activities and document-level fields

## Diff stat

 Cargo.lock                                         |  49 ++++++++
 Cargo.toml                                         |   2 +-
 .../2026-09-17-modelwrite-p0-p1-engine-core.md     |  92 ++++++++++-----
 engine/graph/Cargo.toml                            |  19 +++
 engine/graph/src/lib.rs                            | 129 +++++++++++++++++++++
 engine/graph/tests/graph_stats.rs                  |  64 ++++++++++
 engine/okf/src/diff.rs                             |  48 +++++++-
 engine/okf/tests/okf_diff.rs                       |  18 +++
 8 files changed, 388 insertions(+), 33 deletions(-)

## Full diff (-U10)

diff --git a/Cargo.lock b/Cargo.lock
index f598789..818056a 100644
--- a/Cargo.lock
+++ b/Cargo.lock
@@ -39,69 +39,118 @@ dependencies = [
 [[package]]
 name = "digest"
 version = "0.10.7"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "9ed9a281f7bc9b7576e61468ba615a66a5c8cfdff42420a70aa82701a3b1e292"
 dependencies = [
  "block-buffer",
  "crypto-common",
 ]
 
+[[package]]
+name = "equivalent"
+version = "1.0.2"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "877a4ace8713b0bcf2a4e7eec82529c029f1d0619886d18145fea96c3ffe5c0f"
+
+[[package]]
+name = "fixedbitset"
+version = "0.4.2"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "0ce7134b9999ecaf8bcd65542e436736ef32ddca1b3e06094cb6ec5755203b80"
+
 [[package]]
 name = "generic-array"
 version = "0.14.7"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "85649ca51fd72272d7821adaf274ad91c288277713d9c18820d8499a7ff69e9a"
 dependencies = [
  "typenum",
  "version_check",
 ]
 
+[[package]]
+name = "hashbrown"
+version = "0.17.1"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "ed5909b6e89a2db4456e54cd5f673791d7eca6732202bbf2a9cc504fe2f9b84a"
+
 [[package]]
 name = "hex"
 version = "0.4.3"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "7f24254aa9a54b5c858eaee2f5bccdb46aaf0e486a595ed5fd8f86ba55232a70"
 
+[[package]]
+name = "indexmap"
+version = "2.14.2"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "cc4e190f5d26ca7051642629da2c52fc03bde85a03197c99408dcd291734c855"
+dependencies = [
+ "equivalent",
+ "hashbrown",
+]
+
 [[package]]
 name = "itoa"
 version = "1.0.18"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "8f42a60cbdf9a97f5d2305f08a87dc4e09308d1276d28c869c684d7777685682"
 
 [[package]]
 name = "libc"
 version = "0.2.189"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "3eaf3ede3fee6db1a4c2ee091bf8a8b4dccdc6d17f656fb07896ee72867612f2"
 
 [[package]]
 name = "memchr"
 version = "2.8.3"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "cf8baf1c55e62ffcace7a9f06f4bd9cd3f0c4beb022d3b367256b91b87513d98"
 
+[[package]]
+name = "mw-graph"
+version = "0.1.0"
+dependencies = [
+ "mw-okf",
+ "mw-test-support",
+ "petgraph",
+ "serde",
+ "serde_json",
+]
+
 [[package]]
 name = "mw-okf"
 version = "0.1.0"
 dependencies = [
  "hex",
  "mw-test-support",
  "serde",
  "serde_json",
  "sha2",
 ]
 
 [[package]]
 name = "mw-test-support"
 version = "0.1.0"
 
+[[package]]
+name = "petgraph"
+version = "0.6.5"
+source = "registry+https://github.com/rust-lang/crates.io-index"
+checksum = "b4c5cc86750666a3ed20bdaf5ca2a0344f9c67674cae0515bec2da16fbaa47db"
+dependencies = [
+ "fixedbitset",
+ "indexmap",
+]
+
 [[package]]
 name = "proc-macro2"
 version = "1.0.107"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "985e7ec9bb745e6ce6535b544d84d6cd6f7ad8bd711c398938ae983b91a766d9"
 dependencies = [
  "unicode-ident",
 ]
 
 [[package]]
diff --git a/Cargo.toml b/Cargo.toml
index de89a78..de0841a 100644
--- a/Cargo.toml
+++ b/Cargo.toml
@@ -1,13 +1,13 @@
 [workspace]
 resolver = "2"
-members = ["engine/okf", "engine/test-support"]
+members = ["engine/okf", "engine/test-support", "engine/graph"]
 
 [workspace.package]
 edition = "2021"
 rust-version = "1.75"
 license = "AGPL-3.0-or-later"
 repository = "https://github.com/modelwrite/modelwrite"
 
 [workspace.dependencies]
 anyhow = "1.0"
 hex = "0.4"
diff --git a/docs/superpowers/plans/2026-09-17-modelwrite-p0-p1-engine-core.md b/docs/superpowers/plans/2026-09-17-modelwrite-p0-p1-engine-core.md
index e4b8080..352f99d 100644
--- a/docs/superpowers/plans/2026-09-17-modelwrite-p0-p1-engine-core.md
+++ b/docs/superpowers/plans/2026-09-17-modelwrite-p0-p1-engine-core.md
@@ -1195,37 +1195,71 @@ pub fn element_ids(root: &OkfRoot) -> BTreeSet<String> {
         }
     }
     if let Some(graph) = &root.graph {
         for n in &graph.nodes {
             ids.insert(n.id.clone());
         }
     }
     ids
 }
 
-/// Every relationship as a source|target|kind|label key.
+/// Every relationship as a canonical key. The key is a JSON array, so a field that
+/// contains a separator character cannot alias two distinct edges.
 pub fn edge_keys(root: &OkfRoot) -> BTreeSet<String> {
     let mut keys = BTreeSet::new();
     if let Some(graph) = &root.graph {
         for e in &graph.edges {
-            keys.insert(format!("{}|{}|{}|{}", e.source, e.target, e.kind, e.label));
+            let parts = [
+                e.source.as_str(),
+                e.target.as_str(),
+                e.kind.as_str(),
+                e.label.as_str(),
+            ];
+            if let Ok(key) = serde_json::to_string(&parts) {
+                keys.insert(key);
+            }
         }
     }
     keys
 }
 
-/// Section-scoped canonical JSON per element: "<section>:<id>" -> serialized item.
-/// Section scoping matters: the graph mirrors elements, so the same id appears both
-/// as a section item and as a graph node. Keying by id alone would let the graph
-/// entry mask a removal or a change in the section that owns the element.
+/// Canonical JSON per comparable unit, keyed by "<section>:<id>".
+///
+/// The universe covers the document-level fields, every element-bearing section, and
+/// the activities section (which carries its own nodes and edges and is otherwise easy
+/// to forget). Section scoping matters: the graph mirrors elements, so the same id
+/// appears both as a section item and as a graph node, and keying by id alone would let
+/// the graph entry mask a removal or a change in the section that owns the element.
 pub fn attribute_keys(root: &OkfRoot) -> BTreeMap<String, String> {
     let mut map = BTreeMap::new();
+
+    if let Ok(v) = serde_json::to_string(&root.project) {
+        map.insert("doc:project".to_string(), v);
+    }
+    if let Ok(v) = serde_json::to_string(&root.okf) {
+        map.insert("doc:okf".to_string(), v);
+    }
+    if let Ok(v) = serde_json::to_string(&root.exported_at) {
+        map.insert("doc:exportedAt".to_string(), v);
+    }
+    if let Ok(v) = serde_json::to_string(&root.summary) {
+        map.insert("doc:summary".to_string(), v);
+    }
+    if let Ok(v) = serde_json::to_string(&root.provenance) {
+        map.insert("doc:provenance".to_string(), v);
+    }
+    if let Some(sm) = &root.state_machine {
+        if let Ok(v) = serde_json::to_string(sm) {
+            map.insert("doc:stateMachine".to_string(), v);
+        }
+    }
+
     let mut put = |section: &str, id: &str, json: String| {
         map.insert(format!("{}:{}", section, id), json);
     };
     for el in &root.structure {
         if let Ok(v) = serde_json::to_string(el) {
             put("structure", &el.id, v);
         }
     }
     for el in &root.interfaces {
         if let Ok(v) = serde_json::to_string(el) {
@@ -1244,29 +1278,35 @@ pub fn attribute_keys(root: &OkfRoot) -> BTreeMap<String, String> {
     }
     if let Some(sm) = &root.state_machine {
         for region in &sm.regions {
             for s in &region.states {
                 if let Ok(v) = serde_json::to_string(s) {
                     put("state", &s.id, v);
                 }
             }
         }
     }
+    for (i, a) in root.activities.iter().enumerate() {
+        if let Ok(v) = serde_json::to_string(a) {
+            put("activity", &i.to_string(), v);
+        }
+    }
     if let Some(graph) = &root.graph {
         for n in &graph.nodes {
             if let Ok(v) = serde_json::to_string(n) {
                 put("graphnode", &n.id, v);
             }
         }
     }
     map
 }
+
 pub fn diff(reference: &OkfRoot, candidate: &OkfRoot) -> DiffReport {
     let ref_attrs = attribute_keys(reference);
     let cand_attrs = attribute_keys(candidate);
     let ref_edges = edge_keys(reference);
     let cand_edges = edge_keys(candidate);
 
     let mut missing_elements: Vec<String> = ref_attrs
         .keys()
         .filter(|k| !cand_attrs.contains_key(*k))
         .cloned()
@@ -1276,40 +1316,20 @@ pub fn diff(reference: &OkfRoot, candidate: &OkfRoot) -> DiffReport {
         .filter(|k| !ref_attrs.contains_key(*k))
         .cloned()
         .collect();
     let mut changed_attributes: Vec<String> = ref_attrs
         .iter()
         .filter(|(k, v)| cand_attrs.get(*k).map(|c| c != *v).unwrap_or(false))
         .map(|(k, _)| k.clone())
         .collect();
     let mut missing_edges: Vec<String> = ref_edges.difference(&cand_edges).cloned().collect();
     let mut extra_edges: Vec<String> = cand_edges.difference(&ref_edges).cloned().collect();
-    missing_elements.sort();
-    extra_elements.sort();
-    missing_edges.sort();
-    extra_edges.sort();
-    changed_attributes.sort();
-
-    let equal = missing_elements.is_empty()
-        && extra_elements.is_empty()
-        && missing_edges.is_empty()
-        && extra_edges.is_empty()
-        && changed_attributes.is_empty();
-    DiffReport {
-        equal,
-        missing_elements,
-        extra_elements,
-        missing_edges,
-        extra_edges,
-        changed_attributes,
-    }
-}
 ```
 
 - [ ] **Step 10: Write engine/okf/tests/okf_validation.rs**
 
 ```rust
 // SPDX-License-Identifier: AGPL-3.0-or-later
 use okf::{hash, types::OkfRoot, validate};
 
 fn expected() -> OkfRoot {
     serde_json::from_str(&test_support::load_okf_expected()).expect("corpus fixture parses")
@@ -1444,26 +1464,44 @@ fn removed_edge_is_missing_edge() {
 }
 
 #[test]
 fn renamed_element_is_changed_attribute() {
     let mut candidate = expected();
     candidate.structure[0].name.push_str(" X");
     let d = diff::diff(&expected(), &candidate);
     assert!(!d.equal);
     assert_eq!(d.changed_attributes.len(), 1);
 }
+
+#[test]
+fn activity_change_is_a_difference() {
+    let mut candidate = expected();
+    candidate.activities[0].name.push_str(" X");
+    let d = diff::diff(&expected(), &candidate);
+    assert!(!d.equal);
+    assert_eq!(d.changed_attributes.len(), 1);
+}
+
+#[test]
+fn document_level_change_is_a_difference() {
+    let mut candidate = expected();
+    candidate.project.push_str(" X");
+    let d = diff::diff(&expected(), &candidate);
+    assert!(!d.equal);
+    assert_eq!(d.changed_attributes.len(), 1);
+}
 ```
 
 - [ ] **Step 12: Run the tests**
 
 Run: cargo test -p mw-okf
-Expected: all 11 tests pass (7 in tests/okf_validation.rs, 4 in tests/okf_diff.rs). If corpus_fixture_validates fails, stop and report the validation errors verbatim; do not weaken the validator to make the corpus pass.
+Expected: all 13 tests pass (7 in tests/okf_validation.rs, 6 in tests/okf_diff.rs). If corpus_fixture_validates fails, stop and report the validation errors verbatim; do not weaken the validator to make the corpus pass.
 
 - [ ] **Step 13: Format and lint**
 
 Run: cargo fmt --all
 Run: cargo clippy -p mw-okf --all-targets -- -D warnings
 Expected: no output from fmt; clippy exits 0 with no warnings.
 
 - [ ] **Step 14: Commit**
 
 ```powershell
diff --git a/engine/graph/Cargo.toml b/engine/graph/Cargo.toml
new file mode 100644
index 0000000..c1d100a
--- /dev/null
+++ b/engine/graph/Cargo.toml
@@ -0,0 +1,19 @@
+[package]
+name = "mw-graph"
+version = "0.1.0"
+edition.workspace = true
+rust-version.workspace = true
+license.workspace = true
+publish = false
+
+[lib]
+name = "graph"
+
+[dependencies]
+mw-okf = { path = "../okf" }
+petgraph.workspace = true
+serde.workspace = true
+
+[dev-dependencies]
+mw-test-support = { path = "../test-support" }
+serde_json.workspace = true
diff --git a/engine/graph/src/lib.rs b/engine/graph/src/lib.rs
new file mode 100644
index 0000000..1bddda9
--- /dev/null
+++ b/engine/graph/src/lib.rs
@@ -0,0 +1,129 @@
+// SPDX-License-Identifier: AGPL-3.0-or-later
+use std::collections::{HashMap, HashSet};
+
+use okf::types::OkfRoot;
+use petgraph::unionfind::UnionFind;
+use serde::Serialize;
+
+#[derive(Debug, Clone, Serialize)]
+pub struct GraphStats {
+    pub node_count: usize,
+    pub edge_count: usize,
+    pub isolated: Vec<String>,
+    pub component_count: usize,
+    pub component_sizes: Vec<usize>,
+}
+
+pub fn graph_stats(root: &OkfRoot) -> GraphStats {
+    let graph = root.graph.as_ref().expect("graph required; validate first");
+    let node_count = graph.nodes.len();
+    let edge_count = graph.edges.len();
+    let index: HashMap<&str, usize> = graph
+        .nodes
+        .iter()
+        .enumerate()
+        .map(|(i, n)| (n.id.as_str(), i))
+        .collect();
+    let mut uf = UnionFind::new(node_count);
+    let mut degree = vec![0usize; node_count];
+    for e in &graph.edges {
+        if let (Some(&a), Some(&b)) = (index.get(e.source.as_str()), index.get(e.target.as_str())) {
+            degree[a] += 1;
+            degree[b] += 1;
+            uf.union(a, b);
+        }
+    }
+    let isolated: Vec<String> = graph
+        .nodes
+        .iter()
+        .enumerate()
+        .filter(|(i, _)| degree[*i] == 0)
+        .map(|(_, n)| n.id.clone())
+        .collect();
+    let mut sizes: HashMap<usize, usize> = HashMap::new();
+    for i in 0..node_count {
+        *sizes.entry(uf.find(i)).or_insert(0) += 1;
+    }
+    let mut component_sizes: Vec<usize> = sizes.into_values().collect();
+    component_sizes.sort_unstable_by(|a, b| b.cmp(a));
+    let component_count = component_sizes.len();
+    GraphStats {
+        node_count,
+        edge_count,
+        isolated,
+        component_count,
+        component_sizes,
+    }
+}
+
+#[derive(Debug, Clone, Serialize)]
+pub struct CoverageReport {
+    pub total: usize,
+    pub satisfied: usize,
+    pub refined: usize,
+    pub verified: usize,
+    pub allocated: usize,
+    pub covered: usize,
+    pub uncovered: Vec<String>,
+}
+
+/// Requirement coverage read from dependency edges whose label is exactly
+/// Satisfy, Refine, Verify or Allocate.
+pub fn requirement_coverage(root: &OkfRoot) -> CoverageReport {
+    let req_ids: HashSet<&str> = root.requirements.iter().map(|r| r.id.as_str()).collect();
+    let graph = root.graph.as_ref().expect("graph required; validate first");
+    let mut satisfied = 0usize;
+    let mut refined = 0usize;
+    let mut verified = 0usize;
+    let mut allocated = 0usize;
+    let mut covered: HashSet<&str> = HashSet::new();
+    for e in &graph.edges {
+        if e.kind != "dependency" {
+            continue;
+        }
+        let s = e.source.as_str();
+        let t = e.target.as_str();
+        match e.label.as_str() {
+            "Satisfy" => {
+                if req_ids.contains(t) {
+                    satisfied += 1;
+                    covered.insert(t);
+                }
+            }
+            "Refine" => {
+                if req_ids.contains(t) {
+                    refined += 1;
+                    covered.insert(t);
+                }
+            }
+            "Verify" => {
+                if req_ids.contains(t) {
+                    verified += 1;
+                    covered.insert(t);
+                }
+            }
+            "Allocate" if req_ids.contains(t) || req_ids.contains(s) => {
+                allocated += 1;
+                covered.insert(t);
+                covered.insert(s);
+            }
+            _ => {}
+        }
+    }
+    let mut uncovered: Vec<String> = root
+        .requirements
+        .iter()
+        .filter(|r| !covered.contains(r.id.as_str()))
+        .map(|r| r.id.clone())
+        .collect();
+    uncovered.sort();
+    CoverageReport {
+        total: req_ids.len(),
+        satisfied,
+        refined,
+        verified,
+        allocated,
+        covered: covered.len(),
+        uncovered,
+    }
+}
diff --git a/engine/graph/tests/graph_stats.rs b/engine/graph/tests/graph_stats.rs
new file mode 100644
index 0000000..9a228d0
--- /dev/null
+++ b/engine/graph/tests/graph_stats.rs
@@ -0,0 +1,64 @@
+// SPDX-License-Identifier: AGPL-3.0-or-later
+use graph::{graph_stats, requirement_coverage};
+use okf::types::OkfRoot;
+
+fn expected() -> OkfRoot {
+    serde_json::from_str(&test_support::load_okf_expected()).expect("corpus fixture parses")
+}
+
+fn okf(text: &str) -> OkfRoot {
+    serde_json::from_str(text).expect("test OKF parses")
+}
+
+const TINY: &str = r#"{
+  "project": "tiny",
+  "exportedAt": "2026-09-17T00:00:00Z",
+  "summary": {},
+  "stateMachine": {"name": "tiny sm", "regions": []},
+  "requirements": [
+    {"id": "r1", "name": "R1", "kind": "requirement", "stereotypes": ["Requirement"], "attributes": [], "documentation": "", "reqId": "1.1", "reqText": "covered"},
+    {"id": "r2", "name": "R2", "kind": "requirement", "stereotypes": ["Requirement"], "attributes": [], "documentation": "", "reqId": "1.2", "reqText": "uncovered"}
+  ],
+  "graph": {
+    "nodes": [
+      {"id": "p1", "kind": "block", "name": "P1"},
+      {"id": "r1", "kind": "requirement", "name": "R1"},
+      {"id": "r2", "kind": "requirement", "name": "R2"}
+    ],
+    "edges": [
+      {"source": "p1", "target": "r1", "kind": "dependency", "label": "Satisfy"}
+    ]
+  }
+}"#;
+
+#[test]
+fn corpus_is_fully_integrated() {
+    let stats = graph_stats(&expected());
+    assert_eq!(stats.node_count, 99);
+    assert_eq!(stats.edge_count, 165);
+    assert!(stats.isolated.is_empty(), "isolated: {:?}", stats.isolated);
+    assert_eq!(stats.component_count, 1);
+    assert_eq!(stats.component_sizes, vec![99]);
+}
+
+#[test]
+fn isolated_node_is_detected() {
+    let stats = graph_stats(&okf(TINY));
+    assert_eq!(stats.isolated, vec!["r2"]);
+}
+
+#[test]
+fn two_components_are_counted() {
+    let stats = graph_stats(&okf(TINY));
+    assert_eq!(stats.component_count, 2);
+    assert_eq!(stats.component_sizes, vec![2, 1]);
+}
+
+#[test]
+fn coverage_counts_traceability() {
+    let cov = requirement_coverage(&okf(TINY));
+    assert_eq!(cov.total, 2);
+    assert_eq!(cov.satisfied, 1);
+    assert_eq!(cov.covered, 1);
+    assert_eq!(cov.uncovered, vec!["r2"]);
+}
diff --git a/engine/okf/src/diff.rs b/engine/okf/src/diff.rs
index 3ce8219..32ecb60 100644
--- a/engine/okf/src/diff.rs
+++ b/engine/okf/src/diff.rs
@@ -43,32 +43,65 @@ pub fn element_ids(root: &OkfRoot) -> BTreeSet<String> {
         }
     }
     ids
 }
 
 /// Every relationship as a source|target|kind|label key.
 pub fn edge_keys(root: &OkfRoot) -> BTreeSet<String> {
     let mut keys = BTreeSet::new();
     if let Some(graph) = &root.graph {
         for e in &graph.edges {
-            keys.insert(format!("{}|{}|{}|{}", e.source, e.target, e.kind, e.label));
+            let parts = [
+                e.source.as_str(),
+                e.target.as_str(),
+                e.kind.as_str(),
+                e.label.as_str(),
+            ];
+            if let Ok(key) = serde_json::to_string(&parts) {
+                keys.insert(key);
+            }
         }
     }
     keys
 }
 
-/// Section-scoped canonical JSON per element: "<section>:<id>" -> serialized item.
-/// Section scoping matters: the graph mirrors elements, so the same id appears both
-/// as a section item and as a graph node. Keying by id alone would let the graph
-/// entry mask a removal or a change in the section that owns the element.
+/// Canonical JSON per comparable unit, keyed by "<section>:<id>".
+///
+/// The universe covers the document-level fields, every element-bearing section, and
+/// the activities section (which carries its own nodes and edges). Section scoping
+/// matters: the graph mirrors elements, so the same id appears both as a section item
+/// and as a graph node, and keying by id alone would let the graph entry mask a removal
+/// or a change in the section that owns the element.
 pub fn attribute_keys(root: &OkfRoot) -> BTreeMap<String, String> {
     let mut map = BTreeMap::new();
+
+    if let Ok(v) = serde_json::to_string(&root.project) {
+        map.insert("doc:project".to_string(), v);
+    }
+    if let Ok(v) = serde_json::to_string(&root.okf) {
+        map.insert("doc:okf".to_string(), v);
+    }
+    if let Ok(v) = serde_json::to_string(&root.exported_at) {
+        map.insert("doc:exportedAt".to_string(), v);
+    }
+    if let Ok(v) = serde_json::to_string(&root.summary) {
+        map.insert("doc:summary".to_string(), v);
+    }
+    if let Ok(v) = serde_json::to_string(&root.provenance) {
+        map.insert("doc:provenance".to_string(), v);
+    }
+    if let Some(sm) = &root.state_machine {
+        if let Ok(v) = serde_json::to_string(sm) {
+            map.insert("doc:stateMachine".to_string(), v);
+        }
+    }
+
     let mut put = |section: &str, id: &str, json: String| {
         map.insert(format!("{}:{}", section, id), json);
     };
 
     for el in &root.structure {
         if let Ok(v) = serde_json::to_string(el) {
             put("structure", &el.id, v);
         }
     }
     for el in &root.interfaces {
@@ -88,20 +121,25 @@ pub fn attribute_keys(root: &OkfRoot) -> BTreeMap<String, String> {
     }
     if let Some(sm) = &root.state_machine {
         for region in &sm.regions {
             for s in &region.states {
                 if let Ok(v) = serde_json::to_string(s) {
                     put("state", &s.id, v);
                 }
             }
         }
     }
+    for (i, a) in root.activities.iter().enumerate() {
+        if let Ok(v) = serde_json::to_string(a) {
+            put("activity", &i.to_string(), v);
+        }
+    }
     if let Some(graph) = &root.graph {
         for n in &graph.nodes {
             if let Ok(v) = serde_json::to_string(n) {
                 put("graphnode", &n.id, v);
             }
         }
     }
     map
 }
 
diff --git a/engine/okf/tests/okf_diff.rs b/engine/okf/tests/okf_diff.rs
index 868eef1..4449a6e 100644
--- a/engine/okf/tests/okf_diff.rs
+++ b/engine/okf/tests/okf_diff.rs
@@ -30,10 +30,28 @@ fn removed_edge_is_missing_edge() {
 }
 
 #[test]
 fn renamed_element_is_changed_attribute() {
     let mut candidate = expected();
     candidate.structure[0].name.push_str(" X");
     let d = diff::diff(&expected(), &candidate);
     assert!(!d.equal);
     assert_eq!(d.changed_attributes.len(), 1);
 }
+
+#[test]
+fn activity_change_is_a_difference() {
+    let mut candidate = expected();
+    candidate.activities[0].name.push_str(" X");
+    let d = diff::diff(&expected(), &candidate);
+    assert!(!d.equal);
+    assert_eq!(d.changed_attributes.len(), 1);
+}
+
+#[test]
+fn document_level_change_is_a_difference() {
+    let mut candidate = expected();
+    candidate.project.push_str(" X");
+    let d = diff::diff(&expected(), &candidate);
+    assert!(!d.equal);
+    assert_eq!(d.changed_attributes.len(), 1);
+}
