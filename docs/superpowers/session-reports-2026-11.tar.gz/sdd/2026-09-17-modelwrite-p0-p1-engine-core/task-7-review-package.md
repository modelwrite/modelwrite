﻿# Task 7 review package

## Commit

f98ec36 feat: add C ABI for validation and the gate

## Diff stat

 Cargo.lock                  | 10 ++++++
 Cargo.toml                  |  2 +-
 engine/capi/Cargo.toml      | 20 +++++++++++
 engine/capi/src/lib.rs      | 88 +++++++++++++++++++++++++++++++++++++++++++++
 engine/capi/tests/capi.rs   | 48 +++++++++++++++++++++++++
 engine/include/modelwrite.h | 30 ++++++++++++++++
 6 files changed, 197 insertions(+), 1 deletion(-)

## Full diff (-U10)

diff --git a/Cargo.lock b/Cargo.lock
index 6b4c7ab..59d871e 100644
--- a/Cargo.lock
+++ b/Cargo.lock
@@ -107,20 +107,30 @@ name = "libc"
 version = "0.2.189"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "3eaf3ede3fee6db1a4c2ee091bf8a8b4dccdc6d17f656fb07896ee72867612f2"
 
 [[package]]
 name = "memchr"
 version = "2.8.3"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "cf8baf1c55e62ffcace7a9f06f4bd9cd3f0c4beb022d3b367256b91b87513d98"
 
+[[package]]
+name = "mw-capi"
+version = "0.1.0"
+dependencies = [
+ "mw-gate",
+ "mw-okf",
+ "mw-test-support",
+ "serde_json",
+]
+
 [[package]]
 name = "mw-gate"
 version = "0.1.0"
 dependencies = [
  "anyhow",
  "mw-graph",
  "mw-okf",
  "mw-test-support",
  "serde_json",
 ]
diff --git a/Cargo.toml b/Cargo.toml
index ab1bc4a..44a5990 100644
--- a/Cargo.toml
+++ b/Cargo.toml
@@ -1,13 +1,13 @@
 [workspace]
 resolver = "2"
-members = ["engine/okf", "engine/test-support", "engine/graph", "engine/gate"]
+members = ["engine/okf", "engine/test-support", "engine/graph", "engine/gate", "engine/capi"]
 
 [workspace.package]
 edition = "2021"
 rust-version = "1.75"
 license = "AGPL-3.0-or-later"
 repository = "https://github.com/modelwrite/modelwrite"
 
 [workspace.dependencies]
 anyhow = "1.0"
 hex = "0.4"
diff --git a/engine/capi/Cargo.toml b/engine/capi/Cargo.toml
new file mode 100644
index 0000000..b3e8a9a
--- /dev/null
+++ b/engine/capi/Cargo.toml
@@ -0,0 +1,20 @@
+[package]
+name = "mw-capi"
+version = "0.1.0"
+edition.workspace = true
+rust-version.workspace = true
+license.workspace = true
+publish = false
+
+[lib]
+name = "capi"
+crate-type = ["cdylib", "staticlib", "rlib"]
+
+[dependencies]
+mw-okf = { path = "../okf" }
+mw-gate = { path = "../gate" }
+serde_json.workspace = true
+
+[dev-dependencies]
+mw-test-support = { path = "../test-support" }
+serde_json.workspace = true
diff --git a/engine/capi/src/lib.rs b/engine/capi/src/lib.rs
new file mode 100644
index 0000000..7635bef
--- /dev/null
+++ b/engine/capi/src/lib.rs
@@ -0,0 +1,88 @@
+// SPDX-License-Identifier: AGPL-3.0-or-later
+//! C ABI for the modelwrite engine. All returned strings are owned by the
+//! caller and must be released with modelwrite_free_string.
+use std::ffi::{c_char, CString};
+
+fn err_string(message: &str) -> *mut c_char {
+    let payload = serde_json::json!({ "error": message }).to_string();
+    CString::new(payload)
+        .expect("message has no NUL")
+        .into_raw()
+}
+
+/// Version string; deliberately leaked, never freed.
+#[no_mangle]
+pub extern "C" fn modelwrite_version() -> *const c_char {
+    let s = CString::new(format!("modelwrite {}", env!("CARGO_PKG_VERSION")))
+        .expect("version has no NUL");
+    s.into_raw() as *const c_char
+}
+
+/// Validate one OKF document; returns a JSON ValidationReport string.
+///
+/// # Safety
+/// `json` must point to `len` readable bytes and remain valid for the call.
+#[no_mangle]
+pub unsafe extern "C" fn modelwrite_validate(json: *const u8, len: usize) -> *mut c_char {
+    if json.is_null() || len == 0 {
+        return err_string("empty input");
+    }
+    let bytes = unsafe { std::slice::from_raw_parts(json, len) };
+    let text = match std::str::from_utf8(bytes) {
+        Ok(t) => t,
+        Err(_) => return err_string("input is not UTF-8"),
+    };
+    let root = match serde_json::from_str::<okf::types::OkfRoot>(text) {
+        Ok(r) => r,
+        Err(e) => return err_string(&format!("parse error: {}", e)),
+    };
+    let report = okf::validate::validate(&root);
+    let payload = serde_json::to_string(&report).expect("report serializes");
+    CString::new(payload)
+        .expect("payload has no NUL")
+        .into_raw()
+}
+
+/// Run the round-trip gate; returns the JSON evidence string.
+///
+/// # Safety
+/// `reference` and `candidate` must each point to their corresponding
+/// length of readable bytes and remain valid for the call.
+#[no_mangle]
+pub unsafe extern "C" fn modelwrite_gate(
+    reference: *const u8,
+    reference_len: usize,
+    candidate: *const u8,
+    candidate_len: usize,
+) -> *mut c_char {
+    if reference.is_null() || reference_len == 0 || candidate.is_null() || candidate_len == 0 {
+        return err_string("empty input");
+    }
+    let parse = |ptr: *const u8, len: usize| -> Option<okf::types::OkfRoot> {
+        let bytes = unsafe { std::slice::from_raw_parts(ptr, len) };
+        let text = std::str::from_utf8(bytes).ok()?;
+        serde_json::from_str(text).ok()
+    };
+    let (Some(reference), Some(candidate)) = (
+        parse(reference, reference_len),
+        parse(candidate, candidate_len),
+    ) else {
+        return err_string("parse error: inputs must be OKF JSON documents");
+    };
+    let outcome = gate::run(&reference, &candidate, false);
+    let payload = serde_json::to_string(&outcome.evidence).expect("evidence serializes");
+    CString::new(payload)
+        .expect("payload has no NUL")
+        .into_raw()
+}
+
+/// Free a string returned by this library.
+///
+/// # Safety
+/// `ptr` must be null or a pointer previously returned by this library.
+#[no_mangle]
+pub unsafe extern "C" fn modelwrite_free_string(ptr: *mut c_char) {
+    if !ptr.is_null() {
+        drop(unsafe { CString::from_raw(ptr) });
+    }
+}
diff --git a/engine/capi/tests/capi.rs b/engine/capi/tests/capi.rs
new file mode 100644
index 0000000..01a441b
--- /dev/null
+++ b/engine/capi/tests/capi.rs
@@ -0,0 +1,48 @@
+// SPDX-License-Identifier: AGPL-3.0-or-later
+use std::ffi::CStr;
+
+#[test]
+fn version_returns_string() {
+    let ptr = capi::modelwrite_version();
+    let s = unsafe { CStr::from_ptr(ptr) }
+        .to_string_lossy()
+        .into_owned();
+    assert!(s.starts_with("modelwrite "));
+}
+
+#[test]
+fn validate_returns_json_report() {
+    let okf = test_support::load_okf_expected();
+    let ptr = unsafe { capi::modelwrite_validate(okf.as_ptr(), okf.len()) };
+    let s = unsafe { CStr::from_ptr(ptr) }
+        .to_string_lossy()
+        .into_owned();
+    let v: serde_json::Value = serde_json::from_str(&s).expect("JSON report");
+    assert!(v["valid"].as_bool().unwrap());
+    unsafe { capi::modelwrite_free_string(ptr) };
+}
+
+#[test]
+fn gate_returns_evidence() {
+    let a = test_support::load_okf_expected();
+    let b = a.clone();
+    let ptr = unsafe { capi::modelwrite_gate(a.as_ptr(), a.len(), b.as_ptr(), b.len()) };
+    let s = unsafe { CStr::from_ptr(ptr) }
+        .to_string_lossy()
+        .into_owned();
+    let v: serde_json::Value = serde_json::from_str(&s).expect("JSON evidence");
+    assert!(v["passed"].as_bool().unwrap());
+    unsafe { capi::modelwrite_free_string(ptr) };
+}
+
+#[test]
+fn validate_rejects_garbage() {
+    let garbage = "not json";
+    let ptr = unsafe { capi::modelwrite_validate(garbage.as_ptr(), garbage.len()) };
+    let s = unsafe { CStr::from_ptr(ptr) }
+        .to_string_lossy()
+        .into_owned();
+    let v: serde_json::Value = serde_json::from_str(&s).expect("JSON error report");
+    assert!(v["error"].is_string());
+    unsafe { capi::modelwrite_free_string(ptr) };
+}
diff --git a/engine/include/modelwrite.h b/engine/include/modelwrite.h
new file mode 100644
index 0000000..72ffc87
--- /dev/null
+++ b/engine/include/modelwrite.h
@@ -0,0 +1,30 @@
+/* SPDX-License-Identifier: AGPL-3.0-or-later */
+#ifndef MODELWRITE_H
+#define MODELWRITE_H
+
+#include <stddef.h>
+
+#ifdef __cplusplus
+extern "C" {
+#endif
+
+/* Version string; never free it. */
+const char *modelwrite_version(void);
+
+/* Validate one OKF JSON document; returns a JSON report string.
+   The caller owns the result and must free it with modelwrite_free_string. */
+char *modelwrite_validate(const unsigned char *json, size_t len);
+
+/* Run the round-trip fidelity gate; returns the JSON evidence string.
+   The caller owns the result and must free it with modelwrite_free_string. */
+char *modelwrite_gate(const unsigned char *reference, size_t reference_len,
+                      const unsigned char *candidate, size_t candidate_len);
+
+/* Free a string returned by this library. */
+void modelwrite_free_string(char *ptr);
+
+#ifdef __cplusplus
+}
+#endif
+
+#endif
