﻿### Task 7: engine/capi â€” the C ABI

**Files:**
- Create: engine/capi/Cargo.toml
- Create: engine/capi/src/lib.rs
- Create: engine/include/modelwrite.h
- Test: engine/capi/tests/capi.rs
- Modify: Cargo.toml (add engine/capi to workspace members)

**Interfaces:**
- Consumes: okf::{types, validate}; gate::run.
- Produces: four exported C symbols, stable from now on:
  - const char *modelwrite_version(void)
  - char *modelwrite_validate(const unsigned char *json, size_t len) â€” returns a JSON ValidationReport string.
  - char *modelwrite_gate(const unsigned char *reference, size_t reference_len, const unsigned char *candidate, size_t candidate_len) â€” returns the JSON gate evidence string.
  - void modelwrite_free_string(char *ptr) â€” frees any string returned above.
  All returned strings are owned by the caller and must be released with modelwrite_free_string.

- [ ] **Step 1: Write engine/capi/Cargo.toml**

```toml
[package]
name = "mw-capi"
version = "0.1.0"
edition.workspace = true
rust-version.workspace = true
license.workspace = true
publish = false

[lib]
name = "capi"
crate-type = ["cdylib", "staticlib", "rlib"]

[dependencies]
mw-okf = { path = "../okf" }
mw-gate = { path = "../gate" }
serde_json.workspace = true

[dev-dependencies]
mw-test-support = { path = "../test-support" }
serde_json.workspace = true
```

- [ ] **Step 2: Add engine/capi to the workspace members in the root Cargo.toml**

```toml
members = ["engine/okf", "engine/test-support", "engine/graph", "engine/gate", "engine/capi"]
```

- [ ] **Step 3: Write engine/capi/src/lib.rs**

```rust
// SPDX-License-Identifier: AGPL-3.0-or-later
//! C ABI for the modelwrite engine. All returned strings are owned by the
//! caller and must be released with modelwrite_free_string.
use std::ffi::{c_char, CStr, CString};

fn err_string(message: &str) -> *mut c_char {
    let payload = serde_json::json!({ "error": message }).to_string();
    CString::new(payload).expect("message has no NUL").into_raw()
}

/// Version string; deliberately leaked, never freed.
#[no_mangle]
pub extern "C" fn modelwrite_version() -> *const c_char {
    let s = CString::new(format!("modelwrite {}", env!("CARGO_PKG_VERSION"))).expect("version has no NUL");
    s.into_raw() as *const c_char
}

/// Validate one OKF document; returns a JSON ValidationReport string.
#[no_mangle]
pub extern "C" fn modelwrite_validate(json: *const u8, len: usize) -> *mut c_char {
    if json.is_null() || len == 0 {
        return err_string("empty input");
    }
    let bytes = unsafe { std::slice::from_raw_parts(json, len) };
    let text = match std::str::from_utf8(bytes) {
        Ok(t) => t,
        Err(_) => return err_string("input is not UTF-8"),
    };
    let root = match serde_json::from_str::<okf::types::OkfRoot>(text) {
        Ok(r) => r,
        Err(e) => return err_string(&format!("parse error: {}", e)),
    };
    let report = okf::validate::validate(&root);
    let payload = serde_json::to_string(&report).expect("report serializes");
    CString::new(payload).expect("payload has no NUL").into_raw()
}

/// Run the round-trip gate; returns the JSON evidence string.
#[no_mangle]
pub extern "C" fn modelwrite_gate(
    reference: *const u8,
    reference_len: usize,
    candidate: *const u8,
    candidate_len: usize,
) -> *mut c_char {
    if reference.is_null() || reference_len == 0 || candidate.is_null() || candidate_len == 0 {
        return err_string("empty input");
    }
    let parse = |ptr: *const u8, len: usize| -> Option<okf::types::OkfRoot> {
        let bytes = unsafe { std::slice::from_raw_parts(ptr, len) };
        let text = std::str::from_utf8(bytes).ok()?;
        serde_json::from_str(text).ok()
    };
    let (Some(reference), Some(candidate)) = (parse(reference, reference_len), parse(candidate, candidate_len)) else {
        return err_string("parse error: inputs must be OKF JSON documents");
    };
    let outcome = gate::run(&reference, &candidate, false);
    let payload = serde_json::to_string(&outcome.evidence).expect("evidence serializes");
    CString::new(payload).expect("payload has no NUL").into_raw()
}

/// Free a string returned by this library.
#[no_mangle]
pub extern "C" fn modelwrite_free_string(ptr: *mut c_char) {
    if !ptr.is_null() {
        drop(unsafe { CString::from_raw(ptr) });
    }
}
```

- [ ] **Step 4: Write engine/include/modelwrite.h**

```c
/* SPDX-License-Identifier: AGPL-3.0-or-later */
#ifndef MODELWRITE_H
#define MODELWRITE_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Version string; never free it. */
const char *modelwrite_version(void);

/* Validate one OKF JSON document; returns a JSON report string.
   The caller owns the result and must free it with modelwrite_free_string. */
char *modelwrite_validate(const unsigned char *json, size_t len);

/* Run the round-trip fidelity gate; returns the JSON evidence string.
   The caller owns the result and must free it with modelwrite_free_string. */
char *modelwrite_gate(const unsigned char *reference, size_t reference_len,
                      const unsigned char *candidate, size_t candidate_len);

/* Free a string returned by this library. */
void modelwrite_free_string(char *ptr);

#ifdef __cplusplus
}
#endif

#endif
```

- [ ] **Step 5: Write engine/capi/tests/capi.rs**

```rust
// SPDX-License-Identifier: AGPL-3.0-or-later
use std::ffi::CStr;

#[test]
fn version_returns_string() {
    let ptr = capi::modelwrite_version();
    let s = unsafe { CStr::from_ptr(ptr) }.to_string_lossy().into_owned();
    assert!(s.starts_with("modelwrite "));
}

#[test]
fn validate_returns_json_report() {
    let okf = test_support::load_okf_expected();
    let ptr = capi::modelwrite_validate(okf.as_ptr(), okf.len());
    let s = unsafe { CStr::from_ptr(ptr) }.to_string_lossy().into_owned();
    let v: serde_json::Value = serde_json::from_str(&s).expect("JSON report");
    assert!(v["valid"].as_bool().unwrap());
    capi::modelwrite_free_string(ptr);
}

#[test]
fn gate_returns_evidence() {
    let a = test_support::load_okf_expected();
    let b = a.clone();
    let ptr = capi::modelwrite_gate(a.as_ptr(), a.len(), b.as_ptr(), b.len());
    let s = unsafe { CStr::from_ptr(ptr) }.to_string_lossy().into_owned();
    let v: serde_json::Value = serde_json::from_str(&s).expect("JSON evidence");
    assert!(v["passed"].as_bool().unwrap());
    capi::modelwrite_free_string(ptr);
}

#[test]
fn validate_rejects_garbage() {
    let garbage = "not json";
    let ptr = capi::modelwrite_validate(garbage.as_ptr(), garbage.len());
    let s = unsafe { CStr::from_ptr(ptr) }.to_string_lossy().into_owned();
    let v: serde_json::Value = serde_json::from_str(&s).expect("JSON error report");
    assert!(v["error"].is_string());
    capi::modelwrite_free_string(ptr);
}
```

- [ ] **Step 6: Run the tests**

Run: cargo test -p mw-capi
Expected: all 4 tests pass.

- [ ] **Step 7: Format, lint and commit**

```powershell
cargo fmt --all
cargo clippy -p mw-capi --all-targets -- -D warnings
git add Cargo.toml engine/capi engine/include
git commit -m "feat: add C ABI for validation and the gate"
```

---


