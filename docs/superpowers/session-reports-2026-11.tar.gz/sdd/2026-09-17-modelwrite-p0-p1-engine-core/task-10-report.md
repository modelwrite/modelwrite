# Task 10 Report: judge/ — the gate-as-judge harness

## Status

DONE

## Commit

1a21f5c feat: add gate-as-judge harness

## Test summary

python -m unittest discover -s judge/tests -p "test_*.py" -v — Ran 2 tests, both OK (0 failures, 0 errors).

## Smoke commands and observed output

Build:

    cargo build --workspace
    # Finished `dev` profile [unoptimized + debuginfo] target(s) in 0.29s (exit 0)

Self-comparison (expected → expected):

    python judge/judge.py --ref-dir sample/corpus/coffee-machine/okf/expected --candidate-dir sample/corpus/coffee-machine/okf/expected --gate-bin target/debug/mw-gate.exe

    PASS  coffee_machine_model
    (exit code 0)

Corrupted comparison (expected → corrupted):

    python judge/judge.py --ref-dir sample/corpus/coffee-machine/okf/expected --candidate-dir sample/corpus/coffee-machine/okf/corrupted --gate-bin target/debug/mw-gate.exe

    FAIL  coffee_machine_model  (roundtrip: 1 missing elements, 0 extra elements, 3 missing edges, 0 extra edges, 0 changed attributes; integration: 1 isolated nodes; integration: 3 connected components)
    (exit code 1)

Both smoke runs behaved exactly as the brief specifies: PASS with exit 0 on the
self-comparison, FAIL with exit 1 on the corrupted comparison.

## Self-review

- stdlib only: judge.py imports argparse, json, subprocess, sys, pathlib — all stdlib. No pip installs.
- No assertion weakened: the two tests use the brief's exact assertions (assertEqual(set(pairs), {"a"}) and assertIn for "PASS  a", "FAIL  b", "2 connected components").
- Pairing rule by filename: find_pairs pairs *.json files by matching basename across the two directories, keyed by stem.
- Exit codes match the brief: 0 when all pass, 1 when any fails, 2 when no pairs are found.

## Concerns

None.
