﻿# Task 5 re-review package (coverage fix)

## Commit

f349a3e fix: count only requirement endpoints in coverage, and pin the corpus coverage

## Diff stat

 .../2026-09-17-modelwrite-p0-p1-engine-core.md     | 26 +++++++++++++++++++---
 engine/graph/src/lib.rs                            | 11 +++++++--
 engine/graph/tests/graph_stats.rs                  | 15 +++++++++++++
 3 files changed, 47 insertions(+), 5 deletions(-)

## Full diff (-U10)

diff --git a/docs/superpowers/plans/2026-09-17-modelwrite-p0-p1-engine-core.md b/docs/superpowers/plans/2026-09-17-modelwrite-p0-p1-engine-core.md
index 352f99d..0bca029 100644
--- a/docs/superpowers/plans/2026-09-17-modelwrite-p0-p1-engine-core.md
+++ b/docs/superpowers/plans/2026-09-17-modelwrite-p0-p1-engine-core.md
@@ -1656,24 +1656,29 @@ pub fn requirement_coverage(root: &OkfRoot) -> CoverageReport {
                     refined += 1;
                     covered.insert(t);
                 }
             }
             "Verify" => {
                 if req_ids.contains(t) {
                     verified += 1;
                     covered.insert(t);
                 }
             }
-            "Allocate" => {
-                if req_ids.contains(t) || req_ids.contains(s) {
-                    allocated += 1;
+            "Allocate" if req_ids.contains(t) || req_ids.contains(s) => {
+                allocated += 1;
+                // Count only endpoints that really are requirements: an allocate edge can
+                // connect a function to a part, and inserting a non-requirement id would
+                // inflate the covered count reported in the gate evidence.
+                if req_ids.contains(t) {
                     covered.insert(t);
+                }
+                if req_ids.contains(s) {
                     covered.insert(s);
                 }
             }
             _ => {}
         }
     }
     let mut uncovered: Vec<String> = root
         .requirements
         .iter()
         .filter(|r| !covered.contains(r.id.as_str()))
@@ -1752,20 +1757,35 @@ fn two_components_are_counted() {
 }
 
 #[test]
 fn coverage_counts_traceability() {
     let cov = requirement_coverage(&okf(TINY));
     assert_eq!(cov.total, 2);
     assert_eq!(cov.satisfied, 1);
     assert_eq!(cov.covered, 1);
     assert_eq!(cov.uncovered, vec!["r2"]);
 }
+
+/// The reference model carries 20 Satisfy, 3 Refine, 1 Verify and 3 Allocate edges,
+/// and 15 of its 25 requirements are covered by at least one of them. Pinning the
+/// coverage keeps this measured claim honest: it is the number the gate reports.
+#[test]
+fn corpus_coverage_is_pinned() {
+    let cov = requirement_coverage(&expected());
+    assert_eq!(cov.total, 25);
+    assert_eq!(cov.satisfied, 20);
+    assert_eq!(cov.refined, 3);
+    assert_eq!(cov.verified, 1);
+    assert_eq!(cov.allocated, 0);
+    assert_eq!(cov.covered, 15);
+    assert_eq!(cov.uncovered.len(), 10);
+}
 ```
 
 - [ ] **Step 5: Run the tests**
 
 Run: cargo test -p mw-graph
 Expected: all 4 tests pass. If corpus_is_fully_integrated fails, stop and report the actual isolated nodes and component sizes; do not change the assertions to match.
 
 - [ ] **Step 6: Format, lint and commit**
 
 ```powershell
diff --git a/engine/graph/src/lib.rs b/engine/graph/src/lib.rs
index 1bddda9..d57b75f 100644
--- a/engine/graph/src/lib.rs
+++ b/engine/graph/src/lib.rs
@@ -97,22 +97,29 @@ pub fn requirement_coverage(root: &OkfRoot) -> CoverageReport {
                 }
             }
             "Verify" => {
                 if req_ids.contains(t) {
                     verified += 1;
                     covered.insert(t);
                 }
             }
             "Allocate" if req_ids.contains(t) || req_ids.contains(s) => {
                 allocated += 1;
-                covered.insert(t);
-                covered.insert(s);
+                // Count only endpoints that really are requirements. An allocate edge
+                // can connect a function to a part, and inserting a non-requirement id
+                // here would inflate the covered count reported in the gate evidence.
+                if req_ids.contains(t) {
+                    covered.insert(t);
+                }
+                if req_ids.contains(s) {
+                    covered.insert(s);
+                }
             }
             _ => {}
         }
     }
     let mut uncovered: Vec<String> = root
         .requirements
         .iter()
         .filter(|r| !covered.contains(r.id.as_str()))
         .map(|r| r.id.clone())
         .collect();
diff --git a/engine/graph/tests/graph_stats.rs b/engine/graph/tests/graph_stats.rs
index 9a228d0..8c56a4e 100644
--- a/engine/graph/tests/graph_stats.rs
+++ b/engine/graph/tests/graph_stats.rs
@@ -55,10 +55,25 @@ fn two_components_are_counted() {
 }
 
 #[test]
 fn coverage_counts_traceability() {
     let cov = requirement_coverage(&okf(TINY));
     assert_eq!(cov.total, 2);
     assert_eq!(cov.satisfied, 1);
     assert_eq!(cov.covered, 1);
     assert_eq!(cov.uncovered, vec!["r2"]);
 }
+
+/// The reference model carries 20 Satisfy, 3 Refine, 1 Verify and 3 Allocate edges,
+/// and 15 of its 25 requirements are covered by at least one of them. Pinning the
+/// coverage keeps this measured claim honest: it is the number the gate reports.
+#[test]
+fn corpus_coverage_is_pinned() {
+    let cov = requirement_coverage(&expected());
+    assert_eq!(cov.total, 25);
+    assert_eq!(cov.satisfied, 20);
+    assert_eq!(cov.refined, 3);
+    assert_eq!(cov.verified, 1);
+    assert_eq!(cov.allocated, 0);
+    assert_eq!(cov.covered, 15);
+    assert_eq!(cov.uncovered.len(), 10);
+}
