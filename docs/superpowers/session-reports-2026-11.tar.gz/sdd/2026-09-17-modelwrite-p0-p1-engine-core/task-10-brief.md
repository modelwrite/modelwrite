﻿### Task 10: judge/ â€” the gate-as-judge harness

**Files:**
- Create: judge/judge.py
- Test: judge/tests/test_judge.py

**Interfaces:**
- Consumes: the mw-gate binary (built by cargo build --workspace).
- Produces: python judge/judge.py --ref-dir DIR --candidate-dir DIR [--gate-bin PATH] â€” pairs OKF files with matching filenames across the two directories, runs the gate on each pair with --json, prints one PASS/FAIL line per pair, exits 0 when all pass and 1 when any fails, 2 when no pairs are found.

- [ ] **Step 1: Write judge/judge.py**

```python
# SPDX-License-Identifier: AGPL-3.0-or-later
"""Gate-as-judge harness: run mw-gate over pairs of OKF files in two directories.

Standalone scoring for model migrations, or the scoring step in an agent
loop. Usage:

    python judge/judge.py --ref-dir DIR --candidate-dir DIR [--gate-bin PATH]
"""
import argparse
import json
import subprocess
import sys
from pathlib import Path


def find_pairs(ref_dir: Path, cand_dir: Path) -> dict[str, tuple[Path, Path]]:
    pairs: dict[str, tuple[Path, Path]] = {}
    for ref in sorted(ref_dir.glob("*.json")):
        cand = cand_dir / ref.name
        if cand.is_file():
            pairs[ref.stem] = (ref, cand)
    return pairs


def run_gate(gate_bin: Path, reference: Path, candidate: Path) -> dict:
    proc = subprocess.run(
        [str(gate_bin), "--reference", str(reference), "--candidate", str(candidate), "--json"],
        capture_output=True,
        text=True,
    )
    try:
        payload = json.loads(proc.stdout.strip())
        return payload
    except json.JSONDecodeError:
        return {
            "passed": False,
            "failures": [],
            "parseError": True,
            "raw": proc.stdout.strip(),
            "exitCode": proc.returncode,
            "stderr": proc.stderr.strip(),
        }


def render_table(results: list[tuple[str, dict]]) -> str:
    lines = []
    for name, payload in results:
        if payload.get("parseError"):
            lines.append(f"FAIL  {name}  (gate did not return JSON: {payload.get('stderr', '')})")
        elif payload.get("passed"):
            lines.append(f"PASS  {name}")
        else:
            reasons = "; ".join(payload.get("failures", []))
            lines.append(f"FAIL  {name}  ({reasons})")
    return "\n".join(lines)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Gate-as-judge harness for OKF migrations")
    parser.add_argument("--ref-dir", required=True, type=Path)
    parser.add_argument("--candidate-dir", required=True, type=Path)
    parser.add_argument("--gate-bin", default="mw-gate", type=Path)
    args = parser.parse_args(argv)
    pairs = find_pairs(args.ref_dir, args.candidate_dir)
    if not pairs:
        print("no matching OKF pairs found", file=sys.stderr)
        return 2
    results: list[tuple[str, dict]] = []
    for name, (ref, cand) in pairs.items():
        results.append((name, run_gate(args.gate_bin, ref, cand)))
    print(render_table(results))
    return 0 if all(payload.get("passed") for _, payload in results) else 1


if __name__ == "__main__":
    sys.exit(main())
```

- [ ] **Step 2: Write judge/tests/test_judge.py**

```python
# SPDX-License-Identifier: AGPL-3.0-or-later
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import judge


class JudgeTests(unittest.TestCase):
    def test_find_pairs(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            ref = root / "ref"
            cand = root / "cand"
            ref.mkdir()
            cand.mkdir()
            (ref / "a.json").write_text("{}", encoding="utf-8")
            (ref / "b.json").write_text("{}", encoding="utf-8")
            (cand / "a.json").write_text("{}", encoding="utf-8")
            pairs = judge.find_pairs(ref, cand)
            self.assertEqual(set(pairs), {"a"})

    def test_render_table(self):
        out = judge.render_table([
            ("a", {"passed": True, "failures": []}),
            ("b", {"passed": False, "failures": ["integration: 2 connected components"]}),
        ])
        self.assertIn("PASS  a", out)
        self.assertIn("FAIL  b", out)
        self.assertIn("2 connected components", out)


if __name__ == "__main__":
    unittest.main()
```

- [ ] **Step 3: Run the unit tests**

Run: python -m unittest discover -s judge/tests -p "test_*.py" -v
Expected: 2 tests pass.

- [ ] **Step 4: Smoke test against the corpus (spawns the gate binary)**

```powershell
cargo build --workspace
python judge/judge.py --ref-dir sample/corpus/coffee-machine/okf/expected --candidate-dir sample/corpus/coffee-machine/okf/expected --gate-bin target/debug/mw-gate.exe
python judge/judge.py --ref-dir sample/corpus/coffee-machine/okf/expected --candidate-dir sample/corpus/coffee-machine/okf/corrupted --gate-bin target/debug/mw-gate.exe
```

Expected: the first run prints PASS coffee_machine_model and exits 0; the second prints FAIL coffee_machine_model and exits 1.

- [ ] **Step 5: Commit**

```powershell
git add judge
git commit -m "feat: add gate-as-judge harness"
```

---


