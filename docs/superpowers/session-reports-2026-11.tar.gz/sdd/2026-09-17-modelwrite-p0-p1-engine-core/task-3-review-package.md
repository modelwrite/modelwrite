﻿# Task 3 review package

## Commits

4bcb0f9 chore: port coffee-machine corpus into sample/

## Diff stat

 sample/README.md                                   |  16 +
 sample/corpus/coffee-machine/README.md             |  20 +
 .../legacy/CoffeeMachine-SysML-Model.mdzip         | Bin 0 -> 216922 bytes
 .../okf/expected/coffee_machine_model.json         |   1 +
 sample/demo/CoffeeMachine-Showcase-standalone.html | 977 +++++++++++++++++++++
 5 files changed, 1014 insertions(+)

## Full diff (-U10, mdzip/zip/html binary content omitted by git)

diff --git a/sample/README.md b/sample/README.md
new file mode 100644
index 0000000..c7deb74
--- /dev/null
+++ b/sample/README.md
@@ -0,0 +1,16 @@
+# Sample
+
+The coffee-machine corpus: a complete SysML model and its OKF export,
+shared as the regression fixture for the whole project.
+
+- corpus/coffee-machine/okf/expected/ — the exported model (OKF), the
+  reference snapshot the gate must accept unchanged.
+- corpus/coffee-machine/okf/corrupted/ — a deliberately broken copy the
+  gate must reject (created by scripts/make_corrupted.py in Task 6).
+- corpus/coffee-machine/legacy/ — the CATIA Magic project (.mdzip).
+- demo/ — the standalone portal showcase from the knowledge pack.
+- scripts/ — fixture generators; never hand-edit a fixture.
+
+The corpus originates from the MEMKO MBSEF-SEng coffee machine course work
+by Alex Kovaceski (September 2026) and is shared with the permission of
+the author. See NOTICE.md.
diff --git a/sample/corpus/coffee-machine/README.md b/sample/corpus/coffee-machine/README.md
new file mode 100644
index 0000000..ce0ab7a
--- /dev/null
+++ b/sample/corpus/coffee-machine/README.md
@@ -0,0 +1,20 @@
+# Coffee machine corpus
+
+Model: bean-to-cup coffee machine, SysML v1, built in CATIA Magic
+(Magic Systems of Systems Architect 2026x) during the MEMKO MBSEF-SEng
+course.
+
+Known-good numbers (pinned by tests and by the evidence annex):
+
+- graph nodes: 99
+- graph edges: 165
+- requirements: 25
+- blocks: 49
+- signals: 9
+- activities: 8
+- connected components: 1
+- isolated nodes: 0
+
+Workflow: edit the legacy model in CATIA Magic, re-run the exporter, and
+place the fresh export at okf/expected/coffee_machine_model.json. The gate
+CI job proves the refresh loses nothing.
diff --git a/sample/corpus/coffee-machine/legacy/CoffeeMachine-SysML-Model.mdzip b/sample/corpus/coffee-machine/legacy/CoffeeMachine-SysML-Model.mdzip
new file mode 100644
index 0000000..01f78ee
Binary files /dev/null and b/sample/corpus/coffee-machine/legacy/CoffeeMachine-SysML-Model.mdzip differ
diff --git a/sample/corpus/coffee-machine/okf/expected/coffee_machine_model.json b/sample/corpus/coffee-machine/okf/expected/coffee_machine_model.json
new file mode 100644
index 0000000..15eb1c8
--- /dev/null
+++ b/sample/corpus/coffee-machine/okf/expected/coffee_machine_model.json
@@ -0,0 +1 @@
+{"project":"Coffee Machine Model","exportedAt":"Thu Sep 17 11:36:29 AEST 2026","summary":{"blocks":49,"requirements":25,"interfaces":0,"signals":9,"activities":8,"graphNodes":99,"graphEdges":165},"structure":[{"id":"_2026x_1_12a70364_1789357107731_106889_3635","name":"Coffee Machine","kind":"block","stereotypes":["Block"],"attributes":[{"name":"water System","type":"Water System","aggregation":"composite","default":""},{"name":"electrical System","type":"Electrical System","aggregation":"composite","default":""},{"name":"brew System","type":"Brew System","aggregation":"composite","default":""},{"name":"coffeeSize","type":"coffeeSize","aggregation":"composite","default":""},{"name":"coffeeStrength","type":"coffeeStrength","aggregation":"composite","default":""},{"name":"selectionMade","type":"Boolean","aggregation":"composite","default":""},{"name":"coffeeResult","type":"coffeeResult","aggregation":"composite","default":""},{"name":"coffee Machine Production","type":"Coffee Machine Production","aggregation":"none","default":""},{"name":"Waterin","type":"Water Flow Port","aggregation":"composite","default":""},{"name":"Coffee beans in","type":"Coffee State","aggregation":"composite","default":""},{"name":"dregs","type":"Waste Port","aggregation":"composite","default":""},{"name":"Coffee Dispensed","type":"Drink outlet","aggregation":"composite","default":""},{"name":"liquid waste","type":"Waste Port","aggregation":"composite","default":""},{"name":"p2","type":"GPO","aggregation":"composite","default":""}],"documentation":""},{"id":"_2026x_1_12a70364_1789357175665_504215_3638","name":"Water System","kind":"block","stereotypes":["Block"],"attributes":[{"name":"inlet","type":"Water Inlet","aggregation":"none","default":""}],"documentation":""},{"id":"_2026x_1_12a70364_1789357305852_992852_3641","name":"Electrical System","kind":"block","stereotypes":["Block"],"attributes":[],"documentation":""},{"id":"_2026x_1_12a70364_1789357381144_263298_3644","name":"Brew System","kind":"block","stereotypes":["Block"],"attributes":[],"documentation":""},{"id":"_2026x_1_12a70364_1789358228897_970701_3681","name":"Coffee Machine Production","kind":"block","stereotypes":["Block"],"attributes":[],"documentation":""},{"id":"_2026x_1_12a70364_1789358512516_28052_3684","name":"Water Flow Port","kind":"block","stereotypes":["InterfaceBlock"],"attributes":[{"name":"water","type":"","aggregation":"none","default":""}],"documentation":""},{"id":"_2026x_1_12a70364_1789358695241_447494_3686","name":"Coffee State","kind":"block","stereotypes":["InterfaceBlock"],"attributes":[{"name":"coffeeBeans","type":"","aggregation":"none","default":""}],"documentation":""},{"id":"_2026x_1_12a70364_1789358720758_903471_3688","name":"Waste Port","kind":"block","stereotypes":["InterfaceBlock"],"attributes":[{"name":"waste","type":"","aggregation":"none","default":""}],"documentation":""},{"id":"_2026x_1_12a70364_1789358753658_420800_3690","name":"Drink outlet","kind":"block","stereotypes":["InterfaceBlock"],"attributes":[{"name":"drink","type":"","aggregation":"none","default":""}],"documentation":""},{"id":"_2026x_1_12a70364_1789358830928_193983_3693","name":"GPO","kind":"block","stereotypes":["InterfaceBlock"],"attributes":[{"name":"power","type":"","aggregation":"none","default":""}],"documentation":""},{"id":"_2026x_1_12a70364_1789365065038_185163_3840","name":"Water Inlet","kind":"block","stereotypes":["InterfaceBlock"],"attributes":[],"documentation":""},{"id":"_2026x_1_12a70364_1789365155322_752872_3841","name":"Coffee","kind":"block","stereotypes":["Block"],"attributes":[],"documentation":""},{"id":"_2026x_1_12a70364_1789365188589_930663_3842","name":"Coffee Beans","kind":"block","stereotypes":["Block"],"attributes":[],"documentation":""},{"id":"_2026x_1_12a70364_1789365192860_189919_3843","name":"Water","kind":"block","stereotypes":["Block"],"attributes":[],"documentation":""},{"id":"_2026x_1_12a70364_1789363113514_607533_3714","name":"Brew Subsystem","kind":"block","stereotypes":["Block"],"attributes":[{"name":"bean Storage","type":"Bean Storage","aggregation":"composite","default":""},{"name":"brewing Unit","type":"Brewing Unit","aggregation":"composite","default":""},{"name":"doser Unit","type":"Doser Unit","aggregation":"composite","default":""},{"name":"grinder","type":"Grinder","aggregation":"composite","default":""},{"name":"grounds Drawer","type":"Grounds Drawer","aggregation":"composite","default":""}],"documentation":""},{"id":"_2026x_1_12a70364_1789363134214_804452_3715","name":"Control Subsystem","kind":"block","stereotypes":["Block"],"attributes":[{"name":"control Module","type":"Control Module","aggregation":"composite","default":""},{"name":"user Interface Panel","type":"User Interface Panel","aggregation":"composite","default":""}],"documentation":""},{"id":"_2026x_1_12a70364_1789363176200_671776_3716","name":"Dispensing Subsystem","kind":"block","stereotypes":["Block"],"attributes":[{"name":"coffee Outlet","type":"Coffee Outlet","aggregation":"composite","default":""},{"name":"drip Tray","type":"Drip Tray","aggregation":"composite","default":""}],"documentation":""},{"id":"_2026x_1_12a70364_1789363180535_753073_3717","name":"Power Subsystem","kind":"block","stereotypes":["Block"],"attributes":[{"name":"door Switch","type":"Door Switch","aggregation":"composite","default":""},{"name":"mains Cord","type":"Mains Cord","aggregation":"composite","default":""},{"name":"mains Switch","type":"Mains Switch","aggregation":"composite","default":""},{"name":"power Supply","type":"Power Supply","aggregation":"composite","default":""}],"documentation":""},{"id":"_2026x_1_12a70364_1789363184788_487139_3718","name":"Water Subsystem","kind":"block","stereotypes":["Block"],"attributes":[{"name":"boiler","type":"Boiler","aggregation":"composite","default":""},{"name":"flow Meter","type":"Flow Meter","aggregation":"composite","default":""},{"name":"water Pump","type":"Water Pump","aggregation":"composite","default":""},{"name":"water Tank","type":"Water Tank","aggregation":"composite","default":""},{"name":"water Valve","type":"Water Valve","aggregation":"composite","default":""}],"documentation":""},{"id":"_2026x_1_12a70364_1789363224675_90261_3719","name":"Bean Storage","kind":"block","stereotypes":["Block"],"attributes":[{"name":"storedBeans","type":"Coffee Beans","aggregation":"none","default":""}],"documentation":""},{"id":"_2026x_1_12a70364_1789363229077_574630_3720","name":"Brewing Unit","kind":"block","stereotypes":["Block"],"attributes":[],"documentation":""},{"id":"_2026x_1_12a70364_1789363233424_933473_3721","name":"Doser Unit","kind":"block","stereotypes":["Block"],"attributes":[],"documentation":""},{"id":"_2026x_1_12a70364_1789363237787_500380_3722","name":"Grinder","kind":"block","stereotypes":["Block"],"attributes":[],"documentation":""},{"id":"_2026x_1_12a70364_1789363242138_385667_3723","name":"Grounds Drawer","kind":"block","stereotypes":["Block"],"attributes":[],"documentation":""},{"id":"_2026x_1_12a70364_1789363276685_64862_3724","name":"Control Module","kind":"block","stereotypes":["Block"],"attributes":[],"documentation":""},{"id":"_2026x_1_12a70364_1789363281032_103275_3725","name":"User Interface Panel","kind":"block","stereotypes":["Block"],"attributes":[],"documentation":""},{"id":"_2026x_1_12a70364_1789363285378_732895_3726","name":"Coffee Outlet","kind":"block","stereotypes":["Block"],"attributes":[],"documentation":""},{"id":"_2026x_1_12a70364_1789363289724_897457_3727","name":"Drip Tray","kind":"block","stereotypes":["Block"],"attributes":[],"documentation":""},{"id":"_2026x_1_12a70364_1789363293999_849627_3728","name":"Door Switch","kind":"block","stereotypes":["Block"],"attributes":[],"documentation":""},{"id":"_2026x_1_12a70364_1789363326324_823109_3729","name":"Mains Cord","kind":"block","stereotypes":["Block"],"attributes":[],"documentation":""},{"id":"_2026x_1_12a70364_1789363330606_330250_3730","name":"Mains Switch","kind":"block","stereotypes":["Block"],"attributes":[],"documentation":""},{"id":"_2026x_1_12a70364_1789363334952_109655_3731","name":"Power Supply","kind":"block","stereotypes":["Block"],"attributes":[],"documentation":""},{"id":"_2026x_1_12a70364_1789363551438_409574_3734","name":"Boiler","kind":"block","stereotypes":["Block"],"attributes":[{"name":"inputWaterTemperature","type":"Real","aggregation":"composite","default":"25.0"},{"name":"outputWaterTemperature","type":"Real","aggregation":"composite","default":""},{"name":"boilingFactor","type":"Real","aggregation":"composite","default":"0.6"},{"name":"targetWaterTemperature","type":"Real","aggregation":"composite","default":"84.0"},{"name":"waterTemperatureAtTargetTime","type":"Real","aggregation":"composite","default":""}],"documentation":""},{"id":"_2026x_1_12a70364_1789363585791_503580_3735","name":"Flow Meter","kind":"block","stereotypes":["Block"],"attributes":[],"documentation":""},{"id":"_2026x_1_12a70364_1789363591862_529655_3736","name":"Water Pump","kind":"block","stereotypes":["Block"],"attributes":[],"documentation":""},{"id":"_2026x_1_12a70364_1789363775704_719608_3739","name":"Water Tank","kind":"block","stereotypes":["Block"],"attributes":[{"name":"storedWater","type":"Water","aggregation":"none","default":""}],"documentation":""},{"id":"_2026x_1_12a70364_1789363832704_318902_3740","name":"Water Valve","kind":"block","stereotypes":["Block"],"attributes":[],"documentation":""},{"id":"_2026x_1_12a70364_1789363922516_578822_3741","name":"Coffee Machine System","kind":"block","stereotypes":["Block"],"attributes":[{"name":"brew Subsystem","type":"Brew Subsystem","aggregation":"composite","default":""},{"name":"control Subsystem","type":"Control Subsystem","aggregation":"composite","default":""},{"name":"dispensing Subsystem","type":"Dispensing Subsystem","aggregation":"composite","default":""},{"name":"power Subsystem","type":"Power Subsystem","aggregation":"composite","default":""},{"name":"water Subsystem","type":"Water Subsystem","aggregation":"composite","default":""},{"name":"dispensedCoffee","type":"Coffee","aggregation":"none","default":""}],"documentation":""},{"id":"_2026x_1_12a70364_1789602694850_639924_6114","name":"Isolate Power (RCD trip)","kind":"block","stereotypes":[],"attributes":[],"documentation":""},{"id":"_2026x_1_12a70364_1789524947739_455059_5824","name":"Coffee Consumer","kind":"actor","stereotypes":["Actor"],"attributes":[],"documentation":""},{"id":"_2026x_1_12a70364_1789524947844_364892_5825","name":"Maintenance Operator","kind":"actor","stereotypes":["Actor"],"attributes":[],"documentation":""},{"id":"_2026x_1_12a70364_1789524947853_806196_5826","name":"Select Coffee","kind":"usecase","stereotypes":["UseCase"],"attributes":[],"documentation":""},{"id":"_2026x_1_12a70364_1789524947871_813181_5827","name":"Make Coffee","kind":"usecase","stereotypes":["UseCase"],"attributes":[],"documentation":""},{"id":"_2026x_1_12a70364_1789524947875_764584_5828","name":"Refill Water Tank","kind":"usecase","stereotypes":["UseCase"],"attributes":[],"documentation":""},{"id":"_2026x_1_12a70364_1789524947877_120920_5829","name":"Refill Coffee Beans","kind":"usecase","stereotypes":["UseCase"],"attributes":[],"documentation":""},{"id":"_2026x_1_12a70364_1789524947879_552225_5830","name":"Remove Waste","kind":"usecase","stereotypes":["UseCase"],"attributes":[],"documentation":""},{"id":"_2026x_1_12a70364_1789524431066_920359_5702","name":"Boiler Observer","kind":"block","stereotypes":["Block"],"attributes":[{"name":"Time","type":"Real","aggregation":"composite","default":""},{"name":"targetTime","type":"Real","aggregation":"composite","default":"90.0"}],"documentation":""},{"id":"_2026x_1_12a70364_1789524431068_554815_5703","name":"Water Heating Analysis Context","kind":"block","stereotypes":["Block"],"attributes":[{"name":"boiler","type":"Boiler","aggregation":"composite","default":""},{"name":"boilerObserver","type":"Boiler Observer","aggregation":"composite","default":""}],"documentation":""},{"id":"_2026x_1_12a70364_1789524431144_707453_5727","name":"Water Temperature Constraint","kind":"block","stereotypes":["ConstraintBlock"],"attributes":[{"name":"waterTemperatureAtTargetTime","type":"Real","aggregation":"none","default":""},{"name":"targetWaterTemperature","type":"Real","aggregation":"none","default":""}],"documentation":""}],"interfaces":[],"signals":[{"id":"_2026x_1_12a70364_1789365197170_873209_3844","name":"Command"},{"id":"_2026x_1_12a70364_1789365201520_200533_3845","name":"Power"},{"id":"_2026x_1_12a70364_1789446787460_992481_4188","name":"Coffee Selection"},{"id":"_2026x_1_12a70364_1789433848990_731675_3921","name":"Brew Complete"},{"id":"_2026x_1_12a70364_1789433896301_568328_3928","name":"PowerOff"},{"id":"_2026x_1_12a70364_1789434080835_765687_3939","name":"PowerOn"},{"id":"_2026x_1_12a70364_1789434127181_875752_3946","name":"Selection Made"},{"id":"_2026x_1_12a70364_1789602694790_416161_6107","name":"Short Detected"},{"id":"_2026x_1_12a70364_1789524740660_19378_5755","name":"Target Time Reached"}],"requirements":[{"id":"_2026x_1_12a70364_1789522470201_737876_5617","name":"System Level Requirements","kind":"requirement","stereotypes":["Requirement"],"attributes":[],"documentation":"","reqId":"1","reqText":""},{"id":"_2026x_1_12a70364_1789522470210_613186_5619","name":"Heater Initialization","kind":"requirement","stereotypes":["Requirement"],"attributes":[],"documentation":"","reqId":"1.1","reqText":"The boiler shall heat water to 84°C within 90 seconds of turning on the coffee machine"},{"id":"_2026x_1_12a70364_1789522470213_487063_5622","name":"Overheating","kind":"requirement","stereotypes":["Requirement"],"attributes":[],"documentation":"","reqId":"1.2","reqText":"The thermostat shall stop all power supply if the instantaneous water heater exceeds 170°C"},{"id":"_2026x_1_12a70364_1789522470217_232543_5625","name":"Water Tank Level","kind":"requirement","stereotypes":["Requirement"],"attributes":[],"documentation":"","reqId":"1.3","reqText":"The water tank will not brew coffee if there is less than 500mL of water"},{"id":"_2026x_1_12a70364_1789522470220_757311_5628","name":"Coffee Bean Level","kind":"requirement","stereotypes":["Requirement"],"attributes":[],"documentation":"","reqId":"1.4","reqText":"The grinder will not grind coffee beans if there is less than 45g of beans within the bean container"},{"id":"_2026x_1_12a70364_1789522470227_43173_5631","name":"Water Tank Capacity","kind":"requirement","stereotypes":["Requirement"],"attributes":[],"documentation":"","reqId":"1.5","reqText":"The water tank shall be able to hold a max capacity of 2.4L"},{"id":"_2026x_1_12a70364_1789522470229_653956_5634","name":"Coffee Bean Capacity","kind":"requirement","stereotypes":["Requirement"],"attributes":[],"documentation":"","reqId":"1.6","reqText":"The coffee bean container shall be able to store a max weight of 300g of coffee beans"},{"id":"_2026x_1_12a70364_1789522470232_505575_5637","name":"Grounds Draw Waste","kind":"requirement","stereotypes":["Requirement"],"attributes":[],"documentation":"","reqId":"1.7","reqText":"The grounds draw can store a max waste capacity of 8 grounds before it is deemed full"},{"id":"_2026x_1_12a70364_1789522470236_795679_5640","name":"Pump Pressure","kind":"requirement","stereotypes":["Requirement"],"attributes":[],"documentation":"","reqId":"1.8","reqText":"The pump presser shall not be greater than 15 bar"},{"id":"_2026x_1_12a70364_1789522470238_822356_5643","name":"System Check","kind":"requirement","stereotypes":["Requirement"],"attributes":[],"documentation":"","reqId":"1.9","reqText":"The coffee machine will perform a system check to confirm coffee beans and water levels are satisfied before a coffee is made"},{"id":"_2026x_1_12a70364_1789522470240_748943_5646","name":"System Alert","kind":"requirement","stereotypes":["Requirement"],"attributes":[],"documentation":"","reqId":"1.10","reqText":"The coffee machine will alert to user of a system check to be addressed"},{"id":"_2026x_1_12a70364_1789522470243_75877_5649","name":"Control Panel","kind":"requirement","stereotypes":["Requirement"],"attributes":[],"documentation":"","reqId":"1.11","reqText":"The coffee machine shall have a digital display which the user can make selections with ease"},{"id":"_2026x_1_12a70364_1789522470246_238622_5652","name":"Cleaning Requirements","kind":"requirement","stereotypes":["Requirement"],"attributes":[],"documentation":"","reqId":"2","reqText":""},{"id":"_2026x_1_12a70364_1789522470249_829935_5654","name":"Clean brewing unit","kind":"requirement","stereotypes":["Requirement"],"attributes":[],"documentation":"","reqId":"2.1","reqText":"The maintenance operator shall clean the brewing unit once a week"},{"id":"_2026x_1_12a70364_1789522470251_936773_5657","name":"Clean Machine Exterior","kind":"requirement","stereotypes":["Requirement"],"attributes":[],"documentation":"","reqId":"2.2","reqText":"The maintenance operator shall clean the exterior only using water and kitchen detergent"},{"id":"_2026x_1_12a70364_1789522470252_176734_5660","name":"Clean Water Tank","kind":"requirement","stereotypes":["Requirement"],"attributes":[],"documentation":"","reqId":"2.3","reqText":"The maintenance operator shall clean the water tank 1 time per week"},{"id":"_2026x_1_12a70364_1789522470268_212057_5663","name":"Safety Requirements","kind":"requirement","stereotypes":["Requirement"],"attributes":[],"documentation":"","reqId":"3","reqText":""},{"id":"_2026x_1_12a70364_1789522470269_5755_5665","name":"Internal Features","kind":"requirement","stereotypes":["Requirement"],"attributes":[],"documentation":"","reqId":"3.1","reqText":""},{"id":"_2026x_1_12a70364_1789522470270_589609_5667","name":"Gearmotor Overload","kind":"requirement","stereotypes":["Requirement"],"attributes":[],"documentation":"","reqId":"3.1.1","reqText":"If the gearmotor overloads the motors electronic system shall switchoff after 8-10s and the machine is stopped"},{"id":"_2026x_1_12a70364_1789522470271_475286_5670","name":"HWS Valve Open During Brewing","kind":"requirement","stereotypes":["Requirement"],"attributes":[],"documentation":"","reqId":"3.1.2","reqText":"During brewing operation if the HWS valve is opened the coffee machine shall interrupt the water flow"},{"id":"_2026x_1_12a70364_1789522470272_63721_5673","name":"Interruption By Removal Of Dregs Draw","kind":"requirement","stereotypes":["Requirement"],"attributes":[],"documentation":"","reqId":"3.1.3","reqText":"During operation if interruption occurs by the removal of the dreg draw the machine shall continue its function unrestricted once the drawer is returned"},{"id":"_2026x_1_12a70364_1789522470273_392927_5676","name":"Main Power Supply Disconnection During Operation","kind":"requirement","stereotypes":["Requirement"],"attributes":[],"documentation":"","reqId":"3.1.4","reqText":"If power failure/side doors opened during operation the coffee machines gears will complete the function commenced but without brewing"},{"id":"_2026x_1_12a70364_1789602694801_483599_6108","name":"Electrical Isolation On Dispense","kind":"requirement","stereotypes":["Requirement"],"attributes":[],"documentation":"","reqId":"3.1.5","reqText":"During water dispensing the coffee machine shall electrically isolate the water path and incorporate a residual current device (RCD) so that a short circuit cannot energise the chassis or expose the operator to electric shock."},{"id":"_2026x_1_12a70364_1789522470274_644308_5679","name":"External Features","kind":"requirement","stereotypes":["Requirement"],"attributes":[],"documentation":"","reqId":"3.2","reqText":""},{"id":"_2026x_1_12a70364_1789522470275_767711_5681","name":"Regulatory Compliance Mark","kind":"requirement","stereotypes":["Requirement"],"attributes":[],"documentation":"","reqId":"3.2.1","reqText":"The coffee machine unit shall not be sold unless it has a RCM with the Australian standards of the AS/NZS 4417.1 and AS/NZS 4417.2"}],"stateMachine":{"name":"Coffee Machine STM","regions":[{"states":[{"id":"_2026x_1_12a70364_1789435135035_153882_4003","name":"Initialising","entry":"Initialise System","doActivity":null,"exit":null},{"id":"_2026x_1_12a70364_1789435365659_95882_4015","name":"Idle","entry":"Check System","doActivity":"Select Coffee","exit":null},{"id":"_2026x_1_12a70364_1789435456171_517468_4025","name":"Brewing","entry":null,"doActivity":"Brew Coffee","exit":null}]},{"states":[{"id":"_2026x_1_12a70364_1789435572537_420067_4035","name":"Heating On","entry":null,"doActivity":null,"exit":null},{"id":"_2026x_1_12a70364_1789435653243_288439_4045","name":"Heating Off","entry":null,"doActivity":null,"exit":null}]},{"states":[{"id":"_2026x_1_12a70364_1789434195075_586370_3959","name":"Off","entry":null,"doActivity":null,"exit":null},{"id":"_2026x_1_12a70364_1789434765035_486603_3981","name":"On","entry":null,"doActivity":null,"exit":null}]}]},"activities":[{"name":"Boiler","partitions":[],"nodes":[{"id":"_2026x_1_12a70364_1789524740812_93085_5782","type":"InitialNode","name":"","partition":null},{"id":"_2026x_1_12a70364_1789524740812_700589_5783","type":"ForkNode","name":"","partition":null},{"id":"_2026x_1_12a70364_1789524740812_431953_5784","type":"AcceptEventAction","name":"Target Time Reached","partition":null},{"id":"_2026x_1_12a70364_1789524740813_943391_5785","type":"DecisionNode","name":"","partition":null},{"id":"_2026x_1_12a70364_1789524740813_183921_5786","type":"MergeNode","name":"","partition":null},{"id":"_2026x_1_12a70364_1789524740813_414471_5787","type":"OpaqueAction","name":"","partition":null},{"id":"_2026x_1_12a70364_1789524740813_518030_5788","type":"OpaqueAction","name":"","partition":null}],"edges":[{"type":"control","source":"","target":"","guard":""},{"type":"control","source":"","target":"","guard":""},{"type":"control","source":"","target":"Target Time Reached","guard":""},{"type":"control","source":"","target":"","guard":"outputWaterTemperature < targetWaterTemperature"},{"type":"control","source":"","target":"","guard":""},{"type":"control","source":"","target":"","guard":""},{"type":"control","source":"Target Time Reached","target":"","guard":""}]},{"name":"Clean System","partitions":[],"nodes":[],"edges":[]},{"name":"Initialise System","partitions":[],"nodes":[],"edges":[]},{"name":"Check System","partitions":[],"nodes":[],"edges":[]},{"name":"Select Coffee","partitions":[],"nodes":[],"edges":[]},{"name":"Brew Coffee","partitions":[{"name":"control Subsystem","represents":null},{"name":"water Subsystem","represents":null},{"name":"brew Subsystem","represents":null},{"name":"dispensing Subsystem","represents":null}],"nodes":[{"id":"_2026x_1_12a70364_1789450664669_244157_4265","type":"InitialNode","name":"","partition":"control Subsystem"},{"id":"_2026x_1_12a70364_1789450664670_69624_4266","type":"ActivityFinalNode","name":"","partition":"dispensing Subsystem"},{"id":"_2026x_1_12a70364_1789450664670_937912_4267","type":"AcceptEventAction","name":"","partition":"control Subsystem"},{"id":"_2026x_1_12a70364_1789450664674_1526_4269","type":"ForkNode","name":"","partition":null},{"id":"_2026x_1_12a70364_1789450664690_802950_4270","type":"OpaqueAction","name":"Heat Water","partition":"water Subsystem"},{"id":"_2026x_1_12a70364_1789450664692_239201_4273","type":"OpaqueAction","name":"Grind Beans","partition":"brew Subsystem"},{"id":"_2026x_1_12a70364_1789450664694_284067_4276","type":"OpaqueAction","name":"Extract Coffee","partition":"brew Subsystem"},{"id":"_2026x_1_12a70364_1789450664695_161554_4280","type":"OpaqueAction","name":"Dispense Coffee","partition":"dispensing Subsystem"}],"edges":[{"type":"control","source":"","target":"","guard":""},{"type":"object","source":"result","target":"","guard":""},{"type":"object","source":"","target":"input","guard":""},{"type":"object","source":"","target":"input","guard":""},{"type":"object","source":"output","target":"input","guard":""},{"type":"object","source":"output","target":"input1","guard":""},{"type":"object","source":"output","target":"input","guard":""},{"type":"control","source":"Dispense Coffee","target":"","guard":""}]},{"name":"Heat Water","partitions":[{"name":"water Tank","represents":"water Tank"},{"name":"flow Meter","represents":"flow Meter"},{"name":"water Pump","represents":"water Pump"},{"name":"boiler","represents":"boiler"}],"nodes":[{"id":"_2026x_1_12a70364_1789520884002_616409_5511","type":"ActivityParameterNode","name":"input","partition":null},{"id":"_2026x_1_12a70364_1789520884013_494487_5512","type":"ActivityParameterNode","name":"output","partition":null},{"id":"_2026x_1_12a70364_1789520884037_236501_5513","type":"InitialNode","name":"","partition":"water Tank"},{"id":"_2026x_1_12a70364_1789520884039_439710_5514","type":"OpaqueAction","name":"Open Valve","partition":"water Tank"},{"id":"_2026x_1_12a70364_1789520884041_535279_5515","type":"OpaqueAction","name":"Close Valve","partition":"water Tank"},{"id":"_2026x_1_12a70364_1789520884054_615979_5516","type":"FlowFinalNode","name":"","partition":"water Tank"},{"id":"_2026x_1_12a70364_1789520884064_588707_5517","type":"OpaqueAction","name":"Read Coffee Size","partition":"flow Meter"},{"id":"_2026x_1_12a70364_1789520884093_101205_5518","type":"MergeNode","name":"Merge 1","partition":"flow Meter"},{"id":"_2026x_1_12a70364_1789520884102_849036_5519","type":"OpaqueAction","name":"Measure Water","partition":"flow Meter"},{"id":"_2026x_1_12a70364_1789520884106_595239_5520","type":"DecisionNode","name":"Correct Volume?","partition":"flow Meter"},{"id":"_2026x_1_12a70364_1789520884116_758244_5521","type":"ForkNode","name":"Fork 2","partition":"flow Meter"},{"id":"_2026x_1_12a70364_1789520884117_344927_5522","type":"OpaqueAction","name":"Pump Water","partition":"water Pump"},{"id":"_2026x_1_12a70364_1789520884118_474916_5523","type":"ForkNode","name":"Fork 1","partition":"water Pump"},{"id":"_2026x_1_12a70364_1789520884119_475566_5524","type":"OpaqueAction","name":"Stop Pump","partition":"water Pump"},{"id":"_2026x_1_12a70364_1789520884120_513215_5525","type":"FlowFinalNode","name":"","partition":"water Pump"},{"id":"_2026x_1_12a70364_1789520884120_628547_5526","type":"MergeNode","name":"Merge 2","partition":"boiler"},{"id":"_2026x_1_12a70364_1789520884121_703915_5527","type":"OpaqueAction","name":"Heat Water","partition":"boiler"},{"id":"_2026x_1_12a70364_1789520884122_4579_5528","type":"DecisionNode","name":"Temp OK?","partition":"boiler"}],"edges":[{"type":"control","source":"","target":"Open Valve","guard":""},{"type":"control","source":"Open Valve","target":"Pump Water","guard":""},{"type":"object","source":"input","target":"Read Coffee Size","guard":""},{"type":"control","source":"Pump Water","target":"Fork 1","guard":""},{"type":"control","source":"Fork 1","target":"Read Coffee Size","guard":""},{"type":"control","source":"Fork 1","target":"Merge 2","guard":""},{"type":"control","source":"Read Coffee Size","target":"Merge 1","guard":""},{"type":"control","source":"Merge 1","target":"Measure Water","guard":""},{"type":"control","source":"Measure Water","target":"Correct Volume?","guard":""},{"type":"control","source":"Correct Volume?","target":"Merge 1","guard":"No"},{"type":"control","source":"Correct Volume?","target":"Fork 2","guard":"Yes"},{"type":"control","source":"Fork 2","target":"Close Valve","guard":""},{"type":"control","source":"Fork 2","target":"Stop Pump","guard":""},{"type":"control","source":"Close Valve","target":"","guard":""},{"type":"control","source":"Stop Pump","target":"","guard":""},{"type":"control","source":"Merge 2","target":"Heat Water","guard":""},{"type":"control","source":"Heat Water","target":"Temp OK?","guard":""},{"type":"control","source":"Temp OK?","target":"Merge 2","guard":"No"},{"type":"object","source":"Temp OK?","target":"output","guard":"Yes"}]},{"name":"Boiler Observer","partitions":[],"nodes":[{"id":"_2026x_1_12a70364_1789524740676_267400_5757","type":"InitialNode","name":"","partition":null},{"id":"_2026x_1_12a70364_1789524740676_61147_5758","type":"MergeNode","name":"","partition":null},{"id":"_2026x_1_12a70364_1789524740677_200964_5759","type":"OpaqueAction","name":"","partition":null},{"id":"_2026x_1_12a70364_1789524740677_260966_5760","type":"DecisionNode","name":"","partition":null},{"id":"_2026x_1_12a70364_1789524740685_268013_5761","type":"SendSignalAction","name":"Target Time Reached","partition":null}],"edges":[{"type":"control","source":"","target":"","guard":""},{"type":"control","source":"","target":"","guard":""},{"type":"control","source":"","target":"","guard":""},{"type":"control","source":"","target":"","guard":"Time<targetTime"},{"type":"control","source":"","target":"Target Time Reached","guard":"else"}]}],"graph":{"nodes":[{"id":"_2026x_1_12a70364_1789357107731_106889_3635","kind":"block","name":"Coffee Machine","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789357175665_504215_3638","kind":"block","name":"Water System","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789357305852_992852_3641","kind":"block","name":"Electrical System","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789357381144_263298_3644","kind":"block","name":"Brew System","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789358228897_970701_3681","kind":"block","name":"Coffee Machine Production","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789358512516_28052_3684","kind":"block","name":"Water Flow Port","stereotypes":["InterfaceBlock"]},{"id":"_2026x_1_12a70364_1789358695241_447494_3686","kind":"block","name":"Coffee State","stereotypes":["InterfaceBlock"]},{"id":"_2026x_1_12a70364_1789358720758_903471_3688","kind":"block","name":"Waste Port","stereotypes":["InterfaceBlock"]},{"id":"_2026x_1_12a70364_1789358753658_420800_3690","kind":"block","name":"Drink outlet","stereotypes":["InterfaceBlock"]},{"id":"_2026x_1_12a70364_1789358830928_193983_3693","kind":"block","name":"GPO","stereotypes":["InterfaceBlock"]},{"id":"_2026x_1_12a70364_1789365065038_185163_3840","kind":"block","name":"Water Inlet","stereotypes":["InterfaceBlock"]},{"id":"_2026x_1_12a70364_1789365155322_752872_3841","kind":"block","name":"Coffee","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789365188589_930663_3842","kind":"block","name":"Coffee Beans","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789365192860_189919_3843","kind":"block","name":"Water","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789365197170_873209_3844","kind":"signal","name":"Command"},{"id":"_2026x_1_12a70364_1789365201520_200533_3845","kind":"signal","name":"Power"},{"id":"_2026x_1_12a70364_1789446787460_992481_4188","kind":"signal","name":"Coffee Selection"},{"id":"_2026x_1_12a70364_1789363113514_607533_3714","kind":"block","name":"Brew Subsystem","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789363134214_804452_3715","kind":"block","name":"Control Subsystem","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789363176200_671776_3716","kind":"block","name":"Dispensing Subsystem","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789363180535_753073_3717","kind":"block","name":"Power Subsystem","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789363184788_487139_3718","kind":"block","name":"Water Subsystem","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789363224675_90261_3719","kind":"block","name":"Bean Storage","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789363229077_574630_3720","kind":"block","name":"Brewing Unit","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789363233424_933473_3721","kind":"block","name":"Doser Unit","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789363237787_500380_3722","kind":"block","name":"Grinder","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789363242138_385667_3723","kind":"block","name":"Grounds Drawer","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789363276685_64862_3724","kind":"block","name":"Control Module","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789363281032_103275_3725","kind":"block","name":"User Interface Panel","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789363285378_732895_3726","kind":"block","name":"Coffee Outlet","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789363289724_897457_3727","kind":"block","name":"Drip Tray","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789363293999_849627_3728","kind":"block","name":"Door Switch","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789363326324_823109_3729","kind":"block","name":"Mains Cord","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789363330606_330250_3730","kind":"block","name":"Mains Switch","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789363334952_109655_3731","kind":"block","name":"Power Supply","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789363551438_409574_3734","kind":"block","name":"Boiler","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789524740810_260777_5781","kind":"activity","name":"Boiler"},{"id":"_2026x_1_12a70364_1789363585791_503580_3735","kind":"block","name":"Flow Meter","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789363591862_529655_3736","kind":"block","name":"Water Pump","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789363775704_719608_3739","kind":"block","name":"Water Tank","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789363832704_318902_3740","kind":"block","name":"Water Valve","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789363922516_578822_3741","kind":"block","name":"Coffee Machine System","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789434194641_881326_3952","kind":"stateMachine","name":"Coffee Machine STM"},{"id":"_2026x_1_12a70364_1789434195075_586370_3959","kind":"state","name":"Off"},{"id":"_2026x_1_12a70364_1789434765035_486603_3981","kind":"state","name":"On"},{"id":"_2026x_1_12a70364_1789435135035_153882_4003","kind":"state","name":"Initialising"},{"id":"_2026x_1_12a70364_1789435365659_95882_4015","kind":"state","name":"Idle"},{"id":"_2026x_1_12a70364_1789435456171_517468_4025","kind":"state","name":"Brewing"},{"id":"_2026x_1_12a70364_1789435572537_420067_4035","kind":"state","name":"Heating On"},{"id":"_2026x_1_12a70364_1789435653243_288439_4045","kind":"state","name":"Heating Off"},{"id":"_2026x_1_12a70364_1789602694850_639924_6114","kind":"block","name":"Isolate Power (RCD trip)","stereotypes":[]},{"id":"_2026x_1_12a70364_1789446787441_652035_4187","kind":"activity","name":"Clean System"},{"id":"_2026x_1_12a70364_1789446787423_564713_4183","kind":"activity","name":"Initialise System"},{"id":"_2026x_1_12a70364_1789446787431_596888_4184","kind":"activity","name":"Check System"},{"id":"_2026x_1_12a70364_1789446787433_241392_4185","kind":"activity","name":"Select Coffee"},{"id":"_2026x_1_12a70364_1789446787438_52344_4186","kind":"activity","name":"Brew Coffee"},{"id":"_2026x_1_12a70364_1789433848990_731675_3921","kind":"signal","name":"Brew Complete"},{"id":"_2026x_1_12a70364_1789433896301_568328_3928","kind":"signal","name":"PowerOff"},{"id":"_2026x_1_12a70364_1789434080835_765687_3939","kind":"signal","name":"PowerOn"},{"id":"_2026x_1_12a70364_1789434127181_875752_3946","kind":"signal","name":"Selection Made"},{"id":"_2026x_1_12a70364_1789602694790_416161_6107","kind":"signal","name":"Short Detected"},{"id":"_2026x_1_12a70364_1789520883956_757328_5504","kind":"activity","name":"Heat Water"},{"id":"_2026x_1_12a70364_1789524947739_455059_5824","kind":"actor","name":"Coffee Consumer"},{"id":"_2026x_1_12a70364_1789524947844_364892_5825","kind":"actor","name":"Maintenance Operator"},{"id":"_2026x_1_12a70364_1789524947853_806196_5826","kind":"usecase","name":"Select Coffee"},{"id":"_2026x_1_12a70364_1789524947871_813181_5827","kind":"usecase","name":"Make Coffee"},{"id":"_2026x_1_12a70364_1789524947875_764584_5828","kind":"usecase","name":"Refill Water Tank"},{"id":"_2026x_1_12a70364_1789524947877_120920_5829","kind":"usecase","name":"Refill Coffee Beans"},{"id":"_2026x_1_12a70364_1789524947879_552225_5830","kind":"usecase","name":"Remove Waste"},{"id":"_2026x_1_12a70364_1789522470201_737876_5617","kind":"requirement","name":"System Level Requirements","stereotypes":["Requirement"]},{"id":"_2026x_1_12a70364_1789522470210_613186_5619","kind":"requirement","name":"Heater Initialization","stereotypes":["Requirement"]},{"id":"_2026x_1_12a70364_1789522470213_487063_5622","kind":"requirement","name":"Overheating","stereotypes":["Requirement"]},{"id":"_2026x_1_12a70364_1789522470217_232543_5625","kind":"requirement","name":"Water Tank Level","stereotypes":["Requirement"]},{"id":"_2026x_1_12a70364_1789522470220_757311_5628","kind":"requirement","name":"Coffee Bean Level","stereotypes":["Requirement"]},{"id":"_2026x_1_12a70364_1789522470227_43173_5631","kind":"requirement","name":"Water Tank Capacity","stereotypes":["Requirement"]},{"id":"_2026x_1_12a70364_1789522470229_653956_5634","kind":"requirement","name":"Coffee Bean Capacity","stereotypes":["Requirement"]},{"id":"_2026x_1_12a70364_1789522470232_505575_5637","kind":"requirement","name":"Grounds Draw Waste","stereotypes":["Requirement"]},{"id":"_2026x_1_12a70364_1789522470236_795679_5640","kind":"requirement","name":"Pump Pressure","stereotypes":["Requirement"]},{"id":"_2026x_1_12a70364_1789522470238_822356_5643","kind":"requirement","name":"System Check","stereotypes":["Requirement"]},{"id":"_2026x_1_12a70364_1789522470240_748943_5646","kind":"requirement","name":"System Alert","stereotypes":["Requirement"]},{"id":"_2026x_1_12a70364_1789522470243_75877_5649","kind":"requirement","name":"Control Panel","stereotypes":["Requirement"]},{"id":"_2026x_1_12a70364_1789522470246_238622_5652","kind":"requirement","name":"Cleaning Requirements","stereotypes":["Requirement"]},{"id":"_2026x_1_12a70364_1789522470249_829935_5654","kind":"requirement","name":"Clean brewing unit","stereotypes":["Requirement"]},{"id":"_2026x_1_12a70364_1789522470251_936773_5657","kind":"requirement","name":"Clean Machine Exterior","stereotypes":["Requirement"]},{"id":"_2026x_1_12a70364_1789522470252_176734_5660","kind":"requirement","name":"Clean Water Tank","stereotypes":["Requirement"]},{"id":"_2026x_1_12a70364_1789522470268_212057_5663","kind":"requirement","name":"Safety Requirements","stereotypes":["Requirement"]},{"id":"_2026x_1_12a70364_1789522470269_5755_5665","kind":"requirement","name":"Internal Features","stereotypes":["Requirement"]},{"id":"_2026x_1_12a70364_1789522470270_589609_5667","kind":"requirement","name":"Gearmotor Overload","stereotypes":["Requirement"]},{"id":"_2026x_1_12a70364_1789522470271_475286_5670","kind":"requirement","name":"HWS Valve Open During Brewing","stereotypes":["Requirement"]},{"id":"_2026x_1_12a70364_1789522470272_63721_5673","kind":"requirement","name":"Interruption By Removal Of Dregs Draw","stereotypes":["Requirement"]},{"id":"_2026x_1_12a70364_1789522470273_392927_5676","kind":"requirement","name":"Main Power Supply Disconnection During Operation","stereotypes":["Requirement"]},{"id":"_2026x_1_12a70364_1789602694801_483599_6108","kind":"requirement","name":"Electrical Isolation On Dispense","stereotypes":["Requirement"]},{"id":"_2026x_1_12a70364_1789522470274_644308_5679","kind":"requirement","name":"External Features","stereotypes":["Requirement"]},{"id":"_2026x_1_12a70364_1789522470275_767711_5681","kind":"requirement","name":"Regulatory Compliance Mark","stereotypes":["Requirement"]},{"id":"_2026x_1_12a70364_1789524431066_920359_5702","kind":"block","name":"Boiler Observer","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789524740674_986781_5756","kind":"activity","name":"Boiler Observer"},{"id":"_2026x_1_12a70364_1789524431068_554815_5703","kind":"block","name":"Water Heating Analysis Context","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789524431144_707453_5727","kind":"block","name":"Water Temperature Constraint","stereotypes":["ConstraintBlock"]},{"id":"_2026x_1_12a70364_1789524740660_19378_5755","kind":"signal","name":"Target Time Reached"}],"edges":[{"source":"_2026x_1_12a70364_1789446787460_992481_4188","target":"_2026x_1_12a70364_1789365197170_873209_3844","kind":"generalization","label":""},{"source":"_2026x_1_12a70364_1789363551438_409574_3734","target":"_2026x_1_12a70364_1789524740810_260777_5781","kind":"behavior","label":""},{"source":"_2026x_1_12a70364_1789524740810_260777_5781","target":"_2026x_1_12a70364_1789524740660_19378_5755","kind":"uses","label":"Target Time Reached"},{"source":"_2026x_1_12a70364_1789363922516_578822_3741","target":"_2026x_1_12a70364_1789434194641_881326_3952","kind":"behavior","label":""},{"source":"_2026x_1_12a70364_1789434194641_881326_3952","target":"_2026x_1_12a70364_1789434195075_586370_3959","kind":"contains","label":"region"},{"source":"_2026x_1_12a70364_1789434194641_881326_3952","target":"_2026x_1_12a70364_1789434765035_486603_3981","kind":"contains","label":"region"},{"source":"_2026x_1_12a70364_1789434765035_486603_3981","target":"_2026x_1_12a70364_1789435135035_153882_4003","kind":"contains","label":"region"},{"source":"_2026x_1_12a70364_1789435135035_153882_4003","target":"_2026x_1_12a70364_1789446787423_564713_4183","kind":"behavior","label":"entry"},{"source":"_2026x_1_12a70364_1789434765035_486603_3981","target":"_2026x_1_12a70364_1789435365659_95882_4015","kind":"contains","label":"region"},{"source":"_2026x_1_12a70364_1789435365659_95882_4015","target":"_2026x_1_12a70364_1789446787431_596888_4184","kind":"behavior","label":"entry"},{"source":"_2026x_1_12a70364_1789435365659_95882_4015","target":"_2026x_1_12a70364_1789446787433_241392_4185","kind":"behavior","label":"do"},{"source":"_2026x_1_12a70364_1789434765035_486603_3981","target":"_2026x_1_12a70364_1789435456171_517468_4025","kind":"contains","label":"region"},{"source":"_2026x_1_12a70364_1789435456171_517468_4025","target":"_2026x_1_12a70364_1789446787438_52344_4186","kind":"behavior","label":"do"},{"source":"_2026x_1_12a70364_1789435135035_153882_4003","target":"_2026x_1_12a70364_1789435365659_95882_4015","kind":"transition","label":"after(30s)"},{"source":"_2026x_1_12a70364_1789435365659_95882_4015","target":"_2026x_1_12a70364_1789435456171_517468_4025","kind":"transition","label":"signal:Selection Made"},{"source":"_2026x_1_12a70364_1789434127181_875752_3946","target":"_2026x_1_12a70364_1789435456171_517468_4025","kind":"triggers","label":"Selection Made"},{"source":"_2026x_1_12a70364_1789435456171_517468_4025","target":"_2026x_1_12a70364_1789435365659_95882_4015","kind":"transition","label":"signal:Brew Complete /Clean System"},{"source":"_2026x_1_12a70364_1789433848990_731675_3921","target":"_2026x_1_12a70364_1789435365659_95882_4015","kind":"triggers","label":"Brew Complete"},{"source":"_2026x_1_12a70364_1789435456171_517468_4025","target":"_2026x_1_12a70364_1789446787441_652035_4187","kind":"effect","label":"Clean System"},{"source":"_2026x_1_12a70364_1789434765035_486603_3981","target":"_2026x_1_12a70364_1789435572537_420067_4035","kind":"contains","label":"region"},{"source":"_2026x_1_12a70364_1789434765035_486603_3981","target":"_2026x_1_12a70364_1789435653243_288439_4045","kind":"contains","label":"region"},{"source":"_2026x_1_12a70364_1789435572537_420067_4035","target":"_2026x_1_12a70364_1789435653243_288439_4045","kind":"transition","label":"after(60s)"},{"source":"_2026x_1_12a70364_1789435653243_288439_4045","target":"_2026x_1_12a70364_1789435572537_420067_4035","kind":"transition","label":"after(60s)"},{"source":"_2026x_1_12a70364_1789434195075_586370_3959","target":"_2026x_1_12a70364_1789434765035_486603_3981","kind":"transition","label":"signal:PowerOn"},{"source":"_2026x_1_12a70364_1789434080835_765687_3939","target":"_2026x_1_12a70364_1789434765035_486603_3981","kind":"triggers","label":"PowerOn"},{"source":"_2026x_1_12a70364_1789434765035_486603_3981","target":"_2026x_1_12a70364_1789434195075_586370_3959","kind":"transition","label":"signal:PowerOff"},{"source":"_2026x_1_12a70364_1789433896301_568328_3928","target":"_2026x_1_12a70364_1789434195075_586370_3959","kind":"triggers","label":"PowerOff"},{"source":"_2026x_1_12a70364_1789434765035_486603_3981","target":"_2026x_1_12a70364_1789434195075_586370_3959","kind":"transition","label":"signal:Short Detected /Isolate Power (RCD trip)"},{"source":"_2026x_1_12a70364_1789602694790_416161_6107","target":"_2026x_1_12a70364_1789434195075_586370_3959","kind":"triggers","label":"Short Detected"},{"source":"_2026x_1_12a70364_1789434765035_486603_3981","target":"_2026x_1_12a70364_1789602694850_639924_6114","kind":"effect","label":"Isolate Power (RCD trip)"},{"source":"_2026x_1_12a70364_1789433848990_731675_3921","target":"_2026x_1_12a70364_1789365197170_873209_3844","kind":"generalization","label":""},{"source":"_2026x_1_12a70364_1789433896301_568328_3928","target":"_2026x_1_12a70364_1789365201520_200533_3845","kind":"generalization","label":""},{"source":"_2026x_1_12a70364_1789434080835_765687_3939","target":"_2026x_1_12a70364_1789365201520_200533_3845","kind":"generalization","label":""},{"source":"_2026x_1_12a70364_1789434127181_875752_3946","target":"_2026x_1_12a70364_1789365197170_873209_3844","kind":"generalization","label":""},{"source":"_2026x_1_12a70364_1789524947853_806196_5826","target":"_2026x_1_12a70364_1789363922516_578822_3741","kind":"subject","label":"subject"},{"source":"_2026x_1_12a70364_1789524947853_806196_5826","target":"_2026x_1_12a70364_1789524947871_813181_5827","kind":"include","label":"«include»"},{"source":"_2026x_1_12a70364_1789524947871_813181_5827","target":"_2026x_1_12a70364_1789363922516_578822_3741","kind":"subject","label":"subject"},{"source":"_2026x_1_12a70364_1789524947875_764584_5828","target":"_2026x_1_12a70364_1789363922516_578822_3741","kind":"subject","label":"subject"},{"source":"_2026x_1_12a70364_1789524947877_120920_5829","target":"_2026x_1_12a70364_1789363922516_578822_3741","kind":"subject","label":"subject"},{"source":"_2026x_1_12a70364_1789524947879_552225_5830","target":"_2026x_1_12a70364_1789363922516_578822_3741","kind":"subject","label":"subject"},{"source":"_2026x_1_12a70364_1789522470201_737876_5617","target":"_2026x_1_12a70364_1789522470210_613186_5619","kind":"contains","label":""},{"source":"_2026x_1_12a70364_1789522470201_737876_5617","target":"_2026x_1_12a70364_1789522470213_487063_5622","kind":"contains","label":""},{"source":"_2026x_1_12a70364_1789522470201_737876_5617","target":"_2026x_1_12a70364_1789522470217_232543_5625","kind":"contains","label":""},{"source":"_2026x_1_12a70364_1789522470201_737876_5617","target":"_2026x_1_12a70364_1789522470220_757311_5628","kind":"contains","label":""},{"source":"_2026x_1_12a70364_1789522470201_737876_5617","target":"_2026x_1_12a70364_1789522470227_43173_5631","kind":"contains","label":""},{"source":"_2026x_1_12a70364_1789522470201_737876_5617","target":"_2026x_1_12a70364_1789522470229_653956_5634","kind":"contains","label":""},{"source":"_2026x_1_12a70364_1789522470201_737876_5617","target":"_2026x_1_12a70364_1789522470232_505575_5637","kind":"contains","label":""},{"source":"_2026x_1_12a70364_1789522470201_737876_5617","target":"_2026x_1_12a70364_1789522470236_795679_5640","kind":"contains","label":""},{"source":"_2026x_1_12a70364_1789522470201_737876_5617","target":"_2026x_1_12a70364_1789522470238_822356_5643","kind":"contains","label":""},{"source":"_2026x_1_12a70364_1789522470201_737876_5617","target":"_2026x_1_12a70364_1789522470240_748943_5646","kind":"contains","label":""},{"source":"_2026x_1_12a70364_1789522470201_737876_5617","target":"_2026x_1_12a70364_1789522470243_75877_5649","kind":"contains","label":""},{"source":"_2026x_1_12a70364_1789522470246_238622_5652","target":"_2026x_1_12a70364_1789522470249_829935_5654","kind":"contains","label":""},{"source":"_2026x_1_12a70364_1789522470246_238622_5652","target":"_2026x_1_12a70364_1789522470251_936773_5657","kind":"contains","label":""},{"source":"_2026x_1_12a70364_1789522470246_238622_5652","target":"_2026x_1_12a70364_1789522470252_176734_5660","kind":"contains","label":""},{"source":"_2026x_1_12a70364_1789522470268_212057_5663","target":"_2026x_1_12a70364_1789522470269_5755_5665","kind":"contains","label":""},{"source":"_2026x_1_12a70364_1789522470268_212057_5663","target":"_2026x_1_12a70364_1789522470274_644308_5679","kind":"contains","label":""},{"source":"_2026x_1_12a70364_1789522470269_5755_5665","target":"_2026x_1_12a70364_1789522470270_589609_5667","kind":"contains","label":""},{"source":"_2026x_1_12a70364_1789522470269_5755_5665","target":"_2026x_1_12a70364_1789522470271_475286_5670","kind":"contains","label":""},{"source":"_2026x_1_12a70364_1789522470269_5755_5665","target":"_2026x_1_12a70364_1789522470272_63721_5673","kind":"contains","label":""},{"source":"_2026x_1_12a70364_1789522470269_5755_5665","target":"_2026x_1_12a70364_1789522470273_392927_5676","kind":"contains","label":""},{"source":"_2026x_1_12a70364_1789522470269_5755_5665","target":"_2026x_1_12a70364_1789602694801_483599_6108","kind":"contains","label":""},{"source":"_2026x_1_12a70364_1789522470274_644308_5679","target":"_2026x_1_12a70364_1789522470275_767711_5681","kind":"contains","label":""},{"source":"_2026x_1_12a70364_1789524431066_920359_5702","target":"_2026x_1_12a70364_1789524740674_986781_5756","kind":"behavior","label":""},{"source":"_2026x_1_12a70364_1789524740674_986781_5756","target":"_2026x_1_12a70364_1789524740660_19378_5755","kind":"uses","label":"Target Time Reached"},{"source":"_2026x_1_12a70364_1789357175665_504215_3638","target":"_2026x_1_12a70364_1789357107731_106889_3635","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789357305852_992852_3641","target":"_2026x_1_12a70364_1789357107731_106889_3635","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789357381144_263298_3644","target":"_2026x_1_12a70364_1789357107731_106889_3635","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789363224675_90261_3719","target":"_2026x_1_12a70364_1789363113514_607533_3714","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789363229077_574630_3720","target":"_2026x_1_12a70364_1789363113514_607533_3714","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789363233424_933473_3721","target":"_2026x_1_12a70364_1789363113514_607533_3714","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789363237787_500380_3722","target":"_2026x_1_12a70364_1789363113514_607533_3714","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789363242138_385667_3723","target":"_2026x_1_12a70364_1789363113514_607533_3714","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789363276685_64862_3724","target":"_2026x_1_12a70364_1789363134214_804452_3715","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789363281032_103275_3725","target":"_2026x_1_12a70364_1789363134214_804452_3715","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789363285378_732895_3726","target":"_2026x_1_12a70364_1789363176200_671776_3716","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789363289724_897457_3727","target":"_2026x_1_12a70364_1789363176200_671776_3716","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789363293999_849627_3728","target":"_2026x_1_12a70364_1789363180535_753073_3717","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789363326324_823109_3729","target":"_2026x_1_12a70364_1789363180535_753073_3717","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789363330606_330250_3730","target":"_2026x_1_12a70364_1789363180535_753073_3717","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789363334952_109655_3731","target":"_2026x_1_12a70364_1789363180535_753073_3717","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789363551438_409574_3734","target":"_2026x_1_12a70364_1789363184788_487139_3718","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789363585791_503580_3735","target":"_2026x_1_12a70364_1789363184788_487139_3718","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789363591862_529655_3736","target":"_2026x_1_12a70364_1789363184788_487139_3718","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789363775704_719608_3739","target":"_2026x_1_12a70364_1789363184788_487139_3718","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789363832704_318902_3740","target":"_2026x_1_12a70364_1789363184788_487139_3718","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789363113514_607533_3714","target":"_2026x_1_12a70364_1789363922516_578822_3741","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789363134214_804452_3715","target":"_2026x_1_12a70364_1789363922516_578822_3741","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789363176200_671776_3716","target":"_2026x_1_12a70364_1789363922516_578822_3741","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789363180535_753073_3717","target":"_2026x_1_12a70364_1789363922516_578822_3741","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789363184788_487139_3718","target":"_2026x_1_12a70364_1789363922516_578822_3741","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789446787438_52344_4186","target":"_2026x_1_12a70364_1789520883956_757328_5504","kind":"dependency","label":"Dependency"},{"source":"_2026x_1_12a70364_1789524947739_455059_5824","target":"_2026x_1_12a70364_1789524947853_806196_5826","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789524947739_455059_5824","target":"_2026x_1_12a70364_1789524947871_813181_5827","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789524947844_364892_5825","target":"_2026x_1_12a70364_1789524947875_764584_5828","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789524947844_364892_5825","target":"_2026x_1_12a70364_1789524947877_120920_5829","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789524947844_364892_5825","target":"_2026x_1_12a70364_1789524947879_552225_5830","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789363922516_578822_3741","target":"_2026x_1_12a70364_1789522470238_822356_5643","kind":"dependency","label":"Satisfy"},{"source":"_2026x_1_12a70364_1789363922516_578822_3741","target":"_2026x_1_12a70364_1789522470240_748943_5646","kind":"dependency","label":"Satisfy"},{"source":"_2026x_1_12a70364_1789524947875_764584_5828","target":"_2026x_1_12a70364_1789522470217_232543_5625","kind":"dependency","label":"Refine"},{"source":"_2026x_1_12a70364_1789524947877_120920_5829","target":"_2026x_1_12a70364_1789522470220_757311_5628","kind":"dependency","label":"Refine"},{"source":"_2026x_1_12a70364_1789524431087_459748_5711","target":"_2026x_1_12a70364_1789522470210_613186_5619","kind":"dependency","label":"Satisfy"},{"source":"_2026x_1_12a70364_1789524431091_435540_5713","target":"_2026x_1_12a70364_1789522470210_613186_5619","kind":"dependency","label":"Satisfy"},{"source":"_2026x_1_12a70364_1789524431144_707453_5727","target":"_2026x_1_12a70364_1789522470210_613186_5619","kind":"dependency","label":"Refine"},{"source":"_2026x_1_12a70364_1789524431066_920359_5702","target":"_2026x_1_12a70364_1789524431068_554815_5703","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789363551438_409574_3734","target":"_2026x_1_12a70364_1789524431068_554815_5703","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789363184788_487139_3718","target":"_2026x_1_12a70364_1789357175665_504215_3638","kind":"dependency","label":"Allocate"},{"source":"_2026x_1_12a70364_1789363113514_607533_3714","target":"_2026x_1_12a70364_1789357381144_263298_3644","kind":"dependency","label":"Allocate"},{"source":"_2026x_1_12a70364_1789363180535_753073_3717","target":"_2026x_1_12a70364_1789357305852_992852_3641","kind":"dependency","label":"Allocate"},{"source":"_2026x_1_12a70364_1789363922516_578822_3741","target":"_2026x_1_12a70364_1789357107731_106889_3635","kind":"dependency","label":"Refine"},{"source":"_2026x_1_12a70364_1789363551438_409574_3734","target":"_2026x_1_12a70364_1789522470210_613186_5619","kind":"dependency","label":"Satisfy"},{"source":"_2026x_1_12a70364_1789363551438_409574_3734","target":"_2026x_1_12a70364_1789522470213_487063_5622","kind":"dependency","label":"Satisfy"},{"source":"_2026x_1_12a70364_1789363775704_719608_3739","target":"_2026x_1_12a70364_1789522470217_232543_5625","kind":"dependency","label":"Satisfy"},{"source":"_2026x_1_12a70364_1789363775704_719608_3739","target":"_2026x_1_12a70364_1789522470227_43173_5631","kind":"dependency","label":"Satisfy"},{"source":"_2026x_1_12a70364_1789363224675_90261_3719","target":"_2026x_1_12a70364_1789522470220_757311_5628","kind":"dependency","label":"Satisfy"},{"source":"_2026x_1_12a70364_1789363224675_90261_3719","target":"_2026x_1_12a70364_1789522470229_653956_5634","kind":"dependency","label":"Satisfy"},{"source":"_2026x_1_12a70364_1789363242138_385667_3723","target":"_2026x_1_12a70364_1789522470232_505575_5637","kind":"dependency","label":"Satisfy"},{"source":"_2026x_1_12a70364_1789363591862_529655_3736","target":"_2026x_1_12a70364_1789522470236_795679_5640","kind":"dependency","label":"Satisfy"},{"source":"_2026x_1_12a70364_1789363276685_64862_3724","target":"_2026x_1_12a70364_1789522470238_822356_5643","kind":"dependency","label":"Satisfy"},{"source":"_2026x_1_12a70364_1789363281032_103275_3725","target":"_2026x_1_12a70364_1789522470240_748943_5646","kind":"dependency","label":"Satisfy"},{"source":"_2026x_1_12a70364_1789363281032_103275_3725","target":"_2026x_1_12a70364_1789522470243_75877_5649","kind":"dependency","label":"Satisfy"},{"source":"_2026x_1_12a70364_1789363334952_109655_3731","target":"_2026x_1_12a70364_1789602694801_483599_6108","kind":"dependency","label":"Satisfy"},{"source":"_2026x_1_12a70364_1789363176200_671776_3716","target":"_2026x_1_12a70364_1789602694801_483599_6108","kind":"dependency","label":"Satisfy"},{"source":"_2026x_1_12a70364_1789524431068_554815_5703","target":"_2026x_1_12a70364_1789522470210_613186_5619","kind":"dependency","label":"Verify"},{"source":"_2026x_1_12a70364_1789363775704_719608_3739","target":"_2026x_1_12a70364_1789522470252_176734_5660","kind":"dependency","label":"Satisfy"},{"source":"_2026x_1_12a70364_1789363229077_574630_3720","target":"_2026x_1_12a70364_1789522470249_829935_5654","kind":"dependency","label":"Satisfy"},{"source":"_2026x_1_12a70364_1789357107731_106889_3635","target":"_2026x_1_12a70364_1789522470251_936773_5657","kind":"dependency","label":"Satisfy"},{"source":"_2026x_1_12a70364_1789357107731_106889_3635","target":"_2026x_1_12a70364_1789357175665_504215_3638","kind":"part","label":"water System"},{"source":"_2026x_1_12a70364_1789357107731_106889_3635","target":"_2026x_1_12a70364_1789357305852_992852_3641","kind":"part","label":"electrical System"},{"source":"_2026x_1_12a70364_1789357107731_106889_3635","target":"_2026x_1_12a70364_1789357381144_263298_3644","kind":"part","label":"brew System"},{"source":"_2026x_1_12a70364_1789357107731_106889_3635","target":"_2026x_1_12a70364_1789358228897_970701_3681","kind":"reference","label":"coffee Machine Production"},{"source":"_2026x_1_12a70364_1789357107731_106889_3635","target":"_2026x_1_12a70364_1789358512516_28052_3684","kind":"part","label":"Waterin"},{"source":"_2026x_1_12a70364_1789357107731_106889_3635","target":"_2026x_1_12a70364_1789358695241_447494_3686","kind":"part","label":"Coffee beans in"},{"source":"_2026x_1_12a70364_1789357107731_106889_3635","target":"_2026x_1_12a70364_1789358720758_903471_3688","kind":"part","label":"dregs"},{"source":"_2026x_1_12a70364_1789357107731_106889_3635","target":"_2026x_1_12a70364_1789358753658_420800_3690","kind":"part","label":"Coffee Dispensed"},{"source":"_2026x_1_12a70364_1789357107731_106889_3635","target":"_2026x_1_12a70364_1789358720758_903471_3688","kind":"part","label":"liquid waste"},{"source":"_2026x_1_12a70364_1789357107731_106889_3635","target":"_2026x_1_12a70364_1789358830928_193983_3693","kind":"part","label":"p2"},{"source":"_2026x_1_12a70364_1789357175665_504215_3638","target":"_2026x_1_12a70364_1789365065038_185163_3840","kind":"reference","label":"inlet"},{"source":"_2026x_1_12a70364_1789363113514_607533_3714","target":"_2026x_1_12a70364_1789363224675_90261_3719","kind":"part","label":"bean Storage"},{"source":"_2026x_1_12a70364_1789363113514_607533_3714","target":"_2026x_1_12a70364_1789363229077_574630_3720","kind":"part","label":"brewing Unit"},{"source":"_2026x_1_12a70364_1789363113514_607533_3714","target":"_2026x_1_12a70364_1789363233424_933473_3721","kind":"part","label":"doser Unit"},{"source":"_2026x_1_12a70364_1789363113514_607533_3714","target":"_2026x_1_12a70364_1789363237787_500380_3722","kind":"part","label":"grinder"},{"source":"_2026x_1_12a70364_1789363113514_607533_3714","target":"_2026x_1_12a70364_1789363242138_385667_3723","kind":"part","label":"grounds Drawer"},{"source":"_2026x_1_12a70364_1789363134214_804452_3715","target":"_2026x_1_12a70364_1789363276685_64862_3724","kind":"part","label":"control Module"},{"source":"_2026x_1_12a70364_1789363134214_804452_3715","target":"_2026x_1_12a70364_1789363281032_103275_3725","kind":"part","label":"user Interface Panel"},{"source":"_2026x_1_12a70364_1789363176200_671776_3716","target":"_2026x_1_12a70364_1789363285378_732895_3726","kind":"part","label":"coffee Outlet"},{"source":"_2026x_1_12a70364_1789363176200_671776_3716","target":"_2026x_1_12a70364_1789363289724_897457_3727","kind":"part","label":"drip Tray"},{"source":"_2026x_1_12a70364_1789363180535_753073_3717","target":"_2026x_1_12a70364_1789363293999_849627_3728","kind":"part","label":"door Switch"},{"source":"_2026x_1_12a70364_1789363180535_753073_3717","target":"_2026x_1_12a70364_1789363326324_823109_3729","kind":"part","label":"mains Cord"},{"source":"_2026x_1_12a70364_1789363180535_753073_3717","target":"_2026x_1_12a70364_1789363330606_330250_3730","kind":"part","label":"mains Switch"},{"source":"_2026x_1_12a70364_1789363180535_753073_3717","target":"_2026x_1_12a70364_1789363334952_109655_3731","kind":"part","label":"power Supply"},{"source":"_2026x_1_12a70364_1789363184788_487139_3718","target":"_2026x_1_12a70364_1789363551438_409574_3734","kind":"part","label":"boiler"},{"source":"_2026x_1_12a70364_1789363184788_487139_3718","target":"_2026x_1_12a70364_1789363585791_503580_3735","kind":"part","label":"flow Meter"},{"source":"_2026x_1_12a70364_1789363184788_487139_3718","target":"_2026x_1_12a70364_1789363591862_529655_3736","kind":"part","label":"water Pump"},{"source":"_2026x_1_12a70364_1789363184788_487139_3718","target":"_2026x_1_12a70364_1789363775704_719608_3739","kind":"part","label":"water Tank"},{"source":"_2026x_1_12a70364_1789363184788_487139_3718","target":"_2026x_1_12a70364_1789363832704_318902_3740","kind":"part","label":"water Valve"},{"source":"_2026x_1_12a70364_1789363224675_90261_3719","target":"_2026x_1_12a70364_1789365188589_930663_3842","kind":"reference","label":"storedBeans"},{"source":"_2026x_1_12a70364_1789363775704_719608_3739","target":"_2026x_1_12a70364_1789365192860_189919_3843","kind":"reference","label":"storedWater"},{"source":"_2026x_1_12a70364_1789363922516_578822_3741","target":"_2026x_1_12a70364_1789363113514_607533_3714","kind":"part","label":"brew Subsystem"},{"source":"_2026x_1_12a70364_1789363922516_578822_3741","target":"_2026x_1_12a70364_1789363134214_804452_3715","kind":"part","label":"control Subsystem"},{"source":"_2026x_1_12a70364_1789363922516_578822_3741","target":"_2026x_1_12a70364_1789363176200_671776_3716","kind":"part","label":"dispensing Subsystem"},{"source":"_2026x_1_12a70364_1789363922516_578822_3741","target":"_2026x_1_12a70364_1789363180535_753073_3717","kind":"part","label":"power Subsystem"},{"source":"_2026x_1_12a70364_1789363922516_578822_3741","target":"_2026x_1_12a70364_1789363184788_487139_3718","kind":"part","label":"water Subsystem"},{"source":"_2026x_1_12a70364_1789363922516_578822_3741","target":"_2026x_1_12a70364_1789365155322_752872_3841","kind":"reference","label":"dispensedCoffee"},{"source":"_2026x_1_12a70364_1789524431068_554815_5703","target":"_2026x_1_12a70364_1789363551438_409574_3734","kind":"part","label":"boiler"},{"source":"_2026x_1_12a70364_1789524431068_554815_5703","target":"_2026x_1_12a70364_1789524431066_920359_5702","kind":"part","label":"boilerObserver"}]}}
\ No newline at end of file
diff --git a/sample/demo/CoffeeMachine-Showcase-standalone.html b/sample/demo/CoffeeMachine-Showcase-standalone.html
new file mode 100644
index 0000000..849c83c
--- /dev/null
+++ b/sample/demo/CoffeeMachine-Showcase-standalone.html
@@ -0,0 +1,977 @@
+<!DOCTYPE html>
+<html lang="en">
+<head>
+<meta charset="UTF-8">
+<meta name="viewport" content="width=device-width, initial-scale=1.0">
+<title>Coffee Machine — MBSE Model Explorer</title>
+<script src="https://cdnjs.cloudflare.com/ajax/libs/vis-network/9.1.9/dist/vis-network.min.js"></script>
+<style>
+  :root{
+    --bg:#0f1216; --panel:#171b22; --panel2:#1e232c; --line:#2a313c; --txt:#e6e9ee; --muted:#9aa4b2;
+    --accent:#c8873a; --accent2:#6ab0f3; --green:#63c088; --purple:#b98bd6; --red:#e0685f; --chip:#232a34;
+  }
+  *{box-sizing:border-box}
+  body{margin:0;font-family:'Segoe UI',system-ui,sans-serif;background:var(--bg);color:var(--txt);height:100vh;display:flex;flex-direction:column;overflow:hidden}
+  header{display:flex;align-items:center;gap:16px;padding:12px 18px;background:linear-gradient(90deg,#1a1f27,#12151b);border-bottom:1px solid var(--line)}
+  header h1{font-size:17px;margin:0;font-weight:650;letter-spacing:.2px}
+  header h1 .c{color:var(--accent)}
+  .chips{display:flex;gap:8px;margin-left:auto;flex-wrap:wrap}
+  .chip{background:var(--chip);border:1px solid var(--line);border-radius:20px;padding:4px 12px;font-size:12px;color:var(--muted)}
+  .chip b{color:var(--txt);font-size:13px}
+  .body{flex:1;display:flex;min-height:0}
+  nav{width:186px;background:var(--panel);border-right:1px solid var(--line);padding:10px 8px;display:flex;flex-direction:column;gap:2px}
+  nav button{background:none;border:none;color:var(--muted);text-align:left;padding:10px 12px;border-radius:8px;cursor:pointer;font-size:13.5px;display:flex;align-items:center;gap:9px}
+  nav button:hover{background:var(--panel2);color:var(--txt)}
+  nav button.active{background:var(--accent);color:#141414;font-weight:600}
+  nav .sp{flex:1}
+  nav .st{font-size:11px;color:var(--muted);padding:8px 12px;border-top:1px solid var(--line)}
+  main{flex:1;position:relative;min-width:0}
+  .view{position:absolute;inset:0;overflow:auto;padding:18px;display:none}
+  .view.active{display:block}
+  .view.nopad{padding:0}
+  #graph{width:100%;height:100%}
+  h2{font-size:15px;color:var(--accent2);margin:0 0 12px;font-weight:600}
+  .card{background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:14px 16px;margin-bottom:12px}
+  .card h3{margin:0 0 6px;font-size:14px}
+  .card .st{font-size:11px;color:var(--muted);text-transform:uppercase;letter-spacing:.5px}
+  table{width:100%;border-collapse:collapse;font-size:13px}
+  th,td{text-align:left;padding:7px 10px;border-bottom:1px solid var(--line);vertical-align:top}
+  th{color:var(--muted);font-weight:600;font-size:11px;text-transform:uppercase;letter-spacing:.5px}
+  td .id{color:var(--accent);font-weight:600;font-family:ui-monospace,monospace}
+  .tag{display:inline-block;background:var(--chip);border:1px solid var(--line);border-radius:5px;padding:1px 7px;font-size:11px;color:var(--muted);margin:1px}
+  .attr{font-family:ui-monospace,monospace;font-size:12px;color:var(--muted)}
+  .grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:12px}
+  .flow{font-family:ui-monospace,monospace;font-size:12px;color:var(--muted);line-height:1.7}
+  .flow .n{color:var(--txt)} .flow .g{color:var(--green)} .flow .a{color:var(--accent)}
+  .legend{position:absolute;bottom:14px;left:14px;background:rgba(20,24,30,.9);border:1px solid var(--line);border-radius:8px;padding:10px 12px;font-size:12px;z-index:5}
+  .legend div{display:flex;align-items:center;gap:7px;margin:3px 0;color:var(--muted)}
+  .dot{width:11px;height:11px;border-radius:50%}
+  .gctl{position:absolute;top:14px;right:14px;z-index:5;display:flex;gap:6px;flex-wrap:wrap;max-width:60%}
+  .gctl button{background:var(--panel2);border:1px solid var(--line);color:var(--muted);border-radius:6px;padding:5px 10px;font-size:12px;cursor:pointer}
+  .gctl button.on{background:var(--accent);color:#141414;border-color:var(--accent)}
+  /* chat */
+  #chat{display:flex;flex-direction:column;height:100%}
+  #msgs{flex:1;overflow:auto;padding:18px;display:flex;flex-direction:column;gap:12px}
+  .msg{max-width:80%;padding:10px 14px;border-radius:12px;font-size:13.5px;line-height:1.5;white-space:pre-wrap}
+  .msg.u{align-self:flex-end;background:var(--accent2);color:#0a0a0a}
+  .msg.a{align-self:flex-start;background:var(--panel2);border:1px solid var(--line)}
+  .msg.sys{align-self:center;background:none;color:var(--muted);font-size:12px;border:1px dashed var(--line)}
+  .cbar{display:flex;gap:8px;padding:12px 16px;border-top:1px solid var(--line);background:var(--panel)}
+  .cbar input{flex:1;background:var(--panel2);border:1px solid var(--line);border-radius:8px;padding:10px 12px;color:var(--txt);font-size:13.5px}
+  .cbar button{background:var(--accent);border:none;color:#141414;font-weight:600;border-radius:8px;padding:0 18px;cursor:pointer}
+  .cbar button:disabled{opacity:.5;cursor:default}
+  .suggest{display:flex;gap:6px;flex-wrap:wrap;padding:0 16px 10px}
+  .suggest span{background:var(--chip);border:1px solid var(--line);border-radius:14px;padding:4px 11px;font-size:12px;color:var(--muted);cursor:pointer}
+  .banner{background:#3a2a12;border:1px solid var(--accent);color:#f0c88a;font-size:12px;padding:8px 12px;border-radius:8px;margin:0 16px 8px}
+  a{color:var(--accent2)}
+  /* digital twin */
+  #twinWrap{display:flex;height:100%;min-height:0}
+  #twinStage{flex:1;display:flex;align-items:center;justify-content:center;background:radial-gradient(circle at 50% 30%,#1a2029,#0d1013);min-width:0}
+  #twinStage svg{width:100%;height:100%;max-height:100%}
+  #twinPanel{width:300px;border-left:1px solid var(--line);background:var(--panel);padding:16px;overflow:auto;display:flex;flex-direction:column;gap:14px}
+  .tp-state{text-align:center;padding:12px;border-radius:10px;background:var(--panel2);border:1px solid var(--line)}
+  .tp-state .lbl{font-size:11px;color:var(--muted);text-transform:uppercase;letter-spacing:1px}
+  .tp-state .val{font-size:22px;font-weight:700;color:var(--accent);margin-top:3px}
+  .tp-state .sub{font-size:12px;color:var(--muted);margin-top:3px}
+  .tp-btns{display:grid;grid-template-columns:1fr 1fr;gap:8px}
+  .tp-btns button{padding:11px 8px;border-radius:9px;border:1px solid var(--line);background:var(--panel2);color:var(--txt);font-size:13px;font-weight:600;cursor:pointer}
+  .tp-btns button.power{grid-column:1/3;background:var(--green);color:#0a0a0a;border:none}
+  .tp-btns button.power.on{background:var(--red);color:#fff}
+  .tp-btns button.go{background:var(--accent);color:#141414;border:none}
+  .tp-btns button:disabled{opacity:.4;cursor:default}
+  .tp-row{font-size:12.5px;color:var(--muted);display:flex;justify-content:space-between;align-items:center}
+  .tp-row b{color:var(--txt)}
+  .tp-meter{height:9px;background:var(--panel2);border:1px solid var(--line);border-radius:6px;overflow:hidden;margin-top:4px}
+  .tp-meter > div{height:100%;transition:width .2s}
+  .tp-req{padding:10px;border-radius:9px;font-size:12.5px;border:1px solid var(--line)}
+  .tp-req.ok{background:#12281a;border-color:var(--green);color:#8fe0aa}
+  .tp-req.bad{background:#2a1414;border-color:var(--red);color:#f0a09a}
+  .tp-steps{display:flex;flex-direction:column;gap:5px}
+  .tp-step{font-size:12px;color:var(--muted);padding:5px 9px;border-radius:7px;border:1px solid var(--line);display:flex;gap:7px;align-items:center}
+  .tp-step.active{background:var(--accent);color:#141414;font-weight:600;border-color:var(--accent)}
+  .tp-step.done{color:var(--green);border-color:#2c4a38}
+  .tp-slider{width:100%}
+  .tp-h{font-size:11px;color:var(--muted);text-transform:uppercase;letter-spacing:1px;margin-bottom:-6px}
+  /* market fit */
+  .mk-head{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;margin-bottom:14px}
+  .mk-kpi{background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:14px}
+  .mk-kpi .n{font-size:26px;font-weight:700}
+  .mk-kpi .l{font-size:11px;color:var(--muted);text-transform:uppercase;letter-spacing:.5px;margin-top:2px}
+  .mk-controls{background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:12px 16px;margin-bottom:14px;display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:14px}
+  .mk-ctl label{font-size:12px;color:var(--muted);display:block;margin-bottom:4px}
+  .mk-ctl b{color:var(--accent)}
+  .mk-ctl input[type=range]{width:100%}
+  .mk-cell{text-align:center;font-weight:600;border-radius:5px;padding:3px 0}
+  .mk-pass{background:#12281a;color:#63c088}
+  .mk-fail{background:#2a1414;color:#e0685f}
+  .mk-verdict td{font-weight:700}
+  .mk-rec{background:#3a2a12;border:1px solid var(--accent);color:#f0c88a;border-radius:10px;padding:14px 16px;margin-top:14px;font-size:13.5px;line-height:1.55}
+  .mk-rec b{color:#fff}
+  .mk-src{font-size:11px;color:var(--muted);margin-top:12px}
+  .mk-src a{color:var(--accent2)}
+  .mk-price{color:var(--muted);font-size:12px}
+  table.mk td, table.mk th{font-size:12.5px}
+  /* fault injection */
+  .tp-faults{display:grid;grid-template-columns:1fr 1fr;gap:6px}
+  .tp-faults button{padding:8px 6px;border-radius:8px;border:1px solid #5a2f2a;background:#2a1714;color:#f0b9b2;font-size:11.5px;cursor:pointer;text-align:left}
+  .tp-faults button:hover{background:#3a1f1a}
+  .tp-faults button.clear{grid-column:1/3;background:#12281a;border-color:#2c4a38;color:#8fe0aa}
+  .tp-log{background:#0e1216;border:1px solid var(--line);border-radius:8px;padding:8px 10px;font-family:Consolas,monospace;font-size:11px;color:#9aa4b2;height:96px;overflow:auto;line-height:1.5}
+  .tp-log .f{color:#e0685f}.tp-log .g{color:#63c088}.tp-log .a{color:var(--accent)}
+  /* OEE */
+  .oee-top{display:grid;grid-template-columns:280px 1fr;gap:16px;margin-bottom:14px}
+  .oee-ring{background:var(--panel);border:1px solid var(--line);border-radius:12px;padding:16px;display:flex;flex-direction:column;align-items:center;justify-content:center}
+  .oee-comp{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}
+  .oee-card{background:var(--panel);border:1px solid var(--line);border-radius:12px;padding:16px}
+  .oee-card .l{font-size:12px;color:var(--muted);text-transform:uppercase;letter-spacing:.5px}
+  .oee-card .n{font-size:34px;font-weight:700;margin-top:4px}
+  .oee-card .d{font-size:11px;color:var(--muted);margin-top:4px}
+  .oee-meter{height:8px;background:var(--panel2);border-radius:5px;overflow:hidden;margin-top:8px}
+  .oee-meter>div{height:100%}
+  .oee-kpis{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-top:2px}
+  .oee-kpi{background:var(--panel2);border:1px solid var(--line);border-radius:10px;padding:12px}
+  .oee-kpi .n{font-size:24px;font-weight:700;color:var(--txt)}
+  .oee-kpi .l{font-size:10.5px;color:var(--muted);text-transform:uppercase;letter-spacing:.5px;margin-top:2px}
+  .oee-note{font-size:12px;color:var(--muted);margin-top:14px}
+  /* OEE strip on twin */
+  #twinStage{flex-direction:column}
+  #twinStage svg#twinMachine{flex:1;min-height:0}
+  #twinOee{width:94%;max-width:820px;margin:0 auto 10px;display:flex;align-items:center;gap:14px;background:var(--panel);border:1px solid var(--line);border-radius:12px;padding:10px 16px}
+  #twinOee .big{font-size:30px;font-weight:800;line-height:1}
+  #twinOee .big small{font-size:11px;color:var(--muted);display:block;font-weight:600;letter-spacing:1px}
+  #twinOee .apq{display:flex;gap:10px;flex:1}
+  #twinOee .apq div{flex:1}
+  #twinOee .apq .k{font-size:10px;color:var(--muted);text-transform:uppercase;letter-spacing:.5px}
+  #twinOee .apq .m{height:6px;background:var(--panel2);border-radius:4px;overflow:hidden;margin-top:3px}
+  #twinOee .apq .m>i{display:block;height:100%}
+  #twinOee .apq .v{font-size:13px;font-weight:700;margin-top:2px}
+  #twinOee .cups{text-align:right;font-size:12px;color:var(--muted)}
+  #twinOee .cups b{color:var(--txt);font-size:16px}
+  /* ontology */
+  .on-def{background:var(--panel);border:1px solid var(--line);border-radius:12px;padding:18px 22px;margin-bottom:14px}
+  .on-def .big{font-size:17px;color:var(--txt);line-height:1.5}
+  .on-def .big b{color:var(--accent)}
+  .on-def .joke{font-size:13px;color:var(--muted);font-style:italic;margin-top:8px}
+  .on-cols{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin-bottom:14px}
+  .on-col{background:var(--panel);border:1px solid var(--line);border-radius:12px;padding:14px 16px}
+  .on-col h3{margin:0 0 3px;font-size:15px}
+  .on-col .sub{font-size:11px;color:var(--muted);margin-bottom:10px}
+  .on-chip{display:inline-block;border-radius:6px;padding:3px 9px;margin:3px 3px 3px 0;font-size:12px}
+  .on-class{background:#2a2114;border:1px solid #5a4a2a;color:#e8c15a}
+  .on-ind{background:#122228;border:1px solid #2a4a52;color:#7fd0e0}
+  .on-rel{background:#221426;border:1px solid #4a2a52;color:#c89bd6;font-family:Consolas,monospace}
+  table.on{width:100%;border-collapse:collapse;font-size:13px}
+  table.on td,table.on th{padding:7px 10px;border-bottom:1px solid var(--line);text-align:left}
+  table.on th{font-size:11px;color:var(--muted);text-transform:uppercase;letter-spacing:.5px}
+  table.on .s{color:#e8c15a;font-weight:600}
+  table.on .p{color:#c89bd6;font-family:Consolas,monospace}
+  table.on .o{color:#7fd0e0;font-weight:600}
+  table.on .src{font-size:10px;color:var(--muted)}
+  .on-infer{background:#12281a;border:1px solid #2c4a38;border-radius:12px;padding:16px 18px;margin-top:14px;font-size:13.5px;color:#bfe6cd;line-height:1.6}
+  .on-infer b{color:#8fe0aa}
+  .on-vs{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-top:14px}
+  .on-vs .c{background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:12px 14px}
+  .on-vs .c h4{margin:0 0 4px;font-size:13px;color:var(--accent)}
+  .on-vs .c p{margin:0;font-size:11.5px;color:var(--muted);line-height:1.45}
+</style>
+</head>
+<body>
+<header>
+  <h1>☕ <span class="c">Coffee Machine</span> — MBSE Model Explorer <span style="font-size:11px;font-weight:600;color:#c8873a;border:1px solid #c8873a;border-radius:10px;padding:2px 8px;margin-left:8px">STANDALONE SHOWCASE</span></h1>
+  <div class="chips" id="chips"></div>
+</header>
+<div class="body">
+  <nav>
+    <button data-v="graph" class="active">🕸 Model Graph</button>
+    <button data-v="structure">🧱 Structure</button>
+    <button data-v="stm">🔄 State Machine</button>
+    <button data-v="acts">⚙ Activities</button>
+    <button data-v="reqs">📋 Requirements</button>
+    <button data-v="twin">🎛 Digital Twin</button>
+    <button data-v="market">🛒 Market Fit</button>
+    <button data-v="oee">📈 OEE / Throughput</button>
+    <button data-v="onto">🧠 Ontology</button>
+    <button data-v="chat">💬 Ask the Model</button>
+    <div class="sp"></div>
+    <div class="st" id="meta"></div>
+  </nav>
+  <main>
+    <div class="view nopad active" id="v-graph">
+      <div id="graph"></div>
+      <div class="gctl" id="gctl"></div>
+      <div class="legend" id="legend"></div>
+    </div>
+    <div class="view" id="v-structure"></div>
+    <div class="view" id="v-stm"></div>
+    <div class="view" id="v-acts"></div>
+    <div class="view" id="v-reqs"></div>
+    <div class="view nopad" id="v-twin">
+      <div id="twinWrap">
+        <div id="twinStage"></div>
+        <div id="twinPanel"></div>
+      </div>
+    </div>
+    <div class="view" id="v-market"></div>
+    <div class="view" id="v-oee"></div>
+    <div class="view" id="v-onto"></div>
+    <div class="view nopad" id="v-chat">
+      <div id="chat">
+        <div class="banner" id="llmBanner">Connecting to local LLM at <code>localhost:11434</code>…</div>
+        <div id="msgs"></div>
+        <div class="suggest" id="suggest"></div>
+        <div class="cbar">
+          <input id="q" placeholder="Ask about the coffee machine model…" autocomplete="off">
+          <button id="send">Send</button>
+        </div>
+      </div>
+    </div>
+  </main>
+</div>
+<script>
+const KIND_COLOR = {block:'#c8873a',requirement:'#b98bd6',state:'#6ab0f3',activity:'#63c088',action:'#63c088',signal:'#e0685f',interface:'#4fd1c5',stateMachine:'#6ab0f3',usecase:'#e8c15a',actor:'#8fa0b3'};
+const LLM_URL='http://localhost:11434';
+let MODEL=null, LLM_MODEL=null, network=null;
+window.__MODEL__={"project":"Coffee Machine Model","exportedAt":"Thu Sep 17 11:36:29 AEST 2026","summary":{"blocks":49,"requirements":25,"interfaces":0,"signals":9,"activities":8,"graphNodes":99,"graphEdges":165},"structure":[{"id":"_2026x_1_12a70364_1789357107731_106889_3635","name":"Coffee Machine","kind":"block","stereotypes":["Block"],"attributes":[{"name":"water System","type":"Water System","aggregation":"composite","default":""},{"name":"electrical System","type":"Electrical System","aggregation":"composite","default":""},{"name":"brew System","type":"Brew System","aggregation":"composite","default":""},{"name":"coffeeSize","type":"coffeeSize","aggregation":"composite","default":""},{"name":"coffeeStrength","type":"coffeeStrength","aggregation":"composite","default":""},{"name":"selectionMade","type":"Boolean","aggregation":"composite","default":""},{"name":"coffeeResult","type":"coffeeResult","aggregation":"composite","default":""},{"name":"coffee Machine Production","type":"Coffee Machine Production","aggregation":"none","default":""},{"name":"Waterin","type":"Water Flow Port","aggregation":"composite","default":""},{"name":"Coffee beans in","type":"Coffee State","aggregation":"composite","default":""},{"name":"dregs","type":"Waste Port","aggregation":"composite","default":""},{"name":"Coffee Dispensed","type":"Drink outlet","aggregation":"composite","default":""},{"name":"liquid waste","type":"Waste Port","aggregation":"composite","default":""},{"name":"p2","type":"GPO","aggregation":"composite","default":""}],"documentation":""},{"id":"_2026x_1_12a70364_1789357175665_504215_3638","name":"Water System","kind":"block","stereotypes":["Block"],"attributes":[{"name":"inlet","type":"Water Inlet","aggregation":"none","default":""}],"documentation":""},{"id":"_2026x_1_12a70364_1789357305852_992852_3641","name":"Electrical System","kind":"block","stereotypes":["Block"],"attributes":[],"documentation":""},{"id":"_2026x_1_12a70364_1789357381144_263298_3644","name":"Brew System","kind":"block","stereotypes":["Block"],"attributes":[],"documentation":""},{"id":"_2026x_1_12a70364_1789358228897_970701_3681","name":"Coffee Machine Production","kind":"block","stereotypes":["Block"],"attributes":[],"documentation":""},{"id":"_2026x_1_12a70364_1789358512516_28052_3684","name":"Water Flow Port","kind":"block","stereotypes":["InterfaceBlock"],"attributes":[{"name":"water","type":"","aggregation":"none","default":""}],"documentation":""},{"id":"_2026x_1_12a70364_1789358695241_447494_3686","name":"Coffee State","kind":"block","stereotypes":["InterfaceBlock"],"attributes":[{"name":"coffeeBeans","type":"","aggregation":"none","default":""}],"documentation":""},{"id":"_2026x_1_12a70364_1789358720758_903471_3688","name":"Waste Port","kind":"block","stereotypes":["InterfaceBlock"],"attributes":[{"name":"waste","type":"","aggregation":"none","default":""}],"documentation":""},{"id":"_2026x_1_12a70364_1789358753658_420800_3690","name":"Drink outlet","kind":"block","stereotypes":["InterfaceBlock"],"attributes":[{"name":"drink","type":"","aggregation":"none","default":""}],"documentation":""},{"id":"_2026x_1_12a70364_1789358830928_193983_3693","name":"GPO","kind":"block","stereotypes":["InterfaceBlock"],"attributes":[{"name":"power","type":"","aggregation":"none","default":""}],"documentation":""},{"id":"_2026x_1_12a70364_1789365065038_185163_3840","name":"Water Inlet","kind":"block","stereotypes":["InterfaceBlock"],"attributes":[],"documentation":""},{"id":"_2026x_1_12a70364_1789365155322_752872_3841","name":"Coffee","kind":"block","stereotypes":["Block"],"attributes":[],"documentation":""},{"id":"_2026x_1_12a70364_1789365188589_930663_3842","name":"Coffee Beans","kind":"block","stereotypes":["Block"],"attributes":[],"documentation":""},{"id":"_2026x_1_12a70364_1789365192860_189919_3843","name":"Water","kind":"block","stereotypes":["Block"],"attributes":[],"documentation":""},{"id":"_2026x_1_12a70364_1789363113514_607533_3714","name":"Brew Subsystem","kind":"block","stereotypes":["Block"],"attributes":[{"name":"bean Storage","type":"Bean Storage","aggregation":"composite","default":""},{"name":"brewing Unit","type":"Brewing Unit","aggregation":"composite","default":""},{"name":"doser Unit","type":"Doser Unit","aggregation":"composite","default":""},{"name":"grinder","type":"Grinder","aggregation":"composite","default":""},{"name":"grounds Drawer","type":"Grounds Drawer","aggregation":"composite","default":""}],"documentation":""},{"id":"_2026x_1_12a70364_1789363134214_804452_3715","name":"Control Subsystem","kind":"block","stereotypes":["Block"],"attributes":[{"name":"control Module","type":"Control Module","aggregation":"composite","default":""},{"name":"user Interface Panel","type":"User Interface Panel","aggregation":"composite","default":""}],"documentation":""},{"id":"_2026x_1_12a70364_1789363176200_671776_3716","name":"Dispensing Subsystem","kind":"block","stereotypes":["Block"],"attributes":[{"name":"coffee Outlet","type":"Coffee Outlet","aggregation":"composite","default":""},{"name":"drip Tray","type":"Drip Tray","aggregation":"composite","default":""}],"documentation":""},{"id":"_2026x_1_12a70364_1789363180535_753073_3717","name":"Power Subsystem","kind":"block","stereotypes":["Block"],"attributes":[{"name":"door Switch","type":"Door Switch","aggregation":"composite","default":""},{"name":"mains Cord","type":"Mains Cord","aggregation":"composite","default":""},{"name":"mains Switch","type":"Mains Switch","aggregation":"composite","default":""},{"name":"power Supply","type":"Power Supply","aggregation":"composite","default":""}],"documentation":""},{"id":"_2026x_1_12a70364_1789363184788_487139_3718","name":"Water Subsystem","kind":"block","stereotypes":["Block"],"attributes":[{"name":"boiler","type":"Boiler","aggregation":"composite","default":""},{"name":"flow Meter","type":"Flow Meter","aggregation":"composite","default":""},{"name":"water Pump","type":"Water Pump","aggregation":"composite","default":""},{"name":"water Tank","type":"Water Tank","aggregation":"composite","default":""},{"name":"water Valve","type":"Water Valve","aggregation":"composite","default":""}],"documentation":""},{"id":"_2026x_1_12a70364_1789363224675_90261_3719","name":"Bean Storage","kind":"block","stereotypes":["Block"],"attributes":[{"name":"storedBeans","type":"Coffee Beans","aggregation":"none","default":""}],"documentation":""},{"id":"_2026x_1_12a70364_1789363229077_574630_3720","name":"Brewing Unit","kind":"block","stereotypes":["Block"],"attributes":[],"documentation":""},{"id":"_2026x_1_12a70364_1789363233424_933473_3721","name":"Doser Unit","kind":"block","stereotypes":["Block"],"attributes":[],"documentation":""},{"id":"_2026x_1_12a70364_1789363237787_500380_3722","name":"Grinder","kind":"block","stereotypes":["Block"],"attributes":[],"documentation":""},{"id":"_2026x_1_12a70364_1789363242138_385667_3723","name":"Grounds Drawer","kind":"block","stereotypes":["Block"],"attributes":[],"documentation":""},{"id":"_2026x_1_12a70364_1789363276685_64862_3724","name":"Control Module","kind":"block","stereotypes":["Block"],"attributes":[],"documentation":""},{"id":"_2026x_1_12a70364_1789363281032_103275_3725","name":"User Interface Panel","kind":"block","stereotypes":["Block"],"attributes":[],"documentation":""},{"id":"_2026x_1_12a70364_1789363285378_732895_3726","name":"Coffee Outlet","kind":"block","stereotypes":["Block"],"attributes":[],"documentation":""},{"id":"_2026x_1_12a70364_1789363289724_897457_3727","name":"Drip Tray","kind":"block","stereotypes":["Block"],"attributes":[],"documentation":""},{"id":"_2026x_1_12a70364_1789363293999_849627_3728","name":"Door Switch","kind":"block","stereotypes":["Block"],"attributes":[],"documentation":""},{"id":"_2026x_1_12a70364_1789363326324_823109_3729","name":"Mains Cord","kind":"block","stereotypes":["Block"],"attributes":[],"documentation":""},{"id":"_2026x_1_12a70364_1789363330606_330250_3730","name":"Mains Switch","kind":"block","stereotypes":["Block"],"attributes":[],"documentation":""},{"id":"_2026x_1_12a70364_1789363334952_109655_3731","name":"Power Supply","kind":"block","stereotypes":["Block"],"attributes":[],"documentation":""},{"id":"_2026x_1_12a70364_1789363551438_409574_3734","name":"Boiler","kind":"block","stereotypes":["Block"],"attributes":[{"name":"inputWaterTemperature","type":"Real","aggregation":"composite","default":"25.0"},{"name":"outputWaterTemperature","type":"Real","aggregation":"composite","default":""},{"name":"boilingFactor","type":"Real","aggregation":"composite","default":"0.6"},{"name":"targetWaterTemperature","type":"Real","aggregation":"composite","default":"84.0"},{"name":"waterTemperatureAtTargetTime","type":"Real","aggregation":"composite","default":""}],"documentation":""},{"id":"_2026x_1_12a70364_1789363585791_503580_3735","name":"Flow Meter","kind":"block","stereotypes":["Block"],"attributes":[],"documentation":""},{"id":"_2026x_1_12a70364_1789363591862_529655_3736","name":"Water Pump","kind":"block","stereotypes":["Block"],"attributes":[],"documentation":""},{"id":"_2026x_1_12a70364_1789363775704_719608_3739","name":"Water Tank","kind":"block","stereotypes":["Block"],"attributes":[{"name":"storedWater","type":"Water","aggregation":"none","default":""}],"documentation":""},{"id":"_2026x_1_12a70364_1789363832704_318902_3740","name":"Water Valve","kind":"block","stereotypes":["Block"],"attributes":[],"documentation":""},{"id":"_2026x_1_12a70364_1789363922516_578822_3741","name":"Coffee Machine System","kind":"block","stereotypes":["Block"],"attributes":[{"name":"brew Subsystem","type":"Brew Subsystem","aggregation":"composite","default":""},{"name":"control Subsystem","type":"Control Subsystem","aggregation":"composite","default":""},{"name":"dispensing Subsystem","type":"Dispensing Subsystem","aggregation":"composite","default":""},{"name":"power Subsystem","type":"Power Subsystem","aggregation":"composite","default":""},{"name":"water Subsystem","type":"Water Subsystem","aggregation":"composite","default":""},{"name":"dispensedCoffee","type":"Coffee","aggregation":"none","default":""}],"documentation":""},{"id":"_2026x_1_12a70364_1789602694850_639924_6114","name":"Isolate Power (RCD trip)","kind":"block","stereotypes":[],"attributes":[],"documentation":""},{"id":"_2026x_1_12a70364_1789524947739_455059_5824","name":"Coffee Consumer","kind":"actor","stereotypes":["Actor"],"attributes":[],"documentation":""},{"id":"_2026x_1_12a70364_1789524947844_364892_5825","name":"Maintenance Operator","kind":"actor","stereotypes":["Actor"],"attributes":[],"documentation":""},{"id":"_2026x_1_12a70364_1789524947853_806196_5826","name":"Select Coffee","kind":"usecase","stereotypes":["UseCase"],"attributes":[],"documentation":""},{"id":"_2026x_1_12a70364_1789524947871_813181_5827","name":"Make Coffee","kind":"usecase","stereotypes":["UseCase"],"attributes":[],"documentation":""},{"id":"_2026x_1_12a70364_1789524947875_764584_5828","name":"Refill Water Tank","kind":"usecase","stereotypes":["UseCase"],"attributes":[],"documentation":""},{"id":"_2026x_1_12a70364_1789524947877_120920_5829","name":"Refill Coffee Beans","kind":"usecase","stereotypes":["UseCase"],"attributes":[],"documentation":""},{"id":"_2026x_1_12a70364_1789524947879_552225_5830","name":"Remove Waste","kind":"usecase","stereotypes":["UseCase"],"attributes":[],"documentation":""},{"id":"_2026x_1_12a70364_1789524431066_920359_5702","name":"Boiler Observer","kind":"block","stereotypes":["Block"],"attributes":[{"name":"Time","type":"Real","aggregation":"composite","default":""},{"name":"targetTime","type":"Real","aggregation":"composite","default":"90.0"}],"documentation":""},{"id":"_2026x_1_12a70364_1789524431068_554815_5703","name":"Water Heating Analysis Context","kind":"block","stereotypes":["Block"],"attributes":[{"name":"boiler","type":"Boiler","aggregation":"composite","default":""},{"name":"boilerObserver","type":"Boiler Observer","aggregation":"composite","default":""}],"documentation":""},{"id":"_2026x_1_12a70364_1789524431144_707453_5727","name":"Water Temperature Constraint","kind":"block","stereotypes":["ConstraintBlock"],"attributes":[{"name":"waterTemperatureAtTargetTime","type":"Real","aggregation":"none","default":""},{"name":"targetWaterTemperature","type":"Real","aggregation":"none","default":""}],"documentation":""}],"interfaces":[],"signals":[{"id":"_2026x_1_12a70364_1789365197170_873209_3844","name":"Command"},{"id":"_2026x_1_12a70364_1789365201520_200533_3845","name":"Power"},{"id":"_2026x_1_12a70364_1789446787460_992481_4188","name":"Coffee Selection"},{"id":"_2026x_1_12a70364_1789433848990_731675_3921","name":"Brew Complete"},{"id":"_2026x_1_12a70364_1789433896301_568328_3928","name":"PowerOff"},{"id":"_2026x_1_12a70364_1789434080835_765687_3939","name":"PowerOn"},{"id":"_2026x_1_12a70364_1789434127181_875752_3946","name":"Selection Made"},{"id":"_2026x_1_12a70364_1789602694790_416161_6107","name":"Short Detected"},{"id":"_2026x_1_12a70364_1789524740660_19378_5755","name":"Target Time Reached"}],"requirements":[{"id":"_2026x_1_12a70364_1789522470201_737876_5617","name":"System Level Requirements","kind":"requirement","stereotypes":["Requirement"],"attributes":[],"documentation":"","reqId":"1","reqText":""},{"id":"_2026x_1_12a70364_1789522470210_613186_5619","name":"Heater Initialization","kind":"requirement","stereotypes":["Requirement"],"attributes":[],"documentation":"","reqId":"1.1","reqText":"The boiler shall heat water to 84°C within 90 seconds of turning on the coffee machine"},{"id":"_2026x_1_12a70364_1789522470213_487063_5622","name":"Overheating","kind":"requirement","stereotypes":["Requirement"],"attributes":[],"documentation":"","reqId":"1.2","reqText":"The thermostat shall stop all power supply if the instantaneous water heater exceeds 170°C"},{"id":"_2026x_1_12a70364_1789522470217_232543_5625","name":"Water Tank Level","kind":"requirement","stereotypes":["Requirement"],"attributes":[],"documentation":"","reqId":"1.3","reqText":"The water tank will not brew coffee if there is less than 500mL of water"},{"id":"_2026x_1_12a70364_1789522470220_757311_5628","name":"Coffee Bean Level","kind":"requirement","stereotypes":["Requirement"],"attributes":[],"documentation":"","reqId":"1.4","reqText":"The grinder will not grind coffee beans if there is less than 45g of beans within the bean container"},{"id":"_2026x_1_12a70364_1789522470227_43173_5631","name":"Water Tank Capacity","kind":"requirement","stereotypes":["Requirement"],"attributes":[],"documentation":"","reqId":"1.5","reqText":"The water tank shall be able to hold a max capacity of 2.4L"},{"id":"_2026x_1_12a70364_1789522470229_653956_5634","name":"Coffee Bean Capacity","kind":"requirement","stereotypes":["Requirement"],"attributes":[],"documentation":"","reqId":"1.6","reqText":"The coffee bean container shall be able to store a max weight of 300g of coffee beans"},{"id":"_2026x_1_12a70364_1789522470232_505575_5637","name":"Grounds Draw Waste","kind":"requirement","stereotypes":["Requirement"],"attributes":[],"documentation":"","reqId":"1.7","reqText":"The grounds draw can store a max waste capacity of 8 grounds before it is deemed full"},{"id":"_2026x_1_12a70364_1789522470236_795679_5640","name":"Pump Pressure","kind":"requirement","stereotypes":["Requirement"],"attributes":[],"documentation":"","reqId":"1.8","reqText":"The pump presser shall not be greater than 15 bar"},{"id":"_2026x_1_12a70364_1789522470238_822356_5643","name":"System Check","kind":"requirement","stereotypes":["Requirement"],"attributes":[],"documentation":"","reqId":"1.9","reqText":"The coffee machine will perform a system check to confirm coffee beans and water levels are satisfied before a coffee is made"},{"id":"_2026x_1_12a70364_1789522470240_748943_5646","name":"System Alert","kind":"requirement","stereotypes":["Requirement"],"attributes":[],"documentation":"","reqId":"1.10","reqText":"The coffee machine will alert to user of a system check to be addressed"},{"id":"_2026x_1_12a70364_1789522470243_75877_5649","name":"Control Panel","kind":"requirement","stereotypes":["Requirement"],"attributes":[],"documentation":"","reqId":"1.11","reqText":"The coffee machine shall have a digital display which the user can make selections with ease"},{"id":"_2026x_1_12a70364_1789522470246_238622_5652","name":"Cleaning Requirements","kind":"requirement","stereotypes":["Requirement"],"attributes":[],"documentation":"","reqId":"2","reqText":""},{"id":"_2026x_1_12a70364_1789522470249_829935_5654","name":"Clean brewing unit","kind":"requirement","stereotypes":["Requirement"],"attributes":[],"documentation":"","reqId":"2.1","reqText":"The maintenance operator shall clean the brewing unit once a week"},{"id":"_2026x_1_12a70364_1789522470251_936773_5657","name":"Clean Machine Exterior","kind":"requirement","stereotypes":["Requirement"],"attributes":[],"documentation":"","reqId":"2.2","reqText":"The maintenance operator shall clean the exterior only using water and kitchen detergent"},{"id":"_2026x_1_12a70364_1789522470252_176734_5660","name":"Clean Water Tank","kind":"requirement","stereotypes":["Requirement"],"attributes":[],"documentation":"","reqId":"2.3","reqText":"The maintenance operator shall clean the water tank 1 time per week"},{"id":"_2026x_1_12a70364_1789522470268_212057_5663","name":"Safety Requirements","kind":"requirement","stereotypes":["Requirement"],"attributes":[],"documentation":"","reqId":"3","reqText":""},{"id":"_2026x_1_12a70364_1789522470269_5755_5665","name":"Internal Features","kind":"requirement","stereotypes":["Requirement"],"attributes":[],"documentation":"","reqId":"3.1","reqText":""},{"id":"_2026x_1_12a70364_1789522470270_589609_5667","name":"Gearmotor Overload","kind":"requirement","stereotypes":["Requirement"],"attributes":[],"documentation":"","reqId":"3.1.1","reqText":"If the gearmotor overloads the motors electronic system shall switchoff after 8-10s and the machine is stopped"},{"id":"_2026x_1_12a70364_1789522470271_475286_5670","name":"HWS Valve Open During Brewing","kind":"requirement","stereotypes":["Requirement"],"attributes":[],"documentation":"","reqId":"3.1.2","reqText":"During brewing operation if the HWS valve is opened the coffee machine shall interrupt the water flow"},{"id":"_2026x_1_12a70364_1789522470272_63721_5673","name":"Interruption By Removal Of Dregs Draw","kind":"requirement","stereotypes":["Requirement"],"attributes":[],"documentation":"","reqId":"3.1.3","reqText":"During operation if interruption occurs by the removal of the dreg draw the machine shall continue its function unrestricted once the drawer is returned"},{"id":"_2026x_1_12a70364_1789522470273_392927_5676","name":"Main Power Supply Disconnection During Operation","kind":"requirement","stereotypes":["Requirement"],"attributes":[],"documentation":"","reqId":"3.1.4","reqText":"If power failure/side doors opened during operation the coffee machines gears will complete the function commenced but without brewing"},{"id":"_2026x_1_12a70364_1789602694801_483599_6108","name":"Electrical Isolation On Dispense","kind":"requirement","stereotypes":["Requirement"],"attributes":[],"documentation":"","reqId":"3.1.5","reqText":"During water dispensing the coffee machine shall electrically isolate the water path and incorporate a residual current device (RCD) so that a short circuit cannot energise the chassis or expose the operator to electric shock."},{"id":"_2026x_1_12a70364_1789522470274_644308_5679","name":"External Features","kind":"requirement","stereotypes":["Requirement"],"attributes":[],"documentation":"","reqId":"3.2","reqText":""},{"id":"_2026x_1_12a70364_1789522470275_767711_5681","name":"Regulatory Compliance Mark","kind":"requirement","stereotypes":["Requirement"],"attributes":[],"documentation":"","reqId":"3.2.1","reqText":"The coffee machine unit shall not be sold unless it has a RCM with the Australian standards of the AS/NZS 4417.1 and AS/NZS 4417.2"}],"stateMachine":{"name":"Coffee Machine STM","regions":[{"states":[{"id":"_2026x_1_12a70364_1789435135035_153882_4003","name":"Initialising","entry":"Initialise System","doActivity":null,"exit":null},{"id":"_2026x_1_12a70364_1789435365659_95882_4015","name":"Idle","entry":"Check System","doActivity":"Select Coffee","exit":null},{"id":"_2026x_1_12a70364_1789435456171_517468_4025","name":"Brewing","entry":null,"doActivity":"Brew Coffee","exit":null}]},{"states":[{"id":"_2026x_1_12a70364_1789435572537_420067_4035","name":"Heating On","entry":null,"doActivity":null,"exit":null},{"id":"_2026x_1_12a70364_1789435653243_288439_4045","name":"Heating Off","entry":null,"doActivity":null,"exit":null}]},{"states":[{"id":"_2026x_1_12a70364_1789434195075_586370_3959","name":"Off","entry":null,"doActivity":null,"exit":null},{"id":"_2026x_1_12a70364_1789434765035_486603_3981","name":"On","entry":null,"doActivity":null,"exit":null}]}]},"activities":[{"name":"Boiler","partitions":[],"nodes":[{"id":"_2026x_1_12a70364_1789524740812_93085_5782","type":"InitialNode","name":"","partition":null},{"id":"_2026x_1_12a70364_1789524740812_700589_5783","type":"ForkNode","name":"","partition":null},{"id":"_2026x_1_12a70364_1789524740812_431953_5784","type":"AcceptEventAction","name":"Target Time Reached","partition":null},{"id":"_2026x_1_12a70364_1789524740813_943391_5785","type":"DecisionNode","name":"","partition":null},{"id":"_2026x_1_12a70364_1789524740813_183921_5786","type":"MergeNode","name":"","partition":null},{"id":"_2026x_1_12a70364_1789524740813_414471_5787","type":"OpaqueAction","name":"","partition":null},{"id":"_2026x_1_12a70364_1789524740813_518030_5788","type":"OpaqueAction","name":"","partition":null}],"edges":[{"type":"control","source":"","target":"","guard":""},{"type":"control","source":"","target":"","guard":""},{"type":"control","source":"","target":"Target Time Reached","guard":""},{"type":"control","source":"","target":"","guard":"outputWaterTemperature < targetWaterTemperature"},{"type":"control","source":"","target":"","guard":""},{"type":"control","source":"","target":"","guard":""},{"type":"control","source":"Target Time Reached","target":"","guard":""}]},{"name":"Clean System","partitions":[],"nodes":[],"edges":[]},{"name":"Initialise System","partitions":[],"nodes":[],"edges":[]},{"name":"Check System","partitions":[],"nodes":[],"edges":[]},{"name":"Select Coffee","partitions":[],"nodes":[],"edges":[]},{"name":"Brew Coffee","partitions":[{"name":"control Subsystem","represents":null},{"name":"water Subsystem","represents":null},{"name":"brew Subsystem","represents":null},{"name":"dispensing Subsystem","represents":null}],"nodes":[{"id":"_2026x_1_12a70364_1789450664669_244157_4265","type":"InitialNode","name":"","partition":"control Subsystem"},{"id":"_2026x_1_12a70364_1789450664670_69624_4266","type":"ActivityFinalNode","name":"","partition":"dispensing Subsystem"},{"id":"_2026x_1_12a70364_1789450664670_937912_4267","type":"AcceptEventAction","name":"","partition":"control Subsystem"},{"id":"_2026x_1_12a70364_1789450664674_1526_4269","type":"ForkNode","name":"","partition":null},{"id":"_2026x_1_12a70364_1789450664690_802950_4270","type":"OpaqueAction","name":"Heat Water","partition":"water Subsystem"},{"id":"_2026x_1_12a70364_1789450664692_239201_4273","type":"OpaqueAction","name":"Grind Beans","partition":"brew Subsystem"},{"id":"_2026x_1_12a70364_1789450664694_284067_4276","type":"OpaqueAction","name":"Extract Coffee","partition":"brew Subsystem"},{"id":"_2026x_1_12a70364_1789450664695_161554_4280","type":"OpaqueAction","name":"Dispense Coffee","partition":"dispensing Subsystem"}],"edges":[{"type":"control","source":"","target":"","guard":""},{"type":"object","source":"result","target":"","guard":""},{"type":"object","source":"","target":"input","guard":""},{"type":"object","source":"","target":"input","guard":""},{"type":"object","source":"output","target":"input","guard":""},{"type":"object","source":"output","target":"input1","guard":""},{"type":"object","source":"output","target":"input","guard":""},{"type":"control","source":"Dispense Coffee","target":"","guard":""}]},{"name":"Heat Water","partitions":[{"name":"water Tank","represents":"water Tank"},{"name":"flow Meter","represents":"flow Meter"},{"name":"water Pump","represents":"water Pump"},{"name":"boiler","represents":"boiler"}],"nodes":[{"id":"_2026x_1_12a70364_1789520884002_616409_5511","type":"ActivityParameterNode","name":"input","partition":null},{"id":"_2026x_1_12a70364_1789520884013_494487_5512","type":"ActivityParameterNode","name":"output","partition":null},{"id":"_2026x_1_12a70364_1789520884037_236501_5513","type":"InitialNode","name":"","partition":"water Tank"},{"id":"_2026x_1_12a70364_1789520884039_439710_5514","type":"OpaqueAction","name":"Open Valve","partition":"water Tank"},{"id":"_2026x_1_12a70364_1789520884041_535279_5515","type":"OpaqueAction","name":"Close Valve","partition":"water Tank"},{"id":"_2026x_1_12a70364_1789520884054_615979_5516","type":"FlowFinalNode","name":"","partition":"water Tank"},{"id":"_2026x_1_12a70364_1789520884064_588707_5517","type":"OpaqueAction","name":"Read Coffee Size","partition":"flow Meter"},{"id":"_2026x_1_12a70364_1789520884093_101205_5518","type":"MergeNode","name":"Merge 1","partition":"flow Meter"},{"id":"_2026x_1_12a70364_1789520884102_849036_5519","type":"OpaqueAction","name":"Measure Water","partition":"flow Meter"},{"id":"_2026x_1_12a70364_1789520884106_595239_5520","type":"DecisionNode","name":"Correct Volume?","partition":"flow Meter"},{"id":"_2026x_1_12a70364_1789520884116_758244_5521","type":"ForkNode","name":"Fork 2","partition":"flow Meter"},{"id":"_2026x_1_12a70364_1789520884117_344927_5522","type":"OpaqueAction","name":"Pump Water","partition":"water Pump"},{"id":"_2026x_1_12a70364_1789520884118_474916_5523","type":"ForkNode","name":"Fork 1","partition":"water Pump"},{"id":"_2026x_1_12a70364_1789520884119_475566_5524","type":"OpaqueAction","name":"Stop Pump","partition":"water Pump"},{"id":"_2026x_1_12a70364_1789520884120_513215_5525","type":"FlowFinalNode","name":"","partition":"water Pump"},{"id":"_2026x_1_12a70364_1789520884120_628547_5526","type":"MergeNode","name":"Merge 2","partition":"boiler"},{"id":"_2026x_1_12a70364_1789520884121_703915_5527","type":"OpaqueAction","name":"Heat Water","partition":"boiler"},{"id":"_2026x_1_12a70364_1789520884122_4579_5528","type":"DecisionNode","name":"Temp OK?","partition":"boiler"}],"edges":[{"type":"control","source":"","target":"Open Valve","guard":""},{"type":"control","source":"Open Valve","target":"Pump Water","guard":""},{"type":"object","source":"input","target":"Read Coffee Size","guard":""},{"type":"control","source":"Pump Water","target":"Fork 1","guard":""},{"type":"control","source":"Fork 1","target":"Read Coffee Size","guard":""},{"type":"control","source":"Fork 1","target":"Merge 2","guard":""},{"type":"control","source":"Read Coffee Size","target":"Merge 1","guard":""},{"type":"control","source":"Merge 1","target":"Measure Water","guard":""},{"type":"control","source":"Measure Water","target":"Correct Volume?","guard":""},{"type":"control","source":"Correct Volume?","target":"Merge 1","guard":"No"},{"type":"control","source":"Correct Volume?","target":"Fork 2","guard":"Yes"},{"type":"control","source":"Fork 2","target":"Close Valve","guard":""},{"type":"control","source":"Fork 2","target":"Stop Pump","guard":""},{"type":"control","source":"Close Valve","target":"","guard":""},{"type":"control","source":"Stop Pump","target":"","guard":""},{"type":"control","source":"Merge 2","target":"Heat Water","guard":""},{"type":"control","source":"Heat Water","target":"Temp OK?","guard":""},{"type":"control","source":"Temp OK?","target":"Merge 2","guard":"No"},{"type":"object","source":"Temp OK?","target":"output","guard":"Yes"}]},{"name":"Boiler Observer","partitions":[],"nodes":[{"id":"_2026x_1_12a70364_1789524740676_267400_5757","type":"InitialNode","name":"","partition":null},{"id":"_2026x_1_12a70364_1789524740676_61147_5758","type":"MergeNode","name":"","partition":null},{"id":"_2026x_1_12a70364_1789524740677_200964_5759","type":"OpaqueAction","name":"","partition":null},{"id":"_2026x_1_12a70364_1789524740677_260966_5760","type":"DecisionNode","name":"","partition":null},{"id":"_2026x_1_12a70364_1789524740685_268013_5761","type":"SendSignalAction","name":"Target Time Reached","partition":null}],"edges":[{"type":"control","source":"","target":"","guard":""},{"type":"control","source":"","target":"","guard":""},{"type":"control","source":"","target":"","guard":""},{"type":"control","source":"","target":"","guard":"Time<targetTime"},{"type":"control","source":"","target":"Target Time Reached","guard":"else"}]}],"graph":{"nodes":[{"id":"_2026x_1_12a70364_1789357107731_106889_3635","kind":"block","name":"Coffee Machine","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789357175665_504215_3638","kind":"block","name":"Water System","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789357305852_992852_3641","kind":"block","name":"Electrical System","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789357381144_263298_3644","kind":"block","name":"Brew System","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789358228897_970701_3681","kind":"block","name":"Coffee Machine Production","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789358512516_28052_3684","kind":"block","name":"Water Flow Port","stereotypes":["InterfaceBlock"]},{"id":"_2026x_1_12a70364_1789358695241_447494_3686","kind":"block","name":"Coffee State","stereotypes":["InterfaceBlock"]},{"id":"_2026x_1_12a70364_1789358720758_903471_3688","kind":"block","name":"Waste Port","stereotypes":["InterfaceBlock"]},{"id":"_2026x_1_12a70364_1789358753658_420800_3690","kind":"block","name":"Drink outlet","stereotypes":["InterfaceBlock"]},{"id":"_2026x_1_12a70364_1789358830928_193983_3693","kind":"block","name":"GPO","stereotypes":["InterfaceBlock"]},{"id":"_2026x_1_12a70364_1789365065038_185163_3840","kind":"block","name":"Water Inlet","stereotypes":["InterfaceBlock"]},{"id":"_2026x_1_12a70364_1789365155322_752872_3841","kind":"block","name":"Coffee","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789365188589_930663_3842","kind":"block","name":"Coffee Beans","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789365192860_189919_3843","kind":"block","name":"Water","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789365197170_873209_3844","kind":"signal","name":"Command"},{"id":"_2026x_1_12a70364_1789365201520_200533_3845","kind":"signal","name":"Power"},{"id":"_2026x_1_12a70364_1789446787460_992481_4188","kind":"signal","name":"Coffee Selection"},{"id":"_2026x_1_12a70364_1789363113514_607533_3714","kind":"block","name":"Brew Subsystem","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789363134214_804452_3715","kind":"block","name":"Control Subsystem","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789363176200_671776_3716","kind":"block","name":"Dispensing Subsystem","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789363180535_753073_3717","kind":"block","name":"Power Subsystem","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789363184788_487139_3718","kind":"block","name":"Water Subsystem","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789363224675_90261_3719","kind":"block","name":"Bean Storage","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789363229077_574630_3720","kind":"block","name":"Brewing Unit","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789363233424_933473_3721","kind":"block","name":"Doser Unit","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789363237787_500380_3722","kind":"block","name":"Grinder","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789363242138_385667_3723","kind":"block","name":"Grounds Drawer","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789363276685_64862_3724","kind":"block","name":"Control Module","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789363281032_103275_3725","kind":"block","name":"User Interface Panel","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789363285378_732895_3726","kind":"block","name":"Coffee Outlet","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789363289724_897457_3727","kind":"block","name":"Drip Tray","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789363293999_849627_3728","kind":"block","name":"Door Switch","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789363326324_823109_3729","kind":"block","name":"Mains Cord","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789363330606_330250_3730","kind":"block","name":"Mains Switch","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789363334952_109655_3731","kind":"block","name":"Power Supply","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789363551438_409574_3734","kind":"block","name":"Boiler","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789524740810_260777_5781","kind":"activity","name":"Boiler"},{"id":"_2026x_1_12a70364_1789363585791_503580_3735","kind":"block","name":"Flow Meter","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789363591862_529655_3736","kind":"block","name":"Water Pump","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789363775704_719608_3739","kind":"block","name":"Water Tank","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789363832704_318902_3740","kind":"block","name":"Water Valve","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789363922516_578822_3741","kind":"block","name":"Coffee Machine System","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789434194641_881326_3952","kind":"stateMachine","name":"Coffee Machine STM"},{"id":"_2026x_1_12a70364_1789434195075_586370_3959","kind":"state","name":"Off"},{"id":"_2026x_1_12a70364_1789434765035_486603_3981","kind":"state","name":"On"},{"id":"_2026x_1_12a70364_1789435135035_153882_4003","kind":"state","name":"Initialising"},{"id":"_2026x_1_12a70364_1789435365659_95882_4015","kind":"state","name":"Idle"},{"id":"_2026x_1_12a70364_1789435456171_517468_4025","kind":"state","name":"Brewing"},{"id":"_2026x_1_12a70364_1789435572537_420067_4035","kind":"state","name":"Heating On"},{"id":"_2026x_1_12a70364_1789435653243_288439_4045","kind":"state","name":"Heating Off"},{"id":"_2026x_1_12a70364_1789602694850_639924_6114","kind":"block","name":"Isolate Power (RCD trip)","stereotypes":[]},{"id":"_2026x_1_12a70364_1789446787441_652035_4187","kind":"activity","name":"Clean System"},{"id":"_2026x_1_12a70364_1789446787423_564713_4183","kind":"activity","name":"Initialise System"},{"id":"_2026x_1_12a70364_1789446787431_596888_4184","kind":"activity","name":"Check System"},{"id":"_2026x_1_12a70364_1789446787433_241392_4185","kind":"activity","name":"Select Coffee"},{"id":"_2026x_1_12a70364_1789446787438_52344_4186","kind":"activity","name":"Brew Coffee"},{"id":"_2026x_1_12a70364_1789433848990_731675_3921","kind":"signal","name":"Brew Complete"},{"id":"_2026x_1_12a70364_1789433896301_568328_3928","kind":"signal","name":"PowerOff"},{"id":"_2026x_1_12a70364_1789434080835_765687_3939","kind":"signal","name":"PowerOn"},{"id":"_2026x_1_12a70364_1789434127181_875752_3946","kind":"signal","name":"Selection Made"},{"id":"_2026x_1_12a70364_1789602694790_416161_6107","kind":"signal","name":"Short Detected"},{"id":"_2026x_1_12a70364_1789520883956_757328_5504","kind":"activity","name":"Heat Water"},{"id":"_2026x_1_12a70364_1789524947739_455059_5824","kind":"actor","name":"Coffee Consumer"},{"id":"_2026x_1_12a70364_1789524947844_364892_5825","kind":"actor","name":"Maintenance Operator"},{"id":"_2026x_1_12a70364_1789524947853_806196_5826","kind":"usecase","name":"Select Coffee"},{"id":"_2026x_1_12a70364_1789524947871_813181_5827","kind":"usecase","name":"Make Coffee"},{"id":"_2026x_1_12a70364_1789524947875_764584_5828","kind":"usecase","name":"Refill Water Tank"},{"id":"_2026x_1_12a70364_1789524947877_120920_5829","kind":"usecase","name":"Refill Coffee Beans"},{"id":"_2026x_1_12a70364_1789524947879_552225_5830","kind":"usecase","name":"Remove Waste"},{"id":"_2026x_1_12a70364_1789522470201_737876_5617","kind":"requirement","name":"System Level Requirements","stereotypes":["Requirement"]},{"id":"_2026x_1_12a70364_1789522470210_613186_5619","kind":"requirement","name":"Heater Initialization","stereotypes":["Requirement"]},{"id":"_2026x_1_12a70364_1789522470213_487063_5622","kind":"requirement","name":"Overheating","stereotypes":["Requirement"]},{"id":"_2026x_1_12a70364_1789522470217_232543_5625","kind":"requirement","name":"Water Tank Level","stereotypes":["Requirement"]},{"id":"_2026x_1_12a70364_1789522470220_757311_5628","kind":"requirement","name":"Coffee Bean Level","stereotypes":["Requirement"]},{"id":"_2026x_1_12a70364_1789522470227_43173_5631","kind":"requirement","name":"Water Tank Capacity","stereotypes":["Requirement"]},{"id":"_2026x_1_12a70364_1789522470229_653956_5634","kind":"requirement","name":"Coffee Bean Capacity","stereotypes":["Requirement"]},{"id":"_2026x_1_12a70364_1789522470232_505575_5637","kind":"requirement","name":"Grounds Draw Waste","stereotypes":["Requirement"]},{"id":"_2026x_1_12a70364_1789522470236_795679_5640","kind":"requirement","name":"Pump Pressure","stereotypes":["Requirement"]},{"id":"_2026x_1_12a70364_1789522470238_822356_5643","kind":"requirement","name":"System Check","stereotypes":["Requirement"]},{"id":"_2026x_1_12a70364_1789522470240_748943_5646","kind":"requirement","name":"System Alert","stereotypes":["Requirement"]},{"id":"_2026x_1_12a70364_1789522470243_75877_5649","kind":"requirement","name":"Control Panel","stereotypes":["Requirement"]},{"id":"_2026x_1_12a70364_1789522470246_238622_5652","kind":"requirement","name":"Cleaning Requirements","stereotypes":["Requirement"]},{"id":"_2026x_1_12a70364_1789522470249_829935_5654","kind":"requirement","name":"Clean brewing unit","stereotypes":["Requirement"]},{"id":"_2026x_1_12a70364_1789522470251_936773_5657","kind":"requirement","name":"Clean Machine Exterior","stereotypes":["Requirement"]},{"id":"_2026x_1_12a70364_1789522470252_176734_5660","kind":"requirement","name":"Clean Water Tank","stereotypes":["Requirement"]},{"id":"_2026x_1_12a70364_1789522470268_212057_5663","kind":"requirement","name":"Safety Requirements","stereotypes":["Requirement"]},{"id":"_2026x_1_12a70364_1789522470269_5755_5665","kind":"requirement","name":"Internal Features","stereotypes":["Requirement"]},{"id":"_2026x_1_12a70364_1789522470270_589609_5667","kind":"requirement","name":"Gearmotor Overload","stereotypes":["Requirement"]},{"id":"_2026x_1_12a70364_1789522470271_475286_5670","kind":"requirement","name":"HWS Valve Open During Brewing","stereotypes":["Requirement"]},{"id":"_2026x_1_12a70364_1789522470272_63721_5673","kind":"requirement","name":"Interruption By Removal Of Dregs Draw","stereotypes":["Requirement"]},{"id":"_2026x_1_12a70364_1789522470273_392927_5676","kind":"requirement","name":"Main Power Supply Disconnection During Operation","stereotypes":["Requirement"]},{"id":"_2026x_1_12a70364_1789602694801_483599_6108","kind":"requirement","name":"Electrical Isolation On Dispense","stereotypes":["Requirement"]},{"id":"_2026x_1_12a70364_1789522470274_644308_5679","kind":"requirement","name":"External Features","stereotypes":["Requirement"]},{"id":"_2026x_1_12a70364_1789522470275_767711_5681","kind":"requirement","name":"Regulatory Compliance Mark","stereotypes":["Requirement"]},{"id":"_2026x_1_12a70364_1789524431066_920359_5702","kind":"block","name":"Boiler Observer","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789524740674_986781_5756","kind":"activity","name":"Boiler Observer"},{"id":"_2026x_1_12a70364_1789524431068_554815_5703","kind":"block","name":"Water Heating Analysis Context","stereotypes":["Block"]},{"id":"_2026x_1_12a70364_1789524431144_707453_5727","kind":"block","name":"Water Temperature Constraint","stereotypes":["ConstraintBlock"]},{"id":"_2026x_1_12a70364_1789524740660_19378_5755","kind":"signal","name":"Target Time Reached"}],"edges":[{"source":"_2026x_1_12a70364_1789446787460_992481_4188","target":"_2026x_1_12a70364_1789365197170_873209_3844","kind":"generalization","label":""},{"source":"_2026x_1_12a70364_1789363551438_409574_3734","target":"_2026x_1_12a70364_1789524740810_260777_5781","kind":"behavior","label":""},{"source":"_2026x_1_12a70364_1789524740810_260777_5781","target":"_2026x_1_12a70364_1789524740660_19378_5755","kind":"uses","label":"Target Time Reached"},{"source":"_2026x_1_12a70364_1789363922516_578822_3741","target":"_2026x_1_12a70364_1789434194641_881326_3952","kind":"behavior","label":""},{"source":"_2026x_1_12a70364_1789434194641_881326_3952","target":"_2026x_1_12a70364_1789434195075_586370_3959","kind":"contains","label":"region"},{"source":"_2026x_1_12a70364_1789434194641_881326_3952","target":"_2026x_1_12a70364_1789434765035_486603_3981","kind":"contains","label":"region"},{"source":"_2026x_1_12a70364_1789434765035_486603_3981","target":"_2026x_1_12a70364_1789435135035_153882_4003","kind":"contains","label":"region"},{"source":"_2026x_1_12a70364_1789435135035_153882_4003","target":"_2026x_1_12a70364_1789446787423_564713_4183","kind":"behavior","label":"entry"},{"source":"_2026x_1_12a70364_1789434765035_486603_3981","target":"_2026x_1_12a70364_1789435365659_95882_4015","kind":"contains","label":"region"},{"source":"_2026x_1_12a70364_1789435365659_95882_4015","target":"_2026x_1_12a70364_1789446787431_596888_4184","kind":"behavior","label":"entry"},{"source":"_2026x_1_12a70364_1789435365659_95882_4015","target":"_2026x_1_12a70364_1789446787433_241392_4185","kind":"behavior","label":"do"},{"source":"_2026x_1_12a70364_1789434765035_486603_3981","target":"_2026x_1_12a70364_1789435456171_517468_4025","kind":"contains","label":"region"},{"source":"_2026x_1_12a70364_1789435456171_517468_4025","target":"_2026x_1_12a70364_1789446787438_52344_4186","kind":"behavior","label":"do"},{"source":"_2026x_1_12a70364_1789435135035_153882_4003","target":"_2026x_1_12a70364_1789435365659_95882_4015","kind":"transition","label":"after(30s)"},{"source":"_2026x_1_12a70364_1789435365659_95882_4015","target":"_2026x_1_12a70364_1789435456171_517468_4025","kind":"transition","label":"signal:Selection Made"},{"source":"_2026x_1_12a70364_1789434127181_875752_3946","target":"_2026x_1_12a70364_1789435456171_517468_4025","kind":"triggers","label":"Selection Made"},{"source":"_2026x_1_12a70364_1789435456171_517468_4025","target":"_2026x_1_12a70364_1789435365659_95882_4015","kind":"transition","label":"signal:Brew Complete /Clean System"},{"source":"_2026x_1_12a70364_1789433848990_731675_3921","target":"_2026x_1_12a70364_1789435365659_95882_4015","kind":"triggers","label":"Brew Complete"},{"source":"_2026x_1_12a70364_1789435456171_517468_4025","target":"_2026x_1_12a70364_1789446787441_652035_4187","kind":"effect","label":"Clean System"},{"source":"_2026x_1_12a70364_1789434765035_486603_3981","target":"_2026x_1_12a70364_1789435572537_420067_4035","kind":"contains","label":"region"},{"source":"_2026x_1_12a70364_1789434765035_486603_3981","target":"_2026x_1_12a70364_1789435653243_288439_4045","kind":"contains","label":"region"},{"source":"_2026x_1_12a70364_1789435572537_420067_4035","target":"_2026x_1_12a70364_1789435653243_288439_4045","kind":"transition","label":"after(60s)"},{"source":"_2026x_1_12a70364_1789435653243_288439_4045","target":"_2026x_1_12a70364_1789435572537_420067_4035","kind":"transition","label":"after(60s)"},{"source":"_2026x_1_12a70364_1789434195075_586370_3959","target":"_2026x_1_12a70364_1789434765035_486603_3981","kind":"transition","label":"signal:PowerOn"},{"source":"_2026x_1_12a70364_1789434080835_765687_3939","target":"_2026x_1_12a70364_1789434765035_486603_3981","kind":"triggers","label":"PowerOn"},{"source":"_2026x_1_12a70364_1789434765035_486603_3981","target":"_2026x_1_12a70364_1789434195075_586370_3959","kind":"transition","label":"signal:PowerOff"},{"source":"_2026x_1_12a70364_1789433896301_568328_3928","target":"_2026x_1_12a70364_1789434195075_586370_3959","kind":"triggers","label":"PowerOff"},{"source":"_2026x_1_12a70364_1789434765035_486603_3981","target":"_2026x_1_12a70364_1789434195075_586370_3959","kind":"transition","label":"signal:Short Detected /Isolate Power (RCD trip)"},{"source":"_2026x_1_12a70364_1789602694790_416161_6107","target":"_2026x_1_12a70364_1789434195075_586370_3959","kind":"triggers","label":"Short Detected"},{"source":"_2026x_1_12a70364_1789434765035_486603_3981","target":"_2026x_1_12a70364_1789602694850_639924_6114","kind":"effect","label":"Isolate Power (RCD trip)"},{"source":"_2026x_1_12a70364_1789433848990_731675_3921","target":"_2026x_1_12a70364_1789365197170_873209_3844","kind":"generalization","label":""},{"source":"_2026x_1_12a70364_1789433896301_568328_3928","target":"_2026x_1_12a70364_1789365201520_200533_3845","kind":"generalization","label":""},{"source":"_2026x_1_12a70364_1789434080835_765687_3939","target":"_2026x_1_12a70364_1789365201520_200533_3845","kind":"generalization","label":""},{"source":"_2026x_1_12a70364_1789434127181_875752_3946","target":"_2026x_1_12a70364_1789365197170_873209_3844","kind":"generalization","label":""},{"source":"_2026x_1_12a70364_1789524947853_806196_5826","target":"_2026x_1_12a70364_1789363922516_578822_3741","kind":"subject","label":"subject"},{"source":"_2026x_1_12a70364_1789524947853_806196_5826","target":"_2026x_1_12a70364_1789524947871_813181_5827","kind":"include","label":"«include»"},{"source":"_2026x_1_12a70364_1789524947871_813181_5827","target":"_2026x_1_12a70364_1789363922516_578822_3741","kind":"subject","label":"subject"},{"source":"_2026x_1_12a70364_1789524947875_764584_5828","target":"_2026x_1_12a70364_1789363922516_578822_3741","kind":"subject","label":"subject"},{"source":"_2026x_1_12a70364_1789524947877_120920_5829","target":"_2026x_1_12a70364_1789363922516_578822_3741","kind":"subject","label":"subject"},{"source":"_2026x_1_12a70364_1789524947879_552225_5830","target":"_2026x_1_12a70364_1789363922516_578822_3741","kind":"subject","label":"subject"},{"source":"_2026x_1_12a70364_1789522470201_737876_5617","target":"_2026x_1_12a70364_1789522470210_613186_5619","kind":"contains","label":""},{"source":"_2026x_1_12a70364_1789522470201_737876_5617","target":"_2026x_1_12a70364_1789522470213_487063_5622","kind":"contains","label":""},{"source":"_2026x_1_12a70364_1789522470201_737876_5617","target":"_2026x_1_12a70364_1789522470217_232543_5625","kind":"contains","label":""},{"source":"_2026x_1_12a70364_1789522470201_737876_5617","target":"_2026x_1_12a70364_1789522470220_757311_5628","kind":"contains","label":""},{"source":"_2026x_1_12a70364_1789522470201_737876_5617","target":"_2026x_1_12a70364_1789522470227_43173_5631","kind":"contains","label":""},{"source":"_2026x_1_12a70364_1789522470201_737876_5617","target":"_2026x_1_12a70364_1789522470229_653956_5634","kind":"contains","label":""},{"source":"_2026x_1_12a70364_1789522470201_737876_5617","target":"_2026x_1_12a70364_1789522470232_505575_5637","kind":"contains","label":""},{"source":"_2026x_1_12a70364_1789522470201_737876_5617","target":"_2026x_1_12a70364_1789522470236_795679_5640","kind":"contains","label":""},{"source":"_2026x_1_12a70364_1789522470201_737876_5617","target":"_2026x_1_12a70364_1789522470238_822356_5643","kind":"contains","label":""},{"source":"_2026x_1_12a70364_1789522470201_737876_5617","target":"_2026x_1_12a70364_1789522470240_748943_5646","kind":"contains","label":""},{"source":"_2026x_1_12a70364_1789522470201_737876_5617","target":"_2026x_1_12a70364_1789522470243_75877_5649","kind":"contains","label":""},{"source":"_2026x_1_12a70364_1789522470246_238622_5652","target":"_2026x_1_12a70364_1789522470249_829935_5654","kind":"contains","label":""},{"source":"_2026x_1_12a70364_1789522470246_238622_5652","target":"_2026x_1_12a70364_1789522470251_936773_5657","kind":"contains","label":""},{"source":"_2026x_1_12a70364_1789522470246_238622_5652","target":"_2026x_1_12a70364_1789522470252_176734_5660","kind":"contains","label":""},{"source":"_2026x_1_12a70364_1789522470268_212057_5663","target":"_2026x_1_12a70364_1789522470269_5755_5665","kind":"contains","label":""},{"source":"_2026x_1_12a70364_1789522470268_212057_5663","target":"_2026x_1_12a70364_1789522470274_644308_5679","kind":"contains","label":""},{"source":"_2026x_1_12a70364_1789522470269_5755_5665","target":"_2026x_1_12a70364_1789522470270_589609_5667","kind":"contains","label":""},{"source":"_2026x_1_12a70364_1789522470269_5755_5665","target":"_2026x_1_12a70364_1789522470271_475286_5670","kind":"contains","label":""},{"source":"_2026x_1_12a70364_1789522470269_5755_5665","target":"_2026x_1_12a70364_1789522470272_63721_5673","kind":"contains","label":""},{"source":"_2026x_1_12a70364_1789522470269_5755_5665","target":"_2026x_1_12a70364_1789522470273_392927_5676","kind":"contains","label":""},{"source":"_2026x_1_12a70364_1789522470269_5755_5665","target":"_2026x_1_12a70364_1789602694801_483599_6108","kind":"contains","label":""},{"source":"_2026x_1_12a70364_1789522470274_644308_5679","target":"_2026x_1_12a70364_1789522470275_767711_5681","kind":"contains","label":""},{"source":"_2026x_1_12a70364_1789524431066_920359_5702","target":"_2026x_1_12a70364_1789524740674_986781_5756","kind":"behavior","label":""},{"source":"_2026x_1_12a70364_1789524740674_986781_5756","target":"_2026x_1_12a70364_1789524740660_19378_5755","kind":"uses","label":"Target Time Reached"},{"source":"_2026x_1_12a70364_1789357175665_504215_3638","target":"_2026x_1_12a70364_1789357107731_106889_3635","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789357305852_992852_3641","target":"_2026x_1_12a70364_1789357107731_106889_3635","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789357381144_263298_3644","target":"_2026x_1_12a70364_1789357107731_106889_3635","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789363224675_90261_3719","target":"_2026x_1_12a70364_1789363113514_607533_3714","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789363229077_574630_3720","target":"_2026x_1_12a70364_1789363113514_607533_3714","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789363233424_933473_3721","target":"_2026x_1_12a70364_1789363113514_607533_3714","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789363237787_500380_3722","target":"_2026x_1_12a70364_1789363113514_607533_3714","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789363242138_385667_3723","target":"_2026x_1_12a70364_1789363113514_607533_3714","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789363276685_64862_3724","target":"_2026x_1_12a70364_1789363134214_804452_3715","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789363281032_103275_3725","target":"_2026x_1_12a70364_1789363134214_804452_3715","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789363285378_732895_3726","target":"_2026x_1_12a70364_1789363176200_671776_3716","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789363289724_897457_3727","target":"_2026x_1_12a70364_1789363176200_671776_3716","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789363293999_849627_3728","target":"_2026x_1_12a70364_1789363180535_753073_3717","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789363326324_823109_3729","target":"_2026x_1_12a70364_1789363180535_753073_3717","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789363330606_330250_3730","target":"_2026x_1_12a70364_1789363180535_753073_3717","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789363334952_109655_3731","target":"_2026x_1_12a70364_1789363180535_753073_3717","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789363551438_409574_3734","target":"_2026x_1_12a70364_1789363184788_487139_3718","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789363585791_503580_3735","target":"_2026x_1_12a70364_1789363184788_487139_3718","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789363591862_529655_3736","target":"_2026x_1_12a70364_1789363184788_487139_3718","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789363775704_719608_3739","target":"_2026x_1_12a70364_1789363184788_487139_3718","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789363832704_318902_3740","target":"_2026x_1_12a70364_1789363184788_487139_3718","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789363113514_607533_3714","target":"_2026x_1_12a70364_1789363922516_578822_3741","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789363134214_804452_3715","target":"_2026x_1_12a70364_1789363922516_578822_3741","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789363176200_671776_3716","target":"_2026x_1_12a70364_1789363922516_578822_3741","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789363180535_753073_3717","target":"_2026x_1_12a70364_1789363922516_578822_3741","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789363184788_487139_3718","target":"_2026x_1_12a70364_1789363922516_578822_3741","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789446787438_52344_4186","target":"_2026x_1_12a70364_1789520883956_757328_5504","kind":"dependency","label":"Dependency"},{"source":"_2026x_1_12a70364_1789524947739_455059_5824","target":"_2026x_1_12a70364_1789524947853_806196_5826","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789524947739_455059_5824","target":"_2026x_1_12a70364_1789524947871_813181_5827","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789524947844_364892_5825","target":"_2026x_1_12a70364_1789524947875_764584_5828","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789524947844_364892_5825","target":"_2026x_1_12a70364_1789524947877_120920_5829","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789524947844_364892_5825","target":"_2026x_1_12a70364_1789524947879_552225_5830","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789363922516_578822_3741","target":"_2026x_1_12a70364_1789522470238_822356_5643","kind":"dependency","label":"Satisfy"},{"source":"_2026x_1_12a70364_1789363922516_578822_3741","target":"_2026x_1_12a70364_1789522470240_748943_5646","kind":"dependency","label":"Satisfy"},{"source":"_2026x_1_12a70364_1789524947875_764584_5828","target":"_2026x_1_12a70364_1789522470217_232543_5625","kind":"dependency","label":"Refine"},{"source":"_2026x_1_12a70364_1789524947877_120920_5829","target":"_2026x_1_12a70364_1789522470220_757311_5628","kind":"dependency","label":"Refine"},{"source":"_2026x_1_12a70364_1789524431087_459748_5711","target":"_2026x_1_12a70364_1789522470210_613186_5619","kind":"dependency","label":"Satisfy"},{"source":"_2026x_1_12a70364_1789524431091_435540_5713","target":"_2026x_1_12a70364_1789522470210_613186_5619","kind":"dependency","label":"Satisfy"},{"source":"_2026x_1_12a70364_1789524431144_707453_5727","target":"_2026x_1_12a70364_1789522470210_613186_5619","kind":"dependency","label":"Refine"},{"source":"_2026x_1_12a70364_1789524431066_920359_5702","target":"_2026x_1_12a70364_1789524431068_554815_5703","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789363551438_409574_3734","target":"_2026x_1_12a70364_1789524431068_554815_5703","kind":"association","label":""},{"source":"_2026x_1_12a70364_1789363184788_487139_3718","target":"_2026x_1_12a70364_1789357175665_504215_3638","kind":"dependency","label":"Allocate"},{"source":"_2026x_1_12a70364_1789363113514_607533_3714","target":"_2026x_1_12a70364_1789357381144_263298_3644","kind":"dependency","label":"Allocate"},{"source":"_2026x_1_12a70364_1789363180535_753073_3717","target":"_2026x_1_12a70364_1789357305852_992852_3641","kind":"dependency","label":"Allocate"},{"source":"_2026x_1_12a70364_1789363922516_578822_3741","target":"_2026x_1_12a70364_1789357107731_106889_3635","kind":"dependency","label":"Refine"},{"source":"_2026x_1_12a70364_1789363551438_409574_3734","target":"_2026x_1_12a70364_1789522470210_613186_5619","kind":"dependency","label":"Satisfy"},{"source":"_2026x_1_12a70364_1789363551438_409574_3734","target":"_2026x_1_12a70364_1789522470213_487063_5622","kind":"dependency","label":"Satisfy"},{"source":"_2026x_1_12a70364_1789363775704_719608_3739","target":"_2026x_1_12a70364_1789522470217_232543_5625","kind":"dependency","label":"Satisfy"},{"source":"_2026x_1_12a70364_1789363775704_719608_3739","target":"_2026x_1_12a70364_1789522470227_43173_5631","kind":"dependency","label":"Satisfy"},{"source":"_2026x_1_12a70364_1789363224675_90261_3719","target":"_2026x_1_12a70364_1789522470220_757311_5628","kind":"dependency","label":"Satisfy"},{"source":"_2026x_1_12a70364_1789363224675_90261_3719","target":"_2026x_1_12a70364_1789522470229_653956_5634","kind":"dependency","label":"Satisfy"},{"source":"_2026x_1_12a70364_1789363242138_385667_3723","target":"_2026x_1_12a70364_1789522470232_505575_5637","kind":"dependency","label":"Satisfy"},{"source":"_2026x_1_12a70364_1789363591862_529655_3736","target":"_2026x_1_12a70364_1789522470236_795679_5640","kind":"dependency","label":"Satisfy"},{"source":"_2026x_1_12a70364_1789363276685_64862_3724","target":"_2026x_1_12a70364_1789522470238_822356_5643","kind":"dependency","label":"Satisfy"},{"source":"_2026x_1_12a70364_1789363281032_103275_3725","target":"_2026x_1_12a70364_1789522470240_748943_5646","kind":"dependency","label":"Satisfy"},{"source":"_2026x_1_12a70364_1789363281032_103275_3725","target":"_2026x_1_12a70364_1789522470243_75877_5649","kind":"dependency","label":"Satisfy"},{"source":"_2026x_1_12a70364_1789363334952_109655_3731","target":"_2026x_1_12a70364_1789602694801_483599_6108","kind":"dependency","label":"Satisfy"},{"source":"_2026x_1_12a70364_1789363176200_671776_3716","target":"_2026x_1_12a70364_1789602694801_483599_6108","kind":"dependency","label":"Satisfy"},{"source":"_2026x_1_12a70364_1789524431068_554815_5703","target":"_2026x_1_12a70364_1789522470210_613186_5619","kind":"dependency","label":"Verify"},{"source":"_2026x_1_12a70364_1789363775704_719608_3739","target":"_2026x_1_12a70364_1789522470252_176734_5660","kind":"dependency","label":"Satisfy"},{"source":"_2026x_1_12a70364_1789363229077_574630_3720","target":"_2026x_1_12a70364_1789522470249_829935_5654","kind":"dependency","label":"Satisfy"},{"source":"_2026x_1_12a70364_1789357107731_106889_3635","target":"_2026x_1_12a70364_1789522470251_936773_5657","kind":"dependency","label":"Satisfy"},{"source":"_2026x_1_12a70364_1789357107731_106889_3635","target":"_2026x_1_12a70364_1789357175665_504215_3638","kind":"part","label":"water System"},{"source":"_2026x_1_12a70364_1789357107731_106889_3635","target":"_2026x_1_12a70364_1789357305852_992852_3641","kind":"part","label":"electrical System"},{"source":"_2026x_1_12a70364_1789357107731_106889_3635","target":"_2026x_1_12a70364_1789357381144_263298_3644","kind":"part","label":"brew System"},{"source":"_2026x_1_12a70364_1789357107731_106889_3635","target":"_2026x_1_12a70364_1789358228897_970701_3681","kind":"reference","label":"coffee Machine Production"},{"source":"_2026x_1_12a70364_1789357107731_106889_3635","target":"_2026x_1_12a70364_1789358512516_28052_3684","kind":"part","label":"Waterin"},{"source":"_2026x_1_12a70364_1789357107731_106889_3635","target":"_2026x_1_12a70364_1789358695241_447494_3686","kind":"part","label":"Coffee beans in"},{"source":"_2026x_1_12a70364_1789357107731_106889_3635","target":"_2026x_1_12a70364_1789358720758_903471_3688","kind":"part","label":"dregs"},{"source":"_2026x_1_12a70364_1789357107731_106889_3635","target":"_2026x_1_12a70364_1789358753658_420800_3690","kind":"part","label":"Coffee Dispensed"},{"source":"_2026x_1_12a70364_1789357107731_106889_3635","target":"_2026x_1_12a70364_1789358720758_903471_3688","kind":"part","label":"liquid waste"},{"source":"_2026x_1_12a70364_1789357107731_106889_3635","target":"_2026x_1_12a70364_1789358830928_193983_3693","kind":"part","label":"p2"},{"source":"_2026x_1_12a70364_1789357175665_504215_3638","target":"_2026x_1_12a70364_1789365065038_185163_3840","kind":"reference","label":"inlet"},{"source":"_2026x_1_12a70364_1789363113514_607533_3714","target":"_2026x_1_12a70364_1789363224675_90261_3719","kind":"part","label":"bean Storage"},{"source":"_2026x_1_12a70364_1789363113514_607533_3714","target":"_2026x_1_12a70364_1789363229077_574630_3720","kind":"part","label":"brewing Unit"},{"source":"_2026x_1_12a70364_1789363113514_607533_3714","target":"_2026x_1_12a70364_1789363233424_933473_3721","kind":"part","label":"doser Unit"},{"source":"_2026x_1_12a70364_1789363113514_607533_3714","target":"_2026x_1_12a70364_1789363237787_500380_3722","kind":"part","label":"grinder"},{"source":"_2026x_1_12a70364_1789363113514_607533_3714","target":"_2026x_1_12a70364_1789363242138_385667_3723","kind":"part","label":"grounds Drawer"},{"source":"_2026x_1_12a70364_1789363134214_804452_3715","target":"_2026x_1_12a70364_1789363276685_64862_3724","kind":"part","label":"control Module"},{"source":"_2026x_1_12a70364_1789363134214_804452_3715","target":"_2026x_1_12a70364_1789363281032_103275_3725","kind":"part","label":"user Interface Panel"},{"source":"_2026x_1_12a70364_1789363176200_671776_3716","target":"_2026x_1_12a70364_1789363285378_732895_3726","kind":"part","label":"coffee Outlet"},{"source":"_2026x_1_12a70364_1789363176200_671776_3716","target":"_2026x_1_12a70364_1789363289724_897457_3727","kind":"part","label":"drip Tray"},{"source":"_2026x_1_12a70364_1789363180535_753073_3717","target":"_2026x_1_12a70364_1789363293999_849627_3728","kind":"part","label":"door Switch"},{"source":"_2026x_1_12a70364_1789363180535_753073_3717","target":"_2026x_1_12a70364_1789363326324_823109_3729","kind":"part","label":"mains Cord"},{"source":"_2026x_1_12a70364_1789363180535_753073_3717","target":"_2026x_1_12a70364_1789363330606_330250_3730","kind":"part","label":"mains Switch"},{"source":"_2026x_1_12a70364_1789363180535_753073_3717","target":"_2026x_1_12a70364_1789363334952_109655_3731","kind":"part","label":"power Supply"},{"source":"_2026x_1_12a70364_1789363184788_487139_3718","target":"_2026x_1_12a70364_1789363551438_409574_3734","kind":"part","label":"boiler"},{"source":"_2026x_1_12a70364_1789363184788_487139_3718","target":"_2026x_1_12a70364_1789363585791_503580_3735","kind":"part","label":"flow Meter"},{"source":"_2026x_1_12a70364_1789363184788_487139_3718","target":"_2026x_1_12a70364_1789363591862_529655_3736","kind":"part","label":"water Pump"},{"source":"_2026x_1_12a70364_1789363184788_487139_3718","target":"_2026x_1_12a70364_1789363775704_719608_3739","kind":"part","label":"water Tank"},{"source":"_2026x_1_12a70364_1789363184788_487139_3718","target":"_2026x_1_12a70364_1789363832704_318902_3740","kind":"part","label":"water Valve"},{"source":"_2026x_1_12a70364_1789363224675_90261_3719","target":"_2026x_1_12a70364_1789365188589_930663_3842","kind":"reference","label":"storedBeans"},{"source":"_2026x_1_12a70364_1789363775704_719608_3739","target":"_2026x_1_12a70364_1789365192860_189919_3843","kind":"reference","label":"storedWater"},{"source":"_2026x_1_12a70364_1789363922516_578822_3741","target":"_2026x_1_12a70364_1789363113514_607533_3714","kind":"part","label":"brew Subsystem"},{"source":"_2026x_1_12a70364_1789363922516_578822_3741","target":"_2026x_1_12a70364_1789363134214_804452_3715","kind":"part","label":"control Subsystem"},{"source":"_2026x_1_12a70364_1789363922516_578822_3741","target":"_2026x_1_12a70364_1789363176200_671776_3716","kind":"part","label":"dispensing Subsystem"},{"source":"_2026x_1_12a70364_1789363922516_578822_3741","target":"_2026x_1_12a70364_1789363180535_753073_3717","kind":"part","label":"power Subsystem"},{"source":"_2026x_1_12a70364_1789363922516_578822_3741","target":"_2026x_1_12a70364_1789363184788_487139_3718","kind":"part","label":"water Subsystem"},{"source":"_2026x_1_12a70364_1789363922516_578822_3741","target":"_2026x_1_12a70364_1789365155322_752872_3841","kind":"reference","label":"dispensedCoffee"},{"source":"_2026x_1_12a70364_1789524431068_554815_5703","target":"_2026x_1_12a70364_1789363551438_409574_3734","kind":"part","label":"boiler"},{"source":"_2026x_1_12a70364_1789524431068_554815_5703","target":"_2026x_1_12a70364_1789524431066_920359_5702","kind":"part","label":"boilerObserver"}]}};
+
+function el(t,c,h){const e=document.createElement(t);if(c)e.className=c;if(h!=null)e.innerHTML=h;return e;}
+
+async function boot(){
+  MODEL = window.__MODEL__ ? window.__MODEL__ : await (await fetch('coffee_machine_model.json?_='+Date.now())).json();
+  renderChips(); renderGraph(); renderStructure(); renderSTM(); renderActs(); renderReqs();
+  document.getElementById('meta').textContent = 'Exported '+ (MODEL.exportedAt||'');
+  probeLLM();
+}
+function renderChips(){
+  const s=MODEL.summary||{};
+  const items=[['Blocks',s.blocks],['Requirements',s.requirements],['Signals',s.signals],['Activities',s.activities],['Graph nodes',s.graphNodes],['Relations',s.graphEdges]];
+  document.getElementById('chips').innerHTML = items.map(([k,v])=>`<div class="chip">${k} <b>${v??0}</b></div>`).join('');
+}
+
+/* ---------- GRAPH ---------- */
+let visNodes,visEdges,activeKinds=new Set(Object.keys(KIND_COLOR));
+function renderGraph(){
+  const g=MODEL.graph||{nodes:[],edges:[]};
+  const shapeFor=k=>k==='requirement'?'box':(k==='signal'?'diamond':(k==='actor'?'triangle':(k==='usecase'?'ellipse':'dot')));
+  visNodes=new vis.DataSet(g.nodes.map(n=>({id:n.id,label:n.name||n.kind,group:n.kind,
+    color:{background:KIND_COLOR[n.kind]||'#888',border:'#0008',highlight:{background:KIND_COLOR[n.kind],border:'#fff'}},
+    font:{color:'#e6e9ee',size:13},shape:shapeFor(n.kind),
+    size:(n.kind==='block'?18:13)})));
+  const em={transition:'#6ab0f3',part:'#c8873a',reference:'#d8a15a',dependency:'#b98bd6',generalization:'#888',object:'#63c088',control:'#63c088',association:'#8fa0b3',include:'#e8c15a',subject:'#556',behavior:'#5ad1c0',triggers:'#f38b8b',effect:'#f3c06a',uses:'#8fd15a',contains:'#7c8aa5'};
+  visEdges=new vis.DataSet(g.edges.map((e,i)=>({id:i,from:e.source,to:e.target,label:e.label||'',arrows:'to',
+    color:{color:em[e.kind]||'#556',opacity:.7},font:{color:'#9aa4b2',size:10,strokeWidth:0,align:'middle'},
+    dashes:(e.kind==='dependency'||e.kind==='generalization'||e.kind==='behavior'||e.kind==='triggers'||e.kind==='contains'||e.kind==='uses'||e.kind==='effect'),smooth:{type:'dynamic'}})));
+  network=new vis.Network(document.getElementById('graph'),{nodes:visNodes,edges:visEdges},{
+    physics:{stabilization:true,barnesHut:{gravitationalConstant:-9000,springLength:130,springConstant:.04}},
+    interaction:{hover:true,tooltipDelay:120},layout:{improvedLayout:true}});
+  // legend + filters
+  const lk={block:'Block',requirement:'Requirement',state:'State',activity:'Activity',signal:'Signal',interface:'Interface',usecase:'Use Case',actor:'Actor'};
+  document.getElementById('legend').innerHTML=Object.entries(lk).map(([k,v])=>`<div><span class="dot" style="background:${KIND_COLOR[k]}"></span>${v}</div>`).join('');
+  document.getElementById('gctl').innerHTML=Object.entries(lk).map(([k,v])=>`<button class="on" data-k="${k}">${v}</button>`).join('')+'<button data-fit="1">⤢ Fit</button>';
+  document.getElementById('gctl').onclick=(ev)=>{const b=ev.target.closest('button');if(!b)return;
+    if(b.dataset.fit){network.fit({animation:true});return;}
+    const k=b.dataset.k;if(activeKinds.has(k)){activeKinds.delete(k);b.classList.remove('on');}else{activeKinds.add(k);b.classList.add('on');}
+    visNodes.forEach(n=>visNodes.update({id:n.id,hidden:!activeKinds.has(n.group)}));};
+}
+
+/* ---------- STRUCTURE ---------- */
+function renderStructure(){
+  const v=document.getElementById('v-structure');
+  v.innerHTML='<h2>System Structure — Blocks</h2>';
+  const grid=el('div','grid');
+  (MODEL.structure||[]).sort((a,b)=>a.name.localeCompare(b.name)).forEach(b=>{
+    const c=el('div','card');
+    c.innerHTML=`<div class="st">${(b.stereotypes||[]).join(', ')||'Block'}</div><h3>${b.name}</h3>`;
+    if(b.documentation)c.appendChild(el('div','attr',b.documentation));
+    if(b.attributes&&b.attributes.length){
+      const ul=el('div','',''); b.attributes.forEach(a=>{const part=(a.aggregation||'').toLowerCase().includes('composite');
+        ul.appendChild(el('div','attr',`${part?'◆ ':'• '}${a.name}${a.type?' : '+a.type:''}`));}); c.appendChild(ul);}
+    grid.appendChild(c);
+  });
+  v.appendChild(grid);
+}
+
+/* ---------- STATE MACHINE ---------- */
+function renderSTM(){
+  const v=document.getElementById('v-stm'); const sm=MODEL.stateMachine;
+  if(!sm){v.innerHTML='<h2>State Machine</h2><p class="attr">None.</p>';return;}
+  v.innerHTML=`<h2>State Machine — ${sm.name}</h2>`;
+  (sm.regions||[]).forEach((r,i)=>{
+    const c=el('div','card'); c.innerHTML=`<div class="st">Region ${i+1}</div>`;
+    const t=el('table'); t.innerHTML='<tr><th>State</th><th>Entry</th><th>Do</th><th>Exit</th></tr>';
+    (r.states||[]).forEach(s=>{t.innerHTML+=`<tr><td><b>${s.name||'(unnamed)'}</b></td><td class="attr">${s.entry||''}</td><td class="attr">${s.doActivity||''}</td><td class="attr">${s.exit||''}</td></tr>`;});
+    c.appendChild(t); v.appendChild(c);
+  });
+  // transitions from graph edges of kind transition
+  const trs=(MODEL.graph.edges||[]).filter(e=>e.kind==='transition');
+  if(trs.length){const c=el('div','card');c.innerHTML='<div class="st">Transitions</div>';
+    const nm={};(MODEL.graph.nodes||[]).forEach(n=>nm[n.id]=n.name);
+    const t=el('table');t.innerHTML='<tr><th>From</th><th>To</th><th>Trigger / Guard / Effect</th></tr>';
+    trs.forEach(e=>{t.innerHTML+=`<tr><td>${nm[e.source]||'?'}</td><td>${nm[e.target]||'?'}</td><td class="flow">${e.label||''}</td></tr>`;});
+    c.appendChild(t);v.appendChild(c);}
+}
+
+/* ---------- ACTIVITIES ---------- */
+function renderActs(){
+  const v=document.getElementById('v-acts'); v.innerHTML='<h2>Activities</h2>';
+  (MODEL.activities||[]).forEach(a=>{
+    const c=el('div','card');
+    c.innerHTML=`<h3>${a.name}</h3>`;
+    if(a.partitions&&a.partitions.length)c.appendChild(el('div','',a.partitions.map(p=>`<span class="tag">${p.name}${p.represents?' → '+p.represents:''}</span>`).join('')));
+    if(a.edges&&a.edges.length){const f=el('div','flow');
+      f.innerHTML=a.edges.map(e=>`<span class="n">${e.source||'•'}</span> →${e.type==='object'?'◆':''} <span class="n">${e.target||'•'}</span>${e.guard?' <span class="g">['+e.guard+']</span>':''}`).join('<br>');
+      c.appendChild(f);}
+    v.appendChild(c);
+  });
+}
+
+/* ---------- REQUIREMENTS ---------- */
+function renderReqs(){
+  const v=document.getElementById('v-reqs');
+  const rs=(MODEL.requirements||[]).slice().sort((a,b)=>{
+    const ai=(a.stereotypes,a),bi=b; return (reqId(a)||'').localeCompare(reqId(b)||'',undefined,{numeric:true});});
+  v.innerHTML=`<h2>Requirements (${rs.length})</h2>`;
+  const t=el('table'); t.innerHTML='<tr><th style="width:70px">Id</th><th style="width:220px">Name</th><th>Text</th></tr>';
+  rs.forEach(r=>{t.innerHTML+=`<tr><td class="id">${reqId(r)||''}</td><td><b>${r.name}</b></td><td class="attr">${reqText(r)||''}</td></tr>`;});
+  const c=el('div','card'); c.appendChild(t); v.appendChild(c);
+}
+function reqId(r){return r.reqId||'';}
+function reqText(r){return r.reqText||'';}
+
+/* ---------- LLM CHAT ---------- */
+function modelContext(){
+  const m=MODEL; let s=`PROJECT: ${m.project}\n\nBLOCKS:\n`;
+  (m.structure||[]).forEach(b=>{s+=`- ${b.name}`; if(b.attributes&&b.attributes.length)s+=` [parts/values: ${b.attributes.map(a=>a.name+(a.type?':'+a.type:'')).join(', ')}]`; if(b.documentation)s+=` — ${b.documentation}`; s+='\n';});
+  if(m.stateMachine){s+=`\nSTATE MACHINE ${m.stateMachine.name}:\n`;
+    (m.stateMachine.regions||[]).forEach(r=>(r.states||[]).forEach(st=>{s+=`- state ${st.name}`;if(st.entry)s+=` entry/${st.entry}`;if(st.doActivity)s+=` do/${st.doActivity}`;s+='\n';}));
+    (m.graph.edges||[]).filter(e=>e.kind==='transition').forEach(e=>{const nm={};(m.graph.nodes||[]).forEach(n=>nm[n.id]=n.name);s+=`  transition ${nm[e.source]}->${nm[e.target]} ${e.label||''}\n`;});}
+  s+='\nACTIVITIES:\n';(m.activities||[]).forEach(a=>{s+=`- ${a.name} (lanes: ${(a.partitions||[]).map(p=>p.name).join(', ')})\n`;});
+  s+='\nREQUIREMENTS:\n';(m.requirements||[]).forEach(r=>{s+=`- ${reqId(r)||''} ${r.name}: ${reqText(r)||''}\n`;});
+  try { if(typeof marketSummaryForChat==='function') s+=marketSummaryForChat(); } catch(e){}
+  return s;
+}
+let CTX='';
+async function probeLLM(){
+  const b=document.getElementById('llmBanner');
+  try{
+    const r=await fetch(LLM_URL+'/api/tags');
+    const j=await r.json();
+    if(j.models&&j.models.length){LLM_MODEL=j.models[0].name;
+      b.style.display='none';
+      addMsg('sys','Connected to local model: '+LLM_MODEL+'. Ask me anything about the coffee machine model.');
+    } else { b.innerHTML='Ollama is running but no model is pulled yet. Run <code>ollama pull qwen2.5:1.5b</code>.'; }
+  }catch(e){ b.innerHTML='⚠ Local LLM not reachable at <code>localhost:11434</code>. Start Ollama (<code>ollama serve</code>) and pull a small model, then reload.'; }
+  CTX=modelContext();
+}
+function addMsg(cls,txt){const m=el('div','msg '+cls,txt);document.getElementById('msgs').appendChild(m);m.scrollIntoView();return m;}
+async function ask(q){
+  addMsg('u',q);
+  const a=addMsg('a','…');
+  if(!LLM_MODEL){a.textContent='No local model available. Pull one with: ollama pull qwen2.5:1.5b';return;}
+  try{
+    const body={model:LLM_MODEL,stream:true,
+      prompt:`You are a systems-engineering assistant. Answer ONLY from the SysML model below. Be concise and precise.\n\n===MODEL===\n${CTX}\n===END===\n\nQuestion: ${q}\nAnswer:`};
+    const r=await fetch(LLM_URL+'/api/generate',{method:'POST',body:JSON.stringify(body)});
+    const reader=r.body.getReader();const dec=new TextDecoder();a.textContent='';
+    let buf='';
+    while(true){const{done,value}=await reader.read();if(done)break;
+      buf+=dec.decode(value,{stream:true});let lines=buf.split('\n');buf=lines.pop();
+      for(const ln of lines){if(!ln.trim())continue;try{const j=JSON.parse(ln);if(j.response){a.textContent+=j.response;a.scrollIntoView();}}catch(e){}}}
+  }catch(e){a.textContent='Error contacting LLM: '+e.message;}
+}
+document.getElementById('send').onclick=()=>{const q=document.getElementById('q');if(q.value.trim()){ask(q.value.trim());q.value='';}};
+document.getElementById('q').addEventListener('keydown',e=>{if(e.key==='Enter')document.getElementById('send').click();});
+const SUG=['What states can the coffee machine be in?','Which requirement covers water heating?','Which real machines for sale meet all our requirements?','Which requirement excludes the most machines, and should we change it?','What happens in the Brew Coffee activity?'];
+document.getElementById('suggest').innerHTML=SUG.map(s=>`<span>${s}</span>`).join('');
+document.getElementById('suggest').onclick=e=>{if(e.target.tagName==='SPAN'){document.getElementById('q').value=e.target.textContent;document.getElementById('send').click();}};
+
+/* ================= DIGITAL TWIN ================= */
+let twinInited=false, twinTimer=null, SIM=null, TP={};
+function twinParams(){
+  const boiler=(MODEL.structure||[]).find(b=>b.name==='Boiler')||{attributes:[]};
+  const obs=(MODEL.structure||[]).find(b=>b.name==='Boiler Observer')||{attributes:[]};
+  const g=(n,src,d)=>{const a=(src.attributes||[]).find(x=>x.name===n);return a&&a.default!==''&&a.default!=null?parseFloat(a.default):d;};
+  return {inputT:g('inputWaterTemperature',boiler,25),boilingFactor:g('boilingFactor',boiler,0.6),
+          targetT:g('targetWaterTemperature',boiler,84),targetTime:g('targetTime',obs,90)};
+}
+function twinSVG(){return `
+<svg id="twinMachine" viewBox="0 0 800 560" xmlns="http://www.w3.org/2000/svg">
+  <defs>
+    <linearGradient id="chrome" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#2c333d"/><stop offset="1" stop-color="#1b2027"/></linearGradient>
+  </defs>
+  <!-- chassis -->
+  <rect x="120" y="40" width="500" height="480" rx="20" fill="url(#chrome)" stroke="#3a424e" stroke-width="2"/>
+  <rect x="120" y="40" width="500" height="70" rx="20" fill="#333c47"/>
+  <text x="140" y="82" fill="#c8873a" font-family="Segoe UI" font-size="19" font-weight="700">☕ MEMKO Barista</text>
+  <!-- bean hopper -->
+  <path d="M470 55 L590 55 L575 120 L485 120 Z" fill="#2a2018" stroke="#3a424e"/>
+  <g id="twinBeans"></g>
+  <text x="530" y="140" fill="#9aa4b2" font-size="10" text-anchor="middle">Bean Hopper</text>
+  <!-- grinder -->
+  <circle cx="530" cy="175" r="22" fill="#20262e" stroke="#3a424e"/>
+  <g id="twinBlade" transform="rotate(0 530 175)"><rect x="512" y="173" width="36" height="4" rx="2" fill="#6b7686"/><rect x="528" y="157" width="4" height="36" rx="2" fill="#6b7686"/></g>
+  <!-- water tank -->
+  <rect x="150" y="130" width="70" height="160" rx="8" fill="#141a20" stroke="#3a424e"/>
+  <rect id="twinWater" x="153" y="150" width="64" height="137" rx="6" fill="#2f6fb0" opacity="0.85"/>
+  <text x="185" y="305" fill="#9aa4b2" font-size="10" text-anchor="middle">Water Tank</text>
+  <!-- boiler -->
+  <rect x="300" y="180" width="120" height="120" rx="14" fill="#20262e" stroke="#3a424e" stroke-width="2"/>
+  <rect id="twinBoilerFill" x="306" y="230" width="108" height="64" rx="8" fill="#2f6fb0"/>
+  <text x="360" y="170" fill="#9aa4b2" font-size="11" text-anchor="middle">Boiler</text>
+  <text id="twinTempTxt" x="360" y="248" fill="#fff" font-size="22" font-weight="700" text-anchor="middle">25°</text>
+  <g id="twinSteam" opacity="0">
+    <path d="M330 178 q-8 -18 4 -30 q10 -12 2 -28" stroke="#cfe3f5" stroke-width="3" fill="none" opacity="0.6"/>
+    <path d="M360 178 q-8 -18 4 -30 q10 -12 2 -28" stroke="#cfe3f5" stroke-width="3" fill="none" opacity="0.5"/>
+    <path d="M390 178 q-8 -18 4 -30 q10 -12 2 -28" stroke="#cfe3f5" stroke-width="3" fill="none" opacity="0.6"/>
+  </g>
+  <!-- pump + pipes -->
+  <line x1="220" y1="250" x2="300" y2="250" stroke="#4a5563" stroke-width="6"/>
+  <circle cx="260" cy="250" r="12" fill="#20262e" stroke="#3a424e"/><text x="260" y="254" fill="#6b7686" font-size="9" text-anchor="middle">P</text>
+  <line x1="420" y1="250" x2="470" y2="250" stroke="#4a5563" stroke-width="6"/>
+  <line x1="530" y1="197" x2="530" y2="250" stroke="#4a5563" stroke-width="6"/><line x1="470" y1="250" x2="530" y2="250" stroke="#4a5563" stroke-width="6"/>
+  <!-- brew group + spout -->
+  <rect x="330" y="300" width="60" height="26" rx="5" fill="#333c47" stroke="#3a424e"/>
+  <rect x="352" y="326" width="16" height="18" fill="#4a5563"/>
+  <rect id="twinStream" x="357" y="344" width="6" height="70" fill="#6b4a2a" opacity="0"/>
+  <!-- cup -->
+  <path d="M325 415 L395 415 L388 475 L332 475 Z" fill="#eee" stroke="#bbb" stroke-width="2"/>
+  <path d="M395 425 q26 4 24 26 q-3 18 -26 16" fill="none" stroke="#eee" stroke-width="5"/>
+  <clipPath id="cupClip"><path d="M327 417 L393 417 L387 473 L333 473 Z"/></clipPath>
+  <rect id="twinCup2" x="327" y="473" width="66" height="0" fill="#6b4423" clip-path="url(#cupClip)"/>
+  <!-- control panel -->
+  <rect x="150" y="330" width="150" height="120" rx="10" fill="#151a20" stroke="#3a424e"/>
+  <rect x="162" y="342" width="126" height="46" rx="5" fill="#0a1a12" stroke="#1f3a2a"/>
+  <text id="twinDisplay" x="225" y="371" fill="#4fe08a" font-family="Consolas,monospace" font-size="15" font-weight="700" text-anchor="middle">-- OFF --</text>
+  <circle id="twinLED" cx="172" cy="410" r="7" fill="#3a2020" stroke="#000"/>
+  <text x="188" y="414" fill="#9aa4b2" font-size="11">Power</text>
+  <circle id="twinLEDheat" cx="172" cy="432" r="7" fill="#3a2020" stroke="#000"/>
+  <text x="188" y="436" fill="#9aa4b2" font-size="11">Heating element</text>
+  <!-- easter egg: clickable barista -->
+  <g id="twinBarista" style="cursor:pointer">
+    <title>Click me…</title>
+    <ellipse cx="695" cy="512" rx="34" ry="7" fill="#000" opacity="0.25"/>
+    <g id="twinArm" transform="rotate(0 685 430)"><rect x="681" y="428" width="9" height="46" rx="4" fill="#c8873a"/><circle cx="685" cy="478" r="6" fill="#e8c9a0"/></g>
+    <rect x="700" y="428" width="9" height="46" rx="4" fill="#c8873a"/><circle cx="704" cy="478" r="6" fill="#e8c9a0"/>
+    <path d="M672 508 q23 -70 46 0 Z" fill="#3a4652"/>
+    <rect x="681" y="424" width="28" height="60" rx="10" fill="#c8873a"/>
+    <rect x="686" y="440" width="18" height="44" rx="6" fill="#f0ead9"/>
+    <circle cx="695" cy="410" r="17" fill="#e8c9a0"/>
+    <path d="M678 406 q17 -22 34 0 q0 -14 -17 -16 q-17 2 -17 16Z" fill="#4a3626"/>
+    <ellipse cx="689" cy="410" rx="1.8" ry="2.4" fill="#2a2118"/><ellipse cx="701" cy="410" rx="1.8" ry="2.4" fill="#2a2118"/>
+    <path d="M690 417 q5 4 10 0" stroke="#2a2118" stroke-width="1.6" fill="none"/>
+    <!-- x-ray skeleton (strobes during electrocution) -->
+    <g id="twinSkeleton" opacity="0" pointer-events="none">
+      <ellipse cx="695" cy="408" rx="13" ry="15" fill="#f4f4ef"/>
+      <ellipse cx="690" cy="406" rx="3" ry="3.6" fill="#141414"/><ellipse cx="700" cy="406" rx="3" ry="3.6" fill="#141414"/>
+      <path d="M693 412 l2 4 l2 -4 Z" fill="#141414"/>
+      <path d="M687 420 h16" stroke="#141414" stroke-width="3"/>
+      <path d="M689 418 v5 M693 418 v6 M697 418 v6 M701 418 v5" stroke="#f4f4ef" stroke-width="1"/>
+      <line x1="695" y1="424" x2="695" y2="486" stroke="#f4f4ef" stroke-width="3"/>
+      <path d="M695 432 q-13 3 -14 10 M695 432 q13 3 14 10" stroke="#f4f4ef" stroke-width="2" fill="none"/>
+      <path d="M695 442 q-14 3 -15 10 M695 442 q14 3 15 10" stroke="#f4f4ef" stroke-width="2" fill="none"/>
+      <path d="M695 452 q-13 3 -14 9 M695 452 q13 3 14 9" stroke="#f4f4ef" stroke-width="2" fill="none"/>
+      <path d="M683 486 q12 8 24 0" stroke="#f4f4ef" stroke-width="3" fill="none"/>
+      <line x1="686" y1="428" x2="675" y2="470" stroke="#f4f4ef" stroke-width="3"/>
+      <line x1="704" y1="428" x2="715" y2="470" stroke="#f4f4ef" stroke-width="3"/>
+      <line x1="690" y1="486" x2="684" y2="510" stroke="#f4f4ef" stroke-width="3"/>
+      <line x1="700" y1="486" x2="706" y2="510" stroke="#f4f4ef" stroke-width="3"/>
+    </g>
+    <g id="twinBubble" opacity="0"><rect x="612" y="360" width="150" height="40" rx="10" fill="#fff"/><path d="M655 398 l10 14 l10 -14 Z" fill="#fff"/><text id="twinBubbleTxt" x="687" y="385" fill="#141414" font-size="13" font-weight="600" text-anchor="middle">One coffee, coming up! ☕</text></g>
+    <text id="twinHint" x="695" y="536" fill="#6b7686" font-size="10" text-anchor="middle">psst… click me</text>
+  </g>
+  <!-- electrocution easter egg -->
+  <g id="twinShock" opacity="0" pointer-events="none">
+    <!-- electric arc: energised chassis/spout -> operator's hand -->
+    <polyline points="368,344 372,372 500,300 545,340 600,398 588,420 642,430" stroke="#ffd21f" stroke-width="9" fill="none" opacity="0.35"/>
+    <polyline points="368,344 372,372 500,300 545,340 600,398 588,420 642,430" stroke="#fff45f" stroke-width="4" fill="none" opacity="0.95"/>
+    <!-- shock halo around the operator -->
+    <circle cx="695" cy="430" r="92" fill="#ffe066" opacity="0.20"/>
+    <circle cx="695" cy="430" r="60" fill="#fff45f" opacity="0.18"/>
+    <!-- bolts radiating off the operator -->
+    <polyline points="626,358 656,388 636,394 674,434" stroke="#ffd21f" stroke-width="4" fill="none"/>
+    <polyline points="764,358 736,390 756,396 722,434" stroke="#ffd21f" stroke-width="4" fill="none"/>
+    <polyline points="695,316 712,350 690,354 716,392" stroke="#fff45f" stroke-width="4" fill="none"/>
+    <!-- hair standing on end -->
+    <line x1="686" y1="396" x2="681" y2="372" stroke="#4a3626" stroke-width="2.4"/>
+    <line x1="695" y1="394" x2="695" y2="368" stroke="#4a3626" stroke-width="2.4"/>
+    <line x1="704" y1="396" x2="709" y2="372" stroke="#4a3626" stroke-width="2.4"/>
+    <!-- X-ed out eyes -->
+    <text x="684" y="415" fill="#2a2118" font-size="11" font-weight="700">✖</text>
+    <text x="699" y="415" fill="#2a2118" font-size="11" font-weight="700">✖</text>
+    <g><rect x="548" y="314" width="204" height="40" rx="10" fill="#fff"/><path d="M645 354 l11 15 l9 -15 Z" fill="#fff"/>
+       <text x="650" y="339" fill="#c0392b" font-size="12.5" font-weight="700" text-anchor="middle">BZZZT! Where's the RCD?! ⚡💀</text></g>
+  </g>
+  <!-- full-canvas flash + persistent electrocution banner -->
+  <rect id="twinFlash" x="0" y="0" width="780" height="560" fill="#fff45f" opacity="0" pointer-events="none"/>
+  <g id="twinShockBanner" opacity="0" pointer-events="none">
+    <rect x="135" y="236" width="470" height="66" rx="12" fill="#7a1414" fill-opacity="0.94" stroke="#ffd21f" stroke-width="3"/>
+    <text x="370" y="266" fill="#ffe066" font-size="19" font-weight="800" text-anchor="middle">⚡ OPERATOR ELECTROCUTED ⚡</text>
+    <text x="370" y="288" fill="#ffb0a8" font-size="12" font-weight="600" text-anchor="middle">chassis energised on dispense — no RCD fitted (violates REQ 3.1.5)</text>
+  </g>
+</svg>`;}
+
+function twinPanel(){return `
+  <div class="tp-state"><div class="lbl">State Machine</div><div class="val" id="tpState">Off</div><div class="sub" id="tpSub">powered down</div></div>
+  <div class="tp-btns">
+    <button class="power" id="tpPower">⏻ Power On</button>
+    <button class="go" id="tpSelect" disabled>☕ Select Coffee</button>
+    <button id="tpReset">↺ Reset</button>
+    <button id="tpAuto" style="grid-column:1/3">▶ Auto-serve: OFF</button>
+  </div>
+  <div>
+    <div class="tp-row"><span>Boiler temp</span><b id="tpTemp">25.0 °C</b></div>
+    <div class="tp-meter"><div id="tpTempBar" style="width:0%;background:linear-gradient(90deg,#2f6fb0,#e0685f)"></div></div>
+    <div class="tp-row" style="margin-top:2px"><span style="font-size:11px">target ${TP.targetT}°C</span></div>
+  </div>
+  <div>
+    <div class="tp-row"><span>Water tank</span><b id="tpWater">100%</b></div>
+    <div class="tp-meter"><div id="tpWaterBar" style="width:100%;background:#2f6fb0"></div></div>
+  </div>
+  <div class="tp-req" id="tpReq"><b>REQ 1.1 Heater Initialization</b><br><span id="tpReqTxt">awaiting run…</span></div>
+  <div>
+    <div class="tp-h">Brew Coffee activity</div>
+    <div class="tp-steps" id="tpSteps"></div>
+  </div>
+  <div>
+    <div class="tp-h">⚠ Inject a fault — watch the STM react</div>
+    <div class="tp-faults" id="tpFaults">
+      <button data-flt="WATER_LOW">💧 Empty water tank<br><span style="opacity:.7">REQ 1.3</span></button>
+      <button data-flt="BEANS_LOW">🫘 Beans below 45 g<br><span style="opacity:.7">REQ 1.4</span></button>
+      <button data-flt="OVERHEAT">🔥 Force overheat >170°<br><span style="opacity:.7">REQ 1.2</span></button>
+      <button data-flt="INTERRUPT">🚪 Remove dregs drawer<br><span style="opacity:.7">REQ 3.1.3</span></button>
+      <button data-flt="SHORT" style="grid-column:1/3;background:#3a1414;border-color:#7a2f2a;color:#ffb0a8">⚡ Short circuit on dispense (no RCD)<br><span style="opacity:.7">REQ 3.1.5 — watch the barista…</span></button>
+      <button class="clear" data-flt="CLEAR">✓ Clear fault / refill &amp; resume</button>
+    </div>
+  </div>
+  <div>
+    <div class="tp-h">STM reaction log</div>
+    <div class="tp-log" id="tpLog"></div>
+  </div>
+  <div>
+    <div class="tp-h">boilingFactor (Lab 4 what-if)</div>
+    <input class="tp-slider" type="range" id="tpBF" min="0.1" max="1.0" step="0.05" value="${TP.boilingFactor}">
+    <div class="tp-row"><span>value</span><b id="tpBFval">${TP.boilingFactor}</b></div>
+  </div>
+  <div>
+    <div class="tp-h">Sim speed</div>
+    <input class="tp-slider" type="range" id="tpSpeed" min="1" max="20" step="1" value="8">
+    <div class="tp-row"><span>×<b id="tpSpeedval">8</b> real-time</span></div>
+  </div>`;}
+
+const BREW_STEPS=['Heat Water','Grind Beans','Extract Coffee','Dispense Coffee'];
+function ensureTwin(){
+  if(twinInited){return;}
+  TP=twinParams();
+  document.getElementById('twinStage').innerHTML=twinSVG()+
+    `<div id="twinOee">
+       <div class="big"><span id="toeeVal" style="color:#63c088">0%</span><small>LIVE OEE</small></div>
+       <div class="apq">
+         <div><div class="k">Availability</div><div class="m"><i id="toeeAm"></i></div><div class="v" id="toeeA">–</div></div>
+         <div><div class="k">Performance</div><div class="m"><i id="toeePm"></i></div><div class="v" id="toeeP">–</div></div>
+         <div><div class="k">Quality</div><div class="m"><i id="toeeQm"></i></div><div class="v" id="toeeQ">–</div></div>
+       </div>
+       <div class="cups"><b id="toeeCups">0</b> cups · <span id="toeeTph">0</span>/hr<br><span id="toeeBad" style="color:#e0685f">0 rejected</span></div>
+     </div>`;
+  // beans
+  let bg=''; for(let i=0;i<14;i++){const x=488+Math.random()*80,y=70+Math.random()*40;bg+=`<ellipse cx="${x}" cy="${y}" rx="5" ry="3.5" fill="#5a3a22" transform="rotate(${Math.random()*180} ${x} ${y})"/>`;}
+  document.getElementById('twinBeans').innerHTML=bg;
+  document.getElementById('twinPanel').innerHTML=twinPanel();
+  document.getElementById('tpSteps').innerHTML=BREW_STEPS.map((s,i)=>`<div class="tp-step" data-i="${i}">${i+1}. ${s}</div>`).join('');
+  SIM={power:false,state:'Off',t:0,stateT:0,heatElapsed:0,temp:TP.inputT,heating:false,heatToggle:0,
+       water:1,beans:1,cup:0,brewStep:-1,brewT:0,req:null,reqTemp:null,boilingFactor:TP.boilingFactor,speed:8,bladeAng:0,wave:0,
+       fault:null,prevState:'Off',log:[],autoServe:false,faultsByType:{WATER_LOW:0,BEANS_LOW:0,OVERHEAT:0,INTERRUPT:0,SHORT:0},shock:0,
+       // OEE / throughput counters (sim-seconds & cups)
+       runSec:0,operSec:0,downSec:0,cupsGood:0,cupsBad:0,faultCount:0,idealCycle:24};
+  window.SIMLOG=(cls,msg)=>{SIM.log.unshift({cls,msg,t:Date.now()}); if(SIM.log.length>40)SIM.log.pop();};
+  // wire controls
+  document.getElementById('tpPower').onclick=()=>{ SIM.power=!SIM.power; if(SIM.power){SIM.state='Initialising';SIM.stateT=0;SIM.t=0;SIM.heatElapsed=0;SIM.req=null;SIM.reqTemp=null;} else {SIM.state='Off';SIM.heating=false;} };
+  document.getElementById('tpSelect').onclick=()=>{
+    if(SIM.state!=='Idle') return;
+    if(SIM.beans<0.1){ induceFault('BEANS_LOW'); return; }
+    SIM.state='Brewing';SIM.stateT=0;SIM.brewStep=0;SIM.brewT=0;SIM.cup=0;
+    SIMLOG('a','Selection Made → Brewing (do: Brew Coffee)');
+  };
+  document.getElementById('tpReset').onclick=()=>{ Object.assign(SIM,{power:false,state:'Off',t:0,stateT:0,heatElapsed:0,temp:TP.inputT,heating:false,water:1,cup:0,brewStep:-1,req:null,reqTemp:null}); };
+  document.getElementById('tpBF').oninput=(e)=>{ SIM.boilingFactor=parseFloat(e.target.value); document.getElementById('tpBFval').textContent=SIM.boilingFactor.toFixed(2); };
+  document.getElementById('tpSpeed').oninput=(e)=>{ SIM.speed=parseInt(e.target.value); document.getElementById('tpSpeedval').textContent=SIM.speed; };
+  // easter egg: barista powers it on
+  document.getElementById('twinBarista').onclick=()=>{
+    if(!SIM.power){ SIM.power=true; SIM.state='Initialising'; SIM.stateT=0; SIM.t=0; SIM.heatElapsed=0; SIM.req=null; SIM.reqTemp=null; }
+    SIM.wave=1.4;
+    const bub=document.getElementById('twinBubble'); if(bub) bub.setAttribute('opacity','1');
+    const hint=document.getElementById('twinHint'); if(hint) hint.setAttribute('opacity','0');
+    clearTimeout(SIM._bubT); SIM._bubT=setTimeout(()=>{ if(bub) bub.setAttribute('opacity','0'); },3200);
+  };
+  // fault injection
+  document.getElementById('tpFaults').onclick=(e)=>{ const b=e.target.closest('button'); if(!b)return; induceFault(b.dataset.flt); };
+  document.getElementById('tpAuto').onclick=(e)=>{ SIM.autoServe=!SIM.autoServe; e.target.textContent='▶ Auto-serve: '+(SIM.autoServe?'ON':'OFF'); e.target.style.background=SIM.autoServe?'#63c088':'var(--panel2)'; e.target.style.color=SIM.autoServe?'#0a0a0a':'var(--txt)'; SIMLOG('a','auto-serve '+(SIM.autoServe?'ON — continuous production':'OFF')); };
+  window.SIMLOG('a','twin ready — click ⏻ or the barista to power on');
+  twinInited=true;
+}
+let _oeeTick=0;
+function twinLoop(){ if(twinTimer)return; twinTimer=setInterval(()=>{ twinTick(0.05); twinRender(); if(document.getElementById('v-oee').classList.contains('active') && (++_oeeTick%10===0)) renderOEE(); },50); }
+function resetMetrics(){ if(!SIM)return; Object.assign(SIM,{runSec:0,operSec:0,downSec:0,cupsGood:0,cupsBad:0,faultCount:0,faultsByType:{WATER_LOW:0,BEANS_LOW:0,OVERHEAT:0,INTERRUPT:0,SHORT:0}}); SIMLOG('a','OEE metrics reset'); renderOEE(); }
+
+const FAULTS={
+  WATER_LOW:{code:'E1',msg:'WATER LOW',log:'Water tank &lt;500 mL — REQ 1.3 inhibits brew',cut:false},
+  BEANS_LOW:{code:'E2',msg:'BEANS LOW',log:'Beans &lt;45 g — REQ 1.4 inhibits grind',cut:false},
+  OVERHEAT:{code:'E3',msg:'OVERHEAT',log:'Boiler >170°C — REQ 1.2 thermostat cuts power',cut:true},
+  INTERRUPT:{code:'E4',msg:'DREGS OUT',log:'Dregs drawer removed — REQ 3.1.3 interrupts operation',cut:false},
+  SHORT:{code:'E5',msg:'⚡ SHOCK!',log:'Short on dispense energised the chassis — no RCD (REQ 3.1.5) — operator ZAPPED!',cut:true}
+};
+function induceFault(kind){
+  if(!SIM) return;
+  if(kind==='CLEAR'){
+    if(SIM.fault){ SIMLOG('g','operator clears fault → refill/close → Idle'); }
+    SIM.water=1; SIM.beans=1; SIM.lowWarned=false; if(SIM.temp>95)SIM.temp=TP.targetT; SIM.fault=null;
+    if(SIM.power){ SIM.state='Idle'; SIM.stateT=0; } else { SIM.state='Off'; }
+    return;
+  }
+  if(!SIM.power){ SIMLOG('a','machine is OFF — power on first'); return; }
+  const F=FAULTS[kind]; if(!F) return;
+  if(kind==='WATER_LOW') SIM.water=0.05;
+  if(kind==='BEANS_LOW') SIM.beans=0.05;
+  if(kind==='OVERHEAT') SIM.temp=182;
+  // a brew in progress is spoiled
+  if(SIM.state==='Brewing'){ SIM.cupsBad++; SIM.faultCount; SIMLOG('f','brew aborted → cup rejected (quality loss)'); }
+  SIM.faultCount++; if(SIM.faultsByType[kind]!=null) SIM.faultsByType[kind]++;
+  if(kind==='SHORT'){ SIM.shock=3.5; SIMLOG('f','⚡💀 ZAP! The barista got shocked! An RCD (REQ 3.1.5) would have tripped first.'); }
+  SIMLOG('f','⚠ '+F.code+' '+F.msg+': '+F.log);
+  if(F.cut){ SIM.power=false; SIM.state='Fault'; SIM.fault=kind; SIMLOG('f','STM: On → (PowerOff by thermostat) → Off/Fault'); }
+  else { SIM.prevState=SIM.state; SIM.state='Fault'; SIM.fault=kind; SIMLOG('a','STM: '+SIM.prevState+' → Fault — alert user (System Alert)'); }
+  SIM.brewStep=-1; SIM.cup=0;
+}
+
+function twinTick(dtReal){
+  if(!SIM)return; const dt=dtReal*SIM.speed;
+  const P=TP;
+  if(SIM.wave>0) SIM.wave-=dtReal;
+  if(SIM.shock>0 && SIM.fault!=='SHORT') SIM.shock-=dtReal;
+  // OEE time accounting: the machine's active window = powered on OR halted in a fault
+  const active = SIM.power || SIM.state==='Fault';
+  if(active){ SIM.runSec+=dt; if(SIM.state==='Fault') SIM.downSec+=dt; else SIM.operSec+=dt; }
+  // FAULT: machine halted, awaiting operator; boiler cools if power was cut
+  if(SIM.state==='Fault'){ SIM.heating=false; if(!SIM.power && SIM.temp>P.inputT) SIM.temp-=dt*1.5; SIM.bladeAng+=0; return; }
+  if(!SIM.power){ SIM.state='Off'; SIM.heating=false; if(SIM.temp>P.inputT) SIM.temp-=dt*2; if(SIM.temp<P.inputT)SIM.temp=P.inputT; return; }
+  SIM.t+=dt; SIM.stateT+=dt;
+  // concurrent Heating region: thermostat cycling once up to temp; below target -> heating on
+  SIM.heating = SIM.temp < (P.targetT+1);
+  if(SIM.heating){ SIM.heatElapsed+=dt; SIM.temp=Math.min(99, P.inputT + Math.sqrt(SIM.boilingFactor)*SIM.heatElapsed); }
+  else { SIM.temp += Math.sin(SIM.t*3)*0.15; }
+  // self-protect: runaway temperature trips the thermostat (REQ 1.2)
+  if(SIM.temp>170){ induceFault('OVERHEAT'); return; }
+  // requirement 1.1 check at targetTime
+  if(SIM.req===null && SIM.t>=P.targetTime){ SIM.reqTemp = P.inputT + Math.sqrt(SIM.boilingFactor)*P.targetTime; SIM.req = SIM.reqTemp>=P.targetT; }
+  if(SIM.state==='Initialising'){ if(SIM.stateT>=30){ SIM.state='Idle'; SIM.stateT=0; SIMLOG('a','Initialising → Idle after(30 s)'); } }
+  else if(SIM.state==='Idle'){
+    if(SIM.autoServe && SIM.stateT>0.5){
+      if(SIM.beans<0.1){ induceFault('BEANS_LOW'); }
+      else { SIM.state='Brewing'; SIM.stateT=0; SIM.brewStep=0; SIM.brewT=0; SIM.cup=0; SIMLOG('a','Selection Made → Brewing (auto-serve)'); }
+    }
+  }
+  else if(SIM.state==='Brewing'){
+    SIM.brewT+=dt;
+    const step=Math.min(3,Math.floor(SIM.brewT/6)); SIM.brewStep=step;
+    if(step===1){ SIM.bladeAng+=dt*400; }
+    if(step>=2){
+      SIM.water=Math.max(0, SIM.water-dt*0.02);
+      if(SIM.water<=0.1 && SIM.water>0 && !SIM.lowWarned){ SIM.lowWarned=true; SIMLOG('f','⚠ water low — a compliant design would inhibit the brew here (REQ 1.3); this machine keeps dispensing…'); }
+      if(SIM.water<=0){ SIMLOG('f','tank ran DRY mid-dispense → element/pump energised the wet chassis (no isolation)'); induceFault('SHORT'); return; }
+    }
+    if(step===3){ SIM.cup=Math.min(1, SIM.cup + dt*0.10); }
+    if(SIM.brewT>=24){ SIM.state='Idle'; SIM.stateT=0; SIM.brewStep=-1; SIM.cupsGood++; SIMLOG('g','Brew Complete → Idle (Clean System) — cup #'+(SIM.cupsGood)+' ✓'); }
+  }
+}
+function lerpColor(a,b,t){const p=(x,i)=>parseInt(x.substr(i,2),16);const r=Math.round(p(a,1)+(p(b,1)-p(a,1))*t),g=Math.round(p(a,3)+(p(b,3)-p(a,3))*t),bl=Math.round(p(a,5)+(p(b,5)-p(a,5))*t);return `rgb(${r},${g},${bl})`;}
+function twinRender(){
+  if(!SIM)return; const P=TP; const $=id=>document.getElementById(id);
+  const tempPct=Math.max(0,Math.min(1,(SIM.temp-20)/(100-20)));
+  // boiler fill color blue->red
+  const col = SIM.temp<60? lerpColor('#2f6fb0','#e0a94f',(SIM.temp-25)/35) : lerpColor('#e0a94f','#e0685f',Math.min(1,(SIM.temp-60)/40));
+  const bf=$('twinBoilerFill'); if(bf) bf.setAttribute('fill',col);
+  const tt=$('twinTempTxt'); if(tt) tt.textContent=Math.round(SIM.temp)+'°';
+  const steam=$('twinSteam'); if(steam) steam.setAttribute('opacity', SIM.temp>70? Math.min(0.9,(SIM.temp-70)/30):0);
+  // water tank level
+  const wFull=137, wy=150; const wlvl=$('twinWater'); if(wlvl){ wlvl.setAttribute('height',wFull*SIM.water); wlvl.setAttribute('y',wy+wFull*(1-SIM.water)); }
+  // grinder blade
+  const bl=$('twinBlade'); if(bl) bl.setAttribute('transform',`rotate(${SIM.bladeAng} 530 175)`);
+  // barista wave
+  const arm=$('twinArm'); if(arm){ const a=SIM.wave>0? Math.sin(Date.now()/70)*32 : 0; arm.setAttribute('transform',`rotate(${a} 685 430)`); }
+  // electrocution easter egg
+  const shk=$('twinShock'), bar=$('twinBarista'), fl=$('twinFlash'), ban=$('twinShockBanner'), skel=$('twinSkeleton');
+  const shocked = SIM.shock>0 || SIM.fault==='SHORT';   // persist while the SHORT fault is active
+  if(shocked){ const on=(Date.now()%140<70);
+    if(shk) shk.setAttribute('opacity', on?1:0.4);
+    if(fl)  fl.setAttribute('opacity', on?0.42:0.08);
+    if(ban) ban.setAttribute('opacity', 1);
+    if(skel) skel.setAttribute('opacity', on?1:0);        // x-ray skeleton flashes through the body
+    if(bar){ const jx=(Math.random()*14-7-48).toFixed(1), jy=(Math.random()*14-7).toFixed(1), rot=(Math.random()*7-3.5).toFixed(1);
+      // shift left into view + violent shake + scale the whole person up so the zap is centre-stage and never clipped
+      bar.setAttribute('transform',`translate(${jx},${jy}) translate(695,455) rotate(${rot}) scale(1.28) translate(-695,-455)`); } }
+  else {
+    if(shk) shk.setAttribute('opacity',0);
+    if(fl)  fl.setAttribute('opacity',0);
+    if(ban) ban.setAttribute('opacity',0);
+    if(skel) skel.setAttribute('opacity',0);
+    if(bar) bar.setAttribute('transform','translate(0,0)'); }
+  // stream + cup
+  const stream=$('twinStream'); if(stream) stream.setAttribute('opacity', SIM.state==='Brewing'&&SIM.brewStep>=3?0.9:0);
+  const cupH=56*SIM.cup; const cup=$('twinCup2'); if(cup){cup.setAttribute('height',cupH);cup.setAttribute('y',473-cupH);}
+  // display + LEDs
+  const F = SIM.fault? FAULTS[SIM.fault] : null;
+  const disp=$('twinDisplay');
+  if(disp){
+    if(F){ disp.textContent = F.code+' '+F.msg; disp.setAttribute('fill','#ff6b5e'); }
+    else { disp.textContent = SIM.power? (SIM.state==='Brewing'?('BREW '+Math.round(SIM.brewT/24*100)+'%'):SIM.state.toUpperCase()) : '-- OFF --'; disp.setAttribute('fill','#4fe08a'); }
+  }
+  const led=$('twinLED'); if(led) led.setAttribute('fill', SIM.power?'#4fe08a':(F?'#ff6b5e':'#3a2020'));
+  const ledh=$('twinLEDheat'); if(ledh) ledh.setAttribute('fill', SIM.heating?'#e0685f':'#3a2020');
+  // panel
+  const st=$('tpState'); st.textContent = F? ('⚠ Fault') : SIM.state; st.style.color = F? '#e0685f' : 'var(--accent)';
+  const subs={Off:'powered down',Initialising:'system check (entry: Initialise System)',Idle:'ready — Check System / Select Coffee',Brewing:'brewing (do: Brew Coffee)',Fault:'halted — awaiting operator (System Alert)'};
+  $('tpSub').textContent = F? F.log.replace(/&lt;/g,'<') : (subs[SIM.state]||'');
+  // reaction log
+  const lg=$('tpLog');
+  if(lg){ lg.innerHTML = SIM.log.map(e=>'<span class="'+e.cls+'">'+e.msg+'</span>').join('<br>'); }
+  $('tpPower').textContent = SIM.power?'⏻ Power Off':'⏻ Power On'; $('tpPower').classList.toggle('on',SIM.power);
+  $('tpSelect').disabled = !(SIM.state==='Idle');
+  $('tpTemp').textContent=SIM.temp.toFixed(1)+' °C';
+  $('tpTempBar').style.width=(tempPct*100)+'%';
+  $('tpWater').textContent=Math.round(SIM.water*100)+'%'+(SIM.beans<0.1?'  · beans low':''); $('tpWaterBar').style.width=(SIM.water*100)+'%'; $('tpWaterBar').style.background=(SIM.water<0.1?'#e0685f':'#2f6fb0');
+  const rq=$('tpReq'), rqt=$('tpReqTxt');
+  if(SIM.req===null){ rq.className='tp-req'; rqt.textContent = SIM.power? ('heating… '+Math.round(SIM.t)+'s / '+P.targetTime+'s target'):'awaiting run…'; }
+  else if(SIM.req){ rq.className='tp-req ok'; rqt.textContent='✓ SATISFIED — '+SIM.reqTemp.toFixed(1)+'°C ≥ '+P.targetT+'°C at '+P.targetTime+'s'; }
+  else { rq.className='tp-req bad'; rqt.textContent='✗ NOT met — only '+SIM.reqTemp.toFixed(1)+'°C at '+P.targetTime+'s (raise boilingFactor)'; }
+  document.querySelectorAll('#tpSteps .tp-step').forEach((el,i)=>{ el.classList.toggle('active', SIM.state==='Brewing'&&SIM.brewStep===i); el.classList.toggle('done', SIM.state==='Brewing'&&SIM.brewStep>i); });
+  updateTwinStrip();
+}
+
+/* ================= MARKET FIT (open public data) ================= */
+// Specs compiled from public product listings/reviews (Sep 2026). Values are indicative.
+const MARKET=[
+  {name:"De'Longhi Magnifica S ECAM22.110",  heatUp:25, tank:1.8, beans:250, pump:15, price:280, url:"https://www.ebay.de/p/23060676952"},
+  {name:"De'Longhi Rivelia",                  heatUp:25, tank:1.4, beans:500, pump:19, price:750, url:"https://espressorabbithole.com/en/delonghi-rivelia-review/"},
+  {name:"De'Longhi Dinamica",                 heatUp:25, tank:1.8, beans:300, pump:15, price:450, url:"https://www.idealo.co.uk/cat/3487F1280013/espresso-machines.html"},
+  {name:"De'Longhi Magnifica ESAM4200.S",     heatUp:25, tank:1.8, beans:200, pump:15, price:300, url:"https://www.ebay.de/p/23034636586"},
+  {name:"Jura Z8",                            heatUp:25, tank:2.4, beans:280, pump:15, price:2200,url:"https://www.idealo.co.uk/cat/3487F1280013/espresso-machines.html"},
+  {name:"Jura E8",                            heatUp:25, tank:1.9, beans:280, pump:15, price:1300,url:"https://www.idealo.co.uk/cat/3487F1280013/espresso-machines.html"},
+  {name:"Philips Baristina",                  heatUp:30, tank:1.2, beans:170, pump:15, price:400, url:"https://www.t3.com/home-living/coffee-machines/philips-baristina-review-the-easiest-bean-to-cup-coffee-machine-ive-ever-used"},
+  {name:"Ninja Luxe Cafe Premier",            heatUp:33, tank:2.0, beans:400, pump:15, price:500, url:"https://www.techradar.com/best/best-bean-to-cup-coffee-machine-2022-the-top-coffee-makers-for-barista-worthy-drinks"},
+  {name:"Smeg BCC12",                         heatUp:23, tank:1.4, beans:250, pump:15, price:700, url:"https://www.ebay.de/itm/267318086075"},
+  {name:"Siemens EQ.6 TK76K573",              heatUp:25, tank:2.0, beans:300, pump:19, price:800, url:"https://www.idealo.co.uk/cat/3487F1280013/espresso-machines.html"},
+  {name:"Sage/Breville Barista Touch",        heatUp:30, tank:2.0, beans:250, pump:15, price:1000,url:"https://www.techradar.com/best/best-bean-to-cup-coffee-machine-2022-the-top-coffee-makers-for-barista-worthy-drinks"},
+  {name:"Gaggia Anima",                       heatUp:40, tank:1.8, beans:250, pump:15, price:450, url:"https://coffeeblog.co.uk/best-bean-to-cup-coffee-machines/"}
+];
+// requirement thresholds (defaults from the model's requirements; interactive)
+const MK_REQS={ heat:{id:'1.1',label:'Heat-up ≤',unit:'s',val:90,max:'heatUp',cmp:'le',min:20,maxr:120,step:5},
+                tank:{id:'1.5',label:'Water tank ≤',unit:'L',val:2.4,max:'tank',cmp:'le',min:1.0,maxr:3.0,step:0.1},
+                beans:{id:'1.6',label:'Bean hopper ≤',unit:'g',val:300,max:'beans',cmp:'le',min:150,maxr:600,step:10},
+                pump:{id:'1.8',label:'Pump pressure ≤',unit:'bar',val:15,max:'pump',cmp:'le',min:9,maxr:20,step:1} };
+function mkPass(m,r){ return m[r.max] <= r.val; }
+function mkCompliant(m){ return Object.values(MK_REQS).every(r=>mkPass(m,r)); }
+function marketSummaryForChat(){
+  const n=MARKET.filter(mkCompliant).length;
+  let s=`\nMARKET (public data, ${MARKET.length} real bean-to-cup machines) vs requirements [heat<=${MK_REQS.heat.val}s(1.1), tank<=${MK_REQS.tank.val}L(1.5), beans<=${MK_REQS.beans.val}g(1.6), pump<=${MK_REQS.pump.val}bar(1.8)]: ${n}/${MARKET.length} meet ALL.\n`;
+  MARKET.forEach(m=>{ s+=`- ${m.name}: heat ${m.heatUp}s, tank ${m.tank}L, beans ${m.beans}g, pump ${m.pump}bar, ~£${m.price} -> ${mkCompliant(m)?'MEETS ALL':'fails '+Object.values(MK_REQS).filter(r=>!mkPass(m,r)).map(r=>r.id).join('/')}\n`; });
+  return s;
+}
+function renderMarket(){
+  const v=document.getElementById('v-market');
+  const compliant=MARKET.filter(mkCompliant);
+  // most-violated requirement
+  const viol={}; Object.entries(MK_REQS).forEach(([k,r])=>viol[k]=MARKET.filter(m=>!mkPass(m,r)).length);
+  const worst=Object.entries(viol).sort((a,b)=>b[1]-a[1])[0];
+  const worstR=MK_REQS[worst[0]];
+  let html=`<h2>Market Fit — real machines vs. your requirements</h2>
+   <div style="font-size:12.5px;color:var(--muted);margin:-6px 0 14px">Public bean-to-cup product data (Sep 2026) evaluated against the SysML model's quantifiable requirements. Drag a threshold to explore how a spec change reshapes the viable market.</div>
+   <div class="mk-head">
+     <div class="mk-kpi"><div class="n" style="color:${compliant.length?'#63c088':'#e0685f'}">${compliant.length}/${MARKET.length}</div><div class="l">machines meet all reqs</div></div>
+     <div class="mk-kpi"><div class="n">${Object.keys(MK_REQS).length}</div><div class="l">quantified requirements</div></div>
+     <div class="mk-kpi"><div class="n" style="color:#e0685f">REQ ${worstR.id}</div><div class="l">most-excluding spec (${worst[1]} fail)</div></div>
+     <div class="mk-kpi"><div class="n">£${compliant.length?Math.min(...compliant.map(m=>m.price)):'—'}</div><div class="l">cheapest compliant</div></div>
+   </div>
+   <div class="mk-controls">`;
+  Object.entries(MK_REQS).forEach(([k,r])=>{ html+=`<div class="mk-ctl"><label>REQ ${r.id} — ${r.label} <b id="mkv-${k}">${r.val}${r.unit}</b></label><input type="range" id="mks-${k}" min="${r.min}" max="${r.maxr}" step="${r.step}" value="${r.val}"></div>`; });
+  html+=`</div>`;
+  // matrix
+  html+=`<div class="card"><table class="mk"><tr><th>Machine</th><th>Price</th><th>REQ 1.1<br>heat</th><th>REQ 1.5<br>tank</th><th>REQ 1.6<br>beans</th><th>REQ 1.8<br>pump</th><th>Verdict</th></tr>`;
+  MARKET.slice().sort((a,b)=>(mkCompliant(b)-mkCompliant(a))||a.price-b.price).forEach(m=>{
+    const cell=(r,txt)=>`<td><div class="mk-cell ${mkPass(m,r)?'mk-pass':'mk-fail'}">${txt}</div></td>`;
+    const ok=mkCompliant(m);
+    html+=`<tr><td><b>${m.name}</b></td><td class="mk-price">£${m.price}</td>${cell(MK_REQS.heat,m.heatUp+'s')}${cell(MK_REQS.tank,m.tank+'L')}${cell(MK_REQS.beans,m.beans+'g')}${cell(MK_REQS.pump,m.pump+'bar')}<td><div class="mk-cell ${ok?'mk-pass':'mk-fail'}">${ok?'✓ MEETS':'✗ NO'}</div></td></tr>`;
+  });
+  html+=`</table></div>`;
+  // recommendation
+  const passExHeat=MARKET.filter(m=>mkPass(m,MK_REQS.tank)&&mkPass(m,MK_REQS.beans)&&mkPass(m,MK_REQS.pump)).length;
+  let rec=`<div class="mk-rec"><b>Decision support.</b> `;
+  if(compliant.length===0){ rec+=`No off-the-shelf machine currently meets all four requirements as specified — this points to either a <b>custom build</b> or <b>relaxing a constraint</b>. `; }
+  else { rec+=`${compliant.length} of ${MARKET.length} public machines satisfy the current spec envelope (cheapest ~£${Math.min(...compliant.map(m=>m.price))}). `; }
+  rec+=`The most-excluding requirement is <b>REQ ${worstR.id} (${worstR.label} ${worstR.val}${worstR.unit})</b>, failed by ${worst[1]} machine(s). `;
+  if(worst[0]==='pump'){ rec+=`Market norm for premium bean-to-cup is <b>15–19 bar</b>; the ≤15 bar cap excludes higher-pressure models. If 15 bar is the extraction sweet-spot (not a hard limit), keep it; if procurement flexibility matters, consider ≤19 bar. `; }
+  rec+=`REQ 1.1 (heat 84°C in ≤90 s) is comfortably met by the market (real heat-up ${Math.min(...MARKET.map(m=>m.heatUp))}–${Math.max(...MARKET.map(m=>m.heatUp))} s) — the heater spec is achievable and could even be tightened.</div>`;
+  html+=rec;
+  html+=`<div class="mk-src">Sources (public, Sep 2026): <a href="https://www.idealo.co.uk/cat/3487F1280013/espresso-machines.html" target="_blank">idealo</a>, <a href="https://www.techradar.com/best/best-bean-to-cup-coffee-machine-2022-the-top-coffee-makers-for-barista-worthy-drinks" target="_blank">TechRadar</a>, <a href="https://espressorabbithole.com/en/delonghi-rivelia-review/" target="_blank">Espresso Rabbit Hole</a>, <a href="https://www.t3.com/home-living/coffee-machines/philips-baristina-review-the-easiest-bean-to-cup-coffee-machine-ive-ever-used" target="_blank">T3</a>, <a href="https://coffeeblog.co.uk/best-bean-to-cup-coffee-machines/" target="_blank">Coffee Blog</a>. Specs indicative; verify before procurement.</div>`;
+  v.innerHTML=html;
+  // wire sliders
+  Object.entries(MK_REQS).forEach(([k,r])=>{ const s=document.getElementById('mks-'+k); if(s) s.oninput=(e)=>{ r.val=parseFloat(e.target.value); renderMarket(); }; });
+}
+
+/* ================= OEE / THROUGHPUT ================= */
+function oeeColor(v){ return v>=0.85?'#63c088':(v>=0.6?'#e8c15a':'#e0685f'); }
+function oeeCalc(){
+  if(!SIM) return {A:1,P:0,Q:1,OEE:0,tph:0,total:0,good:0,bad:0,run:0,down:0,started:false};
+  const run=SIM.runSec, oper=SIM.operSec, down=SIM.downSec, total=SIM.cupsGood+SIM.cupsBad;
+  const A=run>0?oper/run:1, P=oper>0?Math.min(1,(total*SIM.idealCycle)/oper):0, Q=total>0?SIM.cupsGood/total:1;
+  return {A,P,Q,OEE:A*P*Q,tph:oper>0?SIM.cupsGood/(oper/3600):0,total,good:SIM.cupsGood,bad:SIM.cupsBad,run,down,started:run>1};
+}
+function updateTwinStrip(){
+  const s=document.getElementById('toeeVal'); if(!s) return; const m=oeeCalc(); const pc=x=>Math.round(x*100);
+  s.textContent=pc(m.OEE)+'%'; s.style.color=oeeColor(m.OEE);
+  const set=(id,v)=>{const e=document.getElementById(id); if(e){e.style.width=pc(v)+'%'; e.style.background=oeeColor(v);}};
+  set('toeeAm',m.A); set('toeePm',m.P); set('toeeQm',m.Q);
+  document.getElementById('toeeA').textContent=pc(m.A)+'%';
+  document.getElementById('toeeP').textContent=pc(m.P)+'%';
+  document.getElementById('toeeQ').textContent=pc(m.Q)+'%';
+  document.getElementById('toeeCups').textContent=m.good;
+  document.getElementById('toeeTph').textContent=m.tph.toFixed(1);
+  document.getElementById('toeeBad').textContent=m.bad+' rejected';
+}
+function ring(pct,label,val){
+  const r=64, c=2*Math.PI*r, off=c*(1-Math.max(0,Math.min(1,pct)));
+  const col=oeeColor(pct);
+  return `<svg width="180" height="180" viewBox="0 0 180 180">
+    <circle cx="90" cy="90" r="${r}" fill="none" stroke="#2a313c" stroke-width="16"/>
+    <circle cx="90" cy="90" r="${r}" fill="none" stroke="${col}" stroke-width="16" stroke-linecap="round"
+      stroke-dasharray="${c}" stroke-dashoffset="${off}" transform="rotate(-90 90 90)"/>
+    <text x="90" y="86" fill="#e6e9ee" font-size="40" font-weight="700" text-anchor="middle">${val}</text>
+    <text x="90" y="110" fill="#9aa4b2" font-size="12" text-anchor="middle" letter-spacing="1">${label}</text>
+  </svg>`;
+}
+function paretoSVG(fb){
+  const labels={WATER_LOW:['Water low','(REQ 1.3)'],BEANS_LOW:['Beans low','(REQ 1.4)'],OVERHEAT:['Overheat','(REQ 1.2)'],INTERRUPT:['Dregs out','(REQ 3.1.3)'],SHORT:['Shock','(REQ 3.1.5)']};
+  let data=Object.keys(fb).map(k=>({k,label:labels[k],n:fb[k]})).sort((a,b)=>b.n-a.n);
+  const total=data.reduce((s,d)=>s+d.n,0);
+  if(total===0) return '<div style="color:var(--muted);font-size:13px;padding:24px;text-align:center">No faults recorded yet — inject some on the Digital Twin page, then come back.</div>';
+  const W=680,H=250,pl=40,pr=48,pt=16,pb=48, iw=W-pl-pr, ih=H-pt-pb;
+  const gap=iw/data.length, bw=gap*0.55, maxN=Math.max(...data.map(d=>d.n));
+  let cum=0, bars='', pts=[];
+  data.forEach((d,i)=>{
+    const x=pl+i*gap+gap/2, bh=maxN? d.n/maxN*ih:0;
+    bars+=`<rect x="${x-bw/2}" y="${pt+ih-bh}" width="${bw}" height="${bh}" rx="3" fill="#c8873a"/>`;
+    if(d.n>0) bars+=`<text x="${x}" y="${pt+ih-bh-6}" fill="#e6e9ee" font-size="12" font-weight="700" text-anchor="middle">${d.n}</text>`;
+    d.label.forEach((ln,j)=>{ bars+=`<text x="${x}" y="${H-pb+16+j*13}" fill="#9aa4b2" font-size="10.5" text-anchor="middle">${ln}</text>`; });
+    cum+=d.n; pts.push([x, pt+ih-(cum/total)*ih, Math.round(cum/total*100)]);
+  });
+  const line=`<polyline points="${pts.map(p=>p[0]+','+p[1]).join(' ')}" fill="none" stroke="#63c088" stroke-width="2"/>`;
+  const dots=pts.map(p=>`<circle cx="${p[0]}" cy="${p[1]}" r="3.5" fill="#63c088"/><text x="${p[0]+7}" y="${p[1]-5}" fill="#8fe0aa" font-size="10" font-weight="600">${p[2]}%</text>`).join('');
+  const axis=`<line x1="${pl}" y1="${pt}" x2="${pl}" y2="${pt+ih}" stroke="#2a313c"/><line x1="${pl}" y1="${pt+ih}" x2="${W-pr}" y2="${pt+ih}" stroke="#2a313c"/>`+
+             `<text x="${pl-6}" y="${pt+6}" fill="#6b7686" font-size="9" text-anchor="end">${maxN}</text><text x="${W-pr+6}" y="${pt+6}" fill="#63c088" font-size="9">100%</text>`;
+  return `<svg viewBox="0 0 ${W} ${H}" style="width:100%;max-width:${W}px">${axis}${bars}${line}${dots}</svg>`;
+}
+function renderOEE(){
+  const v=document.getElementById('v-oee');
+  if(!SIM){ v.innerHTML='<h2>OEE / Throughput</h2><p class="attr">Open the Digital Twin first to start the simulation.</p>'; return; }
+  const run=SIM.runSec, oper=SIM.operSec, down=SIM.downSec;
+  const total=SIM.cupsGood+SIM.cupsBad;
+  const A = run>0? oper/run : 1;
+  const P = oper>0? Math.min(1,(total*SIM.idealCycle)/oper) : 0;
+  const Q = total>0? SIM.cupsGood/total : 1;
+  const OEE = A*P*Q;
+  const tph = oper>0? (SIM.cupsGood/(oper/3600)) : 0;
+  const pc=x=>Math.round(x*100);
+  const started = run>1;
+  let html=`<div style="display:flex;align-items:center;justify-content:space-between"><h2 style="margin-bottom:4px">OEE / Throughput — live from the digital twin</h2><button onclick="resetMetrics()" style="background:var(--panel2);border:1px solid var(--line);color:var(--muted);border-radius:8px;padding:7px 14px;font-size:12px;cursor:pointer">↺ Reset metrics</button></div>
+    <div style="font-size:12.5px;color:var(--muted);margin:-2px 0 14px">Overall Equipment Effectiveness = Availability × Performance × Quality, accumulated as the twin runs. Turn on <b style="color:#63c088">Auto-serve</b> on the Digital Twin page for continuous production, then inject faults to watch OEE react.</div>`;
+  if(!started){
+    html+=`<div class="card" style="text-align:center;padding:40px"><div style="font-size:15px;color:var(--muted)">No production yet. Go to <b style="color:var(--accent)">🎛 Digital Twin</b>, power on and brew a few coffees (try inducing a fault) — metrics will appear here live.</div></div>`;
+    v.innerHTML=html; return;
+  }
+  html+=`<div class="oee-top">
+    <div class="oee-ring"><div style="font-size:12px;color:var(--muted);text-transform:uppercase;letter-spacing:1px;margin-bottom:6px">Overall OEE</div>${ring(OEE,'OEE',pc(OEE)+'%')}
+      <div style="font-size:11px;color:var(--muted);margin-top:8px">${OEE>=0.85?'World-class (≥85%)':(OEE>=0.6?'Typical (60–85%)':'Below par (<60%)')}</div></div>
+    <div class="oee-comp">
+      ${[['Availability',A,'uptime ÷ scheduled','fault downtime '+Math.round(down)+'s'],
+         ['Performance',P,'actual ÷ ideal rate','ideal cycle '+SIM.idealCycle+'s/cup'],
+         ['Quality',Q,'good ÷ total cups',SIM.cupsBad+' rejected']].map(([l,val,d,d2])=>`
+        <div class="oee-card"><div class="l">${l}</div><div class="n" style="color:${oeeColor(val)}">${pc(val)}%</div>
+          <div class="oee-meter"><div style="width:${pc(val)}%;background:${oeeColor(val)}"></div></div>
+          <div class="d">${d}<br>${d2}</div></div>`).join('')}
+    </div></div>
+    <div class="oee-kpis">
+      ${[[tph.toFixed(1),'cups / hour (sim)'],[SIM.cupsGood,'good cups'],[SIM.cupsBad,'rejected cups'],[SIM.faultCount,'faults'],
+         [Math.round(run)+'s','run time'],[Math.round(down)+'s','downtime'],[total,'total brews'],[pc(A*P*Q)+'%','OEE']].slice(0,4).map(([n,l])=>`
+        <div class="oee-kpi"><div class="n">${n}</div><div class="l">${l}</div></div>`).join('')}
+    </div>
+    <div class="oee-kpis" style="margin-top:12px">
+      ${[[Math.round(run)+'s','run time'],[Math.round(down)+'s','fault downtime'],[total,'total brews'],[SIM.faultCount,'faults injected']].map(([n,l])=>`
+        <div class="oee-kpi"><div class="n">${n}</div><div class="l">${l}</div></div>`).join('')}
+    </div>
+    <div class="card" style="margin-top:14px"><div style="font-size:13px;color:var(--muted);margin-bottom:4px"><b style="color:var(--txt)">Fault Pareto</b> — downtime causes ranked by frequency, with cumulative % (green). Classic "vital few": tackle the leftmost bars first for the biggest availability gain.</div>${paretoSVG(SIM.faultsByType)}</div>
+    <div class="oee-note">Availability drops when the STM enters a <b style="color:#e0685f">Fault</b> state (empty tank, low beans, overheat, interruption); Quality drops when a fault spoils an in-progress brew; Performance reflects throughput vs the ideal ${SIM.idealCycle}s cycle. This closes the loop from the SysML behaviour model to operational KPIs.</div>`;
+  v.innerHTML=html;
+}
+
+/* ================= ONTOLOGY (an example, half in jest) ================= */
+function renderOntology(){
+  const v=document.getElementById('v-onto');
+  const nm={}; (MODEL.graph.nodes||[]).forEach(n=>nm[n.id]=n.name);
+  const pred={part:'hasPart',reference:'references',transition:'transitionsTo',association:'associatedWith',generalization:'isA',include:'includes',subject:'appliesTo',
+              behavior:'performsBehaviour',triggers:'triggers',effect:'onExitPerforms',uses:'usesSignal',contains:'contains',
+              dependency:'dependsOn','Satisfy':'satisfies','Refine':'refines'};
+  // pull a few real triples from the model
+  const modelTriples=[]; const seen=new Set();
+  (MODEL.graph.edges||[]).forEach(e=>{
+    let p=pred[e.kind]||e.kind; if(e.kind==='dependency'){ p = /satisf/i.test(e.label)?'satisfies':(/refin/i.test(e.label)?'refines':'dependsOn'); }
+    const s=nm[e.source], o=nm[e.target]; if(!s||!o) return;
+    const key=s+p+o; if(seen.has(key)) return; seen.add(key);
+    if(['hasPart','satisfies','refines','transitionsTo','associatedWith'].includes(p)) modelTriples.push([s,p,o]);
+  });
+  const pick=(p,n)=>modelTriples.filter(t=>t[1]===p).slice(0,n);
+  const shown=[...pick('hasPart',3),...pick('transitionsTo',2),...pick('satisfies',2),...pick('associatedWith',2)];
+  // curated domain triples the ontology adds ON TOP of the SysML model (class-level knowledge + axioms)
+  const domain=[["Espresso","subClassOf","Coffee"],["Coffee","subClassOf","Beverage"],
+    ["Boiler","heats","Water"],["CoffeeMachine","produces","Beverage"],
+    ["Barista","operates","CoffeeMachine"],["Brewing","requires","HotWater"]];
+  const row=(t,src)=>`<tr><td class="s">${t[0]}</td><td class="p">${t[1]}</td><td class="o">${t[2]}</td><td class="src">${src}</td></tr>`;
+  v.innerHTML=`<h2>Ontology — a worked example (settle the debate) ☕</h2>
+   <div class="on-def">
+     <div class="big">An <b>ontology</b> is a shared, formal vocabulary: the <b>classes</b> (kinds of things), the <b>individuals</b> (specific things), the <b>relationships</b> between them, and <b>axioms/rules</b> — written so a <i>machine</i> can reason over them, not just store them.</div>
+     <div class="joke">It is <b>not</b> a diagram, <b>not</b> a database schema, and <b>not</b> "just a fancy taxonomy" — though someone on the team will die on that hill. The test: can it <b>infer a fact nobody typed in?</b> A taxonomy can't. An ontology can (see the green box).</div>
+   </div>
+   <div class="on-cols">
+     <div class="on-col"><h3 style="color:#e8c15a">Classes</h3><div class="sub">concepts / types — "T-Box"</div>
+       ${['CoffeeMachine','Subsystem','Boiler','WaterTank','Beverage','Coffee','Requirement','State','Activity','Signal','Actor'].map(c=>`<span class="on-chip on-class">${c}</span>`).join('')}</div>
+     <div class="on-col"><h3 style="color:#7fd0e0">Individuals</h3><div class="sub">instances — "A-Box"</div>
+       ${['MEMKO-Barista-001','Boiler-B1','Espresso','Long-Black','Alice (Coffee Consumer)','Sam (Maintenance Op)','WaterTank-WT1'].map(c=>`<span class="on-chip on-ind">${c}</span>`).join('')}</div>
+     <div class="on-col"><h3 style="color:#c89bd6">Relationships</h3><div class="sub">object properties + axioms</div>
+       ${['hasPart','heats','produces','satisfies','triggers','isInState','requires','operates','subClassOf'].map(c=>`<span class="on-chip on-rel">${c}</span>`).join('')}</div>
+   </div>
+   <div class="card"><div style="font-size:13px;color:var(--muted);margin-bottom:8px">Knowledge as <b style="color:var(--txt)">triples</b> — subject → predicate → object. The blue ones are read straight from your SysML model; the amber ones are class-level knowledge an ontology layers on top.</div>
+     <table class="on"><tr><th>Subject</th><th>Predicate</th><th>Object</th><th>Source</th></tr>
+       ${shown.map(t=>row(t,'● model')).join('')}
+       ${domain.map(t=>row(t,'○ ontology')).join('')}
+     </table></div>
+   <div class="on-infer"><b>Why it matters (the punchline):</b> the ontology knows <span class="p" style="color:#8fe0aa">Espresso subClassOf Coffee</span>, <span class="p" style="color:#8fe0aa">Coffee subClassOf Beverage</span>, and <span class="p" style="color:#8fe0aa">CoffeeMachine produces Beverage</span>. From those axioms a reasoner <b>infers a brand-new fact nobody stated</b>: <b>“MEMKO-Barista-001 can produce an Espresso.”</b> A taxonomy just filed Espresso under Coffee; a database schema stored a row. Neither can derive that. That inference — not the boxes-and-lines — is what makes it an ontology.</div>
+   <div class="on-vs">
+     <div class="c"><h4>Taxonomy</h4><p>Pure is-a hierarchy. Classifies (Coffee → Espresso). No typed relations, no reasoning.</p></div>
+     <div class="c"><h4>DB Schema</h4><p>Tables & constraints for storage. Knows columns, not meaning. Can't infer.</p></div>
+     <div class="c"><h4>Folksonomy</h4><p>Free tags (#coffee #morning). Social, flexible, informal — zero logic.</p></div>
+     <div class="c"><h4>Ontology</h4><p>Classes + individuals + typed relations + <b style="color:var(--accent)">axioms</b> → a machine can <b style="color:var(--accent)">reason & infer</b>.</p></div>
+   </div>
+   <div class="oee-note">Everything above is generated from the same coffee-machine model — the SysML model gives structure &amp; behaviour; the ontology view reframes it as a reasonable knowledge graph. (And yes, you can now win the argument at standup.)</div>`;
+}
+
+/* ---------- NAV ---------- */
+document.querySelector('nav').addEventListener('click',e=>{const b=e.target.closest('button[data-v]');if(!b)return;
+  document.querySelectorAll('nav button').forEach(x=>x.classList.remove('active'));b.classList.add('active');
+  document.querySelectorAll('.view').forEach(x=>x.classList.remove('active'));
+  document.getElementById('v-'+b.dataset.v).classList.add('active');
+  if(b.dataset.v==='graph'&&network)setTimeout(()=>network.fit(),50);
+  if(b.dataset.v==='twin'){ ensureTwin(); twinLoop(); }
+  if(b.dataset.v==='market'){ renderMarket(); }
+  if(b.dataset.v==='oee'){ ensureTwin(); twinLoop(); renderOEE(); }
+  if(b.dataset.v==='onto'){ renderOntology(); }});
+
+boot();
+</script>
+</body>
+</html>
