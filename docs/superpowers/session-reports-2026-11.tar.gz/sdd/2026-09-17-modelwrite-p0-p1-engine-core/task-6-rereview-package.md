﻿# Task 6 re-review package (gate robustness fix)

## Commit

9a07af0 fix: fail a graph-less candidate cleanly and reject flags without values

## Diff stat

 engine/gate/src/lib.rs    | 97 ++++++++++++++++++++++++++++++++---------------
 engine/gate/src/main.rs   | 24 ++++++++++--
 engine/gate/tests/gate.rs | 20 ++++++++++
 3 files changed, 108 insertions(+), 33 deletions(-)

## Full diff (-U10)

diff --git a/engine/gate/src/lib.rs b/engine/gate/src/lib.rs
index b22514b..9ca6d1a 100644
--- a/engine/gate/src/lib.rs
+++ b/engine/gate/src/lib.rs
@@ -27,68 +27,105 @@ pub fn run(reference: &OkfRoot, candidate: &OkfRoot, strict_coverage: bool) -> G
         ));
     }
 
     let v = validate::validate(candidate);
     if !v.valid {
         for e in &v.errors {
             failures.push(format!("validation: {}", e));
         }
     }
 
-    let stats = graph_stats(candidate);
-    if !stats.isolated.is_empty() {
-        failures.push(format!(
-            "integration: {} isolated nodes",
-            stats.isolated.len()
-        ));
-    }
-    if stats.component_count != 1 {
-        failures.push(format!(
-            "integration: {} connected components",
-            stats.component_count
-        ));
+    // A candidate can lose its graph section entirely. Validation already records that
+    // as an error, so the gate must report a failure rather than panic inside the graph
+    // helpers, which require a graph to exist. Exit code 1 is the contract for a lossy
+    // candidate; a crash would be neither a pass nor a failure.
+    let stats = if candidate.graph.is_some() {
+        Some(graph_stats(candidate))
+    } else {
+        failures.push("integration: candidate has no graph section".to_string());
+        None
+    };
+    if let Some(stats) = &stats {
+        if !stats.isolated.is_empty() {
+            failures.push(format!(
+                "integration: {} isolated nodes",
+                stats.isolated.len()
+            ));
+        }
+        if stats.component_count != 1 {
+            failures.push(format!(
+                "integration: {} connected components",
+                stats.component_count
+            ));
+        }
     }
 
-    let cov = requirement_coverage(candidate);
-    if strict_coverage && !cov.uncovered.is_empty() {
-        failures.push(format!(
-            "coverage: {} uncovered requirements",
-            cov.uncovered.len()
-        ));
+    let cov = if candidate.graph.is_some() {
+        Some(requirement_coverage(candidate))
+    } else {
+        None
+    };
+    if let Some(cov) = &cov {
+        if strict_coverage && !cov.uncovered.is_empty() {
+            failures.push(format!(
+                "coverage: {} uncovered requirements",
+                cov.uncovered.len()
+            ));
+        }
     }
 
     let evidence = json!({
         "gateVersion": env!("CARGO_PKG_VERSION"),
         "okfVersion": "1.0",
         "referenceHash": hash::canonical_hash(reference),
         "candidateHash": hash::canonical_hash(candidate),
         "roundtrip": {
             "equal": d.equal,
             "missingElements": d.missing_elements,
             "extraElements": d.extra_elements,
             "missingEdges": d.missing_edges,
             "extraEdges": d.extra_edges,
             "changedAttributes": d.changed_attributes
         },
-        "integration": {
-            "isolated": stats.isolated,
-            "componentCount": stats.component_count,
-            "componentSizes": stats.component_sizes
+        // The schema stays stable when the candidate has no graph: the keys are always
+        // present, with empty values, so a consumer never has to handle a missing object.
+        "integration": match &stats {
+            Some(s) => json!({
+                "isolated": s.isolated,
+                "componentCount": s.component_count,
+                "componentSizes": s.component_sizes
+            }),
+            None => json!({
+                "isolated": [],
+                "componentCount": 0,
+                "componentSizes": []
+            })
         },
-        "coverage": {
-            "total": cov.total,
-            "satisfied": cov.satisfied,
-            "refined": cov.refined,
-            "verified": cov.verified,
-            "allocated": cov.allocated,
-            "covered": cov.covered,
-            "uncovered": cov.uncovered
+        "coverage": match &cov {
+            Some(c) => json!({
+                "total": c.total,
+                "satisfied": c.satisfied,
+                "refined": c.refined,
+                "verified": c.verified,
+                "allocated": c.allocated,
+                "covered": c.covered,
+                "uncovered": c.uncovered
+            }),
+            None => json!({
+                "total": 0,
+                "satisfied": 0,
+                "refined": 0,
+                "verified": 0,
+                "allocated": 0,
+                "covered": 0,
+                "uncovered": []
+            })
         },
         "strictCoverage": strict_coverage,
         "validationErrors": v.errors,
         "validationWarnings": v.warnings,
         "passed": failures.is_empty(),
         "failures": failures
     });
 
     GateOutcome {
         passed: failures.is_empty(),
diff --git a/engine/gate/src/main.rs b/engine/gate/src/main.rs
index fa055de..78aa8fa 100644
--- a/engine/gate/src/main.rs
+++ b/engine/gate/src/main.rs
@@ -6,23 +6,41 @@ use okf::types::OkfRoot;
 
 fn main() -> ExitCode {
     let mut reference: Option<PathBuf> = None;
     let mut candidate: Option<PathBuf> = None;
     let mut evidence: Option<PathBuf> = None;
     let mut json_output = false;
     let mut strict_coverage = false;
     let mut args = std::env::args().skip(1);
     while let Some(a) = args.next() {
         match a.as_str() {
-            "--reference" => reference = args.next().map(PathBuf::from),
-            "--candidate" => candidate = args.next().map(PathBuf::from),
-            "--evidence" => evidence = args.next().map(PathBuf::from),
+            "--reference" => match args.next() {
+                Some(v) => reference = Some(PathBuf::from(v)),
+                None => {
+                    eprintln!("--reference requires a file path");
+                    return ExitCode::from(2);
+                }
+            },
+            "--candidate" => match args.next() {
+                Some(v) => candidate = Some(PathBuf::from(v)),
+                None => {
+                    eprintln!("--candidate requires a file path");
+                    return ExitCode::from(2);
+                }
+            },
+            "--evidence" => match args.next() {
+                Some(v) => evidence = Some(PathBuf::from(v)),
+                None => {
+                    eprintln!("--evidence requires a file path");
+                    return ExitCode::from(2);
+                }
+            },
             "--json" => json_output = true,
             "--strict-coverage" => strict_coverage = true,
             _ => {
                 eprintln!("unknown argument: {}", a);
                 return ExitCode::from(2);
             }
         }
     }
     let (Some(reference), Some(candidate)) = (reference, candidate) else {
         eprintln!("usage: mw-gate --reference FILE --candidate FILE [--evidence FILE] [--json] [--strict-coverage]");
diff --git a/engine/gate/tests/gate.rs b/engine/gate/tests/gate.rs
index 307d9fa..5bd210a 100644
--- a/engine/gate/tests/gate.rs
+++ b/engine/gate/tests/gate.rs
@@ -70,10 +70,30 @@ fn strict_coverage_fails_on_uncovered() {
         "unexpected failures: {:?}",
         lenient.failures
     );
     let strict = gate::run(&r, &r, true);
     assert!(!strict.passed);
     assert!(strict
         .failures
         .iter()
         .any(|f| f.contains("uncovered requirements")));
 }
+#[test]
+fn candidate_without_a_graph_fails_instead_of_panicking() {
+    // A lossy candidate can lose its graph section outright. The gate must report a
+    // failure with exit-code-1 semantics, never panic inside the graph helpers.
+    let reference = expected();
+    let candidate = okf(r#"{
+  "project": "no graph",
+  "exportedAt": "2026-09-17T00:00:00Z",
+  "summary": {},
+  "stateMachine": {"name": "sm", "regions": []},
+  "graph": null
+}"#);
+    let outcome = gate::run(&reference, &candidate, false);
+    assert!(!outcome.passed);
+    assert!(outcome
+        .failures
+        .iter()
+        .any(|f| f.contains("no graph section")));
+    assert_eq!(outcome.evidence["integration"]["componentCount"], 0);
+}
