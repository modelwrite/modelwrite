# Task 4 Report: engine/okf — types, validation, hashing, diffing

## Status

BLOCKED

## Commits

None. I stopped before committing (Step 14) because the gate in Step 12 /
job step 3 requires reporting BLOCKED when the corpus fixture and the
implementation disagree.

## One-line test summary

11 tests: 0 passed, 11 failed — every test fails parsing the corpus fixture
before reaching any assertion, with one identical serde error.

## The blocker (exact error)

All 11 tests fail inside their shared `expected()` helper with:

```
corpus fixture parses: Error("invalid type: map, expected a string", line: 1, column: 22451)
```

Root cause: the brief types `Activity.partitions` as `Vec<String>`, but the
verified fixture stores partitions as an array of objects:

```json
"partitions": [
  { "name": "control Subsystem", "represents": null },
  { "name": "water Subsystem",   "represents": null },
  { "name": "brew Subsystem",    "represents": null },
  { "name": "dispensing Subsystem", "represents": null },
  { "name": "water Tank",  "represents": "water Tank" },
  { "name": "flow Meter",  "represents": "flow Meter" },
  { "name": "water Pump",  "represents": "water Pump" },
  { "name": "boiler",      "represents": "boiler" }
]
```

Two of the eight activities ("Brew Coffee", "Heat Water") have object
partitions; the other six have empty `partitions: []`. Each partition object
has exactly two keys: `name` (string) and `represents` (string or null).

I verified this is the ONLY mismatch between the brief's types and the
fixture. I exhaustively scanned structure / interfaces / signals /
requirements (including `attributes[].default`), graph nodes and edges,
stateMachine states (`entry`/`doActivity`/`exit`), and activity nodes and
edges — every other field matches the brief's `String` / `Option<String>` /
`u64` / `Vec<String>` types. Only `Activity.partitions` disagrees.

The brief defines no type for these partition objects (there is no
`Partition` struct in the brief). Fixing it requires introducing a new
struct and changing `Activity.partitions`' type, which the task forbids
("Use its content verbatim; do not improvise structure or names"). This needs
a controller ruling on the correct type. A likely shape, based solely on the
fixture, would be:

```rust
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct Partition {
    pub name: String,
    #[serde(default)]
    pub represents: Option<String>,
}
// Activity.partitions: Vec<Partition>
```

(I did not implement this — offered only to speed the controller's ruling.)

## Deviation from the brief (required to compile)

`engine/okf/src/types.rs`: added `Default` to `Summary`'s derive
(`#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Default)]`).
The brief's `#[serde(default)]` on `OkfRoot.summary: Summary` requires
`Summary: Default`; without it the crate does not compile (E0277, the
compiler's own suggestion is to derive `Default` on `Summary`). This
changes no field, structure, or name — it only satisfies the trait the
brief's own serde attribute demands.

## Exact commands and results

1. `cargo test -p mw-okf`
   → compile error E0277: `the trait bound Summary: Default is not satisfied`
     (twice, lib and lib-test). Fixed by the `Default` deviation above.

2. `cargo test -p mw-okf --no-fail-fast`
   → compiles cleanly; then 0 lib tests, 4/4 okf_diff tests FAIL, and
     7/7 okf_validation tests FAIL, all with
     `Error("invalid type: map, expected a string", line: 1, column: 22451)`.

   ```
   test result: okf_diff:        FAILED. 0 passed; 4 failed
   test result: okf_validation:  FAILED. 0 passed; 7 failed
   ```

3. `cargo fmt --all` and `cargo clippy -p mw-okf --all-targets -- -D warnings`
   → not run: blocked before reaching Step 13.

## Files created (all present, uncommitted)

- `Cargo.toml` (workspace root)
- `engine/test-support/Cargo.toml`
- `engine/test-support/src/lib.rs`
- `engine/okf/Cargo.toml`
- `engine/okf/src/lib.rs`
- `engine/okf/src/types.rs` (with the `Default` deviation)
- `engine/okf/src/validate.rs`
- `engine/okf/src/hash.rs`
- `engine/okf/src/diff.rs`
- `engine/okf/tests/okf_validation.rs`
- `engine/okf/tests/okf_diff.rs`

Every source file carries the `// SPDX-License-Identifier: AGPL-3.0-or-later`
header. The corpus fixture was not modified.

---

## Fix round 2 (diff section-scoping) — applied; a validation blocker remains

### Applied this round

- `engine/okf/src/types.rs`: added the `Partition` struct and changed
  `Activity.partitions` to `Vec<Partition>` (round-1 ruling).
- `engine/okf/src/diff.rs`: rewrote `attribute_keys` to key each entry as
  `"<section>:<id>"` (sections: structure, interfaces, signals, requirements,
  state, graphnode) and rewrote `diff` to derive missing/extra/changed from the
  attribute-key sets. `element_ids` and `edge_keys` are unchanged.

### Test result after this round

`cargo test -p mw-okf --no-fail-fast`

```
running 4 tests  -> okf_diff:       ok. 4 passed; 0 failed
running 7 tests  -> okf_validation: FAILED. 6 passed; 1 failed
```

10 of 11 tests pass. The two diff tests the round-2 ruling targeted now pass.

### Remaining blocker — corpus_fixture_validates (exact errors)

```
unexpected errors: [
  "stateMachine section is missing",
  "dangling edge endpoint _2026x_1_12a70364_1789524431087_459748_5711 (source of a dependency edge)",
  "dangling edge endpoint _2026x_1_12a70364_1789524431091_435540_5713 (source of a dependency edge)"
]
```

Two independent root causes, both outside the diff layer (types/validator vs.
fixture). The round-2 ruling did not cover these.

1. **`state_machine` field is missing its rename.** The brief types
   `OkfRoot.state_machine` as `#[serde(default)]` with no
   `#[serde(rename = "stateMachine")]`, but the fixture's top-level key is
   `"stateMachine"` (camelCase). serde therefore treats the field as absent and
   deserializes `state_machine = None`, which the validator reports as
   "stateMachine section is missing". Every other camelCase key in the same
   struct carries an explicit rename (`exportedAt`, `graphNodes`,
   `graphEdges`, `reqId`, `reqText`, `doActivity`), so this is almost
   certainly an omission. Likely fix:
   `#[serde(rename = "stateMachine", default)] pub state_machine: Option<StateMachine>`.

2. **Two genuinely dangling "Satisfy" traceability edges in the fixture.** The
   graph has 29 `dependency` edges. Two of them (label "Satisfy") have a
   `source` id that appears nowhere in the document — not in graph nodes,
   structure, signals, requirements, states, or activity nodes:
   - source `_2026x_1_12a70364_1789524431087_459748_5711` → target (requirement "Heater Initialization")
   - source `_2026x_1_12a70364_1789524431091_435540_5713` → target (same requirement)
   The brief's validator flags them as "dangling edge endpoint". The Task-2
   traceability ruling says the labels (Satisfy/Refine/Verify/Allocate) are
   prose-only and must not be validated, but the brief's dangling-endpoint
   check applies to every edge regardless of label, and these two sources are
   absent from every section — so this is a fixture/validator disagreement that
   needs a controller ruling.

### Not done

- Did not commit (blocked before the round-2 Step 3; the suite is not green).
- Did not run `cargo fmt --all` / `cargo clippy` (blocked before Step 2).

Note: the controller's round-2 message reported "okf_validation 7 passed / 0
failed"; that is not what the suite shows. `cargo test -p mw-okf` (without
`--no-fail-fast`) stops at the first failing test binary (okf_diff), so
okf_validation never ran in that invocation. With `--no-fail-fast`,
corpus_fixture_validates fails as above.

---

## Rulings A & B applied — one test still fails (rejects_dangling_edge_endpoint)

### Applied this round

- RULING A: `engine/okf/src/types.rs` — added `#[serde(rename = "stateMachine", default)]` to `OkfRoot.state_machine`.
- RULING B: `engine/okf/src/validate.rs` — changed the two unresolved-endpoint pushes from `report.errors.push` to `report.warnings.push`, with the explanatory comment; strengthened `corpus_fixture_validates` to assert exactly 2 "dangling edge endpoint" warnings.

### Result

`cargo test -p mw-okf` → 10 passed / 1 failed:
- okf_diff: 4 passed / 0 failed
- okf_validation: 6 passed / 1 failed — `corpus_fixture_validates` now passes, but `rejects_dangling_edge_endpoint` fails.

### Exact remaining failure

```
rejects_dangling_edge_endpoint: assertion failed: !report.valid
  (engine\okf\tests\okf_validation.rs:61:5)
```

Root cause: RULING B made unresolved edge endpoints warnings, but the brief's
`rejects_dangling_edge_endpoint` test was NOT updated and still asserts the
old error behaviour (`assert!(!report.valid)` and `report.errors` contains
"missing-node"). The synthetic "missing-node" edge it injects now yields a
warning, not an error, so `report.valid` is true and the assertion fails.

This test now contradicts RULING B and needs a ruling to align it, e.g.:

```rust
#[test]
fn warns_dangling_edge_endpoint() {
    let mut root = expected();
    if let Some(graph) = root.graph.as_mut() {
        let target = graph.nodes[0].id.clone();
        graph.edges.push(okf::types::GraphEdge {
            source: "missing-node".into(),
            target,
            kind: "part".into(),
            label: String::new(),
        });
    }
    let report = validate::validate(&root);
    assert!(report.valid);
    assert!(report.warnings.iter().any(|w| w.contains("missing-node")));
}
```

I did not edit the assertion, per the instruction to report rather than edit.

### Not done

- Did not commit (suite not green).
- Did not run `cargo fmt --all` / `cargo clippy` (gated on tests passing).

---

## RULING C applied — task complete

### Applied

- RULING C: `engine/okf/tests/okf_validation.rs` — renamed `rejects_dangling_edge_endpoint` to `warns_dangling_edge_endpoint` and re-asserted it for the new severity (document stays valid; the dangling endpoint surfaces as a warning containing "missing-node").

### Final result

`cargo test -p mw-okf` → all 11 pass:
- okf_diff: 4 passed / 0 failed
- okf_validation: 7 passed / 0 failed

`cargo fmt --all` → clean (exit 0, no output).

`cargo clippy -p mw-okf --all-targets -- -D warnings` → clean (exit 0, no warnings).

Toolchain note: rustfmt/clippy were already installed (`rustup component add rustfmt clippy` reported both "up to date"); `cargo fmt --version` → rustfmt 1.9.0-stable; `cargo clippy --version` → clippy 0.1.98.

### Committed

`588a78d feat: add okf crate with types, validation, hashing and diffing` (12 files changed, 993 insertions).

### Corpus finding (note for the corpus README)

The reference export `sample/corpus/coffee-machine/okf/expected/coffee_machine_model.json` carries exactly two `dependency` edges labelled "Satisfy" whose `source` id appears nowhere else in the document (not as a graph node, nor in structure/signals/requirements/states). Per RULING B these unresolved endpoints are warnings, and `corpus_fixture_validates` pins the count at exactly 2 so the finding cannot silently change.

### Summary of rulings A / B / C

- A: `OkfRoot.state_machine` carries `#[serde(rename = "stateMachine", default)]`.
- B: unresolved edge endpoints are warnings, not errors; `corpus_fixture_validates` asserts exactly 2 "dangling edge endpoint" warnings.
- C: `warns_dangling_edge_endpoint` asserts the new warning severity.



