﻿# Task 6 review package

## Commits

38022ae feat: add round-trip fidelity gate with evidence records

## Diff stat

 Cargo.lock                                         |   17 +
 Cargo.toml                                         |    2 +-
 .../2026-09-17-roundtrip-corrupted-fail.json       |   67 +
 docs/evidence/2026-09-17-roundtrip-self-pass.json  |   50 +
 docs/evidence/README.md                            |   18 +
 engine/gate/Cargo.toml                             |   23 +
 engine/gate/src/lib.rs                             |  104 +
 engine/gate/src/main.rs                            |   67 +
 engine/gate/tests/gate.rs                          |   79 +
 .../okf/corrupted/coffee_machine_model.json        | 3485 ++++++++++++++++++++
 sample/scripts/make_corrupted.py                   |   32 +
 11 files changed, 3943 insertions(+), 1 deletion(-)

## New files (full content)

diff --git a/Cargo.toml b/Cargo.toml
index de0841a..ab1bc4a 100644
--- a/Cargo.toml
+++ b/Cargo.toml
@@ -1,13 +1,13 @@
 [workspace]
 resolver = "2"
-members = ["engine/okf", "engine/test-support", "engine/graph"]
+members = ["engine/okf", "engine/test-support", "engine/graph", "engine/gate"]
 
 [workspace.package]
 edition = "2021"
 rust-version = "1.75"
 license = "AGPL-3.0-or-later"
 repository = "https://github.com/modelwrite/modelwrite"
 
 [workspace.dependencies]
 anyhow = "1.0"
 hex = "0.4"
diff --git a/docs/evidence/2026-09-17-roundtrip-corrupted-fail.json b/docs/evidence/2026-09-17-roundtrip-corrupted-fail.json
new file mode 100644
index 0000000..61a6f02
--- /dev/null
+++ b/docs/evidence/2026-09-17-roundtrip-corrupted-fail.json
@@ -0,0 +1,67 @@
+{
+  "candidateHash": "da7c11b664ec5f4da32e16414be3b4eccc0d5a9e719b98dc838541aaf640bdba",
+  "coverage": {
+    "allocated": 0,
+    "covered": 13,
+    "refined": 2,
+    "satisfied": 15,
+    "total": 24,
+    "uncovered": [
+      "_2026x_1_12a70364_1789522470201_737876_5617",
+      "_2026x_1_12a70364_1789522470246_238622_5652",
+      "_2026x_1_12a70364_1789522470268_212057_5663",
+      "_2026x_1_12a70364_1789522470269_5755_5665",
+      "_2026x_1_12a70364_1789522470270_589609_5667",
+      "_2026x_1_12a70364_1789522470271_475286_5670",
+      "_2026x_1_12a70364_1789522470272_63721_5673",
+      "_2026x_1_12a70364_1789522470273_392927_5676",
+      "_2026x_1_12a70364_1789522470274_644308_5679",
+      "_2026x_1_12a70364_1789522470275_767711_5681",
+      "_2026x_1_12a70364_1789602694801_483599_6108"
+    ],
+    "verified": 0
+  },
+  "failures": [
+    "roundtrip: 1 missing elements, 0 extra elements, 3 missing edges, 0 extra edges, 0 changed attributes",
+    "integration: 1 isolated nodes",
+    "integration: 3 connected components"
+  ],
+  "gateVersion": "0.1.0",
+  "integration": {
+    "componentCount": 3,
+    "componentSizes": [
+      90,
+      8,
+      1
+    ],
+    "isolated": [
+      "_2026x_1_12a70364_1789602694801_483599_6108"
+    ]
+  },
+  "okfVersion": "1.0",
+  "passed": false,
+  "referenceHash": "968ac0f83b68d9154053222fd687666914b2b84a3732036aef27b3cd6f914b69",
+  "roundtrip": {
+    "changedAttributes": [],
+    "equal": false,
+    "extraEdges": [],
+    "extraElements": [],
+    "missingEdges": [
+      "[\"_2026x_1_12a70364_1789363176200_671776_3716\",\"_2026x_1_12a70364_1789602694801_483599_6108\",\"dependency\",\"Satisfy\"]",
+      "[\"_2026x_1_12a70364_1789363334952_109655_3731\",\"_2026x_1_12a70364_1789602694801_483599_6108\",\"dependency\",\"Satisfy\"]",
+      "[\"_2026x_1_12a70364_1789522470269_5755_5665\",\"_2026x_1_12a70364_1789602694801_483599_6108\",\"contains\",\"\"]"
+    ],
+    "missingElements": [
+      "requirements:_2026x_1_12a70364_1789522470210_613186_5619"
+    ]
+  },
+  "strictCoverage": false,
+  "validationErrors": [],
+  "validationWarnings": [
+    "legacy OKF without version marker; exporters should emit okf 1.0",
+    "dangling edge endpoint _2026x_1_12a70364_1789524431087_459748_5711 (source of a dependency edge)",
+    "dangling edge endpoint _2026x_1_12a70364_1789524431091_435540_5713 (source of a dependency edge)",
+    "summary graph counts (99/165) do not match graph section (99/162)",
+    "summary requirements 25 do not match requirements length 24"
+  ]
+}
\ No newline at end of file
diff --git a/docs/evidence/2026-09-17-roundtrip-self-pass.json b/docs/evidence/2026-09-17-roundtrip-self-pass.json
new file mode 100644
index 0000000..3cd560a
--- /dev/null
+++ b/docs/evidence/2026-09-17-roundtrip-self-pass.json
@@ -0,0 +1,50 @@
+{
+  "candidateHash": "968ac0f83b68d9154053222fd687666914b2b84a3732036aef27b3cd6f914b69",
+  "coverage": {
+    "allocated": 0,
+    "covered": 15,
+    "refined": 3,
+    "satisfied": 20,
+    "total": 25,
+    "uncovered": [
+      "_2026x_1_12a70364_1789522470201_737876_5617",
+      "_2026x_1_12a70364_1789522470246_238622_5652",
+      "_2026x_1_12a70364_1789522470268_212057_5663",
+      "_2026x_1_12a70364_1789522470269_5755_5665",
+      "_2026x_1_12a70364_1789522470270_589609_5667",
+      "_2026x_1_12a70364_1789522470271_475286_5670",
+      "_2026x_1_12a70364_1789522470272_63721_5673",
+      "_2026x_1_12a70364_1789522470273_392927_5676",
+      "_2026x_1_12a70364_1789522470274_644308_5679",
+      "_2026x_1_12a70364_1789522470275_767711_5681"
+    ],
+    "verified": 1
+  },
+  "failures": [],
+  "gateVersion": "0.1.0",
+  "integration": {
+    "componentCount": 1,
+    "componentSizes": [
+      99
+    ],
+    "isolated": []
+  },
+  "okfVersion": "1.0",
+  "passed": true,
+  "referenceHash": "968ac0f83b68d9154053222fd687666914b2b84a3732036aef27b3cd6f914b69",
+  "roundtrip": {
+    "changedAttributes": [],
+    "equal": true,
+    "extraEdges": [],
+    "extraElements": [],
+    "missingEdges": [],
+    "missingElements": []
+  },
+  "strictCoverage": false,
+  "validationErrors": [],
+  "validationWarnings": [
+    "legacy OKF without version marker; exporters should emit okf 1.0",
+    "dangling edge endpoint _2026x_1_12a70364_1789524431087_459748_5711 (source of a dependency edge)",
+    "dangling edge endpoint _2026x_1_12a70364_1789524431091_435540_5713 (source of a dependency edge)"
+  ]
+}
\ No newline at end of file
diff --git a/docs/evidence/README.md b/docs/evidence/README.md
new file mode 100644
index 0000000..d553621
--- /dev/null
+++ b/docs/evidence/README.md
@@ -0,0 +1,18 @@
+# Evidence annex
+
+Every public claim about modelwrite traces to a recorded gate run in this
+directory. Records are append-only: never rewrite an existing record.
+
+Naming: YYYY-MM-DD-<subject>.json
+
+Each record is the deterministic output of mw-gate --evidence: given the
+same reference and candidate, the record reproduces exactly (hashes and
+all). Dates appear only in filenames, never inside records.
+
+Index:
+
+- 2026-09-17-roundtrip-self-pass.json — the corpus compared with itself:
+  the gate passes. Proves the reference OKF is a fixed point of the gate.
+- 2026-09-17-roundtrip-corrupted-fail.json — the corpus compared with the
+  corrupted fixture: the gate fails on missing elements and isolated
+  nodes. Proves the gate detects loss and fragmentation.
diff --git a/engine/gate/Cargo.toml b/engine/gate/Cargo.toml
new file mode 100644
index 0000000..de494c5
--- /dev/null
+++ b/engine/gate/Cargo.toml
@@ -0,0 +1,23 @@
+[package]
+name = "mw-gate"
+version = "0.1.0"
+edition.workspace = true
+rust-version.workspace = true
+license.workspace = true
+publish = false
+
+[lib]
+name = "gate"
+
+[[bin]]
+name = "mw-gate"
+path = "src/main.rs"
+
+[dependencies]
+mw-okf = { path = "../okf" }
+mw-graph = { path = "../graph" }
+anyhow.workspace = true
+serde_json.workspace = true
+
+[dev-dependencies]
+mw-test-support = { path = "../test-support" }
diff --git a/engine/gate/src/lib.rs b/engine/gate/src/lib.rs
new file mode 100644
index 0000000..b22514b
--- /dev/null
+++ b/engine/gate/src/lib.rs
@@ -0,0 +1,104 @@
+// SPDX-License-Identifier: AGPL-3.0-or-later
+use graph::{graph_stats, requirement_coverage};
+use okf::{diff, hash, types::OkfRoot, validate};
+use serde_json::json;
+
+pub struct GateOutcome {
+    pub passed: bool,
+    pub failures: Vec<String>,
+    pub evidence: serde_json::Value,
+}
+
+/// The provable gate: round-trip fidelity plus graph health, with evidence
+/// recorded for every run. The evidence is deterministic: given the same
+/// inputs, the record reproduces exactly.
+pub fn run(reference: &OkfRoot, candidate: &OkfRoot, strict_coverage: bool) -> GateOutcome {
+    let mut failures: Vec<String> = Vec::new();
+
+    let d = diff::diff(reference, candidate);
+    if !d.equal {
+        failures.push(format!(
+            "roundtrip: {} missing elements, {} extra elements, {} missing edges, {} extra edges, {} changed attributes",
+            d.missing_elements.len(),
+            d.extra_elements.len(),
+            d.missing_edges.len(),
+            d.extra_edges.len(),
+            d.changed_attributes.len()
+        ));
+    }
+
+    let v = validate::validate(candidate);
+    if !v.valid {
+        for e in &v.errors {
+            failures.push(format!("validation: {}", e));
+        }
+    }
+
+    let stats = graph_stats(candidate);
+    if !stats.isolated.is_empty() {
+        failures.push(format!(
+            "integration: {} isolated nodes",
+            stats.isolated.len()
+        ));
+    }
+    if stats.component_count != 1 {
+        failures.push(format!(
+            "integration: {} connected components",
+            stats.component_count
+        ));
+    }
+
+    let cov = requirement_coverage(candidate);
+    if strict_coverage && !cov.uncovered.is_empty() {
+        failures.push(format!(
+            "coverage: {} uncovered requirements",
+            cov.uncovered.len()
+        ));
+    }
+
+    let evidence = json!({
+        "gateVersion": env!("CARGO_PKG_VERSION"),
+        "okfVersion": "1.0",
+        "referenceHash": hash::canonical_hash(reference),
+        "candidateHash": hash::canonical_hash(candidate),
+        "roundtrip": {
+            "equal": d.equal,
+            "missingElements": d.missing_elements,
+            "extraElements": d.extra_elements,
+            "missingEdges": d.missing_edges,
+            "extraEdges": d.extra_edges,
+            "changedAttributes": d.changed_attributes
+        },
+        "integration": {
+            "isolated": stats.isolated,
+            "componentCount": stats.component_count,
+            "componentSizes": stats.component_sizes
+        },
+        "coverage": {
+            "total": cov.total,
+            "satisfied": cov.satisfied,
+            "refined": cov.refined,
+            "verified": cov.verified,
+            "allocated": cov.allocated,
+            "covered": cov.covered,
+            "uncovered": cov.uncovered
+        },
+        "strictCoverage": strict_coverage,
+        "validationErrors": v.errors,
+        "validationWarnings": v.warnings,
+        "passed": failures.is_empty(),
+        "failures": failures
+    });
+
+    GateOutcome {
+        passed: failures.is_empty(),
+        failures,
+        evidence,
+    }
+}
+
+pub fn write_evidence(path: &std::path::Path, evidence: &serde_json::Value) -> anyhow::Result<()> {
+    let text = serde_json::to_string_pretty(evidence)?;
+    std::fs::write(path, text)?;
+    Ok(())
+}
diff --git a/engine/gate/src/main.rs b/engine/gate/src/main.rs
new file mode 100644
index 0000000..fa055de
--- /dev/null
+++ b/engine/gate/src/main.rs
@@ -0,0 +1,67 @@
+// SPDX-License-Identifier: AGPL-3.0-or-later
+use std::path::PathBuf;
+use std::process::ExitCode;
+
+use okf::types::OkfRoot;
+
+fn main() -> ExitCode {
+    let mut reference: Option<PathBuf> = None;
+    let mut candidate: Option<PathBuf> = None;
+    let mut evidence: Option<PathBuf> = None;
+    let mut json_output = false;
+    let mut strict_coverage = false;
+    let mut args = std::env::args().skip(1);
+    while let Some(a) = args.next() {
+        match a.as_str() {
+            "--reference" => reference = args.next().map(PathBuf::from),
+            "--candidate" => candidate = args.next().map(PathBuf::from),
+            "--evidence" => evidence = args.next().map(PathBuf::from),
+            "--json" => json_output = true,
+            "--strict-coverage" => strict_coverage = true,
+            _ => {
+                eprintln!("unknown argument: {}", a);
+                return ExitCode::from(2);
+            }
+        }
+    }
+    let (Some(reference), Some(candidate)) = (reference, candidate) else {
+        eprintln!("usage: mw-gate --reference FILE --candidate FILE [--evidence FILE] [--json] [--strict-coverage]");
+        return ExitCode::from(2);
+    };
+    let read = |p: &PathBuf| -> anyhow::Result<OkfRoot> {
+        let text = std::fs::read_to_string(p)?;
+        Ok(serde_json::from_str(&text)?)
+    };
+    let (reference, candidate) = match (read(&reference), read(&candidate)) {
+        (Ok(r), Ok(c)) => (r, c),
+        (Err(e), _) | (_, Err(e)) => {
+            eprintln!("failed to read input: {:#}", e);
+            return ExitCode::from(2);
+        }
+    };
+    let outcome = gate::run(&reference, &candidate, strict_coverage);
+    if let Some(path) = &evidence {
+        if let Err(e) = gate::write_evidence(path, &outcome.evidence) {
+            eprintln!("failed to write evidence: {:#}", e);
+            return ExitCode::from(2);
+        }
+    }
+    if json_output {
+        println!(
+            "{}",
+            serde_json::to_string(&outcome.evidence).expect("evidence serializes")
+        );
+    } else if outcome.passed {
+        println!("GATE PASS");
+    } else {
+        println!("GATE FAIL");
+        for f in &outcome.failures {
+            println!("- {}", f);
+        }
+    }
+    if outcome.passed {
+        ExitCode::SUCCESS
+    } else {
+        ExitCode::from(1)
+    }
+}
diff --git a/engine/gate/tests/gate.rs b/engine/gate/tests/gate.rs
new file mode 100644
index 0000000..307d9fa
--- /dev/null
+++ b/engine/gate/tests/gate.rs
@@ -0,0 +1,79 @@
+// SPDX-License-Identifier: AGPL-3.0-or-later
+use okf::types::OkfRoot;
+
+fn expected() -> OkfRoot {
+    serde_json::from_str(&test_support::load_okf_expected()).expect("corpus fixture parses")
+}
+
+fn okf(text: &str) -> OkfRoot {
+    serde_json::from_str(text).expect("test OKF parses")
+}
+
+const TINY_GATE: &str = r#"{
+  "project": "tiny",
+  "exportedAt": "2026-09-17T00:00:00Z",
+  "summary": {},
+  "stateMachine": {"name": "tiny sm", "regions": []},
+  "requirements": [
+    {"id": "r1", "name": "R1", "kind": "requirement", "stereotypes": ["Requirement"], "attributes": [], "documentation": "", "reqId": "1.1", "reqText": "covered"},
+    {"id": "r2", "name": "R2", "kind": "requirement", "stereotypes": ["Requirement"], "attributes": [], "documentation": "", "reqId": "1.2", "reqText": "uncovered"}
+  ],
+  "graph": {
+    "nodes": [
+      {"id": "p1", "kind": "block", "name": "P1"},
+      {"id": "r1", "kind": "requirement", "name": "R1"},
+      {"id": "r2", "kind": "requirement", "name": "R2"}
+    ],
+    "edges": [
+      {"source": "p1", "target": "r1", "kind": "dependency", "label": "Satisfy"},
+      {"source": "p1", "target": "r2", "kind": "reference", "label": ""}
+    ]
+  }
+}"#;
+
+#[test]
+fn self_roundtrip_passes() {
+    let r = expected();
+    let outcome = gate::run(&r, &r, false);
+    assert!(
+        outcome.passed,
+        "unexpected failures: {:?}",
+        outcome.failures
+    );
+    assert_eq!(outcome.evidence["passed"], true);
+    assert_eq!(
+        outcome.evidence["referenceHash"],
+        outcome.evidence["candidateHash"]
+    );
+}
+
+#[test]
+fn corrupted_corpus_fails() {
+    let reference = expected();
+    let candidate: OkfRoot =
+        serde_json::from_str(&test_support::load_okf_broken()).expect("broken fixture parses");
+    let outcome = gate::run(&reference, &candidate, false);
+    assert!(!outcome.passed);
+    assert!(outcome
+        .failures
+        .iter()
+        .any(|f| f.contains("missing elements")));
+    assert!(outcome.failures.iter().any(|f| f.contains("isolated")));
+}
+
+#[test]
+fn strict_coverage_fails_on_uncovered() {
+    let r = okf(TINY_GATE);
+    let lenient = gate::run(&r, &r, false);
+    assert!(
+        lenient.passed,
+        "unexpected failures: {:?}",
+        lenient.failures
+    );
+    let strict = gate::run(&r, &r, true);
+    assert!(!strict.passed);
+    assert!(strict
+        .failures
+        .iter()
+        .any(|f| f.contains("uncovered requirements")));
+}
diff --git a/sample/scripts/make_corrupted.py b/sample/scripts/make_corrupted.py
new file mode 100644
index 0000000..916f697
--- /dev/null
+++ b/sample/scripts/make_corrupted.py
@@ -0,0 +1,32 @@
+# SPDX-License-Identifier: AGPL-3.0-or-later
+"""Produce the corrupted OKF fixture the gate must reject.
+
+Deterministic breakage, applied to the reference corpus:
+- every edge touching requirement 3.1.5 is removed, isolating that node;
+- requirement 1.1 is deleted entirely (a lost element).
+"""
+import json
+import sys
+from pathlib import Path
+
+
+def main() -> int:
+    src = Path("sample/corpus/coffee-machine/okf/expected/coffee_machine_model.json")
+    dst = Path("sample/corpus/coffee-machine/okf/corrupted/coffee_machine_model.json")
+    data = json.loads(src.read_text(encoding="utf-8"))
+    target = next(r["id"] for r in data["requirements"] if r["reqId"] == "3.1.5")
+    before = len(data["graph"]["edges"])
+    data["graph"]["edges"] = [
+        e for e in data["graph"]["edges"]
+        if e["source"] != target and e["target"] != target
+    ]
+    removed = before - len(data["graph"]["edges"])
+    data["requirements"] = [r for r in data["requirements"] if r["reqId"] != "1.1"]
+    dst.parent.mkdir(parents=True, exist_ok=True)
+    dst.write_text(json.dumps(data, indent=2), encoding="utf-8")
+    print(f"wrote {dst}: removed {removed} edges around REQ 3.1.5, deleted REQ 1.1")
+    return 0
+
+
+if __name__ == "__main__":
+    sys.exit(main())
