﻿### Task 9: CI workflow

**Files:**
- Create: .github/workflows/ci.yml

**Interfaces:**
- Consumes: the workspace build, the corpus fixture, and (once Task 10 lands) the judge unit tests.
- Produces: a green CI pipeline on every push and pull request. Note: CI first runs when the repository is pushed to GitHub; locally it is verified by inspection only.

- [ ] **Step 1: Write .github/workflows/ci.yml**

```yaml
name: ci
on:
  push:
  pull_request:

jobs:
  engine:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: dtolnay/rust-toolchain@stable
        with:
          components: clippy, rustfmt
      - run: cargo fmt --all -- --check
      - run: cargo clippy --workspace --all-targets -- -D warnings
      - run: cargo test --workspace
      - run: cargo run -p mw-gate -- --reference sample/corpus/coffee-machine/okf/expected/coffee_machine_model.json --candidate sample/corpus/coffee-machine/okf/expected/coffee_machine_model.json
      - run: python -m unittest discover -s judge/tests -p "test_*.py" -v
```

- [ ] **Step 2: Verify the file is present and commit**

```powershell
Get-Content .github/workflows/ci.yml | Select-Object -First 5
git add .github
git commit -m "ci: add engine test and gate pipeline"
```

Expected: the first five lines match the file above. Note for the executor: the judge test step will fail until Task 10 creates judge/tests; complete Task 10 before pushing to GitHub.

---


