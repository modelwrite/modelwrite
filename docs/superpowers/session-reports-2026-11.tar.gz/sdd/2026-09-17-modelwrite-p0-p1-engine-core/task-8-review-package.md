﻿# Task 8 review package

## Commit

a6afa79 feat: add MCP server and the published agent tool contract

## Diff stat

 Cargo.lock                 |  11 +++
 Cargo.toml                 |   2 +-
 docs/agents/mcp-agent.md   |  43 +++++++++
 docs/agents/mcp-tools.json |  43 +++++++++
 engine/mcp/Cargo.toml      |  24 +++++
 engine/mcp/src/lib.rs      | 216 +++++++++++++++++++++++++++++++++++++++++++++
 engine/mcp/src/main.rs     |  22 +++++
 engine/mcp/tests/mcp.rs    |  93 +++++++++++++++++++
 8 files changed, 453 insertions(+), 1 deletion(-)

## Full diff (-U10)

diff --git a/Cargo.lock b/Cargo.lock
index 59d871e..0ffaedd 100644
--- a/Cargo.lock
+++ b/Cargo.lock
@@ -139,20 +139,31 @@ dependencies = [
 name = "mw-graph"
 version = "0.1.0"
 dependencies = [
  "mw-okf",
  "mw-test-support",
  "petgraph",
  "serde",
  "serde_json",
 ]
 
+[[package]]
+name = "mw-mcp"
+version = "0.1.0"
+dependencies = [
+ "mw-gate",
+ "mw-graph",
+ "mw-okf",
+ "mw-test-support",
+ "serde_json",
+]
+
 [[package]]
 name = "mw-okf"
 version = "0.1.0"
 dependencies = [
  "hex",
  "mw-test-support",
  "serde",
  "serde_json",
  "sha2",
 ]
diff --git a/Cargo.toml b/Cargo.toml
index 44a5990..c923385 100644
--- a/Cargo.toml
+++ b/Cargo.toml
@@ -1,13 +1,13 @@
 [workspace]
 resolver = "2"
-members = ["engine/okf", "engine/test-support", "engine/graph", "engine/gate", "engine/capi"]
+members = ["engine/okf", "engine/test-support", "engine/graph", "engine/gate", "engine/capi", "engine/mcp"]
 
 [workspace.package]
 edition = "2021"
 rust-version = "1.75"
 license = "AGPL-3.0-or-later"
 repository = "https://github.com/modelwrite/modelwrite"
 
 [workspace.dependencies]
 anyhow = "1.0"
 hex = "0.4"
diff --git a/docs/agents/mcp-agent.md b/docs/agents/mcp-agent.md
new file mode 100644
index 0000000..29e279b
--- /dev/null
+++ b/docs/agents/mcp-agent.md
@@ -0,0 +1,43 @@
+# The modelwrite agent
+
+Slice 1 provides the contract. Slice 5 provides the agent. This file is the seam
+between them, so the agent is designed for rather than retrofitted.
+
+## What exists after Slice 1
+
+- The MCP server (mw-mcp): okf.validate, okf.diff, graph.stats, gate.run, plus the
+  resources mw://okf/1.0/spec and mw://evidence/latest.
+- The published manifest docs/agents/mcp-tools.json: tool names, input schemas and the
+  stability rule.
+- The rule pack agents/CLAUDE.md: the invariants any agent, ours or third party, must
+  respect.
+
+## What Slice 5 adds
+
+- agent/: the shipped MCP client. Skill packs, a provider abstraction (local model
+  first, customer endpoint or approved cloud optionally), step and token budgets, and a
+  replayable run log.
+- The model-edit API and its tools: model.read, model.propose, rules.check,
+  patterns.list, patterns.instantiate, evidence.write.
+- Generation, repair and review skills, and the agent evaluation harness that measures
+  them.
+
+## The loop
+
+intake -> propose instructions on the model-edit API -> apply them to a draft branch ->
+run the rules -> run the gate -> repair what the gate rejects -> draft commit for human
+review -> evidence.
+
+Patterns are the generation substrate: the agent instantiates and parameterises known
+patterns rather than inventing structure, which is what makes generated models sound
+before anyone reviews them.
+
+## Rules that bind the agent
+
+1. The gate is the only authority on correctness; no agent, log line or tool parameter
+   can mark a run as passed.
+2. Every action is an instruction on the model-edit API, never a direct edit.
+3. Every iteration ends in a gate run, and the output is a draft commit for human review.
+4. Ambiguity is a question, not an invention: the agent asks rather than guessing.
+5. Every run is replayable: prompts, tool calls and results are logged, and step, token
+   and wall-clock budgets are enforced.
diff --git a/docs/agents/mcp-tools.json b/docs/agents/mcp-tools.json
new file mode 100644
index 0000000..3e97e31
--- /dev/null
+++ b/docs/agents/mcp-tools.json
@@ -0,0 +1,43 @@
+{
+  "manifestVersion": "1.0",
+  "server": { "name": "modelwrite-mcp", "protocolVersion": "2024-11-05" },
+  "stability": "Tool names and input schemas are additive. Existing names never change meaning; new capability arrives as new tools.",
+  "tools": [
+    {
+      "name": "okf.validate",
+      "summary": "Validate an OKF document and return the validation report",
+      "inputSchema": { "type": "object", "properties": { "okf": { "type": "string" } }, "required": ["okf"] }
+    },
+    {
+      "name": "okf.diff",
+      "summary": "Semantic diff between two OKF documents: elements, edges and attributes",
+      "inputSchema": { "type": "object", "properties": { "reference": { "type": "string" }, "candidate": { "type": "string" } }, "required": ["reference", "candidate"] }
+    },
+    {
+      "name": "graph.stats",
+      "summary": "Graph health of an OKF document: nodes, edges, isolated nodes, components",
+      "inputSchema": { "type": "object", "properties": { "okf": { "type": "string" } }, "required": ["okf"] }
+    },
+    {
+      "name": "gate.run",
+      "summary": "Run the round-trip fidelity gate and return its evidence record",
+      "inputSchema": { "type": "object", "properties": { "reference": { "type": "string" }, "candidate": { "type": "string" }, "strictCoverage": { "type": "boolean" } }, "required": ["reference", "candidate"] }
+    }
+  ],
+  "resources": [
+    { "uri": "mw://okf/1.0/spec", "mimeType": "text/markdown" },
+    { "uri": "mw://evidence/latest", "mimeType": "application/json" }
+  ],
+  "agentContract": {
+    "gateIsTheOnlyAuthority": true,
+    "plannedTools": [
+      "rules.check",
+      "model.read",
+      "model.propose",
+      "patterns.list",
+      "patterns.instantiate",
+      "evidence.write"
+    ],
+    "note": "The shipped modelwrite agent (Slice 5) binds to this manifest. Planned tools arrive with the slices that own them, and are additive."
+  }
+}
diff --git a/engine/mcp/Cargo.toml b/engine/mcp/Cargo.toml
new file mode 100644
index 0000000..338877b
--- /dev/null
+++ b/engine/mcp/Cargo.toml
@@ -0,0 +1,24 @@
+[package]
+name = "mw-mcp"
+version = "0.1.0"
+edition.workspace = true
+rust-version.workspace = true
+license.workspace = true
+publish = false
+
+[lib]
+name = "mcp"
+
+[[bin]]
+name = "mw-mcp"
+path = "src/main.rs"
+
+[dependencies]
+mw-okf = { path = "../okf" }
+mw-graph = { path = "../graph" }
+mw-gate = { path = "../gate" }
+serde_json.workspace = true
+
+[dev-dependencies]
+mw-test-support = { path = "../test-support" }
+serde_json.workspace = true
diff --git a/engine/mcp/src/lib.rs b/engine/mcp/src/lib.rs
new file mode 100644
index 0000000..b6ca70e
--- /dev/null
+++ b/engine/mcp/src/lib.rs
@@ -0,0 +1,216 @@
+// SPDX-License-Identifier: AGPL-3.0-or-later
+use serde_json::{json, Value};
+
+fn tool_error(message: &str) -> Value {
+    json!({ "content": [{ "type": "text", "text": message }], "isError": true })
+}
+
+fn tool_ok(text: String) -> Value {
+    json!({ "content": [{ "type": "text", "text": text }], "isError": false })
+}
+
+fn call_tool(msg: &Value) -> Value {
+    let params = msg.get("params");
+    let name = params
+        .and_then(|p| p.get("name"))
+        .and_then(Value::as_str)
+        .unwrap_or("");
+    let args = params
+        .and_then(|p| p.get("arguments"))
+        .cloned()
+        .unwrap_or_else(|| json!({}));
+    match name {
+        "okf.validate" => {
+            let Some(okf) = args.get("okf").and_then(Value::as_str) else {
+                return tool_error("missing okf argument");
+            };
+            match serde_json::from_str::<okf::types::OkfRoot>(okf) {
+                Err(e) => tool_error(&format!("parse error: {}", e)),
+                Ok(root) => {
+                    let report = okf::validate::validate(&root);
+                    tool_ok(serde_json::to_string_pretty(&report).expect("report serializes"))
+                }
+            }
+        }
+        "graph.stats" => {
+            let Some(okf) = args.get("okf").and_then(Value::as_str) else {
+                return tool_error("missing okf argument");
+            };
+            match serde_json::from_str::<okf::types::OkfRoot>(okf) {
+                Err(e) => tool_error(&format!("parse error: {}", e)),
+                Ok(root) => {
+                    let stats = graph::graph_stats(&root);
+                    tool_ok(serde_json::to_string_pretty(&stats).expect("stats serialize"))
+                }
+            }
+        }
+        "gate.run" => {
+            let reference = args.get("reference").and_then(Value::as_str);
+            let candidate = args.get("candidate").and_then(Value::as_str);
+            let strict = args
+                .get("strictCoverage")
+                .and_then(Value::as_bool)
+                .unwrap_or(false);
+            let (Some(reference), Some(candidate)) = (reference, candidate) else {
+                return tool_error("missing reference or candidate argument");
+            };
+            let parse = |s: &str| serde_json::from_str::<okf::types::OkfRoot>(s);
+            match (parse(reference), parse(candidate)) {
+                (Err(e), _) | (_, Err(e)) => tool_error(&format!("parse error: {}", e)),
+                (Ok(reference), Ok(candidate)) => {
+                    let outcome = gate::run(&reference, &candidate, strict);
+                    tool_ok(
+                        serde_json::to_string_pretty(&outcome.evidence)
+                            .expect("evidence serializes"),
+                    )
+                }
+            }
+        }
+        "okf.diff" => {
+            let reference = args.get("reference").and_then(Value::as_str);
+            let candidate = args.get("candidate").and_then(Value::as_str);
+            let (Some(reference), Some(candidate)) = (reference, candidate) else {
+                return tool_error("missing reference or candidate argument");
+            };
+            let parse = |s: &str| serde_json::from_str::<okf::types::OkfRoot>(s);
+            match (parse(reference), parse(candidate)) {
+                (Err(e), _) | (_, Err(e)) => tool_error(&format!("parse error: {}", e)),
+                (Ok(reference), Ok(candidate)) => {
+                    let report = okf::diff::diff(&reference, &candidate);
+                    let payload = json!({
+                        "equal": report.equal,
+                        "missingElements": report.missing_elements,
+                        "extraElements": report.extra_elements,
+                        "missingEdges": report.missing_edges,
+                        "extraEdges": report.extra_edges,
+                        "changedAttributes": report.changed_attributes
+                    });
+                    tool_ok(serde_json::to_string_pretty(&payload).expect("diff serializes"))
+                }
+            }
+        }
+        _ => tool_error(&format!("unknown tool: {}", name)),
+    }
+}
+
+pub fn handle_request(line: &str) -> String {
+    let msg: Value = match serde_json::from_str(line) {
+        Ok(m) => m,
+        Err(e) => {
+            return json!({
+                "jsonrpc": "2.0",
+                "id": null,
+                "error": { "code": -32700, "message": format!("parse error: {}", e) }
+            })
+            .to_string();
+        }
+    };
+    let id = msg.get("id").cloned().unwrap_or(Value::Null);
+    let method = msg.get("method").and_then(Value::as_str).unwrap_or("");
+    if method.is_empty() {
+        return json!({
+            "jsonrpc": "2.0",
+            "id": id,
+            "error": { "code": -32600, "message": "method missing" }
+        })
+        .to_string();
+    }
+    if id.is_null() {
+        return String::new();
+    }
+    let result = match method {
+        "initialize" => json!({
+            "protocolVersion": "2024-11-05",
+            "capabilities": { "tools": {} },
+            "serverInfo": { "name": "modelwrite-mcp", "version": env!("CARGO_PKG_VERSION") }
+        }),
+        "tools/list" => json!({ "tools": [
+            {
+                "name": "okf.validate",
+                "description": "Validate an OKF JSON document",
+                "inputSchema": {
+                    "type": "object",
+                    "properties": { "okf": { "type": "string" } },
+                    "required": ["okf"]
+                }
+            },
+            {
+                "name": "graph.stats",
+                "description": "Graph health of an OKF document",
+                "inputSchema": {
+                    "type": "object",
+                    "properties": { "okf": { "type": "string" } },
+                    "required": ["okf"]
+                }
+            },
+            {
+                "name": "gate.run",
+                "description": "Round-trip fidelity gate between two OKF documents",
+                "inputSchema": {
+                    "type": "object",
+                    "properties": {
+                        "reference": { "type": "string" },
+                        "candidate": { "type": "string" },
+                        "strictCoverage": { "type": "boolean" }
+                    },
+                    "required": ["reference", "candidate"]
+                }
+            },
+            {
+                "name": "okf.diff",
+                "description": "Semantic diff between two OKF documents: elements, edges and attributes",
+                "inputSchema": {
+                    "type": "object",
+                    "properties": {
+                        "reference": { "type": "string" },
+                        "candidate": { "type": "string" }
+                    },
+                    "required": ["reference", "candidate"]
+                }
+            }
+        ] }),
+        "resources/list" => json!({ "resources": [
+            {
+                "uri": "mw://okf/1.0/spec",
+                "name": "OKF 1.0 specification",
+                "mimeType": "text/markdown"
+            },
+            {
+                "uri": "mw://evidence/latest",
+                "name": "latest gate evidence",
+                "mimeType": "application/json"
+            }
+        ] }),
+        "resources/read" => {
+            let uri = msg
+                .get("params")
+                .and_then(|p| p.get("uri"))
+                .and_then(Value::as_str)
+                .unwrap_or("");
+            if uri == "mw://okf/1.0/spec" {
+                let path = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
+                    .join("../../docs/okf/okf-1.0-spec.md");
+                match std::fs::read_to_string(&path) {
+                    Ok(text) => {
+                        json!({ "contents": [{ "uri": uri, "mimeType": "text/markdown", "text": text }] })
+                    }
+                    Err(e) => {
+                        json!({ "contents": [], "error": format!("cannot read spec: {}", e) })
+                    }
+                }
+            } else {
+                json!({ "contents": [] })
+            }
+        }
+        "tools/call" => call_tool(&msg),
+        _ => {
+            return json!({
+                "jsonrpc": "2.0",
+                "id": id,
+                "error": { "code": -32601, "message": format!("method not found: {}", method) }
+            })
+            .to_string();
+        }
+    };
+    json!({ "jsonrpc": "2.0", "id": id, "result": result }).to_string()
+}
diff --git a/engine/mcp/src/main.rs b/engine/mcp/src/main.rs
new file mode 100644
index 0000000..51e1bb7
--- /dev/null
+++ b/engine/mcp/src/main.rs
@@ -0,0 +1,22 @@
+// SPDX-License-Identifier: AGPL-3.0-or-later
+use std::io::{BufRead, Write};
+
+fn main() {
+    let stdin = std::io::stdin();
+    let stdout = std::io::stdout();
+    let mut out = stdout.lock();
+    for line in stdin.lock().lines() {
+        let Ok(line) = line else { break };
+        if line.trim().is_empty() {
+            continue;
+        }
+        let response = mcp::handle_request(&line);
+        if response.is_empty() {
+            continue;
+        }
+        if writeln!(out, "{}", response).is_err() {
+            break;
+        }
+        let _ = out.flush();
+    }
+}
diff --git a/engine/mcp/tests/mcp.rs b/engine/mcp/tests/mcp.rs
new file mode 100644
index 0000000..bc68e55
--- /dev/null
+++ b/engine/mcp/tests/mcp.rs
@@ -0,0 +1,93 @@
+// SPDX-License-Identifier: AGPL-3.0-or-later
+use serde_json::{json, Value};
+
+fn call(payload: Value) -> Value {
+    let out = mcp::handle_request(&payload.to_string());
+    serde_json::from_str(&out).expect("valid JSON-RPC response")
+}
+
+#[test]
+fn initialize_returns_server_info() {
+    let resp = call(json!({ "jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {} }));
+    assert_eq!(resp["id"], 1);
+    assert_eq!(resp["result"]["serverInfo"]["name"], "modelwrite-mcp");
+    assert_eq!(resp["result"]["protocolVersion"], "2024-11-05");
+}
+
+#[test]
+fn tools_list_exposes_the_agent_toolset() {
+    let resp = call(json!({ "jsonrpc": "2.0", "id": 2, "method": "tools/list", "params": {} }));
+    let names: Vec<&str> = resp["result"]["tools"]
+        .as_array()
+        .unwrap()
+        .iter()
+        .map(|t| t["name"].as_str().unwrap())
+        .collect();
+    assert_eq!(
+        names,
+        vec!["okf.validate", "graph.stats", "gate.run", "okf.diff"]
+    );
+}
+
+#[test]
+fn validate_tool_reports_invalid() {
+    let resp = call(json!({
+        "jsonrpc": "2.0",
+        "id": 3,
+        "method": "tools/call",
+        "params": { "name": "okf.validate", "arguments": { "okf": "{\"project\":\"x\"}" } }
+    }));
+    let text = resp["result"]["content"][0]["text"].as_str().unwrap();
+    let report: Value = serde_json::from_str(text).unwrap();
+    assert_eq!(report["valid"], false);
+}
+
+#[test]
+fn gate_tool_runs_roundtrip() {
+    let a = test_support::load_okf_expected();
+    let resp = call(json!({
+        "jsonrpc": "2.0",
+        "id": 4,
+        "method": "tools/call",
+        "params": { "name": "gate.run", "arguments": { "reference": a, "candidate": a } }
+    }));
+    let text = resp["result"]["content"][0]["text"].as_str().unwrap();
+    let evidence: Value = serde_json::from_str(text).unwrap();
+    assert!(evidence["passed"].as_bool().unwrap());
+}
+
+#[test]
+fn diff_tool_reports_a_removed_requirement() {
+    let reference = test_support::load_okf_expected();
+    let mut model: serde_json::Value = serde_json::from_str(&reference).unwrap();
+    model["requirements"].as_array_mut().unwrap().pop();
+    let candidate = model.to_string();
+    let resp = call(json!({
+        "jsonrpc": "2.0",
+        "id": 6,
+        "method": "tools/call",
+        "params": { "name": "okf.diff", "arguments": { "reference": reference, "candidate": candidate } }
+    }));
+    let text = resp["result"]["content"][0]["text"].as_str().unwrap();
+    let report: Value = serde_json::from_str(text).unwrap();
+    assert_eq!(report["equal"], false);
+    assert_eq!(report["missingElements"].as_array().unwrap().len(), 1);
+}
+
+#[test]
+fn resources_list_exposes_the_spec() {
+    let resp = call(json!({ "jsonrpc": "2.0", "id": 7, "method": "resources/list", "params": {} }));
+    let uris: Vec<&str> = resp["result"]["resources"]
+        .as_array()
+        .unwrap()
+        .iter()
+        .map(|r| r["uri"].as_str().unwrap())
+        .collect();
+    assert!(uris.contains(&"mw://okf/1.0/spec"));
+}
+
+#[test]
+fn unknown_method_returns_error() {
+    let resp = call(json!({ "jsonrpc": "2.0", "id": 5, "method": "nope", "params": {} }));
+    assert_eq!(resp["error"]["code"], -32601);
+}
