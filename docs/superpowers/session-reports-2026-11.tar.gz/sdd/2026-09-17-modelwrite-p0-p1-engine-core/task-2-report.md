# Task 2 Report: OKF 1.0 specification and JSON Schema

## Status
DONE_WITH_CONCERNS

## Commits
- 183bac4 docs: add OKF 1.0 spec and JSON schema

## Verification
Both checks passed; okf-1.0-spec.md = 4310 bytes, okf-1.0.schema.json = 4948 bytes (schema parses; required == [project, summary, stateMachine, graph]; 9 definitions; 12 top-level properties).

Exact commands run and their output:

```powershell
python -c "import json,pathlib; json.loads(pathlib.Path('docs/okf/okf-1.0.schema.json').read_text(encoding='utf-8')); print('schema parses')"
# -> schema parses

python -c "import json,pathlib; d=json.loads(pathlib.Path('docs/okf/okf-1.0.schema.json').read_text(encoding='utf-8')); assert d['required']==['project','summary','stateMachine','graph']; print('required fields pinned')"
# -> required fields pinned
```

Self-review against the brief: both files are byte-for-byte identical to the brief's fenced blocks (spec compared line-by-line, schema deep-equal via JSON). All 9 spec sections, 12 table rows, 9 validation rules, node/edge kind lists, and the traceability spellings Satisfy/Refine/Verify/Allocate are present.

## Concerns
1. exportedAt prose/schema discrepancy: spec §2 table marks exportedAt "required: yes", but the JSON Schema required array is only [project, summary, stateMachine, graph]. Task 4's Rust validator should treat the schema as the runtime contract (exportedAt optional in the schema) and reconcile the prose note.
2. Traceability enum spellings (Satisfy, Refine, Verify, Allocate) exist only in spec §3 prose; the schema's graphEdge.label is a plain string. Task 4 must encode these exact spellings from the spec, not the schema.
3. Nullable fields: state.entry/doActivity/exit and activityNode.partition use type ["string", "null"]; Task 4 needs Option<String> (or equivalent) for these.
4. Transcription note: the brief's title line contained mojibake (a double-encoded em dash, "â€”"). okf-1.0-spec.md uses a real em dash (—) in "OKF 1.0 — Open Knowledge Format". No field names, enums, or rules were altered.

## Fix round 1

Independent review: spec compliance PASS, task quality FAIL. All findings are inherited from the brief (not transcription errors). Fixes applied exactly as ruled:

1. CRITICAL - exportedAt required contradiction. Spec section 2 table: exportedAt row Required changed "yes" to "no (expected: exporters emit it)" (Meaning text unchanged). Spec section 9 Conformance: added sentence "exportedAt is expected of every export and emitted by every exporter, but it is not a schema-required field; the runtime validator does not reject a document that omits it." Schema required array left unchanged: [project, summary, stateMachine, graph].
2. IMPORTANT - project accepts empty. Added "minLength": 1 to the project property.
3. IMPORTANT - reqId accepts empty. Added "minLength": 1 to requirement.reqId.
4. IMPORTANT - graph.nodes not constrained. Added "minItems": 1 to graph.nodes.
5. IMPORTANT - kind lists unexpressed. Added enum to graphNode.kind (9 node kinds) and graphEdge.kind (13 edge kinds), exactly the section 3 lists. element.kind left unconstrained per ruling.
6. IMPORTANT - traceability spellings prose-only. Spec section 3: added sentence "These spellings are the vocabulary the platform uses on dependency edges; they are checked by the coverage analysis, not by document validation." No closed enum added to graphEdge.label per ruling.
7-9. MINOR - no action needed (em dash title, activityEdge required fields, nullable ["string","null"] fields all correct as-is).

Commit: 80b4d6e docs: align the OKF schema with the specification rules

Verification (stdlib python, no pip). Wrote a short python check and ran it; full output:

```
(a) schema parses
(b) required == [project, summary, stateMachine, graph]
(schema) project.minLength=1, reqId.minLength=1, graph.nodes.minItems=1
(schema) node enum (9): ['activity', 'actor', 'block', 'interface', 'requirement', 'signal', 'state', 'stateMachine', 'usecase']
(schema) edge enum (13): ['association', 'behavior', 'contains', 'dependency', 'effect', 'generalization', 'include', 'part', 'reference', 'subject', 'transition', 'triggers', 'uses']
PASS  project non-empty
PASS  every reqId non-empty
PASS  graph.nodes non-empty
PASS  every graph node kind in node enum
PASS  every graph edge kind in edge enum
corpus fixture: coffee_machine_model.json
ALL CHECKS PASS
```

