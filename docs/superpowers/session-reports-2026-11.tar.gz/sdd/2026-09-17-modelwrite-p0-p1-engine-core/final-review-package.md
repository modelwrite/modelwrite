﻿# Final whole-branch review package - Slice 1 (engine core)

## Commits on this branch

d6af28a docs: add quickstart README
903ae01 test: cover the MCP protocol edges, and align the manifest tool order
1a21f5c feat: add gate-as-judge harness
f880a42 fix: publish the diff report with camelCase keys like every other contract
c3a6750 ci: add engine test and gate pipeline
cb2bfd2 docs: sync the coverage honesty fix into the plan
e887e40 fix: report coverage truthfully when a candidate has no graph
a6afa79 feat: add MCP server and the published agent tool contract
00014a4 fix: remove every panic path from the C ABI
0488500 docs: sync the gate rulings into the plan
9a07af0 fix: fail a graph-less candidate cleanly and reject flags without values
f98ec36 feat: add C ABI for validation and the gate
f70afdc test: pin the allocate coverage path that the coverage fix addressed
f349a3e fix: count only requirement endpoints in coverage, and pin the corpus coverage
38022ae feat: add round-trip fidelity gate with evidence records
be84bfa test: cover the state machine path in the okf diff and fix a stale comment
3b49775 fix: cover activities and document-level fields in the okf diff
b102653 feat: add graph crate with integration and coverage analysis
ada2a53 docs: make the okf diff cover activities and document-level fields
588a78d feat: add okf crate with types, validation, hashing and diffing
08f4d4c docs: align the dangling-endpoint test with the warning ruling
1669bf7 docs: record the two dangling satisfy links found in the reference export
642a2c7 docs: rule on the stateMachine rename and treat unresolved endpoints as warnings
18d9965 docs: scope the okf diff universe by section so graph mirrors cannot mask loss
243ec85 chore: add the partition ruling and store the demo fixture blob verbatim
80b4d6e docs: align the OKF schema with the specification rules
302517d fix: store the demo fixture verbatim by marking it binary
119bffc docs: correct the Task 4 expected test count in the plan
4bcb0f9 chore: port coffee-machine corpus into sample/
183bac4 docs: add OKF 1.0 spec and JSON schema
efb990a fix: repair the last mangled box-drawing glyph in the superseded v1 design
b1c9c5d fix: repair CP1252-mangled punctuation and box-drawing characters in the docs
017a1b5 docs: add the MCP agent to the design and roadmap, and make the Slice 1 tool surface an agent contract
06606f9 chore: scaffold modelwrite repository
0c58480 chore: add MBSE knowledge pack collateral as source material

## Diff stat (whole branch)

 .gitattributes                                     |    3 +
 .github/workflows/ci.yml                           |   18 +
 .gitignore                                         |    6 +
 CODE_OF_CONDUCT.md                                 |   15 +
 CONTRIBUTING.md                                    |   29 +
 Cargo.lock                                         |  290 ++
 Cargo.toml                                         |   17 +
 LICENSE                                            |  661 ++++
 NOTICE.md                                          |   13 +
 README.md                                          |   38 +
 SECURITY.md                                        |   18 +
 agents/CLAUDE.md                                   |   24 +
 collateral/CoffeeMachine-App.zip                   |  Bin 0 -> 34950 bytes
 collateral/CoffeeMachine-Showcase-standalone.html  |  977 ++++++
 collateral/CoffeeMachine-SysML-Model.mdzip         |  Bin 0 -> 216922 bytes
 collateral/MBSE_CoffeeMachine_KnowledgePack.docx   |  Bin 0 -> 1656180 bytes
 collateral/MBSE_CoffeeMachine_KnowledgePack.zip    |  Bin 0 -> 1935195 bytes
 collateral/MBSE_Coffee_Machine_Analysis.pptx       |  Bin 0 -> 1152408 bytes
 collateral/My-CATIA-Magic-User-Guide.docx          |  Bin 0 -> 42722 bytes
 collateral/READ-ME-FIRST.txt                       |   53 +
 docs/agents/mcp-agent.md                           |   43 +
 docs/agents/mcp-tools.json                         |  103 +
 .../2026-09-17-roundtrip-corrupted-fail.json       |   67 +
 docs/evidence/2026-09-17-roundtrip-self-pass.json  |   50 +
 docs/evidence/README.md                            |   18 +
 docs/okf/okf-1.0-spec.md                           |  113 +
 docs/okf/okf-1.0.schema.json                       |  166 +
 .../2026-09-17-modelwrite-capability-roadmap.md    |   43 +-
 .../2026-09-17-modelwrite-p0-p1-engine-core.md     |  781 ++++-
 .../specs/2026-09-17-modelwrite-design.md          |   24 +-
 .../specs/2026-09-17-modelwrite-platform-design.md |   82 +-
 engine/capi/Cargo.toml                             |   20 +
 engine/capi/src/lib.rs                             |   95 +
 engine/capi/tests/capi.rs                          |   48 +
 engine/gate/Cargo.toml                             |   23 +
 engine/gate/src/lib.rs                             |  150 +
 engine/gate/src/main.rs                            |   85 +
 engine/gate/tests/gate.rs                          |  112 +
 engine/graph/Cargo.toml                            |   19 +
 engine/graph/src/lib.rs                            |  136 +
 engine/graph/tests/graph_stats.rs                  |  108 +
 engine/include/modelwrite.h                        |   30 +
 engine/mcp/Cargo.toml                              |   24 +
 engine/mcp/src/lib.rs                              |  210 ++
 engine/mcp/src/main.rs                             |   22 +
 engine/mcp/tests/mcp.rs                            |  127 +
 engine/okf/Cargo.toml                              |   19 +
 engine/okf/src/diff.rs                             |  200 ++
 engine/okf/src/hash.rs                             |   14 +
 engine/okf/src/lib.rs                              |    5 +
 engine/okf/src/types.rs                            |  198 ++
 engine/okf/src/validate.rs                         |  201 ++
 engine/okf/tests/okf_diff.rs                       |   87 +
 engine/okf/tests/okf_validation.rs                 |  105 +
 engine/test-support/Cargo.toml                     |   12 +
 engine/test-support/src/lib.rs                     |   23 +
 judge/judge.py                                     |   76 +
 judge/tests/test_judge.py                          |   37 +
 sample/README.md                                   |   16 +
 sample/corpus/coffee-machine/README.md             |   35 +
 .../legacy/CoffeeMachine-SysML-Model.mdzip         |  Bin 0 -> 216922 bytes
 .../okf/corrupted/coffee_machine_model.json        | 3485 ++++++++++++++++++++
 .../okf/expected/coffee_machine_model.json         |    1 +
 sample/demo/CoffeeMachine-Showcase-standalone.html |  Bin 0 -> 141712 bytes
 sample/scripts/make_corrupted.py                   |   32 +
 65 files changed, 9267 insertions(+), 140 deletions(-)

## Verification observed by the controller

```
cargo fmt --all -- --check                             -> exit 0, clean
cargo clippy --workspace --all-targets -- -D warnings  -> exit 0, clean
cargo test --workspace --no-fail-fast                  -> 39 tests pass (capi 4, gate 4, graph 6, mcp 10, okf 8 + 7)
python -m unittest discover -s judge/tests             -> 2 tests OK
mw-gate corpus self-comparison                         -> GATE PASS, exit 0
mw-gate corpus vs corrupted fixture                    -> GATE FAIL, exit 1
judge.py expected vs expected                          -> PASS, exit 0
judge.py expected vs corrupted                         -> FAIL, exit 1
```

## Full diff of the code under review (-U10)

Fixtures under sample/corpus, the demo HTML, docs/ and collateral/ are excluded: fixtures are verbatim copies reviewed in Task 3, and docs were reviewed task by task. The generator sample/scripts/make_corrupted.py is included.

diff --git a/.github/workflows/ci.yml b/.github/workflows/ci.yml
new file mode 100644
index 0000000..5752dff
--- /dev/null
+++ b/.github/workflows/ci.yml
@@ -0,0 +1,18 @@
+name: ci
+on:
+  push:
+  pull_request:
+
+jobs:
+  engine:
+    runs-on: ubuntu-latest
+    steps:
+      - uses: actions/checkout@v4
+      - uses: dtolnay/rust-toolchain@stable
+        with:
+          components: clippy, rustfmt
+      - run: cargo fmt --all -- --check
+      - run: cargo clippy --workspace --all-targets -- -D warnings
+      - run: cargo test --workspace
+      - run: cargo run -p mw-gate -- --reference sample/corpus/coffee-machine/okf/expected/coffee_machine_model.json --candidate sample/corpus/coffee-machine/okf/expected/coffee_machine_model.json
+      - run: python -m unittest discover -s judge/tests -p "test_*.py" -v
diff --git a/Cargo.toml b/Cargo.toml
new file mode 100644
index 0000000..c923385
--- /dev/null
+++ b/Cargo.toml
@@ -0,0 +1,17 @@
+[workspace]
+resolver = "2"
+members = ["engine/okf", "engine/test-support", "engine/graph", "engine/gate", "engine/capi", "engine/mcp"]
+
+[workspace.package]
+edition = "2021"
+rust-version = "1.75"
+license = "AGPL-3.0-or-later"
+repository = "https://github.com/modelwrite/modelwrite"
+
+[workspace.dependencies]
+anyhow = "1.0"
+hex = "0.4"
+petgraph = "0.6"
+serde = { version = "1.0", features = ["derive"] }
+serde_json = "1.0"
+sha2 = "0.10"
diff --git a/README.md b/README.md
new file mode 100644
index 0000000..618f5b8
--- /dev/null
+++ b/README.md
@@ -0,0 +1,38 @@
+# Modelwrite
+
+**The model you can prove.**
+
+Modelwrite is an open-source MBSE platform that turns legacy SysML models
+into portable, provable data — the Open Knowledge Format (OKF) — and
+automates the skilled work of building and reviewing models with grounded
+AI.
+
+## What is in this repository
+
+- engine/ — the Rust engine (AGPL-3.0-or-later): okf types, validation,
+  hashing and diffing; graph analysis; the round-trip fidelity gate with
+  evidence records; the C ABI; the MCP server
+- judge/ — the gate-as-judge harness for scoring model migrations
+- agents/ — rule packs for AI coding agents working against OKF
+- sample/ — the coffee-machine corpus: the legacy CATIA Magic model, its
+  OKF export, and the corrupted fixture the gate must reject
+- docs/ — the OKF 1.0 spec, the design documents, and the evidence annex
+
+## Quickstart
+
+Requirements: Rust (stable, via rustup) and Python 3.12+ for the judge
+harness.
+
+cargo build --workspace
+cargo test --workspace
+
+Run the gate on the corpus:
+
+cargo run -p mw-gate -- --reference sample/corpus/coffee-machine/okf/expected/coffee_machine_model.json --candidate sample/corpus/coffee-machine/okf/expected/coffee_machine_model.json
+
+Expected output: GATE PASS.
+
+## Licence
+
+The engine is AGPL-3.0-or-later. Importers and exporters will ship under
+Apache-2.0 as they land. See NOTICE.md for attribution.
diff --git a/engine/capi/Cargo.toml b/engine/capi/Cargo.toml
new file mode 100644
index 0000000..b3e8a9a
--- /dev/null
+++ b/engine/capi/Cargo.toml
@@ -0,0 +1,20 @@
+[package]
+name = "mw-capi"
+version = "0.1.0"
+edition.workspace = true
+rust-version.workspace = true
+license.workspace = true
+publish = false
+
+[lib]
+name = "capi"
+crate-type = ["cdylib", "staticlib", "rlib"]
+
+[dependencies]
+mw-okf = { path = "../okf" }
+mw-gate = { path = "../gate" }
+serde_json.workspace = true
+
+[dev-dependencies]
+mw-test-support = { path = "../test-support" }
+serde_json.workspace = true
diff --git a/engine/capi/src/lib.rs b/engine/capi/src/lib.rs
new file mode 100644
index 0000000..d556215
--- /dev/null
+++ b/engine/capi/src/lib.rs
@@ -0,0 +1,95 @@
+// SPDX-License-Identifier: AGPL-3.0-or-later
+//! C ABI for the modelwrite engine. All returned strings are owned by the
+//! caller and must be released with modelwrite_free_string.
+use std::ffi::{c_char, CString};
+
+/// Hand a payload to the caller without any panic path. A panic unwinding across an
+/// `extern "C"` boundary is undefined behaviour, so `expect` is not acceptable here
+/// even where the current payloads provably cannot fail.
+fn into_c_string(payload: String) -> *mut c_char {
+    match CString::new(payload) {
+        Ok(s) => s.into_raw(),
+        // Unreachable in practice: serde_json escapes control characters, so a
+        // serialized payload contains no NUL. Null is returned rather than panicking.
+        Err(_) => std::ptr::null_mut(),
+    }
+}
+
+fn err_string(message: &str) -> *mut c_char {
+    into_c_string(serde_json::json!({ "error": message }).to_string())
+}
+
+/// Version string; deliberately leaked, never freed.
+#[no_mangle]
+pub extern "C" fn modelwrite_version() -> *const c_char {
+    into_c_string(format!("modelwrite {}", env!("CARGO_PKG_VERSION"))) as *const c_char
+}
+
+/// Validate one OKF document; returns a JSON ValidationReport string.
+///
+/// # Safety
+/// `json` must point to `len` readable bytes and remain valid for the call.
+#[no_mangle]
+pub unsafe extern "C" fn modelwrite_validate(json: *const u8, len: usize) -> *mut c_char {
+    if json.is_null() || len == 0 {
+        return err_string("empty input");
+    }
+    let bytes = unsafe { std::slice::from_raw_parts(json, len) };
+    let text = match std::str::from_utf8(bytes) {
+        Ok(t) => t,
+        Err(_) => return err_string("input is not UTF-8"),
+    };
+    let root = match serde_json::from_str::<okf::types::OkfRoot>(text) {
+        Ok(r) => r,
+        Err(e) => return err_string(&format!("parse error: {}", e)),
+    };
+    let report = okf::validate::validate(&root);
+    match serde_json::to_string(&report) {
+        Ok(payload) => into_c_string(payload),
+        Err(e) => err_string(&format!("failed to serialize the validation report: {}", e)),
+    }
+}
+
+/// Run the round-trip gate; returns the JSON evidence string.
+///
+/// # Safety
+/// `reference` and `candidate` must each point to their corresponding
+/// length of readable bytes and remain valid for the call.
+#[no_mangle]
+pub unsafe extern "C" fn modelwrite_gate(
+    reference: *const u8,
+    reference_len: usize,
+    candidate: *const u8,
+    candidate_len: usize,
+) -> *mut c_char {
+    if reference.is_null() || reference_len == 0 || candidate.is_null() || candidate_len == 0 {
+        return err_string("empty input");
+    }
+    let parse = |ptr: *const u8, len: usize| -> Option<okf::types::OkfRoot> {
+        let bytes = unsafe { std::slice::from_raw_parts(ptr, len) };
+        let text = std::str::from_utf8(bytes).ok()?;
+        serde_json::from_str(text).ok()
+    };
+    let (Some(reference), Some(candidate)) = (
+        parse(reference, reference_len),
+        parse(candidate, candidate_len),
+    ) else {
+        return err_string("parse error: inputs must be OKF JSON documents");
+    };
+    let outcome = gate::run(&reference, &candidate, false);
+    match serde_json::to_string(&outcome.evidence) {
+        Ok(payload) => into_c_string(payload),
+        Err(e) => err_string(&format!("failed to serialize the gate evidence: {}", e)),
+    }
+}
+
+/// Free a string returned by this library.
+///
+/// # Safety
+/// `ptr` must be null or a pointer previously returned by this library.
+#[no_mangle]
+pub unsafe extern "C" fn modelwrite_free_string(ptr: *mut c_char) {
+    if !ptr.is_null() {
+        drop(unsafe { CString::from_raw(ptr) });
+    }
+}
diff --git a/engine/capi/tests/capi.rs b/engine/capi/tests/capi.rs
new file mode 100644
index 0000000..01a441b
--- /dev/null
+++ b/engine/capi/tests/capi.rs
@@ -0,0 +1,48 @@
+// SPDX-License-Identifier: AGPL-3.0-or-later
+use std::ffi::CStr;
+
+#[test]
+fn version_returns_string() {
+    let ptr = capi::modelwrite_version();
+    let s = unsafe { CStr::from_ptr(ptr) }
+        .to_string_lossy()
+        .into_owned();
+    assert!(s.starts_with("modelwrite "));
+}
+
+#[test]
+fn validate_returns_json_report() {
+    let okf = test_support::load_okf_expected();
+    let ptr = unsafe { capi::modelwrite_validate(okf.as_ptr(), okf.len()) };
+    let s = unsafe { CStr::from_ptr(ptr) }
+        .to_string_lossy()
+        .into_owned();
+    let v: serde_json::Value = serde_json::from_str(&s).expect("JSON report");
+    assert!(v["valid"].as_bool().unwrap());
+    unsafe { capi::modelwrite_free_string(ptr) };
+}
+
+#[test]
+fn gate_returns_evidence() {
+    let a = test_support::load_okf_expected();
+    let b = a.clone();
+    let ptr = unsafe { capi::modelwrite_gate(a.as_ptr(), a.len(), b.as_ptr(), b.len()) };
+    let s = unsafe { CStr::from_ptr(ptr) }
+        .to_string_lossy()
+        .into_owned();
+    let v: serde_json::Value = serde_json::from_str(&s).expect("JSON evidence");
+    assert!(v["passed"].as_bool().unwrap());
+    unsafe { capi::modelwrite_free_string(ptr) };
+}
+
+#[test]
+fn validate_rejects_garbage() {
+    let garbage = "not json";
+    let ptr = unsafe { capi::modelwrite_validate(garbage.as_ptr(), garbage.len()) };
+    let s = unsafe { CStr::from_ptr(ptr) }
+        .to_string_lossy()
+        .into_owned();
+    let v: serde_json::Value = serde_json::from_str(&s).expect("JSON error report");
+    assert!(v["error"].is_string());
+    unsafe { capi::modelwrite_free_string(ptr) };
+}
diff --git a/engine/gate/Cargo.toml b/engine/gate/Cargo.toml
new file mode 100644
index 0000000..de494c5
--- /dev/null
+++ b/engine/gate/Cargo.toml
@@ -0,0 +1,23 @@
+[package]
+name = "mw-gate"
+version = "0.1.0"
+edition.workspace = true
+rust-version.workspace = true
+license.workspace = true
+publish = false
+
+[lib]
+name = "gate"
+
+[[bin]]
+name = "mw-gate"
+path = "src/main.rs"
+
+[dependencies]
+mw-okf = { path = "../okf" }
+mw-graph = { path = "../graph" }
+anyhow.workspace = true
+serde_json.workspace = true
+
+[dev-dependencies]
+mw-test-support = { path = "../test-support" }
diff --git a/engine/gate/src/lib.rs b/engine/gate/src/lib.rs
new file mode 100644
index 0000000..289a298
--- /dev/null
+++ b/engine/gate/src/lib.rs
@@ -0,0 +1,150 @@
+// SPDX-License-Identifier: AGPL-3.0-or-later
+use graph::{graph_stats, requirement_coverage};
+use okf::{diff, hash, types::OkfRoot, validate};
+use serde_json::json;
+
+pub struct GateOutcome {
+    pub passed: bool,
+    pub failures: Vec<String>,
+    pub evidence: serde_json::Value,
+}
+
+/// The provable gate: round-trip fidelity plus graph health, with evidence
+/// recorded for every run. The evidence is deterministic: given the same
+/// inputs, the record reproduces exactly.
+pub fn run(reference: &OkfRoot, candidate: &OkfRoot, strict_coverage: bool) -> GateOutcome {
+    let mut failures: Vec<String> = Vec::new();
+
+    let d = diff::diff(reference, candidate);
+    if !d.equal {
+        failures.push(format!(
+            "roundtrip: {} missing elements, {} extra elements, {} missing edges, {} extra edges, {} changed attributes",
+            d.missing_elements.len(),
+            d.extra_elements.len(),
+            d.missing_edges.len(),
+            d.extra_edges.len(),
+            d.changed_attributes.len()
+        ));
+    }
+
+    let v = validate::validate(candidate);
+    if !v.valid {
+        for e in &v.errors {
+            failures.push(format!("validation: {}", e));
+        }
+    }
+
+    // A candidate can lose its graph section entirely. Validation already records that
+    // as an error, so the gate must report a failure rather than panic inside the graph
+    // helpers, which require a graph to exist. Exit code 1 is the contract for a lossy
+    // candidate; a crash would be neither a pass nor a failure.
+    let stats = if candidate.graph.is_some() {
+        Some(graph_stats(candidate))
+    } else {
+        failures.push("integration: candidate has no graph section".to_string());
+        None
+    };
+    if let Some(stats) = &stats {
+        if !stats.isolated.is_empty() {
+            failures.push(format!(
+                "integration: {} isolated nodes",
+                stats.isolated.len()
+            ));
+        }
+        if stats.component_count != 1 {
+            failures.push(format!(
+                "integration: {} connected components",
+                stats.component_count
+            ));
+        }
+    }
+
+    let cov = if candidate.graph.is_some() {
+        Some(requirement_coverage(candidate))
+    } else {
+        None
+    };
+    if let Some(cov) = &cov {
+        if strict_coverage && !cov.uncovered.is_empty() {
+            failures.push(format!(
+                "coverage: {} uncovered requirements",
+                cov.uncovered.len()
+            ));
+        }
+    }
+
+    let evidence = json!({
+        "gateVersion": env!("CARGO_PKG_VERSION"),
+        "okfVersion": "1.0",
+        "referenceHash": hash::canonical_hash(reference),
+        "candidateHash": hash::canonical_hash(candidate),
+        "roundtrip": {
+            "equal": d.equal,
+            "missingElements": d.missing_elements,
+            "extraElements": d.extra_elements,
+            "missingEdges": d.missing_edges,
+            "extraEdges": d.extra_edges,
+            "changedAttributes": d.changed_attributes
+        },
+        // The schema stays stable when the candidate has no graph: the keys are always
+        // present, with empty values, so a consumer never has to handle a missing object.
+        "integration": match &stats {
+            Some(s) => json!({
+                "isolated": s.isolated,
+                "componentCount": s.component_count,
+                "componentSizes": s.component_sizes
+            }),
+            None => json!({
+                "isolated": [],
+                "componentCount": 0,
+                "componentSizes": []
+            })
+        },
+        "coverage": match &cov {
+            Some(c) => json!({
+                "total": c.total,
+                "satisfied": c.satisfied,
+                "refined": c.refined,
+                "verified": c.verified,
+                "allocated": c.allocated,
+                "covered": c.covered,
+                "uncovered": c.uncovered
+            }),
+            // Without a graph nothing can be shown to be covered, but the requirement
+            // count is still known: reporting total 0 would understate the model. Every
+            // requirement the candidate retains is reported as uncovered, which is the
+            // truthful reading and keeps the evidence schema stable.
+            None => {
+                let mut uncovered: Vec<String> =
+                    candidate.requirements.iter().map(|r| r.id.clone()).collect();
+                uncovered.sort();
+                json!({
+                    "total": candidate.requirements.len(),
+                    "satisfied": 0,
+                    "refined": 0,
+                    "verified": 0,
+                    "allocated": 0,
+                    "covered": 0,
+                    "uncovered": uncovered
+                })
+            }
+        },
+        "strictCoverage": strict_coverage,
+        "validationErrors": v.errors,
+        "validationWarnings": v.warnings,
+        "passed": failures.is_empty(),
+        "failures": failures
+    });
+
+    GateOutcome {
+        passed: failures.is_empty(),
+        failures,
+        evidence,
+    }
+}
+
+pub fn write_evidence(path: &std::path::Path, evidence: &serde_json::Value) -> anyhow::Result<()> {
+    let text = serde_json::to_string_pretty(evidence)?;
+    std::fs::write(path, text)?;
+    Ok(())
+}
diff --git a/engine/gate/src/main.rs b/engine/gate/src/main.rs
new file mode 100644
index 0000000..78aa8fa
--- /dev/null
+++ b/engine/gate/src/main.rs
@@ -0,0 +1,85 @@
+// SPDX-License-Identifier: AGPL-3.0-or-later
+use std::path::PathBuf;
+use std::process::ExitCode;
+
+use okf::types::OkfRoot;
+
+fn main() -> ExitCode {
+    let mut reference: Option<PathBuf> = None;
+    let mut candidate: Option<PathBuf> = None;
+    let mut evidence: Option<PathBuf> = None;
+    let mut json_output = false;
+    let mut strict_coverage = false;
+    let mut args = std::env::args().skip(1);
+    while let Some(a) = args.next() {
+        match a.as_str() {
+            "--reference" => match args.next() {
+                Some(v) => reference = Some(PathBuf::from(v)),
+                None => {
+                    eprintln!("--reference requires a file path");
+                    return ExitCode::from(2);
+                }
+            },
+            "--candidate" => match args.next() {
+                Some(v) => candidate = Some(PathBuf::from(v)),
+                None => {
+                    eprintln!("--candidate requires a file path");
+                    return ExitCode::from(2);
+                }
+            },
+            "--evidence" => match args.next() {
+                Some(v) => evidence = Some(PathBuf::from(v)),
+                None => {
+                    eprintln!("--evidence requires a file path");
+                    return ExitCode::from(2);
+                }
+            },
+            "--json" => json_output = true,
+            "--strict-coverage" => strict_coverage = true,
+            _ => {
+                eprintln!("unknown argument: {}", a);
+                return ExitCode::from(2);
+            }
+        }
+    }
+    let (Some(reference), Some(candidate)) = (reference, candidate) else {
+        eprintln!("usage: mw-gate --reference FILE --candidate FILE [--evidence FILE] [--json] [--strict-coverage]");
+        return ExitCode::from(2);
+    };
+    let read = |p: &PathBuf| -> anyhow::Result<OkfRoot> {
+        let text = std::fs::read_to_string(p)?;
+        Ok(serde_json::from_str(&text)?)
+    };
+    let (reference, candidate) = match (read(&reference), read(&candidate)) {
+        (Ok(r), Ok(c)) => (r, c),
+        (Err(e), _) | (_, Err(e)) => {
+            eprintln!("failed to read input: {:#}", e);
+            return ExitCode::from(2);
+        }
+    };
+    let outcome = gate::run(&reference, &candidate, strict_coverage);
+    if let Some(path) = &evidence {
+        if let Err(e) = gate::write_evidence(path, &outcome.evidence) {
+            eprintln!("failed to write evidence: {:#}", e);
+            return ExitCode::from(2);
+        }
+    }
+    if json_output {
+        println!(
+            "{}",
+            serde_json::to_string(&outcome.evidence).expect("evidence serializes")
+        );
+    } else if outcome.passed {
+        println!("GATE PASS");
+    } else {
+        println!("GATE FAIL");
+        for f in &outcome.failures {
+            println!("- {}", f);
+        }
+    }
+    if outcome.passed {
+        ExitCode::SUCCESS
+    } else {
+        ExitCode::from(1)
+    }
+}
diff --git a/engine/gate/tests/gate.rs b/engine/gate/tests/gate.rs
new file mode 100644
index 0000000..b650aaf
--- /dev/null
+++ b/engine/gate/tests/gate.rs
@@ -0,0 +1,112 @@
+// SPDX-License-Identifier: AGPL-3.0-or-later
+use okf::types::OkfRoot;
+
+fn expected() -> OkfRoot {
+    serde_json::from_str(&test_support::load_okf_expected()).expect("corpus fixture parses")
+}
+
+fn okf(text: &str) -> OkfRoot {
+    serde_json::from_str(text).expect("test OKF parses")
+}
+
+const TINY_GATE: &str = r#"{
+  "project": "tiny",
+  "exportedAt": "2026-09-17T00:00:00Z",
+  "summary": {},
+  "stateMachine": {"name": "tiny sm", "regions": []},
+  "requirements": [
+    {"id": "r1", "name": "R1", "kind": "requirement", "stereotypes": ["Requirement"], "attributes": [], "documentation": "", "reqId": "1.1", "reqText": "covered"},
+    {"id": "r2", "name": "R2", "kind": "requirement", "stereotypes": ["Requirement"], "attributes": [], "documentation": "", "reqId": "1.2", "reqText": "uncovered"}
+  ],
+  "graph": {
+    "nodes": [
+      {"id": "p1", "kind": "block", "name": "P1"},
+      {"id": "r1", "kind": "requirement", "name": "R1"},
+      {"id": "r2", "kind": "requirement", "name": "R2"}
+    ],
+    "edges": [
+      {"source": "p1", "target": "r1", "kind": "dependency", "label": "Satisfy"},
+      {"source": "p1", "target": "r2", "kind": "reference", "label": ""}
+    ]
+  }
+}"#;
+
+#[test]
+fn self_roundtrip_passes() {
+    let r = expected();
+    let outcome = gate::run(&r, &r, false);
+    assert!(
+        outcome.passed,
+        "unexpected failures: {:?}",
+        outcome.failures
+    );
+    assert_eq!(outcome.evidence["passed"], true);
+    assert_eq!(
+        outcome.evidence["referenceHash"],
+        outcome.evidence["candidateHash"]
+    );
+}
+
+#[test]
+fn corrupted_corpus_fails() {
+    let reference = expected();
+    let candidate: OkfRoot =
+        serde_json::from_str(&test_support::load_okf_broken()).expect("broken fixture parses");
+    let outcome = gate::run(&reference, &candidate, false);
+    assert!(!outcome.passed);
+    assert!(outcome
+        .failures
+        .iter()
+        .any(|f| f.contains("missing elements")));
+    assert!(outcome.failures.iter().any(|f| f.contains("isolated")));
+}
+
+#[test]
+fn strict_coverage_fails_on_uncovered() {
+    let r = okf(TINY_GATE);
+    let lenient = gate::run(&r, &r, false);
+    assert!(
+        lenient.passed,
+        "unexpected failures: {:?}",
+        lenient.failures
+    );
+    let strict = gate::run(&r, &r, true);
+    assert!(!strict.passed);
+    assert!(strict
+        .failures
+        .iter()
+        .any(|f| f.contains("uncovered requirements")));
+}
+#[test]
+fn candidate_without_a_graph_fails_instead_of_panicking() {
+    // A lossy candidate can lose its graph section outright. The gate must report a
+    // failure with exit-code-1 semantics, never panic inside the graph helpers.
+    let reference = expected();
+    let candidate = okf(r#"{
+  "project": "no graph",
+  "exportedAt": "2026-09-17T00:00:00Z",
+  "summary": {},
+  "stateMachine": {"name": "sm", "regions": []},
+  "requirements": [
+    {"id": "r1", "name": "R1", "kind": "requirement", "stereotypes": ["Requirement"], "attributes": [], "documentation": "", "reqId": "1.1", "reqText": "no graph to trace through"}
+  ],
+  "graph": null
+}"#);
+    let outcome = gate::run(&reference, &candidate, false);
+    assert!(!outcome.passed);
+    assert!(outcome
+        .failures
+        .iter()
+        .any(|f| f.contains("no graph section")));
+    assert_eq!(outcome.evidence["integration"]["componentCount"], 0);
+    // Coverage must not understate the model: the retained requirement is reported as
+    // uncovered rather than the total being reported as zero.
+    assert_eq!(outcome.evidence["coverage"]["total"], 1);
+    assert_eq!(
+        outcome.evidence["coverage"]["uncovered"]
+            .as_array()
+            .unwrap()
+            .len(),
+        1
+    );
+}
diff --git a/engine/graph/Cargo.toml b/engine/graph/Cargo.toml
new file mode 100644
index 0000000..c1d100a
--- /dev/null
+++ b/engine/graph/Cargo.toml
@@ -0,0 +1,19 @@
+[package]
+name = "mw-graph"
+version = "0.1.0"
+edition.workspace = true
+rust-version.workspace = true
+license.workspace = true
+publish = false
+
+[lib]
+name = "graph"
+
+[dependencies]
+mw-okf = { path = "../okf" }
+petgraph.workspace = true
+serde.workspace = true
+
+[dev-dependencies]
+mw-test-support = { path = "../test-support" }
+serde_json.workspace = true
diff --git a/engine/graph/src/lib.rs b/engine/graph/src/lib.rs
new file mode 100644
index 0000000..d57b75f
--- /dev/null
+++ b/engine/graph/src/lib.rs
@@ -0,0 +1,136 @@
+// SPDX-License-Identifier: AGPL-3.0-or-later
+use std::collections::{HashMap, HashSet};
+
+use okf::types::OkfRoot;
+use petgraph::unionfind::UnionFind;
+use serde::Serialize;
+
+#[derive(Debug, Clone, Serialize)]
+pub struct GraphStats {
+    pub node_count: usize,
+    pub edge_count: usize,
+    pub isolated: Vec<String>,
+    pub component_count: usize,
+    pub component_sizes: Vec<usize>,
+}
+
+pub fn graph_stats(root: &OkfRoot) -> GraphStats {
+    let graph = root.graph.as_ref().expect("graph required; validate first");
+    let node_count = graph.nodes.len();
+    let edge_count = graph.edges.len();
+    let index: HashMap<&str, usize> = graph
+        .nodes
+        .iter()
+        .enumerate()
+        .map(|(i, n)| (n.id.as_str(), i))
+        .collect();
+    let mut uf = UnionFind::new(node_count);
+    let mut degree = vec![0usize; node_count];
+    for e in &graph.edges {
+        if let (Some(&a), Some(&b)) = (index.get(e.source.as_str()), index.get(e.target.as_str())) {
+            degree[a] += 1;
+            degree[b] += 1;
+            uf.union(a, b);
+        }
+    }
+    let isolated: Vec<String> = graph
+        .nodes
+        .iter()
+        .enumerate()
+        .filter(|(i, _)| degree[*i] == 0)
+        .map(|(_, n)| n.id.clone())
+        .collect();
+    let mut sizes: HashMap<usize, usize> = HashMap::new();
+    for i in 0..node_count {
+        *sizes.entry(uf.find(i)).or_insert(0) += 1;
+    }
+    let mut component_sizes: Vec<usize> = sizes.into_values().collect();
+    component_sizes.sort_unstable_by(|a, b| b.cmp(a));
+    let component_count = component_sizes.len();
+    GraphStats {
+        node_count,
+        edge_count,
+        isolated,
+        component_count,
+        component_sizes,
+    }
+}
+
+#[derive(Debug, Clone, Serialize)]
+pub struct CoverageReport {
+    pub total: usize,
+    pub satisfied: usize,
+    pub refined: usize,
+    pub verified: usize,
+    pub allocated: usize,
+    pub covered: usize,
+    pub uncovered: Vec<String>,
+}
+
+/// Requirement coverage read from dependency edges whose label is exactly
+/// Satisfy, Refine, Verify or Allocate.
+pub fn requirement_coverage(root: &OkfRoot) -> CoverageReport {
+    let req_ids: HashSet<&str> = root.requirements.iter().map(|r| r.id.as_str()).collect();
+    let graph = root.graph.as_ref().expect("graph required; validate first");
+    let mut satisfied = 0usize;
+    let mut refined = 0usize;
+    let mut verified = 0usize;
+    let mut allocated = 0usize;
+    let mut covered: HashSet<&str> = HashSet::new();
+    for e in &graph.edges {
+        if e.kind != "dependency" {
+            continue;
+        }
+        let s = e.source.as_str();
+        let t = e.target.as_str();
+        match e.label.as_str() {
+            "Satisfy" => {
+                if req_ids.contains(t) {
+                    satisfied += 1;
+                    covered.insert(t);
+                }
+            }
+            "Refine" => {
+                if req_ids.contains(t) {
+                    refined += 1;
+                    covered.insert(t);
+                }
+            }
+            "Verify" => {
+                if req_ids.contains(t) {
+                    verified += 1;
+                    covered.insert(t);
+                }
+            }
+            "Allocate" if req_ids.contains(t) || req_ids.contains(s) => {
+                allocated += 1;
+                // Count only endpoints that really are requirements. An allocate edge
+                // can connect a function to a part, and inserting a non-requirement id
+                // here would inflate the covered count reported in the gate evidence.
+                if req_ids.contains(t) {
+                    covered.insert(t);
+                }
+                if req_ids.contains(s) {
+                    covered.insert(s);
+                }
+            }
+            _ => {}
+        }
+    }
+    let mut uncovered: Vec<String> = root
+        .requirements
+        .iter()
+        .filter(|r| !covered.contains(r.id.as_str()))
+        .map(|r| r.id.clone())
+        .collect();
+    uncovered.sort();
+    CoverageReport {
+        total: req_ids.len(),
+        satisfied,
+        refined,
+        verified,
+        allocated,
+        covered: covered.len(),
+        uncovered,
+    }
+}
diff --git a/engine/graph/tests/graph_stats.rs b/engine/graph/tests/graph_stats.rs
new file mode 100644
index 0000000..a80a7f4
--- /dev/null
+++ b/engine/graph/tests/graph_stats.rs
@@ -0,0 +1,108 @@
+// SPDX-License-Identifier: AGPL-3.0-or-later
+use graph::{graph_stats, requirement_coverage};
+use okf::types::OkfRoot;
+
+fn expected() -> OkfRoot {
+    serde_json::from_str(&test_support::load_okf_expected()).expect("corpus fixture parses")
+}
+
+fn okf(text: &str) -> OkfRoot {
+    serde_json::from_str(text).expect("test OKF parses")
+}
+
+const TINY: &str = r#"{
+  "project": "tiny",
+  "exportedAt": "2026-09-17T00:00:00Z",
+  "summary": {},
+  "stateMachine": {"name": "tiny sm", "regions": []},
+  "requirements": [
+    {"id": "r1", "name": "R1", "kind": "requirement", "stereotypes": ["Requirement"], "attributes": [], "documentation": "", "reqId": "1.1", "reqText": "covered"},
+    {"id": "r2", "name": "R2", "kind": "requirement", "stereotypes": ["Requirement"], "attributes": [], "documentation": "", "reqId": "1.2", "reqText": "uncovered"}
+  ],
+  "graph": {
+    "nodes": [
+      {"id": "p1", "kind": "block", "name": "P1"},
+      {"id": "r1", "kind": "requirement", "name": "R1"},
+      {"id": "r2", "kind": "requirement", "name": "R2"}
+    ],
+    "edges": [
+      {"source": "p1", "target": "r1", "kind": "dependency", "label": "Satisfy"}
+    ]
+  }
+}"#;
+
+#[test]
+fn corpus_is_fully_integrated() {
+    let stats = graph_stats(&expected());
+    assert_eq!(stats.node_count, 99);
+    assert_eq!(stats.edge_count, 165);
+    assert!(stats.isolated.is_empty(), "isolated: {:?}", stats.isolated);
+    assert_eq!(stats.component_count, 1);
+    assert_eq!(stats.component_sizes, vec![99]);
+}
+
+#[test]
+fn isolated_node_is_detected() {
+    let stats = graph_stats(&okf(TINY));
+    assert_eq!(stats.isolated, vec!["r2"]);
+}
+
+#[test]
+fn two_components_are_counted() {
+    let stats = graph_stats(&okf(TINY));
+    assert_eq!(stats.component_count, 2);
+    assert_eq!(stats.component_sizes, vec![2, 1]);
+}
+
+#[test]
+fn coverage_counts_traceability() {
+    let cov = requirement_coverage(&okf(TINY));
+    assert_eq!(cov.total, 2);
+    assert_eq!(cov.satisfied, 1);
+    assert_eq!(cov.covered, 1);
+    assert_eq!(cov.uncovered, vec!["r2"]);
+}
+
+/// The reference model carries 20 Satisfy, 3 Refine, 1 Verify and 3 Allocate edges,
+/// and 15 of its 25 requirements are covered by at least one of them. Pinning the
+/// coverage keeps this measured claim honest: it is the number the gate reports.
+#[test]
+fn corpus_coverage_is_pinned() {
+    let cov = requirement_coverage(&expected());
+    assert_eq!(cov.total, 25);
+    assert_eq!(cov.satisfied, 20);
+    assert_eq!(cov.refined, 3);
+    assert_eq!(cov.verified, 1);
+    assert_eq!(cov.allocated, 0);
+    assert_eq!(cov.covered, 15);
+    assert_eq!(cov.uncovered.len(), 10);
+}
+/// Regression check for the coverage inflation bug: an allocate edge from a part to a
+/// requirement must cover the requirement and must NOT add the part to covered. The old
+/// unconditional insert would have reported covered = 2 for a single requirement.
+#[test]
+fn allocate_edge_counts_only_requirement_endpoints() {
+    const ALLOC: &str = r#"{
+  "project": "alloc",
+  "exportedAt": "2026-09-17T00:00:00Z",
+  "summary": {},
+  "stateMachine": {"name": "alloc sm", "regions": []},
+  "requirements": [
+    {"id": "r1", "name": "R1", "kind": "requirement", "stereotypes": ["Requirement"], "attributes": [], "documentation": "", "reqId": "1.1", "reqText": "allocated to a part"}
+  ],
+  "graph": {
+    "nodes": [
+      {"id": "p1", "kind": "block", "name": "P1"},
+      {"id": "r1", "kind": "requirement", "name": "R1"}
+    ],
+    "edges": [
+      {"source": "p1", "target": "r1", "kind": "dependency", "label": "Allocate"}
+    ]
+  }
+}"#;
+    let cov = requirement_coverage(&okf(ALLOC));
+    assert_eq!(cov.total, 1);
+    assert_eq!(cov.allocated, 1);
+    assert_eq!(cov.covered, 1);
+    assert!(cov.uncovered.is_empty());
+}
diff --git a/engine/include/modelwrite.h b/engine/include/modelwrite.h
new file mode 100644
index 0000000..72ffc87
--- /dev/null
+++ b/engine/include/modelwrite.h
@@ -0,0 +1,30 @@
+/* SPDX-License-Identifier: AGPL-3.0-or-later */
+#ifndef MODELWRITE_H
+#define MODELWRITE_H
+
+#include <stddef.h>
+
+#ifdef __cplusplus
+extern "C" {
+#endif
+
+/* Version string; never free it. */
+const char *modelwrite_version(void);
+
+/* Validate one OKF JSON document; returns a JSON report string.
+   The caller owns the result and must free it with modelwrite_free_string. */
+char *modelwrite_validate(const unsigned char *json, size_t len);
+
+/* Run the round-trip fidelity gate; returns the JSON evidence string.
+   The caller owns the result and must free it with modelwrite_free_string. */
+char *modelwrite_gate(const unsigned char *reference, size_t reference_len,
+                      const unsigned char *candidate, size_t candidate_len);
+
+/* Free a string returned by this library. */
+void modelwrite_free_string(char *ptr);
+
+#ifdef __cplusplus
+}
+#endif
+
+#endif
diff --git a/engine/mcp/Cargo.toml b/engine/mcp/Cargo.toml
new file mode 100644
index 0000000..338877b
--- /dev/null
+++ b/engine/mcp/Cargo.toml
@@ -0,0 +1,24 @@
+[package]
+name = "mw-mcp"
+version = "0.1.0"
+edition.workspace = true
+rust-version.workspace = true
+license.workspace = true
+publish = false
+
+[lib]
+name = "mcp"
+
+[[bin]]
+name = "mw-mcp"
+path = "src/main.rs"
+
+[dependencies]
+mw-okf = { path = "../okf" }
+mw-graph = { path = "../graph" }
+mw-gate = { path = "../gate" }
+serde_json.workspace = true
+
+[dev-dependencies]
+mw-test-support = { path = "../test-support" }
+serde_json.workspace = true
diff --git a/engine/mcp/src/lib.rs b/engine/mcp/src/lib.rs
new file mode 100644
index 0000000..885db49
--- /dev/null
+++ b/engine/mcp/src/lib.rs
@@ -0,0 +1,210 @@
+// SPDX-License-Identifier: AGPL-3.0-or-later
+use serde_json::{json, Value};
+
+fn tool_error(message: &str) -> Value {
+    json!({ "content": [{ "type": "text", "text": message }], "isError": true })
+}
+
+fn tool_ok(text: String) -> Value {
+    json!({ "content": [{ "type": "text", "text": text }], "isError": false })
+}
+
+fn call_tool(msg: &Value) -> Value {
+    let params = msg.get("params");
+    let name = params
+        .and_then(|p| p.get("name"))
+        .and_then(Value::as_str)
+        .unwrap_or("");
+    let args = params
+        .and_then(|p| p.get("arguments"))
+        .cloned()
+        .unwrap_or_else(|| json!({}));
+    match name {
+        "okf.validate" => {
+            let Some(okf) = args.get("okf").and_then(Value::as_str) else {
+                return tool_error("missing okf argument");
+            };
+            match serde_json::from_str::<okf::types::OkfRoot>(okf) {
+                Err(e) => tool_error(&format!("parse error: {}", e)),
+                Ok(root) => {
+                    let report = okf::validate::validate(&root);
+                    tool_ok(serde_json::to_string_pretty(&report).expect("report serializes"))
+                }
+            }
+        }
+        "graph.stats" => {
+            let Some(okf) = args.get("okf").and_then(Value::as_str) else {
+                return tool_error("missing okf argument");
+            };
+            match serde_json::from_str::<okf::types::OkfRoot>(okf) {
+                Err(e) => tool_error(&format!("parse error: {}", e)),
+                Ok(root) => {
+                    let stats = graph::graph_stats(&root);
+                    tool_ok(serde_json::to_string_pretty(&stats).expect("stats serialize"))
+                }
+            }
+        }
+        "gate.run" => {
+            let reference = args.get("reference").and_then(Value::as_str);
+            let candidate = args.get("candidate").and_then(Value::as_str);
+            let strict = args
+                .get("strictCoverage")
+                .and_then(Value::as_bool)
+                .unwrap_or(false);
+            let (Some(reference), Some(candidate)) = (reference, candidate) else {
+                return tool_error("missing reference or candidate argument");
+            };
+            let parse = |s: &str| serde_json::from_str::<okf::types::OkfRoot>(s);
+            match (parse(reference), parse(candidate)) {
+                (Err(e), _) | (_, Err(e)) => tool_error(&format!("parse error: {}", e)),
+                (Ok(reference), Ok(candidate)) => {
+                    let outcome = gate::run(&reference, &candidate, strict);
+                    tool_ok(
+                        serde_json::to_string_pretty(&outcome.evidence)
+                            .expect("evidence serializes"),
+                    )
+                }
+            }
+        }
+        "okf.diff" => {
+            let reference = args.get("reference").and_then(Value::as_str);
+            let candidate = args.get("candidate").and_then(Value::as_str);
+            let (Some(reference), Some(candidate)) = (reference, candidate) else {
+                return tool_error("missing reference or candidate argument");
+            };
+            let parse = |s: &str| serde_json::from_str::<okf::types::OkfRoot>(s);
+            match (parse(reference), parse(candidate)) {
+                (Err(e), _) | (_, Err(e)) => tool_error(&format!("parse error: {}", e)),
+                (Ok(reference), Ok(candidate)) => {
+                    // DiffReport already serializes as camelCase, so the report is the
+                    // payload: no hand-rolled key mapping can drift from the type.
+                    let report = okf::diff::diff(&reference, &candidate);
+                    tool_ok(serde_json::to_string_pretty(&report).expect("diff serializes"))
+                }
+            }
+        }
+        _ => tool_error(&format!("unknown tool: {}", name)),
+    }
+}
+
+pub fn handle_request(line: &str) -> String {
+    let msg: Value = match serde_json::from_str(line) {
+        Ok(m) => m,
+        Err(e) => {
+            return json!({
+                "jsonrpc": "2.0",
+                "id": null,
+                "error": { "code": -32700, "message": format!("parse error: {}", e) }
+            })
+            .to_string();
+        }
+    };
+    let id = msg.get("id").cloned().unwrap_or(Value::Null);
+    let method = msg.get("method").and_then(Value::as_str).unwrap_or("");
+    if method.is_empty() {
+        return json!({
+            "jsonrpc": "2.0",
+            "id": id,
+            "error": { "code": -32600, "message": "method missing" }
+        })
+        .to_string();
+    }
+    if id.is_null() {
+        return String::new();
+    }
+    let result = match method {
+        "initialize" => json!({
+            "protocolVersion": "2024-11-05",
+            "capabilities": { "tools": {} },
+            "serverInfo": { "name": "modelwrite-mcp", "version": env!("CARGO_PKG_VERSION") }
+        }),
+        "tools/list" => json!({ "tools": [
+            {
+                "name": "okf.validate",
+                "description": "Validate an OKF JSON document",
+                "inputSchema": {
+                    "type": "object",
+                    "properties": { "okf": { "type": "string" } },
+                    "required": ["okf"]
+                }
+            },
+            {
+                "name": "graph.stats",
+                "description": "Graph health of an OKF document",
+                "inputSchema": {
+                    "type": "object",
+                    "properties": { "okf": { "type": "string" } },
+                    "required": ["okf"]
+                }
+            },
+            {
+                "name": "gate.run",
+                "description": "Round-trip fidelity gate between two OKF documents",
+                "inputSchema": {
+                    "type": "object",
+                    "properties": {
+                        "reference": { "type": "string" },
+                        "candidate": { "type": "string" },
+                        "strictCoverage": { "type": "boolean" }
+                    },
+                    "required": ["reference", "candidate"]
+                }
+            },
+            {
+                "name": "okf.diff",
+                "description": "Semantic diff between two OKF documents: elements, edges and attributes",
+                "inputSchema": {
+                    "type": "object",
+                    "properties": {
+                        "reference": { "type": "string" },
+                        "candidate": { "type": "string" }
+                    },
+                    "required": ["reference", "candidate"]
+                }
+            }
+        ] }),
+        "resources/list" => json!({ "resources": [
+            {
+                "uri": "mw://okf/1.0/spec",
+                "name": "OKF 1.0 specification",
+                "mimeType": "text/markdown"
+            },
+            {
+                "uri": "mw://evidence/latest",
+                "name": "latest gate evidence",
+                "mimeType": "application/json"
+            }
+        ] }),
+        "resources/read" => {
+            let uri = msg
+                .get("params")
+                .and_then(|p| p.get("uri"))
+                .and_then(Value::as_str)
+                .unwrap_or("");
+            if uri == "mw://okf/1.0/spec" {
+                let path = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
+                    .join("../../docs/okf/okf-1.0-spec.md");
+                match std::fs::read_to_string(&path) {
+                    Ok(text) => {
+                        json!({ "contents": [{ "uri": uri, "mimeType": "text/markdown", "text": text }] })
+                    }
+                    Err(e) => {
+                        json!({ "contents": [], "error": format!("cannot read spec: {}", e) })
+                    }
+                }
+            } else {
+                json!({ "contents": [] })
+            }
+        }
+        "tools/call" => call_tool(&msg),
+        _ => {
+            return json!({
+                "jsonrpc": "2.0",
+                "id": id,
+                "error": { "code": -32601, "message": format!("method not found: {}", method) }
+            })
+            .to_string();
+        }
+    };
+    json!({ "jsonrpc": "2.0", "id": id, "result": result }).to_string()
+}
diff --git a/engine/mcp/src/main.rs b/engine/mcp/src/main.rs
new file mode 100644
index 0000000..51e1bb7
--- /dev/null
+++ b/engine/mcp/src/main.rs
@@ -0,0 +1,22 @@
+// SPDX-License-Identifier: AGPL-3.0-or-later
+use std::io::{BufRead, Write};
+
+fn main() {
+    let stdin = std::io::stdin();
+    let stdout = std::io::stdout();
+    let mut out = stdout.lock();
+    for line in stdin.lock().lines() {
+        let Ok(line) = line else { break };
+        if line.trim().is_empty() {
+            continue;
+        }
+        let response = mcp::handle_request(&line);
+        if response.is_empty() {
+            continue;
+        }
+        if writeln!(out, "{}", response).is_err() {
+            break;
+        }
+        let _ = out.flush();
+    }
+}
diff --git a/engine/mcp/tests/mcp.rs b/engine/mcp/tests/mcp.rs
new file mode 100644
index 0000000..6959426
--- /dev/null
+++ b/engine/mcp/tests/mcp.rs
@@ -0,0 +1,127 @@
+// SPDX-License-Identifier: AGPL-3.0-or-later
+use serde_json::{json, Value};
+
+fn call(payload: Value) -> Value {
+    let out = mcp::handle_request(&payload.to_string());
+    serde_json::from_str(&out).expect("valid JSON-RPC response")
+}
+
+#[test]
+fn initialize_returns_server_info() {
+    let resp = call(json!({ "jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {} }));
+    assert_eq!(resp["id"], 1);
+    assert_eq!(resp["result"]["serverInfo"]["name"], "modelwrite-mcp");
+    assert_eq!(resp["result"]["protocolVersion"], "2024-11-05");
+}
+
+#[test]
+fn tools_list_exposes_the_agent_toolset() {
+    let resp = call(json!({ "jsonrpc": "2.0", "id": 2, "method": "tools/list", "params": {} }));
+    let names: Vec<&str> = resp["result"]["tools"]
+        .as_array()
+        .unwrap()
+        .iter()
+        .map(|t| t["name"].as_str().unwrap())
+        .collect();
+    assert_eq!(
+        names,
+        vec!["okf.validate", "graph.stats", "gate.run", "okf.diff"]
+    );
+}
+
+#[test]
+fn validate_tool_reports_invalid() {
+    let resp = call(json!({
+        "jsonrpc": "2.0",
+        "id": 3,
+        "method": "tools/call",
+        "params": { "name": "okf.validate", "arguments": { "okf": "{\"project\":\"x\"}" } }
+    }));
+    let text = resp["result"]["content"][0]["text"].as_str().unwrap();
+    let report: Value = serde_json::from_str(text).unwrap();
+    assert_eq!(report["valid"], false);
+}
+
+#[test]
+fn gate_tool_runs_roundtrip() {
+    let a = test_support::load_okf_expected();
+    let resp = call(json!({
+        "jsonrpc": "2.0",
+        "id": 4,
+        "method": "tools/call",
+        "params": { "name": "gate.run", "arguments": { "reference": a, "candidate": a } }
+    }));
+    let text = resp["result"]["content"][0]["text"].as_str().unwrap();
+    let evidence: Value = serde_json::from_str(text).unwrap();
+    assert!(evidence["passed"].as_bool().unwrap());
+}
+
+#[test]
+fn diff_tool_reports_a_removed_requirement() {
+    let reference = test_support::load_okf_expected();
+    let mut model: serde_json::Value = serde_json::from_str(&reference).unwrap();
+    model["requirements"].as_array_mut().unwrap().pop();
+    let candidate = model.to_string();
+    let resp = call(json!({
+        "jsonrpc": "2.0",
+        "id": 6,
+        "method": "tools/call",
+        "params": { "name": "okf.diff", "arguments": { "reference": reference, "candidate": candidate } }
+    }));
+    let text = resp["result"]["content"][0]["text"].as_str().unwrap();
+    let report: Value = serde_json::from_str(text).unwrap();
+    assert_eq!(report["equal"], false);
+    assert_eq!(report["missingElements"].as_array().unwrap().len(), 1);
+}
+
+#[test]
+fn resources_list_exposes_the_spec() {
+    let resp = call(json!({ "jsonrpc": "2.0", "id": 7, "method": "resources/list", "params": {} }));
+    let uris: Vec<&str> = resp["result"]["resources"]
+        .as_array()
+        .unwrap()
+        .iter()
+        .map(|r| r["uri"].as_str().unwrap())
+        .collect();
+    assert!(uris.contains(&"mw://okf/1.0/spec"));
+}
+
+#[test]
+fn unknown_method_returns_error() {
+    let resp = call(json!({ "jsonrpc": "2.0", "id": 5, "method": "nope", "params": {} }));
+    assert_eq!(resp["error"]["code"], -32601);
+}
+#[test]
+fn notification_gets_no_response() {
+    // A JSON-RPC notification carries no id and must never be answered.
+    let out = mcp::handle_request(
+        &json!({ "jsonrpc": "2.0", "method": "initialize", "params": {} }).to_string(),
+    );
+    assert!(
+        out.is_empty(),
+        "notifications must not be answered: {}",
+        out
+    );
+}
+
+#[test]
+fn malformed_input_returns_a_parse_error() {
+    let resp: Value = serde_json::from_str(&mcp::handle_request("this is not json"))
+        .expect("a valid JSON-RPC error response");
+    assert_eq!(resp["error"]["code"], -32700);
+    assert!(resp["id"].is_null());
+}
+
+#[test]
+fn tool_error_is_reported_in_the_result_not_the_transport() {
+    // A missing argument is a tool failure, not a transport failure: the JSON-RPC
+    // envelope must stay a success so an agent can read the error and adapt.
+    let resp = call(json!({
+        "jsonrpc": "2.0",
+        "id": 9,
+        "method": "tools/call",
+        "params": { "name": "okf.validate", "arguments": {} }
+    }));
+    assert!(resp.get("error").is_none(), "unexpected error: {}", resp);
+    assert_eq!(resp["result"]["isError"], true);
+}
diff --git a/engine/okf/Cargo.toml b/engine/okf/Cargo.toml
new file mode 100644
index 0000000..f54a454
--- /dev/null
+++ b/engine/okf/Cargo.toml
@@ -0,0 +1,19 @@
+[package]
+name = "mw-okf"
+version = "0.1.0"
+edition.workspace = true
+rust-version.workspace = true
+license.workspace = true
+publish = false
+
+[lib]
+name = "okf"
+
+[dependencies]
+serde.workspace = true
+serde_json.workspace = true
+sha2.workspace = true
+hex.workspace = true
+
+[dev-dependencies]
+mw-test-support = { path = "../test-support" }
diff --git a/engine/okf/src/diff.rs b/engine/okf/src/diff.rs
new file mode 100644
index 0000000..d62db39
--- /dev/null
+++ b/engine/okf/src/diff.rs
@@ -0,0 +1,200 @@
+// SPDX-License-Identifier: AGPL-3.0-or-later
+use std::collections::{BTreeMap, BTreeSet};
+
+use serde::Serialize;
+
+use crate::types::OkfRoot;
+
+/// The report's JSON contract is camelCase, matching every other contract the
+/// platform publishes (the OKF document itself, the gate evidence and the MCP tool
+/// results). A consumer must never have to special-case one payload's key style.
+#[derive(Debug, Clone, Serialize)]
+#[serde(rename_all = "camelCase")]
+pub struct DiffReport {
+    pub equal: bool,
+    pub missing_elements: Vec<String>,
+    pub extra_elements: Vec<String>,
+    pub missing_edges: Vec<String>,
+    pub extra_edges: Vec<String>,
+    pub changed_attributes: Vec<String>,
+}
+
+/// Every element id across all sections, plus every graph node id.
+pub fn element_ids(root: &OkfRoot) -> BTreeSet<String> {
+    let mut ids = BTreeSet::new();
+    for el in &root.structure {
+        ids.insert(el.id.clone());
+    }
+    for el in &root.interfaces {
+        ids.insert(el.id.clone());
+    }
+    for el in &root.signals {
+        ids.insert(el.id.clone());
+    }
+    for r in &root.requirements {
+        ids.insert(r.id.clone());
+    }
+    if let Some(sm) = &root.state_machine {
+        for region in &sm.regions {
+            for s in &region.states {
+                ids.insert(s.id.clone());
+            }
+        }
+    }
+    if let Some(graph) = &root.graph {
+        for n in &graph.nodes {
+            ids.insert(n.id.clone());
+        }
+    }
+    ids
+}
+
+/// Every relationship as a canonical key: a JSON array of source, target, kind and
+/// label, so a separator character inside a field cannot alias two distinct edges.
+pub fn edge_keys(root: &OkfRoot) -> BTreeSet<String> {
+    let mut keys = BTreeSet::new();
+    if let Some(graph) = &root.graph {
+        for e in &graph.edges {
+            let parts = [
+                e.source.as_str(),
+                e.target.as_str(),
+                e.kind.as_str(),
+                e.label.as_str(),
+            ];
+            if let Ok(key) = serde_json::to_string(&parts) {
+                keys.insert(key);
+            }
+        }
+    }
+    keys
+}
+
+/// Canonical JSON per comparable unit, keyed by "<section>:<id>".
+///
+/// The universe covers the document-level fields, every element-bearing section, and
+/// the activities section (which carries its own nodes and edges). Section scoping
+/// matters: the graph mirrors elements, so the same id appears both as a section item
+/// and as a graph node, and keying by id alone would let the graph entry mask a removal
+/// or a change in the section that owns the element.
+pub fn attribute_keys(root: &OkfRoot) -> BTreeMap<String, String> {
+    let mut map = BTreeMap::new();
+
+    if let Ok(v) = serde_json::to_string(&root.project) {
+        map.insert("doc:project".to_string(), v);
+    }
+    if let Ok(v) = serde_json::to_string(&root.okf) {
+        map.insert("doc:okf".to_string(), v);
+    }
+    if let Ok(v) = serde_json::to_string(&root.exported_at) {
+        map.insert("doc:exportedAt".to_string(), v);
+    }
+    if let Ok(v) = serde_json::to_string(&root.summary) {
+        map.insert("doc:summary".to_string(), v);
+    }
+    if let Ok(v) = serde_json::to_string(&root.provenance) {
+        map.insert("doc:provenance".to_string(), v);
+    }
+    if let Some(sm) = &root.state_machine {
+        if let Ok(v) = serde_json::to_string(sm) {
+            map.insert("doc:stateMachine".to_string(), v);
+        }
+    }
+
+    let mut put = |section: &str, id: &str, json: String| {
+        map.insert(format!("{}:{}", section, id), json);
+    };
+
+    for el in &root.structure {
+        if let Ok(v) = serde_json::to_string(el) {
+            put("structure", &el.id, v);
+        }
+    }
+    for el in &root.interfaces {
+        if let Ok(v) = serde_json::to_string(el) {
+            put("interfaces", &el.id, v);
+        }
+    }
+    for el in &root.signals {
+        if let Ok(v) = serde_json::to_string(el) {
+            put("signals", &el.id, v);
+        }
+    }
+    for r in &root.requirements {
+        if let Ok(v) = serde_json::to_string(r) {
+            put("requirements", &r.id, v);
+        }
+    }
+    if let Some(sm) = &root.state_machine {
+        for region in &sm.regions {
+            for s in &region.states {
+                if let Ok(v) = serde_json::to_string(s) {
+                    put("state", &s.id, v);
+                }
+            }
+        }
+    }
+    for (i, a) in root.activities.iter().enumerate() {
+        if let Ok(v) = serde_json::to_string(a) {
+            put("activity", &i.to_string(), v);
+        }
+    }
+    if let Some(graph) = &root.graph {
+        for n in &graph.nodes {
+            if let Ok(v) = serde_json::to_string(n) {
+                put("graphnode", &n.id, v);
+            }
+        }
+    }
+    map
+}
+
+pub fn diff(reference: &OkfRoot, candidate: &OkfRoot) -> DiffReport {
+    let ref_attrs = attribute_keys(reference);
+    let cand_attrs = attribute_keys(candidate);
+    let ref_edges = edge_keys(reference);
+    let cand_edges = edge_keys(candidate);
+
+    let mut missing_elements: Vec<String> = ref_attrs
+        .keys()
+        .filter(|k| !cand_attrs.contains_key(*k))
+        .cloned()
+        .collect();
+    let mut extra_elements: Vec<String> = cand_attrs
+        .keys()
+        .filter(|k| !ref_attrs.contains_key(*k))
+        .cloned()
+        .collect();
+
+    let mut changed_attributes: Vec<String> = Vec::new();
+    for (id, ref_value) in &ref_attrs {
+        if let Some(cand_value) = cand_attrs.get(id) {
+            if cand_value != ref_value {
+                changed_attributes.push(id.clone());
+            }
+        }
+    }
+
+    let mut missing_edges: Vec<String> = ref_edges.difference(&cand_edges).cloned().collect();
+    let mut extra_edges: Vec<String> = cand_edges.difference(&ref_edges).cloned().collect();
+
+    missing_elements.sort();
+    extra_elements.sort();
+    missing_edges.sort();
+    extra_edges.sort();
+    changed_attributes.sort();
+
+    let equal = missing_elements.is_empty()
+        && extra_elements.is_empty()
+        && missing_edges.is_empty()
+        && extra_edges.is_empty()
+        && changed_attributes.is_empty();
+
+    DiffReport {
+        equal,
+        missing_elements,
+        extra_elements,
+        missing_edges,
+        extra_edges,
+        changed_attributes,
+    }
+}
diff --git a/engine/okf/src/hash.rs b/engine/okf/src/hash.rs
new file mode 100644
index 0000000..a08111d
--- /dev/null
+++ b/engine/okf/src/hash.rs
@@ -0,0 +1,14 @@
+// SPDX-License-Identifier: AGPL-3.0-or-later
+use sha2::{Digest, Sha256};
+
+use crate::types::OkfRoot;
+
+/// Content fingerprint of an OKF snapshot: sha256 over the canonical
+/// serialization. Field order is fixed by the type definitions, so a given
+/// snapshot always hashes to the same value. It is a fingerprint, not a
+/// semantic identity; the gate uses diffing for equality.
+pub fn canonical_hash(root: &OkfRoot) -> String {
+    let bytes = serde_json::to_vec(root).expect("OkfRoot serialization cannot fail");
+    let digest = Sha256::digest(&bytes);
+    hex::encode(digest)
+}
diff --git a/engine/okf/src/lib.rs b/engine/okf/src/lib.rs
new file mode 100644
index 0000000..6362f85
--- /dev/null
+++ b/engine/okf/src/lib.rs
@@ -0,0 +1,5 @@
+// SPDX-License-Identifier: AGPL-3.0-or-later
+pub mod diff;
+pub mod hash;
+pub mod types;
+pub mod validate;
diff --git a/engine/okf/src/types.rs b/engine/okf/src/types.rs
new file mode 100644
index 0000000..0fd1bf2
--- /dev/null
+++ b/engine/okf/src/types.rs
@@ -0,0 +1,198 @@
+// SPDX-License-Identifier: AGPL-3.0-or-later
+use serde::{Deserialize, Serialize};
+
+#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
+pub struct Attribute {
+    pub name: String,
+    #[serde(rename = "type", default)]
+    pub attr_type: String,
+    #[serde(default)]
+    pub aggregation: String,
+    #[serde(default)]
+    pub default: String,
+}
+
+#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
+pub struct Element {
+    pub id: String,
+    #[serde(default)]
+    pub name: String,
+    #[serde(default)]
+    pub kind: String,
+    #[serde(default)]
+    pub stereotypes: Vec<String>,
+    #[serde(default)]
+    pub attributes: Vec<Attribute>,
+    #[serde(default)]
+    pub documentation: String,
+}
+
+#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
+pub struct Requirement {
+    pub id: String,
+    #[serde(default)]
+    pub name: String,
+    #[serde(default)]
+    pub kind: String,
+    #[serde(default)]
+    pub stereotypes: Vec<String>,
+    #[serde(default)]
+    pub attributes: Vec<Attribute>,
+    #[serde(default)]
+    pub documentation: String,
+    #[serde(rename = "reqId", default)]
+    pub req_id: String,
+    #[serde(rename = "reqText", default)]
+    pub req_text: String,
+}
+
+#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
+pub struct State {
+    pub id: String,
+    #[serde(default)]
+    pub name: String,
+    #[serde(default)]
+    pub entry: Option<String>,
+    #[serde(rename = "doActivity", default)]
+    pub do_activity: Option<String>,
+    #[serde(default)]
+    pub exit: Option<String>,
+}
+
+#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
+pub struct Region {
+    #[serde(default)]
+    pub states: Vec<State>,
+}
+
+#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
+pub struct StateMachine {
+    pub name: String,
+    #[serde(default)]
+    pub regions: Vec<Region>,
+}
+
+#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
+pub struct ActivityNode {
+    pub id: String,
+    #[serde(rename = "type", default)]
+    pub node_type: String,
+    #[serde(default)]
+    pub name: String,
+    #[serde(default)]
+    pub partition: Option<String>,
+}
+
+#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
+pub struct ActivityEdge {
+    #[serde(rename = "type", default)]
+    pub edge_type: String,
+    #[serde(default)]
+    pub source: String,
+    #[serde(default)]
+    pub target: String,
+    #[serde(default)]
+    pub guard: String,
+}
+
+/// A swim-lane on an activity diagram. The fixture stores partitions as
+/// objects with a name and an optional represented element, not as plain strings.
+#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
+pub struct Partition {
+    pub name: String,
+    #[serde(default)]
+    pub represents: Option<String>,
+}
+
+#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
+pub struct Activity {
+    #[serde(default)]
+    pub name: String,
+    #[serde(default)]
+    pub partitions: Vec<Partition>,
+    #[serde(default)]
+    pub nodes: Vec<ActivityNode>,
+    #[serde(default)]
+    pub edges: Vec<ActivityEdge>,
+}
+
+#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
+pub struct GraphNode {
+    pub id: String,
+    #[serde(default)]
+    pub kind: String,
+    #[serde(default)]
+    pub name: String,
+    #[serde(default)]
+    pub stereotypes: Vec<String>,
+}
+
+#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
+pub struct GraphEdge {
+    pub source: String,
+    pub target: String,
+    pub kind: String,
+    #[serde(default)]
+    pub label: String,
+}
+
+#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
+pub struct Graph {
+    pub nodes: Vec<GraphNode>,
+    pub edges: Vec<GraphEdge>,
+}
+
+#[derive(Debug, Clone, Default, Serialize, Deserialize, PartialEq)]
+pub struct Summary {
+    #[serde(default)]
+    pub blocks: u64,
+    #[serde(default)]
+    pub requirements: u64,
+    #[serde(default)]
+    pub interfaces: u64,
+    #[serde(default)]
+    pub signals: u64,
+    #[serde(default)]
+    pub activities: u64,
+    #[serde(rename = "graphNodes", default)]
+    pub graph_nodes: u64,
+    #[serde(rename = "graphEdges", default)]
+    pub graph_edges: u64,
+}
+
+#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
+pub struct Provenance {
+    #[serde(rename = "sourceTool", default)]
+    pub source_tool: String,
+    #[serde(default)]
+    pub exporter: String,
+    #[serde(rename = "exporterVersion", default)]
+    pub exporter_version: String,
+}
+
+#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
+pub struct OkfRoot {
+    #[serde(default)]
+    pub okf: String,
+    pub project: String,
+    #[serde(rename = "exportedAt", default)]
+    pub exported_at: String,
+    #[serde(default)]
+    pub summary: Summary,
+    #[serde(default)]
+    pub structure: Vec<Element>,
+    #[serde(default)]
+    pub interfaces: Vec<Element>,
+    #[serde(default)]
+    pub signals: Vec<Element>,
+    #[serde(default)]
+    pub requirements: Vec<Requirement>,
+    #[serde(rename = "stateMachine", default)]
+    pub state_machine: Option<StateMachine>,
+    #[serde(default)]
+    pub activities: Vec<Activity>,
+    #[serde(default)]
+    pub graph: Option<Graph>,
+    #[serde(default)]
+    pub provenance: Option<Provenance>,
+}
diff --git a/engine/okf/src/validate.rs b/engine/okf/src/validate.rs
new file mode 100644
index 0000000..74a56a3
--- /dev/null
+++ b/engine/okf/src/validate.rs
@@ -0,0 +1,201 @@
+// SPDX-License-Identifier: AGPL-3.0-or-later
+use std::collections::HashSet;
+
+use serde::Serialize;
+
+use crate::types::OkfRoot;
+
+pub const NODE_KINDS: &[&str] = &[
+    "activity",
+    "actor",
+    "block",
+    "interface",
+    "requirement",
+    "signal",
+    "state",
+    "stateMachine",
+    "usecase",
+];
+
+pub const EDGE_KINDS: &[&str] = &[
+    "association",
+    "behavior",
+    "contains",
+    "dependency",
+    "effect",
+    "generalization",
+    "include",
+    "part",
+    "reference",
+    "subject",
+    "transition",
+    "triggers",
+    "uses",
+];
+
+#[derive(Debug, Clone, Serialize)]
+pub struct ValidationReport {
+    pub valid: bool,
+    pub errors: Vec<String>,
+    pub warnings: Vec<String>,
+}
+
+pub fn validate(root: &OkfRoot) -> ValidationReport {
+    let mut report = ValidationReport {
+        valid: true,
+        errors: Vec::new(),
+        warnings: Vec::new(),
+    };
+
+    if !root.okf.is_empty() && root.okf != "1.0" {
+        report.errors.push(format!(
+            "okf marker must be empty or 1.0, found {}",
+            root.okf
+        ));
+    } else if root.okf.is_empty() {
+        report
+            .warnings
+            .push("legacy OKF without version marker; exporters should emit okf 1.0".to_string());
+    }
+    if root.project.is_empty() {
+        report.errors.push("project name is empty".to_string());
+    }
+    if root.graph.is_none() {
+        report.errors.push("graph section is missing".to_string());
+    }
+    if root.state_machine.is_none() {
+        report
+            .errors
+            .push("stateMachine section is missing".to_string());
+    }
+
+    let mut seen: HashSet<String> = HashSet::new();
+    let mut add_id = |id: &str, section: &str, errors: &mut Vec<String>| {
+        if id.is_empty() {
+            errors.push(format!("{}: empty element id", section));
+        } else if !seen.insert(id.to_string()) {
+            errors.push(format!("duplicate element id {} in {}", id, section));
+        }
+    };
+    for el in &root.structure {
+        add_id(&el.id, "structure", &mut report.errors);
+    }
+    for el in &root.interfaces {
+        add_id(&el.id, "interfaces", &mut report.errors);
+    }
+    for el in &root.signals {
+        add_id(&el.id, "signals", &mut report.errors);
+    }
+    for r in &root.requirements {
+        add_id(&r.id, "requirements", &mut report.errors);
+        if r.req_id.trim().is_empty() {
+            report
+                .errors
+                .push(format!("requirement {} has an empty reqId", r.id));
+        }
+    }
+    if let Some(sm) = &root.state_machine {
+        if sm.name.is_empty() {
+            report
+                .errors
+                .push("stateMachine has an empty name".to_string());
+        }
+        for region in &sm.regions {
+            for s in &region.states {
+                add_id(&s.id, "stateMachine", &mut report.errors);
+            }
+        }
+    }
+
+    if let Some(graph) = &root.graph {
+        if graph.nodes.is_empty() {
+            report.errors.push("graph has no nodes".to_string());
+        }
+        let node_ids: HashSet<&str> = graph.nodes.iter().map(|n| n.id.as_str()).collect();
+        for n in &graph.nodes {
+            if !NODE_KINDS.contains(&n.kind.as_str()) {
+                report
+                    .errors
+                    .push(format!("unknown node kind {} on node {}", n.kind, n.id));
+            }
+        }
+        for e in &graph.edges {
+            if !EDGE_KINDS.contains(&e.kind.as_str()) {
+                report.errors.push(format!(
+                    "unknown edge kind {} from {} to {}",
+                    e.kind, e.source, e.target
+                ));
+            }
+            // Unresolved endpoints are warnings, not errors: the reference corpus proves
+            // that real exporter output can carry edges whose element was never emitted as
+            // a node (two satisfy links in the coffee-machine export). The platform must
+            // hold, gate and reason about such a model while reporting the defect loudly;
+            // refusing the document would make the corpus unusable as the proof fixture.
+            if !node_ids.contains(e.source.as_str()) {
+                report.warnings.push(format!(
+                    "dangling edge endpoint {} (source of a {} edge)",
+                    e.source, e.kind
+                ));
+            }
+            if !node_ids.contains(e.target.as_str()) {
+                report.warnings.push(format!(
+                    "dangling edge endpoint {} (target of a {} edge)",
+                    e.target, e.kind
+                ));
+            }
+        }
+    }
+
+    let sm = &root.summary;
+    if let Some(graph) = &root.graph {
+        if sm.graph_nodes as usize != graph.nodes.len()
+            || sm.graph_edges as usize != graph.edges.len()
+        {
+            report.warnings.push(format!(
+                "summary graph counts ({}/{}) do not match graph section ({}/{})",
+                sm.graph_nodes,
+                sm.graph_edges,
+                graph.nodes.len(),
+                graph.edges.len()
+            ));
+        }
+    }
+    if sm.blocks as usize != root.structure.len() {
+        report.warnings.push(format!(
+            "summary blocks {} do not match structure length {}",
+            sm.blocks,
+            root.structure.len()
+        ));
+    }
+    if sm.requirements as usize != root.requirements.len() {
+        report.warnings.push(format!(
+            "summary requirements {} do not match requirements length {}",
+            sm.requirements,
+            root.requirements.len()
+        ));
+    }
+    if sm.signals as usize != root.signals.len() {
+        report.warnings.push(format!(
+            "summary signals {} do not match signals length {}",
+            sm.signals,
+            root.signals.len()
+        ));
+    }
+    if sm.activities as usize != root.activities.len() {
+        report.warnings.push(format!(
+            "summary activities {} do not match activities length {}",
+            sm.activities,
+            root.activities.len()
+        ));
+    }
+    if sm.interfaces as usize != root.interfaces.len() {
+        report.warnings.push(format!(
+            "summary interfaces {} do not match interfaces length {}",
+            sm.interfaces,
+            root.interfaces.len()
+        ));
+    }
+
+    report.valid = report.errors.is_empty();
+    report
+}
diff --git a/engine/okf/tests/okf_diff.rs b/engine/okf/tests/okf_diff.rs
new file mode 100644
index 0000000..8d0ae76
--- /dev/null
+++ b/engine/okf/tests/okf_diff.rs
@@ -0,0 +1,87 @@
+// SPDX-License-Identifier: AGPL-3.0-or-later
+use okf::{diff, types::OkfRoot};
+
+fn expected() -> OkfRoot {
+    serde_json::from_str(&test_support::load_okf_expected()).expect("corpus fixture parses")
+}
+
+#[test]
+fn identical_models_diff_equal() {
+    let r = expected();
+    assert!(diff::diff(&r, &r).equal);
+}
+
+#[test]
+fn removed_requirement_is_missing_element() {
+    let mut candidate = expected();
+    candidate.requirements.pop();
+    let d = diff::diff(&expected(), &candidate);
+    assert!(!d.equal);
+    assert_eq!(d.missing_elements.len(), 1);
+}
+
+#[test]
+fn removed_edge_is_missing_edge() {
+    let mut candidate = expected();
+    candidate.graph.as_mut().expect("graph present").edges.pop();
+    let d = diff::diff(&expected(), &candidate);
+    assert!(!d.equal);
+    assert_eq!(d.missing_edges.len(), 1);
+}
+
+#[test]
+fn renamed_element_is_changed_attribute() {
+    let mut candidate = expected();
+    candidate.structure[0].name.push_str(" X");
+    let d = diff::diff(&expected(), &candidate);
+    assert!(!d.equal);
+    assert_eq!(d.changed_attributes.len(), 1);
+}
+
+#[test]
+fn activity_change_is_a_difference() {
+    let mut candidate = expected();
+    candidate.activities[0].name.push_str(" X");
+    let d = diff::diff(&expected(), &candidate);
+    assert!(!d.equal);
+    assert_eq!(d.changed_attributes.len(), 1);
+}
+
+#[test]
+fn document_level_change_is_a_difference() {
+    let mut candidate = expected();
+    candidate.project.push_str(" X");
+    let d = diff::diff(&expected(), &candidate);
+    assert!(!d.equal);
+    assert_eq!(d.changed_attributes.len(), 1);
+}
+
+#[test]
+fn state_machine_change_is_a_difference() {
+    let mut candidate = expected();
+    candidate
+        .state_machine
+        .as_mut()
+        .expect("state machine present")
+        .name
+        .push_str(" X");
+    let d = diff::diff(&expected(), &candidate);
+    assert!(!d.equal);
+    assert!(d.changed_attributes.iter().any(|k| k == "doc:stateMachine"));
+}
+#[test]
+fn report_serializes_with_camel_case_keys() {
+    // The report is a published contract (the MCP okf.diff tool and any agent binding
+    // to it). Pin the key style so a serde rename cannot silently change the contract.
+    let report = diff::diff(&expected(), &expected());
+    let value = serde_json::to_value(&report).expect("report serializes");
+    let keys: Vec<&str> = value
+        .as_object()
+        .unwrap()
+        .keys()
+        .map(|k| k.as_str())
+        .collect();
+    assert!(keys.contains(&"missingElements"), "keys: {:?}", keys);
+    assert!(keys.contains(&"changedAttributes"), "keys: {:?}", keys);
+    assert!(!keys.contains(&"missing_elements"), "keys: {:?}", keys);
+}
diff --git a/engine/okf/tests/okf_validation.rs b/engine/okf/tests/okf_validation.rs
new file mode 100644
index 0000000..9642087
--- /dev/null
+++ b/engine/okf/tests/okf_validation.rs
@@ -0,0 +1,105 @@
+// SPDX-License-Identifier: AGPL-3.0-or-later
+use okf::{hash, types::OkfRoot, validate};
+
+fn expected() -> OkfRoot {
+    serde_json::from_str(&test_support::load_okf_expected()).expect("corpus fixture parses")
+}
+
+#[test]
+fn corpus_fixture_validates() {
+    let report = validate::validate(&expected());
+    assert!(report.valid, "unexpected errors: {:?}", report.errors);
+    assert_eq!(report.errors, Vec::<String>::new());
+    // The reference export carries two edges whose source element was never emitted as
+    // a node; they are warned about, so the finding is recorded rather than silently
+    // accepted. See the corpus README.
+    assert_eq!(
+        report
+            .warnings
+            .iter()
+            .filter(|w| w.contains("dangling edge endpoint"))
+            .count(),
+        2,
+        "expected exactly two dangling edge endpoints in the legacy export"
+    );
+}
+
+#[test]
+fn corpus_fixture_has_expected_graph() {
+    let root = expected();
+    let graph = root.graph.as_ref().expect("graph present");
+    assert_eq!(graph.nodes.len(), 99);
+    assert_eq!(graph.edges.len(), 165);
+    assert_eq!(root.requirements.len(), 25);
+}
+
+#[test]
+fn rejects_duplicate_element_ids() {
+    let mut root = expected();
+    if root.structure.len() >= 2 {
+        let dup = root.structure[1].id.clone();
+        root.structure[0].id = dup;
+    }
+    let report = validate::validate(&root);
+    assert!(!report.valid);
+    assert!(report
+        .errors
+        .iter()
+        .any(|e| e.contains("duplicate element id")));
+}
+
+#[test]
+fn warns_dangling_edge_endpoint() {
+    let mut root = expected();
+    if let Some(graph) = root.graph.as_mut() {
+        let target = graph.nodes[0].id.clone();
+        graph.edges.push(okf::types::GraphEdge {
+            source: "missing-node".into(),
+            target,
+            kind: "part".into(),
+            label: String::new(),
+        });
+    }
+    let report = validate::validate(&root);
+    // Unresolved endpoints are warnings, not errors (ruling B): a real exporter can
+    // emit them, so the document stays valid and the defect is reported loudly.
+    assert!(report.valid, "unexpected errors: {:?}", report.errors);
+    assert!(report.warnings.iter().any(|w| w.contains("missing-node")));
+}
+
+#[test]
+fn rejects_unknown_edge_kind() {
+    let mut root = expected();
+    if let Some(graph) = root.graph.as_mut() {
+        let target = graph.nodes[0].id.clone();
+        graph.edges.push(okf::types::GraphEdge {
+            source: "missing-node".into(),
+            target,
+            kind: "not-a-kind".into(),
+            label: String::new(),
+        });
+    }
+    let report = validate::validate(&root);
+    assert!(!report.valid);
+    assert!(report
+        .errors
+        .iter()
+        .any(|e| e.contains("unknown edge kind")));
+}
+
+#[test]
+fn rejects_empty_requirement_id() {
+    let mut root = expected();
+    root.requirements[0].req_id = String::new();
+    let report = validate::validate(&root);
+    assert!(!report.valid);
+    assert!(report.errors.iter().any(|e| e.contains("empty reqId")));
+}
+
+#[test]
+fn canonical_hash_is_stable() {
+    let a = hash::canonical_hash(&expected());
+    let b = hash::canonical_hash(&expected());
+    assert_eq!(a, b);
+    assert_eq!(a.len(), 64);
+}
diff --git a/engine/test-support/Cargo.toml b/engine/test-support/Cargo.toml
new file mode 100644
index 0000000..57f8d85
--- /dev/null
+++ b/engine/test-support/Cargo.toml
@@ -0,0 +1,12 @@
+[package]
+name = "mw-test-support"
+version = "0.1.0"
+edition.workspace = true
+rust-version.workspace = true
+license.workspace = true
+publish = false
+
+[lib]
+name = "test_support"
+
+[dependencies]
diff --git a/engine/test-support/src/lib.rs b/engine/test-support/src/lib.rs
new file mode 100644
index 0000000..5b13f64
--- /dev/null
+++ b/engine/test-support/src/lib.rs
@@ -0,0 +1,23 @@
+// SPDX-License-Identifier: AGPL-3.0-or-later
+use std::path::PathBuf;
+
+/// The repository root, two levels above this crate (engine/test-support).
+pub fn repo_root() -> PathBuf {
+    PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("../..")
+}
+
+pub fn okf_expected() -> PathBuf {
+    repo_root().join("sample/corpus/coffee-machine/okf/expected/coffee_machine_model.json")
+}
+
+pub fn okf_broken() -> PathBuf {
+    repo_root().join("sample/corpus/coffee-machine/okf/corrupted/coffee_machine_model.json")
+}
+
+pub fn load_okf_expected() -> String {
+    std::fs::read_to_string(okf_expected()).expect("corpus fixture must exist")
+}
+
+pub fn load_okf_broken() -> String {
+    std::fs::read_to_string(okf_broken()).expect("corrupted fixture must exist")
+}
diff --git a/judge/judge.py b/judge/judge.py
new file mode 100644
index 0000000..12f6a43
--- /dev/null
+++ b/judge/judge.py
@@ -0,0 +1,76 @@
+# SPDX-License-Identifier: AGPL-3.0-or-later
+"""Gate-as-judge harness: run mw-gate over pairs of OKF files in two directories.
+
+Standalone scoring for model migrations, or the scoring step in an agent
+loop. Usage:
+
+    python judge/judge.py --ref-dir DIR --candidate-dir DIR [--gate-bin PATH]
+"""
+import argparse
+import json
+import subprocess
+import sys
+from pathlib import Path
+
+
+def find_pairs(ref_dir: Path, cand_dir: Path) -> dict[str, tuple[Path, Path]]:
+    pairs: dict[str, tuple[Path, Path]] = {}
+    for ref in sorted(ref_dir.glob("*.json")):
+        cand = cand_dir / ref.name
+        if cand.is_file():
+            pairs[ref.stem] = (ref, cand)
+    return pairs
+
+
+def run_gate(gate_bin: Path, reference: Path, candidate: Path) -> dict:
+    proc = subprocess.run(
+        [str(gate_bin), "--reference", str(reference), "--candidate", str(candidate), "--json"],
+        capture_output=True,
+        text=True,
+    )
+    try:
+        payload = json.loads(proc.stdout.strip())
+        return payload
+    except json.JSONDecodeError:
+        return {
+            "passed": False,
+            "failures": [],
+            "parseError": True,
+            "raw": proc.stdout.strip(),
+            "exitCode": proc.returncode,
+            "stderr": proc.stderr.strip(),
+        }
+
+
+def render_table(results: list[tuple[str, dict]]) -> str:
+    lines = []
+    for name, payload in results:
+        if payload.get("parseError"):
+            lines.append(f"FAIL  {name}  (gate did not return JSON: {payload.get('stderr', '')})")
+        elif payload.get("passed"):
+            lines.append(f"PASS  {name}")
+        else:
+            reasons = "; ".join(payload.get("failures", []))
+            lines.append(f"FAIL  {name}  ({reasons})")
+    return "\n".join(lines)
+
+
+def main(argv: list[str] | None = None) -> int:
+    parser = argparse.ArgumentParser(description="Gate-as-judge harness for OKF migrations")
+    parser.add_argument("--ref-dir", required=True, type=Path)
+    parser.add_argument("--candidate-dir", required=True, type=Path)
+    parser.add_argument("--gate-bin", default="mw-gate", type=Path)
+    args = parser.parse_args(argv)
+    pairs = find_pairs(args.ref_dir, args.candidate_dir)
+    if not pairs:
+        print("no matching OKF pairs found", file=sys.stderr)
+        return 2
+    results: list[tuple[str, dict]] = []
+    for name, (ref, cand) in pairs.items():
+        results.append((name, run_gate(args.gate_bin, ref, cand)))
+    print(render_table(results))
+    return 0 if all(payload.get("passed") for _, payload in results) else 1
+
+
+if __name__ == "__main__":
+    sys.exit(main())
diff --git a/judge/tests/test_judge.py b/judge/tests/test_judge.py
new file mode 100644
index 0000000..2f14477
--- /dev/null
+++ b/judge/tests/test_judge.py
@@ -0,0 +1,37 @@
+# SPDX-License-Identifier: AGPL-3.0-or-later
+import sys
+import tempfile
+import unittest
+from pathlib import Path
+
+sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
+
+import judge
+
+
+class JudgeTests(unittest.TestCase):
+    def test_find_pairs(self):
+        with tempfile.TemporaryDirectory() as tmp:
+            root = Path(tmp)
+            ref = root / "ref"
+            cand = root / "cand"
+            ref.mkdir()
+            cand.mkdir()
+            (ref / "a.json").write_text("{}", encoding="utf-8")
+            (ref / "b.json").write_text("{}", encoding="utf-8")
+            (cand / "a.json").write_text("{}", encoding="utf-8")
+            pairs = judge.find_pairs(ref, cand)
+            self.assertEqual(set(pairs), {"a"})
+
+    def test_render_table(self):
+        out = judge.render_table([
+            ("a", {"passed": True, "failures": []}),
+            ("b", {"passed": False, "failures": ["integration: 2 connected components"]}),
+        ])
+        self.assertIn("PASS  a", out)
+        self.assertIn("FAIL  b", out)
+        self.assertIn("2 connected components", out)
+
+
+if __name__ == "__main__":
+    unittest.main()
diff --git a/sample/scripts/make_corrupted.py b/sample/scripts/make_corrupted.py
new file mode 100644
index 0000000..916f697
--- /dev/null
+++ b/sample/scripts/make_corrupted.py
@@ -0,0 +1,32 @@
+# SPDX-License-Identifier: AGPL-3.0-or-later
+"""Produce the corrupted OKF fixture the gate must reject.
+
+Deterministic breakage, applied to the reference corpus:
+- every edge touching requirement 3.1.5 is removed, isolating that node;
+- requirement 1.1 is deleted entirely (a lost element).
+"""
+import json
+import sys
+from pathlib import Path
+
+
+def main() -> int:
+    src = Path("sample/corpus/coffee-machine/okf/expected/coffee_machine_model.json")
+    dst = Path("sample/corpus/coffee-machine/okf/corrupted/coffee_machine_model.json")
+    data = json.loads(src.read_text(encoding="utf-8"))
+    target = next(r["id"] for r in data["requirements"] if r["reqId"] == "3.1.5")
+    before = len(data["graph"]["edges"])
+    data["graph"]["edges"] = [
+        e for e in data["graph"]["edges"]
+        if e["source"] != target and e["target"] != target
+    ]
+    removed = before - len(data["graph"]["edges"])
+    data["requirements"] = [r for r in data["requirements"] if r["reqId"] != "1.1"]
+    dst.parent.mkdir(parents=True, exist_ok=True)
+    dst.write_text(json.dumps(data, indent=2), encoding="utf-8")
+    print(f"wrote {dst}: removed {removed} edges around REQ 3.1.5, deleted REQ 1.1")
+    return 0
+
+
+if __name__ == "__main__":
+    sys.exit(main())
