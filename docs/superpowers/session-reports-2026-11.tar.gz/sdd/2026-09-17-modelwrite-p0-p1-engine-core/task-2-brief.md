### Task 2: OKF 1.0 specification and JSON Schema

**Files:**
- Create: docs/okf/okf-1.0-spec.md
- Create: docs/okf/okf-1.0.schema.json

**Interfaces:**
- Consumes: nothing.
- Produces: the normative OKF 1.0 field names, kind enums and validation rules that every later task implements verbatim. The Rust validator in Task 4 is the runtime conformance checker; this document and the schema are the readable descriptions.

- [ ] **Step 1: Write docs/okf/okf-1.0-spec.md**

```markdown
# OKF 1.0 â€” Open Knowledge Format

Status: normative, v1.0-draft

Normative description of the modelwrite interchange format. The Rust
validator in engine/okf is the runtime conformance checker; this document
and okf-1.0.schema.json are the human and tool readable descriptions.

## 1. Purpose

OKF is a single self-describing JSON document that captures a systems
model: its elements, its requirements, its state machine and activities,
and a graph of every relationship. One OKF file drives every downstream
consumer: portals, analysis, AI, and the gate.

## 2. Top level

| Field | Type | Required | Meaning |
|---|---|---|---|
| okf | string | no | Version marker; exporters emit 1.0. Absent means legacy export. |
| project | string | yes | Model or project name. |
| exportedAt | string | yes | Export timestamp. Exporters SHOULD emit ISO-8601; legacy exports may be free text. |
| provenance | object | no | sourceTool, exporter, exporterVersion strings. |
| summary | object | yes | Counts used as a sanity cross-check (mismatches are warnings). |
| structure | Element[] | no | Blocks and interface blocks. |
| interfaces | Element[] | no | Ports and interfaces (empty in the reference corpus). |
| signals | Element[] | no | Signals and events. |
| requirements | Requirement[] | no | Requirements with reqId and reqText. |
| stateMachine | object | yes | name plus regions of states. |
| activities | Activity[] | no | Activity diagrams: nodes and control edges. |
| graph | object | yes | Every element as a node and every relationship as an edge. |

## 3. Element kinds and edge kinds

Node kinds: activity, actor, block, interface, requirement, signal, state,
stateMachine, usecase.

Edge kinds: association, behavior, contains, dependency, effect,
generalization, include, part, reference, subject, transition, triggers,
uses.

Traceability lives on dependency edges in the label field with exactly
these spellings: Satisfy, Refine, Verify, Allocate (capitalised).

## 4. Section item shapes

Element: id (required, opaque, stable), name, kind, stereotypes[],
attributes[] (each with name, type, aggregation, default), documentation.

Requirement: everything in Element plus reqId (required, non-empty) and
reqText.

State: id (required), name, entry, doActivity, exit. The entry, doActivity
and exit fields reference behaviour names, not ids.

StateMachine: name plus regions[]; each region holds states[].

Activity: name, partitions[] (swim-lane names), nodes[] (each with id,
type, name, partition) and edges[] (each with type, source, target,
guard). Control edges may reference node ids or be empty.

Graph node: id (required), kind, name, stereotypes[].

Graph edge: source, target, kind (required), label.

## 5. Graph rules

- Every node has an id unique within the graph.
- Every edge endpoint must reference an existing node id.
- Node and edge kinds must come from the tables above.
- Element ids are unique across all sections.

## 6. Summary cross-check

The summary counts (blocks, requirements, interfaces, signals, activities,
graphNodes, graphEdges) are compared with the actual section sizes; a
mismatch is a warning, never a failure.

## 7. Validation rules (normative list)

1. The okf marker is empty or 1.0.
2. project is non-empty.
3. graph and stateMachine are present.
4. No duplicate element ids; no empty ids.
5. Every requirement has a non-empty reqId.
6. The graph has at least one node; all kinds come from the tables.
7. Every edge endpoint resolves to a node; all kinds come from the tables.
8. Summary counts match section sizes (warning only).
9. A legacy document without the okf marker produces a warning, not an
   error.

## 8. Hashing

The canonical hash of an OKF snapshot is sha256 over the serialized
document with the structural field order of the Rust types. It is a
fingerprint of the snapshot, not a semantic identity: two semantically
equal files that differ in array order hash differently. The gate uses
semantic diffing for equality and hashes for evidence records.

## 9. Conformance

The reference corpus fixture
(sample/corpus/coffee-machine/okf/expected/coffee_machine_model.json) is a
legacy export: no okf marker and a free text exportedAt. It is conformant
with one warning. New exporters MUST emit okf 1.0 and an ISO-8601
exportedAt.
```

- [ ] **Step 2: Write docs/okf/okf-1.0.schema.json**

```json
{
  "$schema": "http://json-schema.org/draft-07/schema#",
  "$id": "https://modelwrite.org/okf/1.0/schema.json",
  "title": "OKF 1.0",
  "type": "object",
  "required": ["project", "summary", "stateMachine", "graph"],
  "properties": {
    "okf": {"type": "string", "enum": ["", "1.0"]},
    "project": {"type": "string"},
    "exportedAt": {"type": "string"},
    "provenance": {
      "type": "object",
      "properties": {
        "sourceTool": {"type": "string"},
        "exporter": {"type": "string"},
        "exporterVersion": {"type": "string"}
      }
    },
    "summary": {
      "type": "object",
      "properties": {
        "blocks": {"type": "integer"},
        "requirements": {"type": "integer"},
        "interfaces": {"type": "integer"},
        "signals": {"type": "integer"},
        "activities": {"type": "integer"},
        "graphNodes": {"type": "integer"},
        "graphEdges": {"type": "integer"}
      }
    },
    "structure": {"type": "array", "items": {"$ref": "#/definitions/element"}},
    "interfaces": {"type": "array", "items": {"$ref": "#/definitions/element"}},
    "signals": {"type": "array", "items": {"$ref": "#/definitions/element"}},
    "requirements": {"type": "array", "items": {"$ref": "#/definitions/requirement"}},
    "stateMachine": {
      "type": "object",
      "required": ["name"],
      "properties": {
        "name": {"type": "string"},
        "regions": {
          "type": "array",
          "items": {
            "type": "object",
            "properties": {
              "states": {"type": "array", "items": {"$ref": "#/definitions/state"}}
            }
          }
        }
      }
    },
    "activities": {"type": "array", "items": {"$ref": "#/definitions/activity"}},
    "graph": {
      "type": "object",
      "required": ["nodes", "edges"],
      "properties": {
        "nodes": {"type": "array", "items": {"$ref": "#/definitions/graphNode"}},
        "edges": {"type": "array", "items": {"$ref": "#/definitions/graphEdge"}}
      }
    }
  },
  "definitions": {
    "attribute": {
      "type": "object",
      "required": ["name"],
      "properties": {
        "name": {"type": "string"},
        "type": {"type": "string"},
        "aggregation": {"type": "string"},
        "default": {"type": "string"}
      }
    },
    "element": {
      "type": "object",
      "required": ["id"],
      "properties": {
        "id": {"type": "string"},
        "name": {"type": "string"},
        "kind": {"type": "string"},
        "stereotypes": {"type": "array", "items": {"type": "string"}},
        "attributes": {"type": "array", "items": {"$ref": "#/definitions/attribute"}},
        "documentation": {"type": "string"}
      }
    },
    "requirement": {
      "type": "object",
      "required": ["id", "reqId"],
      "properties": {
        "id": {"type": "string"},
        "name": {"type": "string"},
        "kind": {"type": "string"},
        "stereotypes": {"type": "array", "items": {"type": "string"}},
        "attributes": {"type": "array", "items": {"$ref": "#/definitions/attribute"}},
        "documentation": {"type": "string"},
        "reqId": {"type": "string"},
        "reqText": {"type": "string"}
      }
    },
    "state": {
      "type": "object",
      "required": ["id"],
      "properties": {
        "id": {"type": "string"},
        "name": {"type": "string"},
        "entry": {"type": ["string", "null"]},
        "doActivity": {"type": ["string", "null"]},
        "exit": {"type": ["string", "null"]}
      }
    },
    "activityNode": {
      "type": "object",
      "required": ["id"],
      "properties": {
        "id": {"type": "string"},
        "type": {"type": "string"},
        "name": {"type": "string"},
        "partition": {"type": ["string", "null"]}
      }
    },
    "activityEdge": {
      "type": "object",
      "properties": {
        "type": {"type": "string"},
        "source": {"type": "string"},
        "target": {"type": "string"},
        "guard": {"type": "string"}
      }
    },
    "activity": {
      "type": "object",
      "properties": {
        "name": {"type": "string"},
        "partitions": {"type": "array", "items": {"type": "string"}},
        "nodes": {"type": "array", "items": {"$ref": "#/definitions/activityNode"}},
        "edges": {"type": "array", "items": {"$ref": "#/definitions/activityEdge"}}
      }
    },
    "graphNode": {
      "type": "object",
      "required": ["id"],
      "properties": {
        "id": {"type": "string"},
        "kind": {"type": "string"},
        "name": {"type": "string"},
        "stereotypes": {"type": "array", "items": {"type": "string"}}
      }
    },
    "graphEdge": {
      "type": "object",
      "required": ["source", "target", "kind"],
      "properties": {
        "source": {"type": "string"},
        "target": {"type": "string"},
        "kind": {"type": "string"},
        "label": {"type": "string"}
      }
    }
  }
}
```

- [ ] **Step 3: Verify both files parse**

```powershell
python -c "import json,pathlib; json.loads(pathlib.Path('docs/okf/okf-1.0.schema.json').read_text(encoding='utf-8')); print('schema parses')"
python -c "import json,pathlib; d=json.loads(pathlib.Path('docs/okf/okf-1.0.schema.json').read_text(encoding='utf-8')); assert d['required']==['project','summary','stateMachine','graph']; print('required fields pinned')"
```

Expected: schema parses and required fields pinned, both printed.

- [ ] **Step 4: Commit**

```powershell
git add docs/okf
git commit -m "docs: add OKF 1.0 spec and JSON schema"
```

---
