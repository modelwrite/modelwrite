﻿# Final re-review package (fixes to the three Important findings)

## Commit

85213f0 fix: guard the MCP graph tool, unify the JSON key style, and pin determinism

## Diff stat

 .github/workflows/ci.yml          |  9 +++++++++
 engine/gate/tests/gate.rs         | 17 +++++++++++++++++
 engine/graph/src/lib.rs           |  5 +++++
 engine/graph/tests/graph_stats.rs | 16 ++++++++++++++++
 engine/mcp/src/lib.rs             |  6 ++++++
 engine/mcp/tests/mcp.rs           | 37 +++++++++++++++++++++++++++++++++++++
 6 files changed, 90 insertions(+)

## Full diff (-U10)

diff --git a/.github/workflows/ci.yml b/.github/workflows/ci.yml
index 5752dff..b264b66 100644
--- a/.github/workflows/ci.yml
+++ b/.github/workflows/ci.yml
@@ -8,11 +8,20 @@ jobs:
     runs-on: ubuntu-latest
     steps:
       - uses: actions/checkout@v4
       - uses: dtolnay/rust-toolchain@stable
         with:
           components: clippy, rustfmt
       - run: cargo fmt --all -- --check
       - run: cargo clippy --workspace --all-targets -- -D warnings
       - run: cargo test --workspace
       - run: cargo run -p mw-gate -- --reference sample/corpus/coffee-machine/okf/expected/coffee_machine_model.json --candidate sample/corpus/coffee-machine/okf/expected/coffee_machine_model.json
+      # The evidence annex is the trust anchor of the provable identity, so the
+      # committed records must regenerate byte for byte. A new timestamp or a
+      # nondeterministic iteration order anywhere in the gate fails this step.
+      - name: evidence records must regenerate byte for byte
+        run: |
+          cargo run -q -p mw-gate -- --reference sample/corpus/coffee-machine/okf/expected/coffee_machine_model.json --candidate sample/corpus/coffee-machine/okf/expected/coffee_machine_model.json --evidence /tmp/self-pass.json > /dev/null
+          cargo run -q -p mw-gate -- --reference sample/corpus/coffee-machine/okf/expected/coffee_machine_model.json --candidate sample/corpus/coffee-machine/okf/corrupted/coffee_machine_model.json --evidence /tmp/corrupted-fail.json > /dev/null || true
+          diff /tmp/self-pass.json docs/evidence/2026-09-17-roundtrip-self-pass.json
+          diff /tmp/corrupted-fail.json docs/evidence/2026-09-17-roundtrip-corrupted-fail.json
       - run: python -m unittest discover -s judge/tests -p "test_*.py" -v
diff --git a/engine/gate/tests/gate.rs b/engine/gate/tests/gate.rs
index b650aaf..d869126 100644
--- a/engine/gate/tests/gate.rs
+++ b/engine/gate/tests/gate.rs
@@ -103,10 +103,27 @@ fn candidate_without_a_graph_fails_instead_of_panicking() {
     // uncovered rather than the total being reported as zero.
     assert_eq!(outcome.evidence["coverage"]["total"], 1);
     assert_eq!(
         outcome.evidence["coverage"]["uncovered"]
             .as_array()
             .unwrap()
             .len(),
         1
     );
 }
+#[test]
+fn evidence_is_identical_across_runs() {
+    // The evidence annex is the trust anchor of the provable identity, so the
+    // determinism claim is pinned rather than asserted in prose: the same inputs must
+    // serialise to the same bytes, every time, including for independently parsed copies.
+    let reference = expected();
+    let first = gate::run(&reference, &reference, false);
+    let second = gate::run(&reference, &reference, false);
+    assert_eq!(
+        serde_json::to_string(&first.evidence).unwrap(),
+        serde_json::to_string(&second.evidence).unwrap()
+    );
+
+    let reparsed = expected();
+    let third = gate::run(&reparsed, &reparsed, false);
+    assert_eq!(first.evidence, third.evidence);
+}
diff --git a/engine/graph/src/lib.rs b/engine/graph/src/lib.rs
index d57b75f..ea163be 100644
--- a/engine/graph/src/lib.rs
+++ b/engine/graph/src/lib.rs
@@ -1,18 +1,22 @@
 // SPDX-License-Identifier: AGPL-3.0-or-later
 use std::collections::{HashMap, HashSet};
 
 use okf::types::OkfRoot;
 use petgraph::unionfind::UnionFind;
 use serde::Serialize;
 
+/// Published as camelCase JSON, like every other contract the platform exposes (the
+/// OKF document, the gate evidence, the diff report), so a consumer never has to
+/// special-case one payload's key style.
 #[derive(Debug, Clone, Serialize)]
+#[serde(rename_all = "camelCase")]
 pub struct GraphStats {
     pub node_count: usize,
     pub edge_count: usize,
     pub isolated: Vec<String>,
     pub component_count: usize,
     pub component_sizes: Vec<usize>,
 }
 
 pub fn graph_stats(root: &OkfRoot) -> GraphStats {
     let graph = root.graph.as_ref().expect("graph required; validate first");
@@ -50,20 +54,21 @@ pub fn graph_stats(root: &OkfRoot) -> GraphStats {
     GraphStats {
         node_count,
         edge_count,
         isolated,
         component_count,
         component_sizes,
     }
 }
 
 #[derive(Debug, Clone, Serialize)]
+#[serde(rename_all = "camelCase")]
 pub struct CoverageReport {
     pub total: usize,
     pub satisfied: usize,
     pub refined: usize,
     pub verified: usize,
     pub allocated: usize,
     pub covered: usize,
     pub uncovered: Vec<String>,
 }
 
diff --git a/engine/graph/tests/graph_stats.rs b/engine/graph/tests/graph_stats.rs
index a80a7f4..c804bfe 100644
--- a/engine/graph/tests/graph_stats.rs
+++ b/engine/graph/tests/graph_stats.rs
@@ -99,10 +99,26 @@ fn allocate_edge_counts_only_requirement_endpoints() {
       {"source": "p1", "target": "r1", "kind": "dependency", "label": "Allocate"}
     ]
   }
 }"#;
     let cov = requirement_coverage(&okf(ALLOC));
     assert_eq!(cov.total, 1);
     assert_eq!(cov.allocated, 1);
     assert_eq!(cov.covered, 1);
     assert!(cov.uncovered.is_empty());
 }
+#[test]
+fn stats_serialize_with_camel_case_keys() {
+    // The stats are a published contract (the MCP graph.stats tool). Pin the key style
+    // so they cannot drift away from the rest of the platform's JSON.
+    let stats = graph_stats(&expected());
+    let value = serde_json::to_value(&stats).expect("stats serialize");
+    let keys: Vec<&str> = value
+        .as_object()
+        .unwrap()
+        .keys()
+        .map(|k| k.as_str())
+        .collect();
+    assert!(keys.contains(&"nodeCount"), "keys: {:?}", keys);
+    assert!(keys.contains(&"componentCount"), "keys: {:?}", keys);
+    assert!(!keys.contains(&"node_count"), "keys: {:?}", keys);
+}
diff --git a/engine/mcp/src/lib.rs b/engine/mcp/src/lib.rs
index 885db49..b8e8b50 100644
--- a/engine/mcp/src/lib.rs
+++ b/engine/mcp/src/lib.rs
@@ -32,20 +32,26 @@ fn call_tool(msg: &Value) -> Value {
                 }
             }
         }
         "graph.stats" => {
             let Some(okf) = args.get("okf").and_then(Value::as_str) else {
                 return tool_error("missing okf argument");
             };
             match serde_json::from_str::<okf::types::OkfRoot>(okf) {
                 Err(e) => tool_error(&format!("parse error: {}", e)),
                 Ok(root) => {
+                    // The engine's graph helpers require a graph, so an invalid candidate
+                    // must be reported as a tool error rather than crashing the server: a
+                    // repair loop calls this tool on exactly these documents.
+                    if root.graph.is_none() {
+                        return tool_error("candidate has no graph section");
+                    }
                     let stats = graph::graph_stats(&root);
                     tool_ok(serde_json::to_string_pretty(&stats).expect("stats serialize"))
                 }
             }
         }
         "gate.run" => {
             let reference = args.get("reference").and_then(Value::as_str);
             let candidate = args.get("candidate").and_then(Value::as_str);
             let strict = args
                 .get("strictCoverage")
diff --git a/engine/mcp/tests/mcp.rs b/engine/mcp/tests/mcp.rs
index 6959426..2ad1d1d 100644
--- a/engine/mcp/tests/mcp.rs
+++ b/engine/mcp/tests/mcp.rs
@@ -118,10 +118,47 @@ fn tool_error_is_reported_in_the_result_not_the_transport() {
     // envelope must stay a success so an agent can read the error and adapt.
     let resp = call(json!({
         "jsonrpc": "2.0",
         "id": 9,
         "method": "tools/call",
         "params": { "name": "okf.validate", "arguments": {} }
     }));
     assert!(resp.get("error").is_none(), "unexpected error: {}", resp);
     assert_eq!(resp["result"]["isError"], true);
 }
+#[test]
+fn graph_stats_tool_reports_health() {
+    let okf = test_support::load_okf_expected();
+    let resp = call(json!({
+        "jsonrpc": "2.0",
+        "id": 10,
+        "method": "tools/call",
+        "params": { "name": "graph.stats", "arguments": { "okf": okf } }
+    }));
+    let text = resp["result"]["content"][0]["text"].as_str().unwrap();
+    let stats: Value = serde_json::from_str(text).unwrap();
+    assert_eq!(stats["nodeCount"], 99);
+    assert_eq!(stats["edgeCount"], 165);
+    assert_eq!(stats["componentCount"], 1);
+}
+
+#[test]
+fn graph_stats_tool_errors_on_a_graph_less_document() {
+    // A repair loop calls this on invalid candidates, so it must answer with an error
+    // rather than taking the server down.
+    let resp = call(json!({
+        "jsonrpc": "2.0",
+        "id": 11,
+        "method": "tools/call",
+        "params": { "name": "graph.stats", "arguments": { "okf": "{\"project\":\"x\",\"summary\":{},\"stateMachine\":{\"name\":\"sm\",\"regions\":[]},\"graph\":null}" } }
+    }));
+    assert!(
+        resp.get("error").is_none(),
+        "unexpected transport error: {}",
+        resp
+    );
+    assert_eq!(resp["result"]["isError"], true);
+    assert!(resp["result"]["content"][0]["text"]
+        .as_str()
+        .unwrap()
+        .contains("no graph section"));
+}
