﻿# Task 5 review package

## Commits

b102653 feat: add graph crate with integration and coverage analysis

## Diff stat

 Cargo.toml                        |   2 +-
 engine/graph/Cargo.toml           |  19 ++++++
 engine/graph/src/lib.rs           | 129 ++++++++++++++++++++++++++++++++++++++
 engine/graph/tests/graph_stats.rs |  64 +++++++++++++++++++
 4 files changed, 213 insertions(+), 1 deletion(-)

## Full diff (-U10)

diff --git a/Cargo.toml b/Cargo.toml
index de89a78..de0841a 100644
--- a/Cargo.toml
+++ b/Cargo.toml
@@ -1,13 +1,13 @@
 [workspace]
 resolver = "2"
-members = ["engine/okf", "engine/test-support"]
+members = ["engine/okf", "engine/test-support", "engine/graph"]
 
 [workspace.package]
 edition = "2021"
 rust-version = "1.75"
 license = "AGPL-3.0-or-later"
 repository = "https://github.com/modelwrite/modelwrite"
 
 [workspace.dependencies]
 anyhow = "1.0"
 hex = "0.4"
diff --git a/engine/graph/Cargo.toml b/engine/graph/Cargo.toml
new file mode 100644
index 0000000..c1d100a
--- /dev/null
+++ b/engine/graph/Cargo.toml
@@ -0,0 +1,19 @@
+[package]
+name = "mw-graph"
+version = "0.1.0"
+edition.workspace = true
+rust-version.workspace = true
+license.workspace = true
+publish = false
+
+[lib]
+name = "graph"
+
+[dependencies]
+mw-okf = { path = "../okf" }
+petgraph.workspace = true
+serde.workspace = true
+
+[dev-dependencies]
+mw-test-support = { path = "../test-support" }
+serde_json.workspace = true
diff --git a/engine/graph/src/lib.rs b/engine/graph/src/lib.rs
new file mode 100644
index 0000000..1bddda9
--- /dev/null
+++ b/engine/graph/src/lib.rs
@@ -0,0 +1,129 @@
+// SPDX-License-Identifier: AGPL-3.0-or-later
+use std::collections::{HashMap, HashSet};
+
+use okf::types::OkfRoot;
+use petgraph::unionfind::UnionFind;
+use serde::Serialize;
+
+#[derive(Debug, Clone, Serialize)]
+pub struct GraphStats {
+    pub node_count: usize,
+    pub edge_count: usize,
+    pub isolated: Vec<String>,
+    pub component_count: usize,
+    pub component_sizes: Vec<usize>,
+}
+
+pub fn graph_stats(root: &OkfRoot) -> GraphStats {
+    let graph = root.graph.as_ref().expect("graph required; validate first");
+    let node_count = graph.nodes.len();
+    let edge_count = graph.edges.len();
+    let index: HashMap<&str, usize> = graph
+        .nodes
+        .iter()
+        .enumerate()
+        .map(|(i, n)| (n.id.as_str(), i))
+        .collect();
+    let mut uf = UnionFind::new(node_count);
+    let mut degree = vec![0usize; node_count];
+    for e in &graph.edges {
+        if let (Some(&a), Some(&b)) = (index.get(e.source.as_str()), index.get(e.target.as_str())) {
+            degree[a] += 1;
+            degree[b] += 1;
+            uf.union(a, b);
+        }
+    }
+    let isolated: Vec<String> = graph
+        .nodes
+        .iter()
+        .enumerate()
+        .filter(|(i, _)| degree[*i] == 0)
+        .map(|(_, n)| n.id.clone())
+        .collect();
+    let mut sizes: HashMap<usize, usize> = HashMap::new();
+    for i in 0..node_count {
+        *sizes.entry(uf.find(i)).or_insert(0) += 1;
+    }
+    let mut component_sizes: Vec<usize> = sizes.into_values().collect();
+    component_sizes.sort_unstable_by(|a, b| b.cmp(a));
+    let component_count = component_sizes.len();
+    GraphStats {
+        node_count,
+        edge_count,
+        isolated,
+        component_count,
+        component_sizes,
+    }
+}
+
+#[derive(Debug, Clone, Serialize)]
+pub struct CoverageReport {
+    pub total: usize,
+    pub satisfied: usize,
+    pub refined: usize,
+    pub verified: usize,
+    pub allocated: usize,
+    pub covered: usize,
+    pub uncovered: Vec<String>,
+}
+
+/// Requirement coverage read from dependency edges whose label is exactly
+/// Satisfy, Refine, Verify or Allocate.
+pub fn requirement_coverage(root: &OkfRoot) -> CoverageReport {
+    let req_ids: HashSet<&str> = root.requirements.iter().map(|r| r.id.as_str()).collect();
+    let graph = root.graph.as_ref().expect("graph required; validate first");
+    let mut satisfied = 0usize;
+    let mut refined = 0usize;
+    let mut verified = 0usize;
+    let mut allocated = 0usize;
+    let mut covered: HashSet<&str> = HashSet::new();
+    for e in &graph.edges {
+        if e.kind != "dependency" {
+            continue;
+        }
+        let s = e.source.as_str();
+        let t = e.target.as_str();
+        match e.label.as_str() {
+            "Satisfy" => {
+                if req_ids.contains(t) {
+                    satisfied += 1;
+                    covered.insert(t);
+                }
+            }
+            "Refine" => {
+                if req_ids.contains(t) {
+                    refined += 1;
+                    covered.insert(t);
+                }
+            }
+            "Verify" => {
+                if req_ids.contains(t) {
+                    verified += 1;
+                    covered.insert(t);
+                }
+            }
+            "Allocate" if req_ids.contains(t) || req_ids.contains(s) => {
+                allocated += 1;
+                covered.insert(t);
+                covered.insert(s);
+            }
+            _ => {}
+        }
+    }
+    let mut uncovered: Vec<String> = root
+        .requirements
+        .iter()
+        .filter(|r| !covered.contains(r.id.as_str()))
+        .map(|r| r.id.clone())
+        .collect();
+    uncovered.sort();
+    CoverageReport {
+        total: req_ids.len(),
+        satisfied,
+        refined,
+        verified,
+        allocated,
+        covered: covered.len(),
+        uncovered,
+    }
+}
diff --git a/engine/graph/tests/graph_stats.rs b/engine/graph/tests/graph_stats.rs
new file mode 100644
index 0000000..9a228d0
--- /dev/null
+++ b/engine/graph/tests/graph_stats.rs
@@ -0,0 +1,64 @@
+// SPDX-License-Identifier: AGPL-3.0-or-later
+use graph::{graph_stats, requirement_coverage};
+use okf::types::OkfRoot;
+
+fn expected() -> OkfRoot {
+    serde_json::from_str(&test_support::load_okf_expected()).expect("corpus fixture parses")
+}
+
+fn okf(text: &str) -> OkfRoot {
+    serde_json::from_str(text).expect("test OKF parses")
+}
+
+const TINY: &str = r#"{
+  "project": "tiny",
+  "exportedAt": "2026-09-17T00:00:00Z",
+  "summary": {},
+  "stateMachine": {"name": "tiny sm", "regions": []},
+  "requirements": [
+    {"id": "r1", "name": "R1", "kind": "requirement", "stereotypes": ["Requirement"], "attributes": [], "documentation": "", "reqId": "1.1", "reqText": "covered"},
+    {"id": "r2", "name": "R2", "kind": "requirement", "stereotypes": ["Requirement"], "attributes": [], "documentation": "", "reqId": "1.2", "reqText": "uncovered"}
+  ],
+  "graph": {
+    "nodes": [
+      {"id": "p1", "kind": "block", "name": "P1"},
+      {"id": "r1", "kind": "requirement", "name": "R1"},
+      {"id": "r2", "kind": "requirement", "name": "R2"}
+    ],
+    "edges": [
+      {"source": "p1", "target": "r1", "kind": "dependency", "label": "Satisfy"}
+    ]
+  }
+}"#;
+
+#[test]
+fn corpus_is_fully_integrated() {
+    let stats = graph_stats(&expected());
+    assert_eq!(stats.node_count, 99);
+    assert_eq!(stats.edge_count, 165);
+    assert!(stats.isolated.is_empty(), "isolated: {:?}", stats.isolated);
+    assert_eq!(stats.component_count, 1);
+    assert_eq!(stats.component_sizes, vec![99]);
+}
+
+#[test]
+fn isolated_node_is_detected() {
+    let stats = graph_stats(&okf(TINY));
+    assert_eq!(stats.isolated, vec!["r2"]);
+}
+
+#[test]
+fn two_components_are_counted() {
+    let stats = graph_stats(&okf(TINY));
+    assert_eq!(stats.component_count, 2);
+    assert_eq!(stats.component_sizes, vec![2, 1]);
+}
+
+#[test]
+fn coverage_counts_traceability() {
+    let cov = requirement_coverage(&okf(TINY));
+    assert_eq!(cov.total, 2);
+    assert_eq!(cov.satisfied, 1);
+    assert_eq!(cov.covered, 1);
+    assert_eq!(cov.uncovered, vec!["r2"]);
+}
