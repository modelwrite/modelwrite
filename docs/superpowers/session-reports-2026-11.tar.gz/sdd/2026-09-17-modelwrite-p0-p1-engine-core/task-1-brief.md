﻿### Task 1: Repository scaffold

**Files:**
- Create: .gitignore
- Create: .gitattributes
- Create: LICENSE (AGPL-3.0-or-later full text)
- Create: CODE_OF_CONDUCT.md
- Create: CONTRIBUTING.md
- Create: SECURITY.md
- Create: NOTICE.md
- Create: README.md (stub; completed in Task 11)
- Create: agents/CLAUDE.md
- Create: docs/okf/ (empty directory; filled by Task 2)
- Create: docs/evidence/ (empty directory; filled by Task 6)
- Create: sample/ (empty directory; filled by Task 3)

**Interfaces:**
- Consumes: nothing.
- Produces: a git repository at the repo root with main as the default branch; the AGPL licence text; the rule pack in agents/CLAUDE.md that every later agent task must respect; a working Rust toolchain.

- [ ] **Step 1: Install the Rust toolchain (rustup, stable, minimal profile)**

Run in PowerShell from the repo root:

```powershell
Invoke-WebRequest -Uri https://win.rustup.rs -OutFile "$env:TEMP\rustup-init.exe"
& "$env:TEMP\rustup-init.exe" -y --default-toolchain stable --profile minimal
$env:Path = "$env:USERPROFILE\.cargo\bin;" + $env:Path
```

If the download is blocked, fall back to: winget install --id Rustlang.Rustup -e --accept-source-agreements --accept-package-agreements

- [ ] **Step 2: Verify the toolchain**

Run: cargo --version and rustc --version
Expected: both print a stable version (1.75 or newer).

- [ ] **Step 3: Initialise the repository**

```powershell
git init -b main
```

Expected: Initialized empty Git repository in ... If .git already exists, skip this step. Note: do not add a remote yet; when the GitHub remote URL is confirmed, run git remote add origin URL as a separate commit-free step.

- [ ] **Step 4: Write .gitignore**

```
/target/
**/__pycache__/
*.pyc
.cache/
.DS_Store
Thumbs.db
```

- [ ] **Step 5: Write .gitattributes**

```
*.mdzip binary
*.zip binary
```

- [ ] **Step 6: Write LICENSE (AGPL-3.0-or-later)**

Download the verbatim licence text:

```powershell
Invoke-WebRequest -Uri https://www.gnu.org/licenses/agpl-3.0.txt -OutFile LICENSE
```

Expected: LICENSE contains the full GNU AGPL v3 text beginning with GNU AFFERO GENERAL PUBLIC LICENSE. If the download is blocked, stop and report; do not substitute a truncated copy.

- [ ] **Step 7: Write CODE_OF_CONDUCT.md**

```markdown
# Code of Conduct

Modelwrite is an open community. Be kind, be precise, and keep the work
professional.

- Harassment, discrimination, and personal attacks are not welcome anywhere
  in the project (issues, pull requests, chat, events).
- Critique the work, never the person. Engineering disagreements are fine;
  personal hostility is not.
- Assume good faith. If someone is wrong, show them the evidence; the
  evidence annex exists for exactly that reason.
- Respect boundaries and do not share private information without consent.

Maintainers enforce this code. Report concerns to conduct@modelwrite.org.
Violations may lead to warnings or removal from the project.
```

- [ ] **Step 8: Write CONTRIBUTING.md**

```markdown
# Contributing to modelwrite

Thanks for helping. The bar for merging is: tests pass, the gate passes,
and every claim traces to evidence.

## Workflow

1. Fork the repository and create a branch off main.
2. Make one focused change per pull request.
3. Commit with conventional commit messages (feat:, fix:, docs:, test:, ci:).
4. Before pushing run:

   cargo fmt --all -- --check
   cargo clippy --workspace --all-targets -- -D warnings
   cargo test --workspace

5. If your change touches model data, run the gate against the corpus:

   cargo run -p mw-gate -- --reference sample/corpus/coffee-machine/okf/expected/coffee_machine_model.json --candidate sample/corpus/coffee-machine/okf/expected/coffee_machine_model.json

## Rules

- The gate is the only authority on correctness. No pull request comment,
  tool parameter, or log line can mark a run as passed.
- Never hand-edit a corpus fixture. Changes to fixtures must be reproduced
  by a committed script in sample/scripts/.
- Evidence records in docs/evidence/ are append-only.
- Importers and exporters ship under Apache-2.0; the engine stays
  AGPL-3.0-or-later. Keep the split clean in every pull request.
```

- [ ] **Step 9: Write SECURITY.md**

```markdown
# Security

Modelwrite parses untrusted model files; treat any crash, panic, or memory
unsafety triggered by a crafted OKF or legacy file as a security issue.

## Reporting

Email security@modelwrite.org with a minimal reproducer. Please do not open
a public issue for a suspected vulnerability. We acknowledge within 5
business days and aim to fix within 90 days.

## Scope

- The Rust engine (parsing, validation, gate, C ABI, MCP server).
- The judge harness when it handles untrusted files.

The static site and sample data are out of scope. There is no bounty
program yet.
```

- [ ] **Step 10: Write NOTICE.md**

```markdown
# NOTICE

Modelwrite is a community project. The engine, portal, judge harness, and
sample data are contributions of the modelwrite contributors.

The coffee-machine corpus under sample/corpus/coffee-machine/ is based on
course work by Alex Kovaceski in the MEMKO MBSEF-SEng course (September
2026): a SysML model built in CATIA Magic, its OKF export, and the analysis
portal described in the knowledge pack. The original material is shared as
the starting corpus for this project with the permission of the author.

The name modelwrite and the modelwrite.org domain are used in this notice
as the project identity.
```

- [ ] **Step 11: Write agents/CLAUDE.md (the rule pack)**

```markdown
# Modelwrite agent rules

Modelwrite models are OKF documents plus their legacy sources. Every claim
about a model is proven by the gate, never by assertion.

## Invariants

1. The gate is the only authority on correctness. No tool parameter, no log
   line, and no LLM output can mark a gate run as passed; only a real
   mw-gate run counts.
2. Any change to the corpus fixtures must be reproduced by a committed
   script in sample/scripts/; never hand-edit the expected OKF.
3. Round-trip fidelity means zero loss: element sets, edge sets, and
   attributes must match exactly between reference and candidate OKF.
4. Graph health is non-negotiable: a candidate with isolated nodes or more
   than one connected component fails the gate.
5. OKF ids are opaque and stable. Never regenerate or renumber ids when
   transforming a model; a missing id is data loss.
6. Traceability labels are capitalised exactly: Satisfy, Refine, Verify,
   Allocate. Dependency edges carry them in the label field.
7. State entry/do behaviour references point at activity names, and the
   activity section keeps every activity the state machine reaches.
8. Evidence goes to docs/evidence/ and is committed; never rewrite an
   existing evidence record.
```

- [ ] **Step 12: Write README.md stub**

```markdown
# Modelwrite

**The model you can prove.**

Modelwrite is an open-source MBSE platform that turns legacy SysML models
into portable, provable data â€” the Open Knowledge Format (OKF) â€” and
automates the skilled work of building and reviewing models with grounded
AI.

Status: engine core under construction. See docs/superpowers/plans/ for the
implementation plan and docs/superpowers/specs/ for the design.

Quickstart once the engine lands:

cargo build --workspace
cargo test --workspace

Licence: AGPL-3.0-or-later (engine). See NOTICE.md for attribution.
```

- [ ] **Step 13: Verify and commit**

```powershell
Get-ChildItem -Name
git status --short
git add -A
git commit -m "chore: scaffold modelwrite repository"
```

Expected: the listing shows the ten created files plus docs/ and sample/; the commit lands on main.

---

