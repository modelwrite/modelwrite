﻿### Task 3: Port the coffee-machine corpus into sample/

**Files:**
- Create: sample/corpus/coffee-machine/okf/expected/coffee_machine_model.json (copied fixture)
- Create: sample/corpus/coffee-machine/legacy/CoffeeMachine-SysML-Model.mdzip (copied fixture)
- Create: sample/demo/CoffeeMachine-Showcase-standalone.html (copied fixture)
- Create: sample/README.md
- Create: sample/corpus/coffee-machine/README.md

**Interfaces:**
- Consumes: the read-only sources in collateral/.
- Produces: the canonical fixture paths that every later task and test reads. Paths are fixed from now on: sample/corpus/coffee-machine/okf/expected/coffee_machine_model.json is the reference OKF.

- [ ] **Step 1: Expand the app archive to a temporary directory**

```powershell
$tmp = "C:/Users/alexk/projects/modelwrite/.tmp-corpus"
New-Item -ItemType Directory -Force -Path $tmp | Out-Null
Expand-Archive -Path "collateral/CoffeeMachine-App.zip" -DestinationPath "$tmp/app"
Get-ChildItem "$tmp/app" -Name
```

Expected: the listing shows coffee_machine_model.json, index.html, READ-ME.txt, serve.ps1, upload_server.ps1.

- [ ] **Step 2: Copy the three fixtures into sample/**

```powershell
New-Item -ItemType Directory -Force -Path "sample/corpus/coffee-machine/okf/expected" | Out-Null
Copy-Item "$tmp/app/coffee_machine_model.json" "sample/corpus/coffee-machine/okf/expected/coffee_machine_model.json"
New-Item -ItemType Directory -Force -Path "sample/corpus/coffee-machine/legacy" | Out-Null
Copy-Item "collateral/CoffeeMachine-SysML-Model.mdzip" "sample/corpus/coffee-machine/legacy/CoffeeMachine-SysML-Model.mdzip"
New-Item -ItemType Directory -Force -Path "sample/demo" | Out-Null
Copy-Item "collateral/CoffeeMachine-Showcase-standalone.html" "sample/demo/CoffeeMachine-Showcase-standalone.html"
Remove-Item $tmp -Recurse -Force
```

- [ ] **Step 3: Pin the corpus numbers**

```powershell
python -c "import json,pathlib; d=json.loads(pathlib.Path('sample/corpus/coffee-machine/okf/expected/coffee_machine_model.json').read_text(encoding='utf-8')); assert d['summary']['graphNodes']==99 and d['summary']['graphEdges']==165, d['summary']; assert len(d['requirements'])==25 and d['summary']['blocks']==49 and d['summary']['signals']==9 and d['summary']['activities']==8; print('corpus pinned: 99 nodes, 165 edges, 25 requirements')"
```

Expected: corpus pinned: 99 nodes, 165 edges, 25 requirements.

- [ ] **Step 4: Write sample/README.md**

```markdown
# Sample

The coffee-machine corpus: a complete SysML model and its OKF export,
shared as the regression fixture for the whole project.

- corpus/coffee-machine/okf/expected/ — the exported model (OKF), the
  reference snapshot the gate must accept unchanged.
- corpus/coffee-machine/okf/corrupted/ — a deliberately broken copy the
  gate must reject (created by scripts/make_corrupted.py in Task 6).
- corpus/coffee-machine/legacy/ — the CATIA Magic project (.mdzip).
- demo/ — the standalone portal showcase from the knowledge pack.
- scripts/ — fixture generators; never hand-edit a fixture.

The corpus originates from the MEMKO MBSEF-SEng coffee machine course work
by Alex Kovaceski (September 2026) and is shared with the permission of
the author. See NOTICE.md.
```

- [ ] **Step 5: Write sample/corpus/coffee-machine/README.md**

```markdown
# Coffee machine corpus

Model: bean-to-cup coffee machine, SysML v1, built in CATIA Magic
(Magic Systems of Systems Architect 2026x) during the MEMKO MBSEF-SEng
course.

Known-good numbers (pinned by tests and by the evidence annex):

- graph nodes: 99
- graph edges: 165
- requirements: 25
- blocks: 49
- signals: 9
- activities: 8
- connected components: 1
- isolated nodes: 0

Workflow: edit the legacy model in CATIA Magic, re-run the exporter, and
place the fresh export at okf/expected/coffee_machine_model.json. The gate
CI job proves the refresh loses nothing.
```

- [ ] **Step 6: Commit**

```powershell
git add sample
git commit -m "chore: port coffee-machine corpus into sample/"
```

---


