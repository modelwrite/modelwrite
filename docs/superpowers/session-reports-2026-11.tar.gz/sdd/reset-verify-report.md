# Periodic forced reset — weekly verify canary (idc-1)

Status: **DONE**

## What was added (idc-1 only)

A second systemd timer that runs the existing reset with `FORCE=1` weekly, so the
change-detection guard can never again mask a broken rebuild (the 2026-09-21
SEED_PORT=3103 collision that only a hand-run FORCE=1 exposed).

- Service `/etc/systemd/system/modelwrite-trial-verify.service` (Type=oneshot,
  `Environment=FORCE=1`, `ExecStart=/opt/modelwrite/deploy/reset-trial.sh`,
  `OnFailure=algolotl-failure-notify@%n.service`).
- Timer `/etc/systemd/system/modelwrite-trial-verify.timer`
  (`OnCalendar=Mon *-*-* 03:30:00`, `Persistent=true`, `WantedBy=timers.target`).
- Source copies also in `/opt/modelwrite/deploy/` (matches the existing reset-unit pattern).

## Notification path

The host HAS an existing failure path: the algolotl fleet wires
`OnFailure=algolotl-failure-notify@%n.service` on ~10 units. That template runs
`notify_failure.py`, which posts the failing unit's journal tail to the business-events
sink (`helpers.zulip.post` → Postgres `business_events`; Zulip/Slack are retired). I
reused it verbatim — no new email/webhook dependency was invented. `/opt/insights` and the
other modelwrite trial (`modelwrite-app.service`) have no OnFailure of their own.

## Retention / backup storm

Forced runs take one backup per the existing policy. Confirmed: retention `KEEP_BACKUPS=48`
still makes sense. One extra ~221 KB backup a week is negligible against the hourly churn
(up to 24/day when dirty); 48 ≈ 2 days of hourly backups. No backup storm.

## Schedule (proof 1 — verbatim)

```
NEXT                          LEFT LAST                           PASSED UNIT                          ACTIVATES
Mon 2026-09-21 08:00:00 UTC  18min Mon 2026-09-21 07:00:00 UTC 41min ago modelwrite-trial-reset.timer  modelwrite-trial-reset.service
Mon 2026-09-28 03:30:00 UTC 6 days -                                   - modelwrite-trial-verify.timer modelwrite-trial-verify.service
```

Both timers are live: the hourly reset (unchanged) and the new weekly verify at
Monday 03:30 UTC. The verify time is offset from `:00` so it cannot collide with the
hourly reset (which fires at `:00:00` every hour).

## Forced-run proof (proof 2 — clean trial, one hand trigger)

Pre-run: 9 backups. Ran `sudo systemctl start modelwrite-trial-verify.service` once on the
clean trial. The journal shows it BYPASSED the guard and did the full rebuild (not a skip):

```
Starting modelwrite-trial-verify.service - modelwrite trial weekly FORCED reset (full-rebuild canary)...
[2026-09-21T07:42:05+00:00] FORCE=1 set - bypassing change-detection guard, forcing full reset
[2026-09-21T07:42:05+00:00] === modelwrite trial reset start ===
[2026-09-21T07:42:05+00:00] started seed server container modelwrite-seed on :3104
[2026-09-21T07:42:06+00:00] seed server healthy
createProject coffee-machine -> 201  ... (6 createProject + 7 commits + 1 createBranch)
commit cafe-stand/with-microduck -> 33e1914b17bc6218fd84ff17c97b0d9a870e31de7c05753241006dcc05080ecb
verify /projects -> ['cafe-stand', 'coffee-machine', 'floor-robot', 'microduck', 'purchasing-terminal', 'sandwich-toaster']
seed replay verified: six models present
fresh DB verified: all six models present
cafe-stand main references resolve: ..."resolves":true...  (purchasing-terminal, coffee-machine, sandwich-toaster, floor-robot — all resolves:true)
stopping modelwrite.service
backed up outgoing DB to /opt/modelwrite/backups/2026-09-21T074217.db (221184 bytes)
swapped fresh database into /opt/modelwrite/data/modelwrite.db
final verify after restart: [six models]
=== modelwrite trial reset complete ===
```

A new backup was created (count 9 → 10, latest `2026-09-21T074217.db`), proving the forced
path really exercised the rebuild + backup + swap that the guard would otherwise have skipped.

## Restored state (proof 3)

- `curl /projects` → the six models (`cafe-stand, coffee-machine, floor-robot, microduck,
  purchasing-terminal, sandwich-toaster`).
- cafe-stand main tip `dd905e70…` resolve → `"resolves":true` with 4 references
  (purchasing-terminal, coffee-machine, sandwich-toaster, floor-robot), each `resolves:true`.
- Hourly reset skip behaviour unchanged — hand-start of `modelwrite-trial-reset.service`:
  `[2026-09-21T07:42:59+00:00] no changes since the last reset, skipping (service not restarted, no backup taken)`.

## Failure-state proof (proof 4 — achieved, then restored)

Pointed the unit at a COPY of the script with `SEED_PORT=3103` (the old collision) via a
drop-in, ran it, observed failure, then removed the drop-in + copy and re-verified.

```
× modelwrite-trial-verify.service - modelwrite trial weekly FORCED reset (full-rebuild canary)
     Active: failed (Result: exit-code)
    Process: 3179650 ExecStart=/opt/modelwrite/deploy/reset-trial.broken.sh (code=exited, status=125)
   Main PID: 3179650 (code=exited, status=125)

docker: Error response from daemon: ... Bind for 127.0.0.1:3103 failed: port is already allocated
[2026-09-21T07:44:59+00:00] RESET FAILED - restarting modelwrite.service on the last good database
modelwrite-trial-verify.service: Failed with result 'exit-code'.
modelwrite-trial-verify.service: Triggering OnFailure= dependencies.
```

The OnFailure pager fired and succeeded:

```
2026-09-21T07:44:59.455704+00:00 notified unit=modelwrite-trial-verify.service ok=True
```

`modelwrite.service` and `modelwrite-app.service` stayed `active` throughout. Restored:
drop-in and broken copy removed, `systemctl reset-failed`, then re-ran the good unit →
`status=0/SUCCESS`, six models present, both services `active`. Host left clean.

## Documentation

- Repo: `docs/deploy/idc-1-trial.md` — new "Weekly forced reset (canary)" section + Operate line.
- Host: `/opt/modelwrite/README.md` — same section + Operate line.
- `systemd-analyze verify` passes on both new units; timer enabled (`systemctl enable --now`).

## Concerns

1. Minor naming lag (pre-existing, not changed): `algolotl-failure-notify@.service` and
   `notify_failure.py` still say "Slack"/"Zulip", but the sink is now the Postgres
   `business_events` table. Reused as-is per "follow whatever exists".
2. The weekly canary depends on the algolotl-failure-notify template continuing to resolve
   (`uv run` + `algolotl-research/.env` DATABASE_URL). If that ever breaks, the unit's
   `failed` state is still the loud primary signal; the notifier logs its own failure to
   `/tmp/notify-failure.log`.
3. Concurrent commit: while this task ran, another task committed to `slice-2-repository`
   (`11ed410 docs: STPA/STAMP - not the methodology gap, the defensibility gap`) and its
   `git add` swept my `docs/deploy/idc-1-trial.md` change into that commit (the file's +34
   lines are mine, bundled with their spec doc). The doc update is committed and intact;
   I did not push or amend it, so as not to disturb the concurrent task. No source files
   were touched.
4. Hourly reset, modelwrite-app (3103), haproxy, cloudflared, and the showcase image were
   all left untouched.
