# CLI exposure: report

## Status

NEEDS_CONTEXT

Every deliverable except the crates.io publish is complete and verified. The publish is
blocked by a version drift outside this task's scope (see Concerns), and unblocking it
needs a decision from the maintainer.

## Commits

- `182322f` — chore(cli): expose the mw CLI - ship release binaries and document it
  (6 files, +238/-23): release.yml, README.md, cli/Cargo.toml, cli/README.md,
  docs/guide/README.md, docs/guide/cli.md.

## One-line test summary

556 passed, 0 failed, 24 ignored (PostgreSQL suite skipped); `cargo clippy --workspace
--all-targets -- -D warnings` clean; `cargo fmt --all` clean — all exit 0.

## Published version

**None.** `mw-cli 0.1.0` is NOT on crates.io. Publication is blocked (see Concerns #1).
The manifest is publish-ready: `publish = false` removed, description/repository/readme/
keywords/categories added, and `version = "0.1.0"` added to its path dependencies,
matching the engine crates.

## Asset names added (release.yml)

The `mw` binary now builds in the same five-platform matrix as `mw-mcp`:

- `mw-linux-x64`
- `mw-linux-arm64`
- `mw-darwin-x64`
- `mw-darwin-arm64`
- `mw-windows-x64.exe`

The `mw-mcp-*` asset names and their download path are untouched.

## Verbatim install + offline run

`cargo install --path cli --root <tmp>` then the installed `mw.exe` against a throwaway
SQLite database (a 2-node connected model so the gate passes):

```console
$ mw --help
usage: mw [--server <url> [--token <ENV_VAR>] | --db <path>] <command>

  --server <url>   talk to a running service over plain http://
  --token <VAR>    read the bearer token from the environment variable named VAR
  --db <path>      open a local SQLite store directly (offline, no server)

commands:
  project create <name>
  project list
  commit <project> --branch <branch> --message <msg> --file <path> [--holder <name>]
  log <project> --branch <branch>
  artifact <project> --hash <hash>
  branch list <project>
  branch create <project> --name <name> --from <commit>
  branch delete <project> --name <name>
  merge <project> --branch <branch> --other <branch> --message <msg> [--holder <name>]
  reset <project> --branch <branch> --to <commit> --message <msg> [--holder <name>]
  gate <project> --reference <commit> --candidate <commit>
  lock acquire <project> --branch <branch> --elements <a,b> --holder <name> --ttl <seconds>
  lock release <project> --holder <name> --ids <a,b>
  lock list <project>
  audit <project> [--limit <n>]
```

```console
$ mw --db <db> project create coffee
{
  "createdAt": "1789898602",
  "name": "coffee"
}

$ mw --db <db> commit coffee --branch main --message "first commit" --file model.json
{
  "author": "",
  "branch": "main",
  "createdAt": "1789898602",
  "hash": "3d6e90c1dbd8c5a4d19bd42f719c02876b78c6a0d3d4ac6900cb0cb2f16d3844",
  "message": "first commit",
  "okfHash": "fefd4b367f6808dcb107405f3f586fd91a74beb3bb1c120af9091177dc785e05",
  "parents": [],
  "project": "coffee",
  "provenance": { "kind": "authored" }
}

$ mw --db <db> gate coffee --reference 3d6e90c1... --candidate 3d6e90c1...
{
  "candidateHash": "83c4659d33bb347dd9c5bfa67a7aff33b79e974ad1af475dcb683d9839f3014a",
  "composition": {
    "boundary": {
      "asserted": [ "the combined system-of-systems, as a whole, has the global graph property (connected, coverage-complete, orphan-free); proving it would require importing every subsystem, which is the copy R1 forbids" ],
      "measured": [ "every subsystem reference resolves at its pinned revision", "every integrated revision was itself gated", "every platform requirement is covered within the platform model" ]
    },
    "coverage": { "crossModelOnly": [], "local": [] },
    "resolution": [],
    "wasGated": []
  },
  "coverage": { "allocated": 0, "covered": 0, "refined": 0, "satisfied": 0, "total": 0, "uncovered": [], "verified": 0 },
  "failures": [],
  "gateVersion": "0.1.0",
  "integration": { "componentCount": 1, "componentSizes": [ 2 ], "isolated": [] },
  "okfVersion": "1.0",
  "passed": true,
  "referenceHash": "83c4659d33bb347dd9c5bfa67a7aff33b79e974ad1af475dcb683d9839f3014a",
  "roundtrip": { "changedAttributes": [], "equal": true, "extraEdges": [], "extraElements": [], "missingEdges": [], "missingElements": [] },
  "strictCoverage": false,
  "validationErrors": [],
  "validationWarnings": []
}

$ mw --db <db> log coffee --branch main
[
  {
    "author": "",
    "branch": "main",
    "createdAt": "1789898602",
    "hash": "3d6e90c1dbd8c5a4d19bd42f719c02876b78c6a0d3d4ac6900cb0cb2f16d3844",
    "message": "first commit",
    "okfHash": "fefd4b367f6808dcb107405f3f586fd91a74beb3bb1c120af9091177dc785e05",
    "parents": [],
    "project": "coffee",
    "provenance": { "kind": "authored" }
  }
]
```

(All four commands exit 0. A single-node throwaway model was also tried: the offline gate
correctly returned `"passed": false` with `"integration: 1 isolated nodes"`, i.e.
enforcement is live offline, not just a pass-through.)

## Documented limitations (docs/guide/cli.md — "What offline mode does not do")

1. **No identity, no authorisation** — offline writes are recorded as actor `anonymous`;
   anyone who can open the SQLite file can write to it, and the audit trail records *what*,
   not *who*.
2. **Single writer, assumed** — `--db` does not coordinate with a running server or
   another process; do not point it at a live server's database.
3. **SQLite only** — no PostgreSQL backend offline.
4. **`artifact` is text only** — non-UTF-8 artifacts must be fetched over the server route.
5. **Nothing beyond the store** — no HTTP API, MCP, workbench UI, analytics, or assist.

## Concerns

1. **crates.io publish is BLOCKED by engine version drift.** The ten engine crates on
   crates.io are frozen at 0.1.0 from a snapshot that predates the subsystem-reference
   (`OkfRoot.references`, added in `1e693cc` "feat(sos): add the typed, pinned
   subsystem-reference primitive (S0)") and the write-path-convergence work. The current
   `mw-server` source uses those newer fields, so `cargo publish --dry-run -p mw-server`
   fails verification with 30 compile errors (e.g. `no field references on type &OkfRoot`)
   against the published 0.1.0. Publishing `mw-cli` (and `mw-server`) therefore requires
   first re-releasing the whole engine layer at a bumped version (0.1.1+), which touches all
   ten engine manifests — including `engine/mcp` — and is explicitly outside this task's
   scope ("do not touch engine/mcp and sample/"). Decision needed: bump + re-publish the
   engine layer, then publish `mw-server` and `mw-cli`.
2. **`mw-cli` additionally depends on `mw-server`** (offline mode is built on its store),
   and `mw-server` is `publish = false` and unpublished. I temporarily removed that flag
   and added metadata to enable the dependency, then reverted it (out of scope) once the
   deeper engine drift surfaced. Any eventual publish of `mw-cli` must also publish
   `mw-server` first.
3. **`cargo install --path cli` (no `--locked`) resolves `zeroize 1.9.0`** (edition 2024)
   rather than the workspace pin `=1.8.2`. This is harmless on modern toolchains and for
   `mw-cli`'s declared floor of 1.88, but the engine layer's 1.75 floor is only protected
   by the lockfile pin, not by a version constraint on transitive TLS deps.
4. **website/index.html** still says the crates are not published (I reverted my edit once
   the publish did not land). That remains true, but it is now slightly stale in that
   release binaries do exist. Updating it is outside this task's ownership.
