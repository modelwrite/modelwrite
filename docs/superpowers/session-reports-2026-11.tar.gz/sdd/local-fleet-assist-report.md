# Local fleet assist — report

## Status

DONE

## Commits

- `6f76172` — assist: add local OpenAI-compatible live backend (Axoquant fleet)

## One-line test summary

`cargo test --workspace --no-fail-fast`: 488 passed, 0 failed, 24 ignored (postgres, require MW_TEST_DATABASE_URL); `cargo clippy --workspace --all-targets -- -D warnings` clean; `cargo fmt --all` clean.

## The verbatim live result

Server: `mw-server` on `MW_PORT=8090`, temp `MW_DB`, `MW_ASSIST_BASE_URL=http://idc-1:8012/v1`, `MW_ASSIST_MODEL=qwen3.8-27b-fp8`, no `MW_ASSIST_API_KEY` (the endpoint needs no auth). Seeded with the coffee-machine corpus, then:

`POST /projects/coffee/assist` with request `"add a heater block with a water inlet port and a requirement that it heats to 95 degrees"` and branch `main` returned `201`.

**The proposal** (what the endpoint recorded; decision `null` = still undecided, never a commit):

```
id: 6eee1f17e303ac857f7277734a50093f
agent: mw-assist
goal: add a heater block with a water inlet port and a requirement that it heats to 95 degrees
proposals:
  - action=EditElement subject=_2026x_1_12a70364_1789602694850_639924_6115 confidence=High
    rationale="Adds the requested heater block and gives it a water inlet port."
  - action=DraftText   subject=_2026x_1_12a70364_1789602694850_639924_6116 confidence=High
    rationale="Adds the requested requirement that the heater heats to 95 degrees."
```

**What the model returned** (the raw `choices[0].message.content`, captured verbatim from the reasoner before parsing):

```json
{
  "changes": [
    {
      "action": "EditElement",
      "element": {
        "id": "_2026x_1_12a70364_1789602694850_639924_6115",
        "name": "Heater",
        "kind": "block",
        "stereotypes": ["Block"],
        "attributes": [
          { "aggregation": "none", "default": "", "name": "waterInlet", "type": "Water Inlet" }
        ],
        "documentation": "Heater block with a water inlet port."
      },
      "requirement": null,
      "rationale": "Adds the requested heater block and gives it a water inlet port.",
      "confidence": "High"
    },
    {
      "action": "DraftText",
      "requirement": {
        "id": "_2026x_1_12a70364_1789602694850_639924_6116",
        "name": "Heater Temperature",
        "kind": "requirement",
        "reqId": "4",
        "reqText": "The heater shall heat water to 95 degrees.",
        "stereotypes": ["Requirement"],
        "attributes": [],
        "documentation": ""
      },
      "element": null,
      "rationale": "Adds the requested requirement that the heater heats to 95 degrees.",
      "confidence": "High"
    }
  ]
}
```

**What validation did with it**: accepted. The answer was a clean JSON object (no fence, no prose — the model honoured both the strict prompt and `response_format: json_object`), so `extract_json_object` passed it through unchanged; `parse_and_validate` deserialised the `changes` array into `Vec<ModelChange>` and each `change.validate()` passed (EditElement carries an element with a non-empty id and no requirement; DraftText carries a requirement with a non-empty id and non-empty `reqId` "4" and no element). The proposal was recorded as a review artifact; nothing was committed.

## Concerns

- None blocking. Two observations worth noting:
  1. The model invented element/requirement ids in the corpus's own internal `_2026x_1_12a70364_<timestamp>_<seq>` scheme rather than a human-readable id like the scripted reasoner's `heater-block`. This is structurally valid (non-empty, non-colliding), so validation rightly accepted it, but the ids are opaque to a human reader.
  2. The defensive JSON extraction path (`extract_json_object`) was not needed in this run because the model answered cleanly; it is exercised by the loopback tests (`the_openai_reasoner_extracts_json_from_a_fenced_text_answer`) and remains in place as the safety net.
