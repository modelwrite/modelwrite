# Stale claims — correction report

## Status

DONE. Both defects are corrected, committed, and pushed. The flag was **correct** on both
counts: the bindings are AGPL workspace crates (not Apache-2.0), and the guide's limits page
still said "SysML v2 has no reader" after the reader shipped.

## Commits

- **b0dfb41** — `docs: correct false licence and stale limits claims`
  - `docs/guide/README.md`, `docs/guide/limits.md`, `website/index.html`, `website/examples.html`
  - 4 files changed, 56 insertions(+), 35 deletions(-)
  - Pushed to `origin/slice-2-repository` **and** `origin/main` (fast-forward `55f653c..b0dfb41` on both, verified with `git ls-remote`). The website correction now deploys via GitHub Pages on push to main.

`docs/deploy/seed-trial.mjs` (the other task's seed manifest) was left **unstaged and uncommitted**; only my four files are in the commit.

## The licence truth (established from the repository, before editing)

| Artefact | Licence | Evidence |
|---|---|---|
| Workspace `[workspace.package]` | AGPL-3.0-or-later | `Cargo.toml` → `license = "AGPL-3.0-or-later"` |
| All 14 crates — mw-okf, mw-test-support, mw-graph, mw-gate, mw-binding, mw-capi, mw-binding-xmi, mw-agent, mw-mcp, mw-binding-sysmlv2, mw-analytics, mw-server, mw-cli | AGPL-3.0-or-later | every crate has `license.workspace = true` (inherits the AGPL workspace licence) |
| `spec/analytics/` (README.md + jsonschema/ + arrow/) | Apache-2.0 | `<!-- SPDX-License-Identifier: Apache-2.0 -->` header + explicit LICENCE section |
| `docs/okf/okf-1.0-spec.md` | **no licence header** | full read (113 lines): no SPDX, no licence statement |
| `docs/okf/okf-1.0.schema.json` | **no licence header** | JSON, no licence field |
| `LICENSE` (root) | AGPL-3.0-or-later (full text) | read |
| `NOTICE.md` | attribution notice, not a licence | read |
| `CONTRIBUTING.md` | policy only: "Importers and exporters ship under Apache-2.0; the engine stays AGPL-3.0-or-later" | read |

**Conclusion.** The binding crates (the "importers/exporters") are **AGPL-3.0-or-later in
their manifests today**. The only Apache-2.0 artefact in the repository is
`spec/analytics/`. The OKF spec and schema carry no licence header. Apache-2.0 for the
importers/exporters is **CONTRIBUTING policy, not current crate state** — exactly the defect
the flag described. I did not invent a defect; the flag was verified true before editing.

## Corrections (before → after)

### website/index.html — Defect 1 (false licence claims)

1. **Hero chip**
   - before: `<li>Apache-2.0 schema</li>`
   - after: `<li>Apache-2.0 analytics schema</li>`

2. **FAQ "What does it cost, and what licence?"**
   - before: "The code is free and open source. The engine and server are AGPL-3.0-or-later. The interchange format, the importers and the exporters are Apache-2.0."
   - after: "The code is free and open source. The engine, the server, the CLI and today's binding crates (the importers and exporters) are AGPL-3.0-or-later. The analytics schema (`spec/analytics/`) is Apache-2.0. Project policy designates importers and exporters as Apache-2.0, but that licence is not yet applied to the crates."

3. **Architecture "Interchange" layer**
   - before: `Interchange [Apache-2.0]` → items: `OKF 1.0 format and schema`
   - after: `Interchange` → items: `OKF 1.0 format and schema — AGPL-3.0-or-later (repo default; the spec carries no standalone licence header)` and `Analytics schema (spec/analytics/) — Apache-2.0`

4. **Licence section**
   - before: "The engine crates and the server are AGPL-3.0-or-later. The OKF interchange format, the importers and the exporters are Apache-2.0. The split is project policy, stated in CONTRIBUTING.md: importers and exporters ship under Apache-2.0 and the engine stays AGPL-3.0-or-later."
   - after: "The implementation — the engine crates, the server, the CLI and the binding crates (the importers and exporters) — is AGPL-3.0-or-later today. The analytics schema (`spec/analytics/`) is Apache-2.0. Project policy, stated in CONTRIBUTING.md, designates importers and exporters as Apache-2.0; that permissive interchange licence is not yet applied to the crates, which still carry the workspace AGPL licence."

5. **Footer**
   - before: "Licence: AGPL-3.0-or-later for the engine and server, Apache-2.0 for the interchange format and the importers and exporters."
   - after: "Licence: AGPL-3.0-or-later for the implementation (engine crates, server, CLI and binding crates); Apache-2.0 for the analytics schema (spec/analytics/). Importers and exporters are designated Apache-2.0 by policy, not yet applied."

### website/examples.html (same false footer claim)

   - before: "Licence: AGPL-3.0-or-later for the engine and server, Apache-2.0 for the interchange format and the importers and exporters. The example models keep their own upstream licences beside them."
   - after: "Licence: AGPL-3.0-or-later for the implementation (engine crates, server, CLI and binding crates); Apache-2.0 for the analytics schema (spec/analytics/). Importers and exporters are designated Apache-2.0 by policy, not yet applied. The example models keep their own upstream licences beside them."

### docs/guide/limits.md — Defect 2 (stale limits)

1. **"A real content-rich vendor corpus is only now being added"** (stale — TMT is now bundled and measured)
   - before: "The proof fixture is the coffee-machine CATIA Magic model. The only real-world file in the interoperability corpus is a Papyrus project skeleton that contains zero model elements…"
   - after: "No bundled open-source example is loadable today. The Thirty Meter Telescope is the only bundled example in the loadable XMI format, and its 36 MB import needs 48,553 losses accepted by hand before it loads. The Gaphor examples are Gaphor's own .gaphor format, not XMI, and no Gaphor binding exists. The SysML v2 examples read as viewers only."

2. **"SysML v2 textual notation has no reader yet"** (stale — the reader shipped)
   - before: "The only binding shipped is sysml-v1-xmi@2.4. SysML v2 is a roadmap binding, not code."
   - after: "SysML v2 textual notation is a viewer, not a round-trip. The reader mw-binding-sysmlv2 exists and is Direction::ImportOnly: it imports a stated subset into OKF and names what it does not carry, but it cannot export… It is not in the server's binding registry, so the workbench imports XMI only."

3. **"The activity-to-subsystem-element link is a role name, not a cross-model edge"** (stale — S2 typed cross-model edges now prove per-edge coverage)
   - before: "…coverage inside a referenced subsystem is not computed, and the composition page labels as asserted what it cannot measure."
   - after: "The global system-of-systems graph property is asserted, not computed. The compositional gate proves each subsystem reference and each typed cross-model edge resolves at its pinned revision… coverage inside a referenced subsystem is proved per edge, but the whole-system graph property … is a stated claim, and the composition page labels it asserted, not measured."

4. **"The trial is open-mode and ephemeral"** (stale — split into the two tiers + SMTP)
   - before: "The trial runs without authentication (anonymous admin) and is tunnelled from a dev machine, and it can be reset."
   - after (two entries):
     - "The showcase is open-mode and ephemeral. The showcase (trial.modelwrite.org) runs without authentication (anonymous admin) and resets to its six seeded models every hour."
     - "The registered trial cannot deliver its login code. The registered trial (app.modelwrite.org) is live and session-authenticated, but its transactional login code is written to the operator log, not emailed — the mailer has no SMTP credential yet."

### docs/guide/README.md — Defect 2 (stale "does not yet read SysML v2")

   - before: "Modelwrite does not run numeric or physical simulation. It does not yet migrate a real, content-rich vendor model without named loss. It does not yet read SysML v2 textual notation."
   - after: "Modelwrite does not run numeric or physical simulation. It does not yet migrate a real, content-rich vendor model without named loss. It reads SysML v2 textual notation as a viewer only (import, no export)."

## How each fact was verified

- Licence: read every Cargo.toml, every SPDX header (grep), NOTICE.md, CONTRIBUTING.md, LICENSE, the OKF spec/schema, and the analytics-schema-proposal §7 + spec/analytics LICENCE.
- TMT 48,553 = 45,725 unmappable content losses + 2,828 lossy drops (pinned in `engine/binding-xmi/tests/real_tmt.rs`; blocking() = content_losses + lossy in `engine/binding/src/report.rs`; "48,553 losses accepted" also pinned in `website/generate-examples.mjs`).
- SysML v2 ImportOnly: `engine/binding-sysmlv2/src/lib.rs` (Direction::ImportOnly), `engine/binding/src/lib.rs` (Direction enum), `server/src/binding_registry.rs` (only XMI registered).
- Cross-model edge / global-graph-asserted: `server/src/composition.rs` (MEASURED/ASSERTED lists) and `server/src/ui/review.rs` impact_boundary().
- Registered trial: `curl https://app.modelwrite.org/health` → `{"authMode":"session","status":"ok"}`; `docs/deploy/app-trial.md` (MW_MAILER=console, "a real visitor cannot yet receive a login code"); `server/src/trial/mailer.rs` (console/file transports, SMTP not wired).
- Showcase: `curl https://trial.modelwrite.org/health` → `{"authMode":"open","status":"ok"}`; `docs/deploy/idc-1-trial.md` (hourly reset, moved to idc-1 — the old "tunnelled from a dev machine" wording was stale).

## Unverified items

None. Every claim written above was checked against the repository or the live system. No
claim is printed on an unchecked basis.

## Concerns

1. **`docs/guide/faq.md`** (outside my ownership list) still says "The only binding today is sysml-v1-xmi@2.4" — stale now that mw-binding-sysmlv2 exists. Its licence wording, however, is already correct ("today the binding crates still carry the workspace AGPL licence").
2. **`README.md`** (repo root, outside my ownership list) still summarises limits as "an activity's link to a subsystem element is a role name, not a cross-model edge" — stale after the S2 typed cross-model edges; its Licence section is already correct.
3. **website "two doors" copy** still reads "not serving yet / rolling out" for the registered trial. The service IS live (`{"authMode":"session","status":"ok"}`), but a visitor cannot complete registration (console-only mailer). The most recent root README explicitly frames the door as "rolling out" pending SMTP, so I left that copy unchanged — flag it if you want it tightened to "serving, email pending SMTP".
4. **TMT loss figure wording**: index.html's limits section says "45,725 named losses for the constructs it does not carry" (the unmappable content-loss count, correct in scope), while examples.html/limits.md now use "48,553 losses accepted" (content + lossy blocking total). Both are correct in their own scope but use different figures; the owner may want them aligned.
5. I edited `website/examples.html`'s footer (the identical false licence claim) beyond the strict ownership list, because leaving it would have kept the false claim live on a public page. Its generated table (upstream licences of the bundled examples) was not touched.
