// Seed the six modelwrite models for the idc-1 trial.
// Mirrors e2e/tests/composition.spec.js + impact-panel.spec.js, with the S2
// crossModelEdges added to the cafe-stand floor-care reference (impact.rs).
import fs from 'node:fs';
import path from 'node:path';

const BASE = process.env.MW_BASE_URL || 'http://127.0.0.1:14102';
const TOKEN = process.env.MW_TOKEN || '';
const repoRoot = 'C:/Users/alexk/projects/modelwrite';
const modelsDir = path.join(repoRoot, 'e2e', 'models');
const corpusPath = path.join(repoRoot, 'sample', 'corpus', 'coffee-machine', 'okf', 'expected', 'coffee_machine_model.json');

const headers = {
  'content-type': 'application/json',
  'authorization': 'Bearer ' + TOKEN,
};

function readModel(name) {
  return JSON.parse(fs.readFileSync(path.join(modelsDir, name), 'utf8'));
}
function readCorpus() {
  return JSON.parse(fs.readFileSync(corpusPath, 'utf8'));
}

async function post(url, body) {
  const res = await fetch(url, { method: 'POST', headers, body: JSON.stringify(body) });
  const text = await res.text();
  if (!res.ok) throw new Error(res.status + ' ' + url + ' :: ' + text);
  try { return JSON.parse(text); } catch { return text; }
}

async function main() {
  for (const p of ['coffee-machine','sandwich-toaster','purchasing-terminal','floor-robot','microduck','cafe-stand']) {
    try {
      await post(BASE + '/projects', { name: p });
      console.log('created project', p);
    } catch (e) {
      if (e.message.includes('409')) console.log('project exists', p);
      else throw e;
    }
  }

  const commit = async (project, okf) =>
    (await post(BASE + '/projects/' + project + '/commits', {
      branch: 'main', author: 'admin', message: 'seed platform scenario', okf,
    })).hash;

  const hashes = {
    'coffee-machine': await commit('coffee-machine', readCorpus()),
    'sandwich-toaster': await commit('sandwich-toaster', readModel('sandwich-toaster.json')),
    'purchasing-terminal': await commit('purchasing-terminal', readModel('purchasing-terminal.json')),
    'floor-robot': await commit('floor-robot', readModel('floor-robot.json')),
    'microduck': await commit('microduck', readModel('microduck.json')),
  };
  console.log('subsystem hashes:', JSON.stringify(hashes, null, 2));

  // cafe-stand main: floor-care -> floor-robot, crossModelEdges collector.
  const cafeMain = readModel('cafe-stand.json');
  for (const ref of cafeMain.references) {
    ref.revision = hashes[ref.project];
    if (ref.role === 'floor-care') {
      ref.crossModelEdges = [{ from: 'req-floor-clear', relation: 'satisfiedBy', to: 'collector' }];
    }
  }
  const mainHash = (await post(BASE + '/projects/cafe-stand/commits', {
    branch: 'main', author: 'admin', message: 'seed platform scenario', okf: cafeMain,
  })).hash;
  console.log('cafe-stand main hash:', mainHash);

  await post(BASE + '/projects/cafe-stand/branches', { name: 'with-microduck', from: mainHash });
  console.log('created branch with-microduck from', mainHash);

  // cafe-stand with-microduck: floor-care -> microduck, crossModelEdges gripper-arm.
  const cafeMicro = readModel('cafe-stand.json');
  for (const ref of cafeMicro.references) {
    if (ref.role === 'floor-care') {
      ref.project = 'microduck';
      ref.revision = hashes.microduck;
      ref.bounds = ['gripper-arm', 'gripper-camera', 'microduck'];
      ref.crossModelEdges = [{ from: 'req-floor-clear', relation: 'satisfiedBy', to: 'gripper-arm' }];
    } else {
      ref.revision = hashes[ref.project];
    }
  }
  const microHash = (await post(BASE + '/projects/cafe-stand/commits', {
    branch: 'with-microduck', author: 'admin', message: 'seed platform scenario', okf: cafeMicro,
  })).hash;
  console.log('cafe-stand with-microduck hash:', microHash);

  console.log('SEED_OK');
}

main().catch((e) => { console.error('SEED_FAIL:', e.message); process.exit(1); });
