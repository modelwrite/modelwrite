# Diagram presentation

## Status
DONE_WITH_CONCERNS

## Commits
94224e5 Present the diagram: layered layout, arrowheads, pan/zoom/filter interaction

## One-line test summary
cargo test --workspace --no-fail-fast is green across all suites; cargo fmt --all and cargo clippy --workspace --all-targets -- -D warnings are clean; 20 Playwright tests pass (16 existing + 4 new diagram tests: layout determinism, kind filtering, no-process fallback, process order).

## Before / after
- Before: a column-per-kind grid with no relationship awareness. Edges were centre-to-centre diagonals spanning the whole canvas; the picture was a tall narrow strip that wasted the width; labels were tiny (9px) and truncated; no arrowheads, no routing, no pan/zoom/filter.
- After: the engine computes a layered (Sugiyama-style) layout by longest path from the roots, with SCC condensation for cycles, two barycentre passes for crossing reduction, and containment edges weighted double so parents stay near children. Edges run border-to-border with explicit arrowhead polygons (no url() references, preserving the no-external-reference guarantee). Labels render at >=11px, truncate with an ellipsis and expose the full name on hover; edge labels only show on hover/select. The canvas is sized to the layout and the page pans (drag), zooms (wheel + buttons), fits to view, filters by kind, and highlights search matches. Two diagram types - Structure (default) and Process (activity flow laid left-to-right with parallel branches) - are chosen by a control kept in the URL (?view=).

## Verified visually vs structurally
- Structurally (automated): engine/graph/tests/layout.rs pins determinism (byte-identical), completeness (99 nodes), non-overlap, containment pointing left-to-right, and the cafe-stand process order with its parallel branch. server/tests/ui.rs pins the rendered SVG: 99 nodes, 165 edges, 2 dangling markers, 25 requirement fills, byte-identical across loads, no script/href/url()/image/use/foreignObject. A live-server geometry probe reported: coffee-machine structure canvas 2130x2080 (aspect 1.02, was a tall strip), 0 overlaps, 0 containment violations, 165 arrowheads; cafe-stand process canvas 804x306 (aspect 2.63), order and parallel both true.
- Visually: this model cannot read images, so I did not inspect the rendered PNGs by eye. Screenshots were captured at e2e/diagram-structure.png and e2e/diagram-process.png for a human to review; legibility is asserted by the geometry checks above, not by viewing.

## Concerns
- Visual acceptance is geometry-asserted, not eyeballed (this model has no image input); a human should glance at the two PNGs.
- Requirement nodes keep the historical amber fill (#fff3cd, a value the existing server test pins); every other kind is white with a token-coloured stroke and kind label. No new kind colours were introduced, but the requirement tint is an existing hex rather than a new token.
- The trial server on 8080 was left running (untouched); all build/test used CARGO_TARGET_DIR=target-tests.

---

## Crate verification (follow-up from controller)

### Crate tried
rust-sugiyama v0.4.0 (MIT, edition 2021). Deps: log 0.4.20, petgraph 0.8.3 (resolves from "0.8.1").

### MSRV gate
cargo +1.75.0 build -p mw-graph  ->  EXIT 0  (with rust-sugiyama added to engine/graph/Cargo.toml)

Why it passed: the workspace pins indexmap = =2.11.4, and that pin unifies petgraph 0.8.3's own indexmap requirement, keeping the whole tree at indexmap 2.11.4 (edition 2021). In a bare scratch crate WITHOUT the pin, the same dependency resolves indexmap 2.14.2 (edition 2024) and fails at 1.75 with "feature edition2024 is required" - so the workspace pin is what makes it work, not the crate itself.

### Determinism
Empirically deterministic: the corpus (99 nodes, 165 edges) produced byte-identical coordinates across 4 separate processes and 3 in-process runs (hash identical every time). HOWEVER, the crate's own test source carries the comment "this test might fail eventually, since the order of elements in a row cannot be guaranteed", which is a HashMap-iteration red flag: determinism is observed, not guaranteed by contract. That is a real risk for a product whose ruling is byte-identical renders.

### Comparison vs my committed implementation (94224e5)
My implementation is SysML-aware and the crate is generic, so it is not a drop-in improvement:
- Edge semantics: mine ignores association for ranking, reverses generalization, and double-weights part/contains so parents stay near children. rust-sugiyama treats every edge uniformly, so the corpus's 33 child->parent association edges (which cycle against the part tree) would be fed raw and collapsed as cycles.
- Process view: mine lays activities left-to-right by include/triggers flow with parallel branches; the crate has no such notion.
- Node sizing: mine sizes boxes to labels; from_vertices_and_edges needs explicit per-vertex sizes and returns grid-unit width/height (the corpus came back 38x10, not pixel extents) plus a LIST of disjoint subgraphs to merge.
- Dangling edges: the corpus has 2 edges whose endpoints name no node; from_vertices_and_edges panics on such edges, so I would still have to pre-filter and draw the unresolved markers myself.
- Determinism: mine is deterministic BY CONSTRUCTION (sorted iteration + id tie-breaks, pinned by a unit test); the crate's is only empirically stable.

### Recommendation
Keep the committed hand-rolled layout. The crate builds at 1.75 and is stable on this corpus, but it is a generic Sugiyama: adopting it would mean re-implementing the SysML edge semantics, containment weighting, process view, node sizing and dangling handling ON TOP of it, and its determinism is not contractually guaranteed. The controller may still choose to switch if it prefers a vetted library over owned code; the module boundary (engine/graph/src/layout.rs returning positions + canvas size) means that swap remains a one-file change.
