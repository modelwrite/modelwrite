# Browser tests for the workbench IDE — report

## Status

**DONE_WITH_CONCERNS**

## What was built

- `e2e/` — a Playwright (`@playwright/test@1.61.1`) suite that starts `mw-server`
  against a throwaway SQLite database, seeds it with the coffee-machine corpus, and
  asserts the three-pane enhancement's runtime behaviour in a real headless browser.
  - `e2e/global-setup.js` starts the server and seeds it; `e2e/global-teardown.js`
    stops it; `e2e/seed.js` is the seeding step (also runnable standalone:
    `node seed.js`).
  - `e2e/tests/ide.spec.js` asserts: the containment tree renders every structure
    element and requirement the page declares; clicking a node updates the properties
    panel; the search box narrows the tree; keyboard navigation selects; the diagram
    carries the `data-mw-id` hook and honours `?select=`; `?select=<id>` deep links
    highlight the right entry; and the no-JS page still shows every element.
- A `browser` job in `.github/workflows/ci.yml` (chosen over a separate workflow
  because it is the same class as the existing `postgres`/\`deploy\` jobs: a CI-only
  runtime dependency that cannot run on a bare machine, triggered by the same push/PR
  events with no special schedule or permissions).
- `.gitignore` entries for `e2e/node_modules/`, `e2e/test-results/`,
  `e2e/playwright-report/`, `e2e/.state.json`.

The dependency boundary holds: Playwright is a devDependency under `e2e/` only, never
served by the product (the product has no build step and `app.js` is embedded in the
binary), and never in the Docker image (`deploy/Dockerfile` copies only `Cargo.toml`,
`engine`, `server` and `cli`).

## The bug the tests caught (primary concern)

Running the suite locally **immediately caught a real runtime bug** in
`server/src/ui/app.js`: `buildGroup` builds the group `<li>` (which contains every
tree node) and returns it, but it is **never appended to the tree** — the `tree`
parameter is unused inside `buildGroup`, and `buildTree` discards
`buildGroup(...)`'s return value. The tree `<ul class="mw-tree">` therefore always
stays empty, so selection, search, keyboard navigation and deep links all operate on
zero DOM nodes.

Evidence:
- `grep appendChild server/src/ui/app.js` shows no `tree.appendChild(li)` for groups
  (the tree `<ul>` only ever receives the empty-state `<li>`).
- The Playwright failure snapshot shows `ul.mw-tree` empty even though the page
  declares 49 structure elements, 25 requirements, 9 signals and 8 activities.
- Patching the one line (insert `tree.appendChild(li);` before `return li;` in
  `buildGroup`, i.e. `buildTree` line 218 could instead read
  `tree.appendChild(buildGroup(tree, group, state));`) — done at runtime in a
  throwaway, uncommitted script — makes **all five** model-page behaviours pass:
  tree = 91 nodes, click → properties panel, search narrows to 1, deep-link highlight,
  keyboard selection.

I did **not** fix it: the task forbids touching `server/src/`. The fix is one line,
but it is out of scope for this task and is flagged here for the delegating agent.

## Local vs CI verification split

Verified **locally** (Windows, Node 22, Chromium already cached):
- All e2e JS files pass `node --check`.
- `.github/workflows/ci.yml` parses as YAML (jobs: engine, msrv, postgres, browser,
  deploy, publish).
- `npm install` succeeds; `package-lock.json` generated (locks @playwright/test 1.61.1,
  chosen to match the locally-cached Chromium build so the suite could actually run).
- The seed step runs against a live server: `node seed.js` → commit
  `f486e54b…`; the served model page renders 49 `li.element`, 25 `tr.requirement`,
  9 `li.signal`, 8 `div.activity`, and the diagram page renders 99 `g.node[data-mw-id]`.
- `npx playwright test` runs end-to-end in a real Chromium: **2 passed** (diagram hook,
  no-JS contract), **5 failed** — all five downstream of the single `buildGroup` bug.

Only runs in **CI** (cannot be verified locally):
- The `ubuntu-latest` GitHub Actions runner itself, `npm ci`, and
  `npx playwright install --with-deps chromium` (apt system-dependency install).
- The GitHub Actions YAML actually executing (local machine is not GitHub Actions).

## Commits

One commit, scoped to the e2e work only (see below). The working tree also contained
unrelated uncommitted changes under `engine/`, `server/src/`, `server/tests/` (from
other in-flight work); the commit below is surgical and excludes them.

## Concerns

1. **The `browser` CI job will be RED until `app.js`'s `buildGroup` appends its
   `<li>` to the tree.** One-line fix in `server/src/ui/app.js` (out of scope here).
2. The workspace had unrelated uncommitted changes (`engine/…`, `server/src/…`,
   `server/tests/references.rs`) that are not part of this task; they were left
   untouched and uncommitted.
