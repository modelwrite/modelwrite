# Agent Acceptance Flow

## Status

DONE

## Commits

- `8efd6a4` — "Build the agent acceptance flow: proposals are persisted and a human accepts them" (12 files: server/ only). Landed on `slice-2-repository`, the workspace's active branch (ahead of `main`, which holds only a docs commit and none of the slice-2 work).

## Test summary

`cargo test --workspace --no-fail-fast`: **413 passed, 0 failed, 24 ignored** (PostgreSQL suite, run by CI).
`cargo fmt --all`: clean. `cargo clippy --workspace --all-targets -- -D warnings`: clean.

New/affected test binaries:

- `server/tests/proposal.rs` (new): 8 passed — record+fetch by id, acceptance commit names both parties, missing-proposal refusal, decided-proposal refusal, HTTP record+fetch, agent refused at accept, human accept end-to-end, refusal recorded.
- `server/tests/postgres.rs`: 3 new `#[ignore]`d proposal tests (24 ignored total, up from 21) so CI's real database run covers the same rules.
- `server/tests/store.rs`, `server/tests/governance.rs`: only the `acceptance: None` field added to existing `ImportProvenance` literals.

## Provenance shape

`CommitProvenance` (server/src/store/mod.rs) gained a fourth variant, `Accepted`, written in the SAME transaction as the commit row:

```json
{ "kind": "accepted", "proposalId": "...", "agent": "loss-report-resolver",
  "acceptedBy": "alex", "acceptedItems": ["uml:Model model-grinder [lossy]", ...] }
```

The acceptance rides the EXISTING import provenance (`ImportProvenance.acceptance: Option<ProposalAcceptance>`) rather than a new commit-model parameter, so the store's commit signature is unchanged (the offline CLI keeps compiling) and every existing commit call site is untouched. `ProposalAcceptance` names the proposal id, the agent that proposed, and the human that accepted; the accepted items are the import's resolved accepted losses.

Both parties are recorded from verified sources, never from a request body:

- the **agent** is the proposal record's `agent` column (the verified subject that recorded the proposal), read back by the commit path;
- the **human** is the accepting request's verified subject (`identity.subject`), carried as `accepted_by` and written to the proposal's `decided_by` column and the commit's provenance.

## How the agent is prevented from accepting

Three layers, all tested:

1. **Startup** (existing, kept): `AuthConfig::agent_token` refuses an agent token holding `author` or `admin`, so an agent can never hold a write role.
2. **Endpoint** (new): `POST /projects/:project/proposals/:id/accept` requires `Permission::Write` before anything else — an agent token (viewer/reviewer only) is refused 403. Proven by `an_agent_is_refused_at_the_acceptance_endpoint`.
3. **Commit path** (new, the authority): the store's `commit_model` substantiates the acceptance inside its transaction — the proposal must exist, be undecided, and have been recorded by the agent the provenance names, and the proposal is marked accepted atomically with the commit. Proven by the store-level tests that drive `commit_model` directly (missing proposal -> NotFound, decided proposal -> Conflict), so ANY route reaching the commit path inherits the rule, not just the endpoint.

A refusal is recorded too: `POST .../refuse` marks the proposal refused with the verified subject and writes a `proposal.refused` audit entry in the same transaction (`a_refusal_is_recorded`).

## Concerns

- The task brief named `main` as the working branch, but the checked-out branch was `slice-2-repository` (which contains all seven slices; `main` is a single docs commit). The commit landed on `slice-2-repository` alongside the rest of the slice-2 history.
- The agent-contract prose (`docs/agents/mcp-tools.json` -> `agentContract.agentIsAClient`) still says "no automated acceptance path yet". It is now stale, but `docs/` is out of scope for this change per the controller's constraints; the manifest is still correct (the new routes are not agent-callable).
- Acceptance is import-scoped: only a loss-report proposal (with a retained artifact and binding) can be accepted; a proposal over other material returns 400. This matches the one real agent (the loss resolver) and is documented in `proposal_api.rs`.
- Re-recording an identical proposal is idempotent on the proposal row but appends a second `proposal.record` audit entry.
