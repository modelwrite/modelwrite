# idc-1 trial live — report

**Status:** DONE_WITH_CONCERNS

## URL and true origin

- **URL:** https://trial.modelwrite.org
- **Served by:** idc-1 (NOT the workstation). The hostname was moved: the Cloudflare
  DNS CNAME now points at idc-1's hatch tunnel
  `895153ce-0e3a-44dd-ae05-d2546302cdcb.cfargotunnel.com`, whose ingress routes it to
  `http://localhost:3102` (modelwrite.service). The workstation cloudflared tunnel that
  previously claimed it was stopped; the local 8080 server still runs (open mode) but no
  longer serves the hostname.

Verbatim (fetched over the public internet from the workstation, third place):

    $ curl -sS https://trial.modelwrite.org/health
    {"authMode":"static","status":"ok"}     [http=200]

    $ curl -sS https://trial.modelwrite.org/projects -H "Authorization: Bearer <token>"
    [{"createdAt":"1789906463","name":"cafe-stand"},{"createdAt":"1789906463","name":"coffee-machine"},{"createdAt":"1789906463","name":"floor-robot"},{"createdAt":"1789906463","name":"microduck"},{"createdAt":"1789906463","name":"purchasing-terminal"},{"createdAt":"1789906463","name":"sandwich-toaster"}]  [http=200]

    $ curl -sS -X POST https://trial.modelwrite.org/projects -H 'content-type: application/json' -d '{"name":"evil-probe"}'
    {"error":"missing bearer token"}   [http=401]

`authMode:"static"` (not the workstation's `"open"`) plus the six seeded models plus a
401 on an unauthenticated write is the proof this is idc-1.

## Reset schedule

- `modelwrite-trial-reset.timer`: `OnCalendar=*-*-* 18:00:00`, `Persistent=true`
  (18:00 UTC = 04:00 Sydney, outside the vLLM fleet's working hours). Enabled.
- Runs `modelwrite-trial-reset.service` (Type=oneshot) →
  `/opt/modelwrite/deploy/reset-trial.sh`.
- The reset is CPU-trivial (starts the existing image, replays seven seed commits over the
  API; no build), so it never disturbs the live model fleet.

## Backup policy

- Before every reset the outgoing DB is copied to `/opt/modelwrite/backups/<date>.db`.
- The last 7 are kept; older ones are pruned. (Same-day re-runs overwrite that day's file,
  date-only naming.)

## Seed baseline (outside the live DB)

- Canonical capture: `/opt/modelwrite/seed/manifest.json` + `documents/` — the exact
  stored documents plus an ordered operation list with expected commit hashes.
- Reproducible from the repository: `docs/deploy/seed-trial.mjs` (committed, pushed as
  `e2c0d2b`) reads `e2e/models/*.json` + the coffee-machine corpus and rebuilds the same
  six models with identical commit hashes (verified).

## Verbatim proof

Reset run by hand (first run) — every reproduced hash matched the captured expected hash:

    commit coffee-machine/main -> 8e373a72c8b5a2b7c38b57a2b26dd749ead41d631450bd9e459958615f9ba498
    commit sandwich-toaster/main -> 3082f48039afa052f9a619c6d07bb8b181be35dda0b96fd92098c15f1ff77d71
    commit purchasing-terminal/main -> caeecbeac90554eac71c84e1d1041d79d614f0f5efc36b65d625021a40a2d0ce
    commit floor-robot/main -> 18dce0588f0065ffbc7b4f3e891fc5cbeaef2dbd48d81d45d1c68387893ec44c
    commit microduck/main -> 44949abc083ddd59ebe66d6dd806bd6a9e2eb5fa274b92e6de357fc0f3da04ca
    commit cafe-stand/main -> dd905e708e8c21a6ea0660a4ea08e2b0814d1a3fe3dc32e16481942681d208f1
    createBranch cafe-stand/with-microduck from dd905e70... -> 201
    commit cafe-stand/with-microduck -> 33e1914b17bc6218fd84ff17c97b0d9a870e31de7c05753241006dcc05080ecb
    verify /projects -> six models present
    cafe-stand main references resolve: {"resolves":true, ... 4 references resolves:true}
    === modelwrite trial reset complete ===

Backup captured the day's play (a throwaway `visitor-play` project was added first, then
the reset ran):

    $ sqlite3 /opt/modelwrite/backups/2026-09-20.db 'SELECT name FROM projects ORDER BY name;'
    cafe-stand, coffee-machine, floor-robot, microduck, purchasing-terminal,
    sandwich-toaster, visitor-play          <- day's play preserved
    $ sqlite3 /opt/modelwrite/data/modelwrite.db 'SELECT name FROM projects ORDER BY name;'
    cafe-stand, coffee-machine, floor-robot, microduck, purchasing-terminal,
    sandwich-toaster                       <- back to the six-model baseline

Safe to run twice: the second run reproduced the same seven hashes and completed cleanly.

Failure partway leaves the service up (seed manifest hidden so the replay fails AFTER the
service is stopped):

    FileNotFoundError: ... '/opt/modelwrite/seed/manifest.json'
    [RESET FAILED - restarting modelwrite.service on the last good database]
    reset exit code: 1
    systemctl is-active modelwrite.service -> active
    /projects -> six models present (last good DB intact)

Repo seed reproducibility (from a fresh checkout, against a throwaway container):

    hashes {"coffee-machine":"8e373a72...","sandwich-toaster":"3082f480...","purchasing-terminal":"caeecbea...","floor-robot":"18dce058...","microduck":"44949abc..."}
    cafe-stand main dd905e70...
    cafe-stand with-microduck 33e1914b...
    SEED_OK

## Pending

None. The DNS change was made with the reachable Cloudflare WRITE token
(`insights-oaic-poc/.env`). Revert record saved at
`.superpowers/sdd/trial-modelwrite-dns-revert.md` (old CNAME target
`dff63553-e90e-4554-bc7a-c266b4b7455f.cfargotunnel.com`).

## Concerns

1. **Concurrent overlapping work.** A second actor was working the same two jobs on idc-1
   while I was: it committed `83b31e9` (the docs update, already pushed), created
   `/opt/modelwrite/seed/models/` + `seed.mjs` + `seed/README.md`, set the reset timer
   to `18:00 UTC` and rewrote the host README. I reconciled rather than fought it: the
   timer is now a single canonical value (18:00 UTC = 04:00 Sydney, matching the pushed
   doc), both seed representations coexist (canonical capture + repo script), and I added
   and pushed `docs/deploy/seed-trial.mjs` (`e2c0d2b`) so the baseline is reproducible
   from the repo, not just from host files. Worth a look to make sure only one agent owns
   this hostname/timer going forward.
2. **Browser note** (unchanged): the UI has no login form; a human visitor must send
   `Authorization: Bearer <token>` (curl/CLI, or a header-setting extension). A public
   URL alone renders a 401 page unless Cloudflare Access (or equivalent) injects the header.
