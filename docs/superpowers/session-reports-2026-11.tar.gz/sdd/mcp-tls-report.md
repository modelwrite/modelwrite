# MCP repository client: HTTPS support (full certificate verification)

## Status

DONE

## Commits

- `34e54dc` mcp: speak HTTPS as well as HTTP, with certificate verification on
  (6 files: Cargo.toml, Cargo.lock, docs/agents/mcp-agent.md, engine/mcp/Cargo.toml,
  engine/mcp/src/repository.rs, engine/mcp/tests/repository.rs)

## Test summary

`cargo test --workspace --no-fail-fast` -> 434 passed, 0 failed, 24 ignored (exit 0);
`cargo clippy --workspace --all-targets -- -D warnings` -> exit 0;
`cargo fmt --all -- --check` -> exit 0. The engine/mcp suite adds two loopback-TLS tests
(a self-signed cert is refused with a certificate error; the same loopback succeeds only when
its CA is added as a trust anchor) and keeps the plain-http loopback test unchanged.

## Reproduced failure (before)

```
$env:MW_MCP_SERVICE_URL = 'https://trial.modelwrite.org'
$env:MW_MCP_TOKEN = 'test-token'
'{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"repo.projects","arguments":{}}}' | mw-mcp
```

-> `{"id":1,"jsonrpc":"2.0","result":{"content":[{"text":"the service URL must be plain http:// (no TLS), got https://trial.modelwrite.org/projects","type":"text"}],"isError":true}}`

## Live check (after)

```
$env:MW_MCP_SERVICE_URL = 'https://trial.modelwrite.org'
$env:MW_MCP_TOKEN = 'agent-demo-token'
'{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"repo.projects","arguments":{}}}' | .	argetdebugmw-mcp.exe
```

-> `{"id":1,"jsonrpc":"2.0","result":{"content":[{"text":"[\n  {\n    \"createdAt\": \"1789773288\",\n    \"name\": \"coffee-machine\"\n  }\n]","type":"text"}],"isError":false}}`

The TLS handshake completes against Cloudflare's certificate (verified against bundled webpki
roots) and the tool returns the real project list, so the failure is gone.

## MSRV evidence

Command: `cargo +1.75.0 build -p mw-mcp --locked`

Output: `Finished dev [unoptimized + debuginfo] target(s) in ...` with `CARGO_EXIT=0`.

The engine 1.75 floor is preserved: rustls 0.23 declares MSRV 1.71, ring 0.17 declares 1.66,
webpki-roots 1.0.9 declares 1.70. The one transitive crate that regressed (zeroize 1.9.0 now
uses edition 2024 / rustc 1.85) is pinned to 1.8.2 in `[workspace.dependencies]`, the same
mechanism as the existing indexmap pin.

## Concerns

- A concurrent loss-reduction task was editing engine/binding-xmi/* and server/src/lib.rs in
  the working tree during this session. Those files were deliberately excluded from the commit
  (this commit touches only engine/mcp/, docs/agents/mcp-agent.md, Cargo.toml and Cargo.lock),
  and were not modified by this work.
- `zeroize = "=1.8.2"` is a hard pin required to keep the engine layer buildable at rustc 1.75;
  it is documented in Cargo.toml exactly like the existing indexmap pin.
- `TcpTransport::with_roots` exists solely to add trust anchors (a private CA, or the loopback
  test CA). It is NOT a verification-disable flag: there is no code path anywhere that accepts
  an invalid certificate, and the self-signed-cert test proves verification is always on.
