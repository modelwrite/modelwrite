# Showcase redeploy report (idc-1)

Status: **DONE_WITH_CONCERNS**

## Commit deployed

- Deployed commit: `47efbf1035a8250e227c9cb2d703a14c1dddf730`
  (`Workbench UX: health view, bulk-accept, branch fix, readable diagram, global search, accept-error`)
  — the tip of `slice-2-repository`, read (fetched), not assumed.
- New image: `modelwrite/modelwrite:idc-1-trial` id `50c8623ed6ac` (~149 MB), built on idc-1
  with `docker build --cpuset-cpus=0-3 -f deploy/Dockerfile -t modelwrite/modelwrite:idc-1-trial .`.
- **Revert note (previous):** image `73211ddac82b`, commit `195cbf84090a68d994900baa2b3acae7ba998479`.
- Restarted **only** `modelwrite.service` (127.0.0.1:3102). `modelwrite-app.service` (3103),
  `cloudflared`, `cloudflared-hatch`, `haproxy` were left untouched and stayed `active`
  throughout. `/health` → `{"authMode":"open","status":"ok"}`.
- Doc commit: `4a3b17f` (`docs(deploy): redeploy idc-1 trial at 47efbf1 (UX fixes), seed container on 3104`),
  pushed to `origin/slice-2-repository`. Host `/opt/modelwrite/README.md` updated in place.

## Reset proof (the reset BROKE, then was fixed)

1. First hand-run `sudo env FORCE=1 /opt/modelwrite/deploy/reset-trial.sh` **FAILED**:
   `docker: Error response from daemon: ... Bind for 127.0.0.1:3103 failed: port is already allocated`
   Root cause: `reset-trial.sh` had `SEED_PORT=3103`, which now collides with
   `modelwrite-app.service` (`-p 127.0.0.1:3103:8080`). The collision was masked because the
   change-detection guard had been skipping (the trial was clean), so the full reset never ran.
   **Fix:** `SEED_PORT=3103` → `SEED_PORT=3104` in `/opt/modelwrite/deploy/reset-trial.sh`.
2. After the fix, the hand-run succeeded end-to-end:
   - replayed the seed manifest (6 createProject + 6 commit + 1 createBranch + 1 commit) and **every
     commit hash matched its `expectedHash`** (8e373a72…, 3082f480…, caeecbea…, 18dce058…, 44949abc…,
     dd905e70…, 33e1914b…);
   - verified all six models present (`cafe-stand, coffee-machine, floor-robot, microduck, purchasing-terminal, sandwich-toaster`);
   - `cafe-stand` main references resolve — 4/4 `resolves:true` (purchasing-terminal, coffee-machine,
     sandwich-toaster, floor-robot);
   - backed up the outgoing DB to `/opt/modelwrite/backups/2026-09-21T071933.db` (217088 bytes);
   - swapped in the fresh DB and restarted; final verify listed the six models.
3. Change-detection guard: ran the reset twice WITHOUT `FORCE`; both logged
   `no changes since the last reset, skipping (service not restarted, no backup taken)`
   and the service was **not** restarted (no new backup taken).

## Acceptance checks (from this workstation, https://trial.modelwrite.org, open mode)

1. **Model-health view — present, one screen, counts verbatim:**
   - `coffee-machine`: Orphaned nodes (0) · Isolated groups (0) · Dangling links (2) · Uncovered requirements (10) → "12 issues found."
     (2 dangling Satisfy links with missing source; 10 named uncovered requirements.)
   - `cafe-stand`: Orphaned nodes (0) · Isolated groups (1) · Dangling links (0) · Uncovered requirements (0) → "1 issue found."
     The isolated group is real: "Group 1 (3 nodes)" — `cafe-stand`, `provisioning-bay`, `service-window`.
2. **Global search — header box + matches with open/reveal actions:**
   - `header.site-header` contains `form.site-search` with input placeholder "Find element"
     (aria-label "Find an element") on project pages.
   - `q=pump` → 2 matches, `q=valve` → 2 matches, `q=grind` → 1 match; every hit carries both an
     `open` (model page, selected) and an `in diagram` (reveal) link.
3. **Bulk receive — blocking page shows accept-all with a visible count:**
   - POSTed a small lossy import (`engine/binding-xmi/fixtures/name-loss.xmi`, binding
     `sysml-v1-xmi@2.4`) → HTTP 422 `Import refused: blocking losses`,
     summary `5 blocking losses · 0 selected`, `Select all 5 losses`, and the button
     `Accept all 5 losses and import`. (No 36 MB import was run.)
4. **Diagram default — readable scale, not fit-to-view:**
   - coffee-machine diagram (99 nodes) server-renders full canvas `2130×2080`; after load the SVG opens at
     `viewBox 0 0 1245.64 640.55` (viewport 1054×542), scale 0.8462 → **effective label size 11 px**
     (the minimum readable), instead of fit-to-view (~6 px labels).
5. **Branding + apex HTTPS:**
   - New branding is served at the apex over HTTP (`http://modelwrite.org/` → 200): `styles.css` has
     `--bg: #faf7ef;`; `index.html` links `favicon.svg` and carries inline SVG wordmark + hero mark.
   - **Apex HTTPS state (verbatim):**
     `curl: (60) schannel: SNI or certificate check failed: SEC_E_WRONG_PRINCIPAL (0x80090322) - The target principal name is incorrect.`
     (`https://www.modelwrite.org` likewise fails with "Hostname/IP does not match certificate's altnames"
     against a `*.github.io` cert.) Not fixed — out of scope, per the brief.

## Concerns

1. **The hourly reset safety net was silently broken** by a seed-port collision introduced when the
   registered tier (`modelwrite-app.service`) took 127.0.0.1:3103. The skip-guard had masked it (the
   trial stayed clean, so the full reset never ran). It would have failed on the next real change, leaving
   an open writable trial with no reset. Fixed (`SEED_PORT=3104`) and re-verified by hand; documented in
   `docs/deploy/idc-1-trial.md` and in the host `reset-trial.sh`.
2. **Apex `https://modelwrite.org` has a TLS trust failure** (`SEC_E_WRONG_PRINCIPAL`) — a known open
   issue, recorded verbatim above and deliberately not fixed.
3. The documented previous commit (`195cbf8`) was stale relative to the `/opt/modelwrite/src` checkout
   (which had been moved to `94953fc` for the registered-tier build); the running showcase image was
   confirmed to be built from `195cbf8` via the reflog and diagram history, so the revert note is accurate.
