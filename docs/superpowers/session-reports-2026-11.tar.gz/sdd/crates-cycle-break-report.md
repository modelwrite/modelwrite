# Crates cycle break & publish: report

## Status

DONE_WITH_CONCERNS

## Commits

- `7bc1dbc6cfb8d8170d948ff6da63694dd719b596` — "chore: break the binding dev-dep cycle and publish the remaining crates"
  - Rename (100%): `engine/binding/tests/xmi_harness.rs` -> `engine/binding-xmi/tests/xmi_harness.rs` — all assertions intact, imports unchanged (crate names `binding` / `binding_xmi` / `okf` resolve identically in the new crate).
  - `engine/binding/Cargo.toml`: removed `mw-binding-xmi` from `[dev-dependencies]` (production deps untouched).
  - `engine/binding-xmi/Cargo.toml`: added `serde_json.workspace = true` to `[dev-dependencies]` (the only genuinely required addition for the moved test's `serde_json::to_vec`).
  - `Cargo.lock`: reflects the graph change (mw-binding no longer dev-depends on mw-binding-xmi; mw-binding-xmi gains serde_json).

## Per-crate results

| Crate | Result | Version |
|-------|--------|---------|
| mw-binding | published | 0.1.0 |
| mw-binding-xmi | published | 0.1.0 |
| mw-agent | published | 0.1.0 |

## Publish order & confirmation

1. mw-binding — `--dry-run` OK, then published; `cargo search mw-binding --limit 1` -> `mw-binding = "0.1.0"`
2. mw-binding-xmi — `--dry-run` OK (verified against the fresh mw-binding 0.1.0 from the index), then published; `cargo search mw-binding-xmi --limit 1` -> `mw-binding-xmi = "0.1.0"`
3. mw-agent — `--dry-run` OK, then published; `cargo search mw-agent --limit 1` -> `mw-agent = "0.1.0"`

## Verification

- `cargo test --workspace --no-fail-fast`: exit 0 (all green, 24 ignored as before)
- `cargo fmt --all -- --check`: exit 0
- `cargo clippy --workspace --all-targets -- -D warnings`: exit 0
- Moved test ran under binding-xmi and passed: `the_real_binding_round_trips_the_subset_with_only_named_id_loss ... ok`

## Concerns

1. **Concurrent edit outside my scope.** A separate process committed `7ced50b` ("website: update MagicDraw measurement (25 reqs, 28 trace links, 270 losses)") on top of my commit while I worked. My commit is intact as its parent; `website/` was out of my scope and I did not touch it.
2. **crates.io new-crate rate limit (429).** mw-binding-xmi and mw-agent each hit 429 once; I waited out the retry windows (until 00:53:02 and 01:03:02 UTC respectively) rather than looping.
3. **serde_json dev-dep.** The moved test's only new dependency need beyond binding-xmi's existing deps was `serde_json` (for `serde_json::to_vec`); added to dev-dependencies only, as instructed.
