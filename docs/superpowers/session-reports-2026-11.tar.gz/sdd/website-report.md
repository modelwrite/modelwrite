# Website report — Modelwrite project website

Status: **DONE_WITH_CONCERNS**

## Commits

- `1b050fc` — `docs: add the static project website and its Pages workflow`
  (website/index.html, website/styles.css, .github/workflows/pages.yml, README.md)

## Files

- `website/index.html` (created) — single-page site: what it is, why it exists,
  how to run it, what works, what it does not do, architecture, numbers, licence.
- `website/styles.css` (created) — hand-written CSS; system fonts only.
- `.github/workflows/pages.yml` (created) — deploys `website/` to GitHub Pages on
  push to `main`; no build step (upload-pages-artifact from the `website/` dir).
- `README.md` (edited) — added a short "Website" section.

## Numbers verified

Each number was read from the repository, not invented.

1. **Test count — 412 passing, 24 ignored** (verified against committed HEAD
   `4a345a7`).
   - Command: `cargo test --workspace --no-fail-fast` (with
     `$env:Path = "$env:USERPROFILE\.cargo\bin;" + $env:Path` first).
   - Result in this working tree: **413 passed, 0 failed, 24 ignored**.
   - The 24 ignored are the PostgreSQL backend suite (`server/tests/postgres.rs`,
     all marked `#[ignore = "requires MW_TEST_DATABASE_URL"]`); CI's `postgres` job
     runs them with `--include-ignored` against a real PostgreSQL 16 container.
   - The committed count is **412**: the working tree carries one extra untracked
     test (`engine/binding-xmi/tests/real_world.rs`, 1 test) that is not committed.
   - NOTE: the brief said "404 tests". That was correct for the earlier HEAD
     (`eeab3c9`). During this task the delegating agent committed `8efd6a4`
     ("Build the agent acceptance flow"), which added `server/tests/proposal.rs`
     (8 passing tests) plus 3 PostgreSQL tests, moving the count from 404/21 to
     412/24. A first run earlier in the session gave 405 passed / 21 ignored (that
     run predated `proposal.rs`).

2. **CI jobs — 4**: `engine`, `msrv`, `postgres`, `deploy`.
   - Verified by reading `.github/workflows/ci.yml` (the `jobs:` keys).

3. **Corpus figures** (`sample/corpus/coffee-machine`), each pinned by a test or the
   evidence annex:
   - 99 graph nodes, 165 graph edges — `engine/graph/tests/graph_stats.rs`
     (`assert_eq!(stats.node_count, 99)`, `assert_eq!(stats.edge_count, 165)`).
   - 1 connected component, 0 isolated nodes — `server/tests/corpus.rs`
     (`componentCount == 1`) and `docs/evidence/2026-09-17-roundtrip-self-pass.json`
     (`"isolated": []`).
   - 25 requirements — `server/tests/corpus.rs` (`coverage.total == 25`) and the
     evidence record.
   - 49 blocks, 9 signals, 8 activities — `server/tests/ui.rs` ("49 structure
     elements, 9 signals, 25 requirements, 8 activities"; asserts 9 signals and
     8 activities in the rendered HTML).

## What the site says the project cannot do

1. An agent cannot write — it proposes; only a human with the write role accepts a
   proposal into a commit, and the commit records both parties.
2. The agent loop is not wired end to end — nothing outside `engine/agent` consumes
   the reasoner's proposals; acceptance is import-scoped (migration loss-report
   proposals only).
3. No content-rich real vendor XMI has been tested — the only real document is a
   Papyrus project skeleton with zero model elements; all other XMI fixtures are
   hand-written and say so.
4. The native XMI-to-OKF direction is not independently measured — the gate measures
   the binding's own round trip; the read rests on the binding's self-reported loss
   report.

## Concerns

1. **The brief's premises were stale.** The brief stated "404 tests" and "there is no
   proposal-to-acceptance flow yet". During this task the delegating agent committed
   the acceptance flow (`8efd6a4`) and the first real model (`4a345a7`). I verified
   against the current HEAD and wrote the site to match it (412 tests; acceptance flow
   exists but an agent still cannot write). If the delegating agent wanted the site to
   describe the pre-acceptance state, this needs their attention.
2. **Branch is `slice-2-repository`, not `main`.** The brief said "branch main",
   but `main` holds only a docs commit; all seven slices live on
   `slice-2-repository`. I committed there. The Pages workflow deploys on push to
   `main`, so it takes effect once this branch merges to `main`.
3. **Active concurrent work.** The working tree contains the delegating agent's
   in-progress, uncommitted changes (several `engine/binding*` files, a new fixture
   `declaration-with-content.xmi`, and `real_world.rs`). I staged only my files and
   left all of that untouched. That ongoing work may change the test count again
   after this report is written.
