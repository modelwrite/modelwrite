# SysML v2 reader wired into the server — report

## Status
DONE

## Commits
- `2772b5f` feat(server): wire the SysML v2 reader into the workbench import surface
  (pushed to origin/slice-2-repository, on top of `6ea0913` the canonical-hash fix).

## One-line test summary
cargo test --workspace --no-fail-fast: 639 passed / 0 failed (3 new sysmlv2_import tests);
cargo fmt --all -- --check clean; cargo clippy --workspace --all-targets -- -D warnings clean;
cargo +1.75.0 build -p mw-binding-sysmlv2 succeeds (engine floor unchanged).

## The fixture result (verbatim loss report)
Real GfSE community model `server/tests/fixtures/Drone_BaseArchitecture.sysml`
(BSD 3-Clause, Gesellschaft für Systems Engineering e.V., 2024; copied byte-for-byte,
SHA256 4d4259468c92d7ec2a89a15a6012360be0199a46bc24f4e96eeafccee7a612a1).
Carried: 1 block (the Drone part def), 4 requirements, 5 graph nodes, 1 subject edge.
Fidelity recorded as `null` (viewer: no round trip measured).

```
[Unmappable] part drone :: top-level usage owned by a package; outside the subset — only definitions and requirements are carried
[Unmappable] #derivation connection :: extension (SYSMOD/custom) declaration; outside the subset
[Unmappable] subject drone : Drone_SystemArchitecture::drone :: redefinition subject type does not resolve to a carried element
[Unmappable] subject battery : Drone_SystemArchitecture::drone.battery :: redefinition subject type does not resolve to a carried element
[Unmappable] subject battery : Drone_SystemArchitecture::drone.battery :: redefinition subject type does not resolve to a carried element
[Unmappable] satisfy Drone_StakeholderRequirements::longDistance by drone :: satisfy relationship: an endpoint is outside the carried subset
[Exact] import RequirementDerivation::* :: declaration: import recognised and not carried — it carries no model content
```

## The exact wording a user sees when an export is refused
The server has no export endpoint, so the refusal surfaces at the binding contract:

- export: `binding export failed: sysml-v2-textual is a viewer (ImportOnly): it reads the textual notation into OKF but cannot write it back`
- round trip: `binding sysml-v2-textual is a viewer and cannot export`

Both are clean `BindingError` values — never a panic, never a 500. The import path
never attempts a round trip for a viewer (it records `fidelity: null` instead), so a
viewer import can never 500 on the fidelity harness.

## Regeneration needed
YES — the docs-consistency task must re-run `node website/generate-docs.mjs` and commit
the regenerated binding list. The generator reads `server/src/binding_registry.rs` and the
binding crate's `BINDING_ID/BINDING_VERSION/Direction/description`; with
`binding_sysmlv2` now registered it will list `sysml-v2-textual@1.0` as a registered
viewer (ImportOnly) in `README.md`, `docs/guide/limits.md` and `docs/guide/faq.md`.
I did NOT run it: it rewrites `docs/` and `README.md`, which the docs task owns, and
my scope forbids touching `docs/`. No generated section was hand-edited.

## Concerns
1. The commit provenance (`commits.provenance`, kind `imported`) records
   `bindingId=sysml-v2-textual`, `bindingVersion=1.0`, the artifact hash and the accepted
   losses — but not a literal `direction` field. The precise story is durable in the import
   record instead: `loss_report.binding.direction = "ImportOnly"` plus `fidelity_diff = null`
   (no round trip measured), so a viewer migration is NOT recorded as round-trip-capable.
   Inlining a `direction` field on `CommitProvenance::Imported`/`ImportProvenance` would
   be a store change (`server/src/store/mod.rs` + sqlite/postgres), which the task rules
   assign to the canonical-hash task — left out deliberately, flagged here for the owner.
2. The canonical-hash task amended its commit while I was working (9bc54ef → 6ea0913), which
   briefly reverted my uncommitted `binding_api.rs` edits; I re-applied them on the final HEAD
   and re-verified (full suite + clippy + fmt all green again). Worth noting for future
   overlapping tasks.
3. The drone fixture demonstrates the top-level-usage, extension, redefinition and
   unsatisfiable-satisfy boundaries; calc/state-machine/actor boundaries are covered by the
   binding's own `out-of-scope.sysml` test (already committed in engine/binding-sysmlv2),
   not by this server fixture.

## Collision record (controller follow-up) — recorded plainly

A file-ownership collision with the canonical-hash task DID happen, and it is
recorded here rather than papered over:

- The canonical-hash task's first `git add` swept my in-progress
  `server/src/binding_api.rs` edits into its commit `9bc54ef`; its amend to
  `6ea0913` (with a force-push) dropped them. This left `binding_api.rs` with
  ONLY that task's canonicalisation changes and NONE of my viewer handling.
- I detected this myself mid-session (a `cargo build` failed with
  `no field 'diff' on type Option<FidelityOutcome>`), re-applied the FULL
  viewer-handling on top of `6ea0913`, re-verified (full suite + clippy + fmt),
  and committed it as `2772b5f`, then pushed. Nothing of my intended work is
  missing: `2772b5f` carries all 108 changed lines of `binding_api.rs`
  (the `Option<binding::FidelityOutcome>` plumbing, the `fidelity_value`
  helper, the ImportOnly round-trip skip, and the three handler responses).
- The docs task then committed `dab69f8` on top of `2772b5f`, regenerating
  the binding list — so the "regeneration needed" flag is now RESOLVED, not open.

Re-verified from the CURRENT tree (HEAD `dab69f8`) after the controller
warning, fresh runs:
- cargo test --test sysmlv2_import → 3 passed / 0 failed
- cargo test --workspace --no-fail-fast → 639 passed / 0 failed
- cargo fmt --all -- --check → clean
- cargo clippy --workspace --all-targets -- -D warnings → clean
- cargo +1.75.0 build -p mw-binding-sysmlv2 → succeeds (engine floor 1.75)

The controller's summary-drift caution (a fixture with a hand-written/empty
summary being re-derived on commit) does NOT apply to this task: the fixture is a
`.sysml` SOURCE file, not an OKF JSON, so there is no summary to drift; the
binding derives the OKF summary and the store re-derives it identically on commit
(the test asserts structure/requirements counts, not the hash).

Stray file observed (not mine, left untouched): an untracked `.json` in the repo
root containing a PowerShell type-reflection dump — appears to be another task's
crashed command output, flagged for the owner rather than deleted.

