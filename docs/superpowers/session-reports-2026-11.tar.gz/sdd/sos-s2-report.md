# System-of-systems S2 — the cross-model edge — report

**Status:** DONE_WITH_CONCERNS

**Commit:** 65898a4 — `S2: typed, content-addressed cross-model edge` (9 files, +771/−33)

**One-line test summary:** `cargo test --workspace --no-fail-fast` green — 565 passed, 0 failed, 25 ignored (4 new S2 tests: 3 compositional-gate cross-model-edge tests + 1 variant-impact test), `cargo fmt --all` clean, `cargo clippy --workspace --all-targets -- -D warnings` clean.

## What S2 delivers

A **typed, content-addressed cross-model edge**: a platform element (an activity or a requirement) declares that it is `implementedBy` or `satisfiedBy` a named element inside a pinned subsystem revision. The edge is `CrossModelEdge { from, relation, to }`, carried as `crossModelEdges` on the existing `SubsystemReference`, so it inherits the reference's (project, revision, role) directly and resolves through the pinned revision — never `latest`.

Three things now hold:

1. **The gate checks it.** `server/src/composition.rs` resolves every cross-model edge against the store (the same `check_reference` + pinned-revision lookup the references endpoint already uses) and reports, as data under `evidence.composition.crossModelEdges`, `resolved` / `unresolved` counts and one finding per edge (`from`, `relation`, `to`, `project`, `revision`, `role`, `resolves`, `reason`, `elementName`). An edge naming an element that does not exist at that revision is a NAMED failure — never a silent dangling edge.
2. **The variant impact becomes provable.** `server/src/ui/review.rs` now renders a `Cross-model edges` table that resolves each side's edges against the store and shows, per platform element, WHAT each version is actually satisfied/implemented by — element name + project@revision. main and with-microduck now differ checkably, not just by a hidden reference.
3. **The boundary shrinks honestly.** The panel's measured-vs-asserted text was narrowed: cross-model edge resolution moved from 'not computed' to 'computed', and the only remaining asserted claim is the global graph property.

## What the panel now shows (main vs with-microduck)

Rendered verbatim from the compare page (the two cafe-stand sides declare one cross-model edge each):

```
References
  role         from · main             to · with-microduck
  floor-care   floor-robot@f07dcec1    microduck@825d5325   [changed]

Requirements
  CS-4  Floor Kept Clear  [both]

Cross-model edges
  platform element        relation      from · main                      to · with-microduck
  CS-4 · Floor Kept Clear satisfied by  Cup Collector (floor-robot@f07dcec1)  Gripper Arm (microduck@825d5325)  [changed]

Summary
  Requirement CS-4 is satisfied in both versions.
```

The `[changed]` rows are the proof: CS-4 resolves to **Cup Collector** (`collector`) inside floor-robot in main, and to **Gripper Arm** (`gripper-arm`) inside microduck in with-microduck — the exact element names the running server's floor-robot and microduck models carry. (The `@f07dcec1` / `@825d5325` hashes are from the demonstration store; the running server's real revisions are floor-robot@`9dcccb6d…` and microduck@`dddf2978…`, which the edges would resolve against once those models declare `crossModelEdges`.)

## The narrowed boundary (verbatim)

**Computed — proved:**
- the platform model's own requirement coverage on each side, from the engine's `requirement_coverage` over that version's graph
- the subsystem reference differences, shown role → project@revision and marked where they change
- each cross-model edge, resolved at its pinned revision — the named element inside the referenced subsystem is shown with its name and project@revision

**Not computed — asserted, not proved:**
- the global graph property: that the union of the platform and all its subsystems, transitively, at their pinned revisions, forms one connected, coverage-complete, orphan-free graph — proving it would require importing every subsystem, which is the copy R1 forbids

The old claim — 'a requirement satisfied by an activity allocated to a role is not proved to be satisfied by the bound element', plus the `allocatedTo`-is-not-a-first-class-edge note — is gone, because it is no longer true.

## Tests added

- `server/tests/composition.rs`: `a_cross_model_edge_resolves_at_the_pinned_revision`, `a_cross_model_edge_naming_a_missing_element_fails_by_name`, `a_reference_revision_change_re_resolves_the_cross_model_edge`.
- `server/tests/impact.rs` (new): `two_cafe_stand_versions_show_a_different_checkable_requirement_impact` (asserts 'Cup Collector' vs 'Gripper Arm', 'satisfied by', and the narrowed boundary).
- `server/tests/references.rs`: listing assertion updated for the new `crossModelEdges` field.
- `engine/okf/tests/{okf_validation,okf_diff}.rs`: struct literals gained `cross_model_edges`.

## Concerns

1. **The edge is nested on the reference, not a top-level list.** The brief says the edge 'names the reference (by role or project)'; I implemented it as `crossModelEdges` *inside* `SubsystemReference`, so it inherits the reference's (project, revision, role) by construction rather than by a `reference` field. This is the content-addressed-through-the-reference ruling made stronger, and it keeps the blast radius inside my ownership (a top-level `OkfRoot` field would have forced edits to ~16 `OkfRoot` literals across binding-xmi, assist, create, analytics, graph, and other crates — several in the other two tasks' territory — for no behavioural gain). Flagged because it is a deliberate deviation from the literal wording.
2. **The running server's real cafe-stand models do not yet declare `crossModelEdges`.** The field is new, so the panel on port 8080 will not show the cross-model row until main and with-microduck gain commits that declare the edges (the running binary also still predates this change). The demonstration above reproduced the real element ids/names (`collector`/Cup Collector, `gripper-arm`/Gripper Arm, `floor-care`, CS-4) into a fresh store, so the proven difference is real but the live 8080 page needs a redeploy + re-commit of the two cafe-stand branches.
3. **`engine/okf/src/validate.rs` does not validate cross-model edge fields.** It is outside the stated ownership list; an empty or dangling `to` is caught by the gate's named resolution check instead of by validation, so nothing is silently dropped — but an empty `from`/`relation` is not rejected at commit time.
4. **`server/tests/references.rs` assertion updated mechanically** (like S0/S1) because the serialised reference now includes `crossModelEdges: []`. No single-model gate behaviour changed.

## What S3 still owes (unchanged by this slice)

- Redaction-preserving references: content redacted, hash intact (R3).
- Security-boundary annotations on references (security vs safety case, §5.2).
- Fleet baselines: a platform model per hull, diffable divergence (§5.4).

## Files

- `engine/okf/src/types.rs` — `CrossModelEdge` type + `crossModelEdges` field on `SubsystemReference`.
- `engine/okf/tests/okf_validation.rs`, `engine/okf/tests/okf_diff.rs` — struct literals.
- `server/src/composition.rs` — `resolve_cross_model_edges`, `CrossModelEdgeResolution`, gate evidence + failures, 4th measured entry.
- `server/src/ui/review.rs` — variant-impact cross-model edges table + narrowed boundary.
- `server/src/ui/composition.rs` — process-view fidelity note updated.
- `server/tests/composition.rs` — 3 new gate tests.
- `server/tests/impact.rs` (new) — 1 new variant-impact test.
- `server/tests/references.rs` — listing assertion.
