﻿# Slice 2 tranche 2 - whole-tranche review package

## Commits

a0a7bff test: pin the merge parent order and cover the shared-deletion path
8aa37c7 feat: revert a branch by appending a commit
758e68e fix: preserve document order through a merge and reject a malformed merge commit
e7c8275 feat: merge two branches with element-level conflict reporting
7a82203 fix: name the missing project on branch deletion and cover both 404 paths
2fb5df1 feat: add the three-way merge engine and multi-parent commits
fd43323 feat: list and delete branches without touching history
24fc136 docs: add the Slice 2 tranche 2 plan (branches, merge, revert)

## Diff stat

 ...026-09-17-modelwrite-slice-2-tranche-2-merge.md | 1250 ++++++++++++++++++++
 server/src/api.rs                                  |  100 +-
 server/src/gate_api.rs                             |   21 +-
 server/src/lib.rs                                  |   16 +-
 server/src/merge.rs                                |  312 +++++
 server/src/merge_api.rs                            |  129 ++
 server/src/store/mod.rs                            |   17 +
 server/src/store/sqlite.rs                         |   92 ++
 server/tests/api.rs                                |  184 +++
 server/tests/merge.rs                              |  237 ++++
 server/tests/merge_api.rs                          |  209 ++++
 11 files changed, 2545 insertions(+), 22 deletions(-)

## Verification observed by the controller

```
cargo test --workspace --no-fail-fast -> 78 tests pass (engine 44, service 34)
cargo fmt --all -- --check and cargo clippy --workspace --all-targets -- -D warnings -> clean
```

## Full diff (-U10)

diff --git a/server/src/api.rs b/server/src/api.rs
index 8cc8d4f..238e9c8 100644
--- a/server/src/api.rs
+++ b/server/src/api.rs
@@ -59,21 +59,40 @@ pub fn map_store_error(e: StoreError) -> ApiError {
     match e {
         StoreError::NotFound(m) => ApiError::not_found(m),
         StoreError::Conflict(m) => ApiError::conflict(m),
         StoreError::Backend(m) => {
             eprintln!("storage error: {}", m);
             ApiError::internal("internal storage error")
         }
     }
 }
 
-fn commit_json(commit: &Commit) -> Value {
+/// Load the OKF document behind a commit hash.
+pub fn load_model(
+    state: &ApiState,
+    project: &str,
+    hash: &str,
+) -> Result<okf::types::OkfRoot, ApiError> {
+    let commit = state
+        .store
+        .commit(project, hash)
+        .map_err(map_store_error)?
+        .ok_or_else(|| ApiError::not_found(format!("commit {}", hash)))?;
+    let bytes = state
+        .store
+        .blob(&commit.okf_hash)
+        .map_err(map_store_error)?
+        .ok_or_else(|| ApiError::internal(format!("missing blob {}", commit.okf_hash)))?;
+    serde_json::from_slice(&bytes).map_err(|e| ApiError::internal(e.to_string()))
+}
+
+pub fn commit_json(commit: &Commit) -> Value {
     json!({
         "hash": commit.hash,
         "project": commit.project,
         "branch": commit.branch,
         "parents": commit.parents,
         "okfHash": commit.okf_hash,
         "author": commit.author,
         "message": commit.message,
         "createdAt": commit.created_at
     })
@@ -219,10 +238,89 @@ pub async fn create_branch(
     validate_name("branch name", &body.name)?;
     state
         .store
         .create_branch(&project, &body.name, &body.from)
         .map_err(map_store_error)?;
     Ok((
         StatusCode::CREATED,
         Json(json!({ "name": body.name, "tip": body.from })),
     ))
 }
+
+pub async fn list_branches(
+    State(state): State<ApiState>,
+    Path(project): Path<String>,
+) -> Result<Json<Value>, ApiError> {
+    if state
+        .store
+        .project(&project)
+        .map_err(map_store_error)?
+        .is_none()
+    {
+        return Err(ApiError::not_found(format!("project {}", project)));
+    }
+    let branches = state
+        .store
+        .list_branches(&project)
+        .map_err(map_store_error)?;
+    let out: Vec<Value> = branches
+        .iter()
+        .map(|(name, tip)| json!({ "name": name, "tip": tip }))
+        .collect();
+    Ok(Json(Value::Array(out)))
+}
+
+pub async fn delete_branch(
+    State(state): State<ApiState>,
+    Path((project, name)): Path<(String, String)>,
+) -> Result<StatusCode, ApiError> {
+    validate_name("branch name", &name)?;
+    state
+        .store
+        .delete_branch(&project, &name)
+        .map_err(map_store_error)?;
+    Ok(StatusCode::NO_CONTENT)
+}
+
+#[derive(Deserialize)]
+pub struct ResetBranch {
+    pub to: String,
+    pub author: String,
+    pub message: String,
+}
+
+/// Restore a branch to the CONTENT of an earlier commit by appending a new commit. The
+/// history is never rewritten: the old tip stays reachable, and the revert is itself a
+/// commit with an author and a message.
+pub async fn reset_branch(
+    State(state): State<ApiState>,
+    Path((project, name)): Path<(String, String)>,
+    Json(body): Json<ResetBranch>,
+) -> Result<(StatusCode, Json<Value>), ApiError> {
+    validate_name("branch name", &name)?;
+    if state
+        .store
+        .branch_tip(&project, &name)
+        .map_err(map_store_error)?
+        .is_none()
+    {
+        return Err(ApiError::not_found(format!("branch {}", name)));
+    }
+    let target = state
+        .store
+        .commit(&project, &body.to)
+        .map_err(map_store_error)?
+        .ok_or_else(|| ApiError::not_found(format!("commit {}", body.to)))?;
+    // The target's model is already stored, so this reuses its blob rather than copying
+    // the bytes: the restored content is byte-identical to the original by construction.
+    let commit = state
+        .store
+        .commit_model(
+            &project,
+            &name,
+            &target.okf_hash,
+            &body.author,
+            &body.message,
+        )
+        .map_err(map_store_error)?;
+    Ok((StatusCode::CREATED, Json(commit_json(&commit))))
+}
diff --git a/server/src/lib.rs b/server/src/lib.rs
index 68d5d63..b47a565 100644
--- a/server/src/lib.rs
+++ b/server/src/lib.rs
@@ -1,14 +1,16 @@
 // SPDX-License-Identifier: AGPL-3.0-or-later
 pub mod api;
 pub mod error;
 pub mod gate_api;
+pub mod merge;
+pub mod merge_api;
 pub mod store;
 
 pub use error::ApiError;
 
 use std::sync::Arc;
 
 use axum::routing::{get, post};
 use axum::{Json, Router};
 use serde_json::json;
 
@@ -34,22 +36,34 @@ pub fn app(state: AppState) -> Router {
         .route("/version", get(version))
         .route(
             "/projects",
             post(api::create_project).get(api::list_projects),
         )
         .route(
             "/projects/:project/commits",
             post(api::create_commit).get(api::list_commits),
         )
         .route("/projects/:project/commits/:hash", get(api::get_commit))
-        .route("/projects/:project/branches", post(api::create_branch))
+        .route(
+            "/projects/:project/branches",
+            post(api::create_branch).get(api::list_branches),
+        )
+        .route(
+            "/projects/:project/branches/:name",
+            axum::routing::delete(api::delete_branch),
+        )
+        .route(
+            "/projects/:project/branches/:name/reset",
+            post(api::reset_branch),
+        )
         .route("/projects/:project/gate", post(gate_api::run_gate))
+        .route("/projects/:project/merge", post(merge_api::merge_branches))
         .route(
             "/projects/:project/gate-runs",
             get(gate_api::list_gate_runs),
         )
         .with_state(api_state)
 }
 
 async fn health() -> Json<serde_json::Value> {
     Json(json!({ "status": "ok" }))
 }
diff --git a/server/src/merge.rs b/server/src/merge.rs
new file mode 100644
index 0000000..98c88b1
--- /dev/null
+++ b/server/src/merge.rs
@@ -0,0 +1,312 @@
+// SPDX-License-Identifier: AGPL-3.0-or-later
+//! Three-way merge over OKF documents, as a pure function.
+//!
+//! Two elements are the same when their canonical JSON is the same, which is the same
+//! discipline the engine's diff uses. Nothing here touches storage or HTTP, so every rule
+//! is unit-testable on its own.
+
+use std::collections::BTreeMap;
+
+use okf::types::{
+    Activity, Element, GraphEdge, GraphNode, OkfRoot, Requirement, StateMachine, Summary,
+};
+use serde::Serialize;
+
+#[derive(Debug, Clone, Serialize, PartialEq)]
+#[serde(rename_all = "camelCase")]
+pub struct Conflict {
+    pub subject: String,
+    pub kind: String,
+    pub base: Option<String>,
+    pub ours: Option<String>,
+    pub theirs: Option<String>,
+}
+
+#[derive(Debug)]
+pub struct MergeOutcome {
+    pub merged: Option<OkfRoot>,
+    pub conflicts: Vec<Conflict>,
+}
+
+fn json<T: Serialize>(value: &T) -> Option<String> {
+    serde_json::to_string(value).ok()
+}
+
+/// Resolve one key by the three-way rule. Returns Ok(Some(value)) to take a value,
+/// Ok(None) when the key is absent in the result, or Err(conflict).
+fn resolve(
+    subject: &str,
+    base: Option<&String>,
+    ours: Option<&String>,
+    theirs: Option<&String>,
+) -> Result<Option<String>, Conflict> {
+    if ours == theirs {
+        return Ok(ours.cloned());
+    }
+    if ours == base {
+        return Ok(theirs.cloned());
+    }
+    if theirs == base {
+        return Ok(ours.cloned());
+    }
+    let kind = match (base, ours, theirs) {
+        (None, Some(_), Some(_)) => "bothAdded",
+        (Some(_), Some(_), None) | (Some(_), None, Some(_)) => "modifiedVersusDeleted",
+        _ => "bothModified",
+    };
+    Err(Conflict {
+        subject: subject.to_string(),
+        kind: kind.to_string(),
+        base: base.cloned(),
+        ours: ours.cloned(),
+        theirs: theirs.cloned(),
+    })
+}
+
+/// Merge a Vec of items keyed by some id, keeping our order and appending theirs.
+fn merge_keyed<T, K, F>(
+    section: &str,
+    base: &[T],
+    ours: &[T],
+    theirs: &[T],
+    key: F,
+    conflicts: &mut Vec<Conflict>,
+) -> Vec<T>
+where
+    T: Clone + Serialize + serde::de::DeserializeOwned,
+    K: Ord + Clone + std::fmt::Debug,
+    F: Fn(&T) -> K,
+{
+    let to_map = |items: &[T]| -> BTreeMap<K, (String, T)> {
+        items
+            .iter()
+            .map(|item| (key(item), (json(item).unwrap_or_default(), item.clone())))
+            .collect()
+    };
+    let base_map = to_map(base);
+    let ours_map = to_map(ours);
+    let theirs_map = to_map(theirs);
+
+    // Our order first, then what only theirs added, in their order. Iterating the maps
+    // would sort by key, and a merge that silently reshuffles a document makes every
+    // merge look like a rewrite. A key present only in base was deleted by both sides, so
+    // it never appears here - which is exactly what should happen to it.
+    let mut keys: Vec<K> = Vec::new();
+    for item in ours {
+        let k = key(item);
+        if !keys.contains(&k) {
+            keys.push(k);
+        }
+    }
+    for item in theirs {
+        let k = key(item);
+        if !keys.contains(&k) {
+            keys.push(k);
+        }
+    }
+
+    let mut out: Vec<T> = Vec::new();
+    for k in keys {
+        let subject = format!("{}:{:?}", section, k);
+        let b = base_map.get(&k).map(|(j, _)| j);
+        let o = ours_map.get(&k).map(|(j, _)| j);
+        let t = theirs_map.get(&k).map(|(j, _)| j);
+        match resolve(&subject, b, o, t) {
+            Ok(Some(chosen)) => {
+                if let Ok(item) = serde_json::from_str::<T>(&chosen) {
+                    out.push(item);
+                }
+            }
+            Ok(None) => {}
+            Err(conflict) => conflicts.push(conflict),
+        }
+    }
+    out
+}
+
+/// Merge a document-level value that is treated as one unit.
+fn merge_unit<T>(
+    subject: &str,
+    base: Option<&T>,
+    ours: Option<&T>,
+    theirs: Option<&T>,
+    conflicts: &mut Vec<Conflict>,
+) -> Option<T>
+where
+    T: Clone + Serialize + serde::de::DeserializeOwned,
+{
+    let b = base.and_then(json);
+    let o = ours.and_then(json);
+    let t = theirs.and_then(json);
+    match resolve(subject, b.as_ref(), o.as_ref(), t.as_ref()) {
+        Ok(Some(chosen)) => serde_json::from_str(&chosen).ok(),
+        Ok(None) => None,
+        Err(conflict) => {
+            conflicts.push(conflict);
+            None
+        }
+    }
+}
+
+fn edge_key(edge: &GraphEdge) -> String {
+    let parts = [
+        edge.source.as_str(),
+        edge.target.as_str(),
+        edge.kind.as_str(),
+        edge.label.as_str(),
+    ];
+    serde_json::to_string(&parts).unwrap_or_default()
+}
+
+/// Recompute the derived counts so the merged document cannot contradict itself.
+fn recompute_summary(merged: &mut OkfRoot) {
+    merged.summary = Summary {
+        blocks: merged.structure.len() as u64,
+        requirements: merged.requirements.len() as u64,
+        interfaces: merged.interfaces.len() as u64,
+        signals: merged.signals.len() as u64,
+        activities: merged.activities.len() as u64,
+        graph_nodes: merged.graph.as_ref().map(|g| g.nodes.len()).unwrap_or(0) as u64,
+        graph_edges: merged.graph.as_ref().map(|g| g.edges.len()).unwrap_or(0) as u64,
+    };
+}
+
+pub fn merge(base: &OkfRoot, ours: &OkfRoot, theirs: &OkfRoot) -> MergeOutcome {
+    let mut conflicts: Vec<Conflict> = Vec::new();
+
+    if base.project != ours.project || base.project != theirs.project {
+        conflicts.push(Conflict {
+            subject: "doc:project".to_string(),
+            kind: "bothModified".to_string(),
+            base: Some(base.project.clone()),
+            ours: Some(ours.project.clone()),
+            theirs: Some(theirs.project.clone()),
+        });
+    }
+
+    let structure = merge_keyed(
+        "structure",
+        &base.structure,
+        &ours.structure,
+        &theirs.structure,
+        |e: &Element| e.id.clone(),
+        &mut conflicts,
+    );
+    let interfaces = merge_keyed(
+        "interfaces",
+        &base.interfaces,
+        &ours.interfaces,
+        &theirs.interfaces,
+        |e: &Element| e.id.clone(),
+        &mut conflicts,
+    );
+    let signals = merge_keyed(
+        "signals",
+        &base.signals,
+        &ours.signals,
+        &theirs.signals,
+        |e: &Element| e.id.clone(),
+        &mut conflicts,
+    );
+    let requirements = merge_keyed(
+        "requirements",
+        &base.requirements,
+        &ours.requirements,
+        &theirs.requirements,
+        |r: &Requirement| r.id.clone(),
+        &mut conflicts,
+    );
+
+    // Ordered structures merge all or nothing: see the rule list above.
+    let state_machine: Option<StateMachine> = merge_unit(
+        "doc:stateMachine",
+        base.state_machine.as_ref(),
+        ours.state_machine.as_ref(),
+        theirs.state_machine.as_ref(),
+        &mut conflicts,
+    );
+    let activities: Vec<Activity> = merge_unit(
+        "doc:activities",
+        Some(&base.activities),
+        Some(&ours.activities),
+        Some(&theirs.activities),
+        &mut conflicts,
+    )
+    .unwrap_or_else(|| ours.activities.clone());
+
+    let base_nodes = base
+        .graph
+        .as_ref()
+        .map(|g| g.nodes.clone())
+        .unwrap_or_default();
+    let our_nodes = ours
+        .graph
+        .as_ref()
+        .map(|g| g.nodes.clone())
+        .unwrap_or_default();
+    let their_nodes = theirs
+        .graph
+        .as_ref()
+        .map(|g| g.nodes.clone())
+        .unwrap_or_default();
+    let nodes = merge_keyed(
+        "graphnode",
+        &base_nodes,
+        &our_nodes,
+        &their_nodes,
+        |n: &GraphNode| n.id.clone(),
+        &mut conflicts,
+    );
+
+    let base_edges = base
+        .graph
+        .as_ref()
+        .map(|g| g.edges.clone())
+        .unwrap_or_default();
+    let our_edges = ours
+        .graph
+        .as_ref()
+        .map(|g| g.edges.clone())
+        .unwrap_or_default();
+    let their_edges = theirs
+        .graph
+        .as_ref()
+        .map(|g| g.edges.clone())
+        .unwrap_or_default();
+    let edges = merge_keyed(
+        "edge",
+        &base_edges,
+        &our_edges,
+        &their_edges,
+        edge_key,
+        &mut conflicts,
+    );
+
+    if !conflicts.is_empty() {
+        return MergeOutcome {
+            merged: None,
+            conflicts,
+        };
+    }
+
+    let mut merged = ours.clone();
+    merged.structure = structure;
+    merged.interfaces = interfaces;
+    merged.signals = signals;
+    merged.requirements = requirements;
+    merged.state_machine = state_machine;
+    merged.activities = activities;
+    // A graph section is only emitted if some input had one: inventing an empty graph
+    // would turn a document that never had one into one that appears to.
+    merged.graph = if base.graph.is_some() || ours.graph.is_some() || theirs.graph.is_some() {
+        Some(okf::types::Graph { nodes, edges })
+    } else {
+        None
+    };
+    recompute_summary(&mut merged);
+
+    MergeOutcome {
+        merged: Some(merged),
+        conflicts,
+    }
+}
diff --git a/server/src/merge_api.rs b/server/src/merge_api.rs
new file mode 100644
index 0000000..e651bf1
--- /dev/null
+++ b/server/src/merge_api.rs
@@ -0,0 +1,129 @@
+// SPDX-License-Identifier: AGPL-3.0-or-later
+use axum::extract::{Path, State};
+use axum::http::StatusCode;
+use axum::Json;
+use serde::Deserialize;
+use serde_json::{json, Value};
+
+use crate::api::{commit_json, load_model, map_store_error, validate_name, ApiState};
+use crate::error::ApiError;
+use crate::merge::merge;
+
+#[derive(Deserialize)]
+pub struct MergeRequest {
+    pub branch: String,
+    pub other: String,
+    pub author: String,
+    pub message: String,
+}
+
+/// Every commit reachable from a tip, tip first. The walk stops at a commit already seen,
+/// so a malformed cycle in stored data cannot loop forever.
+fn ancestry(state: &ApiState, project: &str, tip: &str) -> Result<Vec<String>, ApiError> {
+    // Order matters (the first shared commit is the merge base), so the walk keeps a Vec;
+    // membership is a HashSet so the walk stays linear rather than quadratic in history.
+    let mut seen: Vec<String> = Vec::new();
+    let mut known: std::collections::HashSet<String> = std::collections::HashSet::new();
+    let mut stack: Vec<String> = vec![tip.to_string()];
+    while let Some(hash) = stack.pop() {
+        if !known.insert(hash.clone()) {
+            continue;
+        }
+        if let Some(commit) = state
+            .store
+            .commit(project, &hash)
+            .map_err(map_store_error)?
+        {
+            for parent in &commit.parents {
+                stack.push(parent.clone());
+            }
+        }
+        seen.push(hash);
+    }
+    Ok(seen)
+}
+
+/// The nearest commit both branches share, found by walking our ancestry and taking the
+/// first hash that theirs also reaches. With a linear history that is exactly the fork
+/// point; with merge commits it is an approximation, which is documented rather than
+/// hidden: a general lowest-common-ancestor is a later refinement.
+fn common_ancestor(
+    state: &ApiState,
+    project: &str,
+    ours: &str,
+    theirs: &str,
+) -> Result<String, ApiError> {
+    let our_side = ancestry(state, project, ours)?;
+    let their_side = ancestry(state, project, theirs)?;
+    our_side
+        .iter()
+        .find(|hash| their_side.contains(*hash))
+        .cloned()
+        .ok_or_else(|| ApiError::conflict("the branches share no common ancestor"))
+}
+
+pub async fn merge_branches(
+    State(state): State<ApiState>,
+    Path(project): Path<String>,
+    Json(body): Json<MergeRequest>,
+) -> Result<(StatusCode, Json<Value>), ApiError> {
+    validate_name("branch name", &body.branch)?;
+    validate_name("branch name", &body.other)?;
+
+    let ours_tip = state
+        .store
+        .branch_tip(&project, &body.branch)
+        .map_err(map_store_error)?
+        .ok_or_else(|| ApiError::not_found(format!("branch {}", body.branch)))?;
+    let theirs_tip = state
+        .store
+        .branch_tip(&project, &body.other)
+        .map_err(map_store_error)?
+        .ok_or_else(|| ApiError::not_found(format!("branch {}", body.other)))?;
+
+    let base_hash = common_ancestor(&state, &project, &ours_tip, &theirs_tip)?;
+    let base = load_model(&state, &project, &base_hash)?;
+    let ours = load_model(&state, &project, &ours_tip)?;
+    let theirs = load_model(&state, &project, &theirs_tip)?;
+
+    let outcome = merge(&base, &ours, &theirs);
+    if !outcome.conflicts.is_empty() {
+        // A conflict is not a transport failure: nothing is written, and the caller gets
+        // every conflicting subject with its base, ours and theirs values so a human or an
+        // agent can resolve it deliberately rather than guess.
+        return Ok((
+            StatusCode::CONFLICT,
+            Json(json!({
+                "base": base_hash,
+                "branch": body.branch,
+                "other": body.other,
+                "conflicts": outcome.conflicts
+            })),
+        ));
+    }
+
+    let merged = outcome.merged.ok_or_else(|| {
+        ApiError::internal("the merge reported no conflicts but produced nothing")
+    })?;
+    let bytes = serde_json::to_vec(&merged).map_err(|e| {
+        eprintln!("merged model could not be serialised: {}", e);
+        ApiError::internal("the merged model could not be stored")
+    })?;
+    let okf_hash = state.store.put_blob(&bytes).map_err(map_store_error)?;
+    let commit = state
+        .store
+        .commit_merge(
+            &project,
+            &body.branch,
+            &[ours_tip, theirs_tip],
+            &okf_hash,
+            &body.author,
+            &body.message,
+        )
+        .map_err(map_store_error)?;
+
+    Ok((
+        StatusCode::CREATED,
+        Json(json!({ "commit": commit_json(&commit), "base": base_hash })),
+    ))
+}
