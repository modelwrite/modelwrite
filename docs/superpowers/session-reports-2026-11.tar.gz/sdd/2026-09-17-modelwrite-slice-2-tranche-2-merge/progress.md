﻿# SDD ledger - plan: docs/superpowers/plans/2026-09-17-modelwrite-slice-2-tranche-2-merge.md

Spec: docs/superpowers/specs/2026-09-17-modelwrite-platform-design.md (sections 4.2, 4.3)
Predecessor ledger: .superpowers/sdd/2026-09-17-modelwrite-slice-2-repository-service/progress.md
Working branch: slice-2-repository (tranche 2 continues on the same branch and the same pull request #2, because both tranches are one slice; the pull request body will be updated when tranche 2 completes)

## Pre-flight conflict scan

| Pair / task | Produces vs consumes | Finding |
|---|---|---|
| T1 -> T3 | T1 adds delete_branch and the branch routes; T3 adds the merge route to the same router | Handled: T1 Step 4 names the exact route lines, T3 Step 2 names its one addition. |
| T2 -> T3 | T3 consumes merge::merge and Store::commit_merge | Signatures match the T2 interface block. |
| T2 -> T4 | T4 consumes Store::commit_model only | No dependency on the merge engine. |
| T3 -> T3 | merge_api needs commit_json and load_model from api.rs | Finding: both are private today. Ruling recorded below. |
| T4 -> T4 | the reset handler reuses the target commit's existing blob | No new store method needed: commit_model takes an okf_hash, which is exactly the restored content. |

## Rulings

Ruling: tranche 2 continues on the slice-2-repository branch rather than a new branch, so one pull request covers the slice. Cost if wrong: a larger pull request to review; the alternative, stacked pull requests, is harder to review and to merge in order.
Ruling: the merge engine is a pure function over three documents, in its own module, so every rule is unit-testable without HTTP or storage. Cost if wrong: a small amount of glue in the endpoint.
Ruling: the state machine and the activity list merge all-or-nothing, because they are ordered structures whose internal identity is not stable across an edit. A change on one side is taken; a change on both sides with different results is a conflict. Cost if wrong: a legitimate concurrent edit inside an activity diagram is reported as a conflict and must be resolved by hand, which is safe but less clever.
Ruling: the merge base is the first common commit found by walking our ancestry, which is exact for a linear history and an approximation once merge commits exist. Cost if wrong: an unusual history picks a slightly older base, which produces more conflicts, never a wrong automatic merge.
Ruling: helper functions needed across modules (commit_json, load_model) become public and exist once: load_model moves to api.rs and the copy in gate_api.rs is deleted. Cost if wrong: none; two loaders would drift.

## Environment facts

- Rust and the toolchain are as recorded in the predecessor ledger; the workspace is 62 tests green with fmt and clippy clean.
- No Docker and no PostgreSQL on this machine, so the PostgreSQL backend and the deployment skeleton cannot be exercised locally. They belong to a later tranche and must be verified in CI with a service container, with that limitation recorded honestly rather than glossed.

## Progress

Task 1: dispatched

Task 1: implementation complete (fd43323), 19 service tests pass. Deviation recorded: api.rs had only a post helper, so a get helper was added next to it, as the brief's Step 5 anticipated. Review dispatched; Task 2 (the merge engine) dispatched.

Task 2: implementation complete (2fb5df1), then FAILED its review on one point - the ordering rule. MY BRIEF PRESCRIBED THE BUG: the rule said keep our order and append theirs, while the code it prescribed iterated a BTreeMap, which sorts by key. No test caught it because every fixture used pre-sorted ids.
Ruling: correctness of the stated rule wins. merge_keyed now builds its key list by walking OUR items in order and then theirs, so a merge cannot reshuffle a document and make every merge look like a rewrite. Three tests were added, including one whose ids are deliberately unsorted (b2, b1, then b0 added by them) so the old key-sorted behaviour fails it. Also fixed: the merged document no longer invents an empty graph section when no input had one, and commit_merge now rejects a parent count other than two rather than silently writing a root or single-parent commit under the name of a merge. Merge tests are 9 now; the service suite is 32.
Task 3: implementation complete (e7c8275) with two corrections to my brief - a borrow that did not compile and a test assertion that claimed every commit has exactly one parent when the root has none. Review dispatched.

Task 3: review PASS/PASS. Two Minors were fixed by the controller: the ancestry walk now keeps a HashSet for membership so it is linear rather than quadratic (order is still preserved in a Vec, because the merge base depends on it), and the clean-merge test now pins the parent ORDER [our tip, their tip] rather than only the count.
Task 4: review PASS/PASS. One Minor was fixed: the two 404 paths of the reset endpoint (unknown branch, unknown target) were implemented but untested, and now have a test. The review also flagged a one-test delta between the implementer's report (77) and the controller's count (78): the explanation is that the controller added the shared-deletion merge test after the implementer's run, so the implementer's figure was accurate when it ran and the current figure is 79 with this new test. The third Minor (the brief's Produces wording showing a nested commit object while the handler returns a flat one) is a brief-level wording defect, recorded rather than fixed, since the behaviour is the sane one.

Edge rework re-review: PASS. Findings A, B, D and E resolved; C accepted deliberately with the rationale in the code. The reviewer confirmed the key is injective (a tuple, not a joined string), that no traced edge change can now be lost or duplicated, and that graph.edges order is preserved at pair granularity.
It then found one more Minor, and it was a good catch about MY OWN TEST: the kind test did not discriminate. With ours unchanged and theirs changing the kind, the OLD keying also produced a single edge of the new kind, so the test passed under both keyings and was not regression evidence at all. Ruling: a test that cannot fail against the behaviour it claims to pin is worse than no test, because it looks like proof. It is now three tests - the one-sided change kept for the expected behaviour with a comment saying it does not discriminate, plus two that DO: deleting a link while the other side retypes it must be modifiedVersusDeleted (the old keying silently kept the retyped link and discarded the deletion), and two divergent retypings must be bothModified (the old keying silently kept both).
One residual case is now documented in the code rather than fixed: a link RE-POINTED to a different element on both sides is not detected as a disagreement, because without rename detection each side's new pair is an addition and the two additions union. The merge keeps both relationships rather than inventing one; detecting a re-point needs identity tracking across an edit, which is a larger piece of work than this rule should attempt.
Slice 2 tranche 2 is COMPLETE and verified. Service suite 42 tests; workspace 86. fmt and clippy clean. Pull request #2 updated to describe both tranches.
