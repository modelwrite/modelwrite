﻿### Task 3: The merge endpoint

**Files:**
- Create: server/src/merge_api.rs
- Modify: server/src/lib.rs (declare the module, add the route)
- Test: server/tests/merge_api.rs

**Interfaces:**
- Consumes: store::{Store, commit_merge, commit, branch_tip}; merge::{merge, MergeOutcome}; the gate_api pattern for loading a model behind a commit.
- Produces: POST /projects/:project/merge {"branch", "other", "author", "message"} ->
  - 201 {"commit": {...}, "base": ancestor-hash} when the merge is clean, with a commit whose parents are [branch tip, other tip];
  - 409 {"conflicts": [...], "base": ancestor-hash} when the documents conflict, and NO commit is written;
  - 404 when either branch is unknown.

- [ ] **Step 1: Write server/src/merge_api.rs**

```rust
// SPDX-License-Identifier: AGPL-3.0-or-later
use axum::extract::{Path, State};
use axum::http::StatusCode;
use axum::Json;
use serde::Deserialize;
use serde_json::{json, Value};

use crate::api::{commit_json, load_model, map_store_error, validate_name, ApiState};
use crate::error::ApiError;
use crate::merge::merge;

#[derive(Deserialize)]
pub struct MergeRequest {
    pub branch: String,
    pub other: String,
    pub author: String,
    pub message: String,
}

/// Every commit reachable from a tip, tip first. The walk stops at a commit already seen,
/// so a malformed cycle in stored data cannot loop forever.
fn ancestry(state: &ApiState, project: &str, tip: &str) -> Result<Vec<String>, ApiError> {
    let mut seen: Vec<String> = Vec::new();
    let mut stack: Vec<String> = vec![tip.to_string()];
    while let Some(hash) = stack.pop() {
        if seen.contains(&hash) {
            continue;
        }
        if let Some(commit) = state.store.commit(project, &hash).map_err(map_store_error)? {
            for parent in &commit.parents {
                stack.push(parent.clone());
            }
        }
        seen.push(hash);
    }
    Ok(seen)
}

/// The nearest commit both branches share, found by walking our ancestry and taking the
/// first hash that theirs also reaches. With a linear history that is exactly the fork
/// point; with merge commits it is an approximation, which is documented rather than
/// hidden: a general lowest-common-ancestor is a later refinement.
fn common_ancestor(state: &ApiState, project: &str, ours: &str, theirs: &str) -> Result<String, ApiError> {
    let our_side = ancestry(state, project, ours)?;
    let their_side = ancestry(state, project, theirs)?;
    our_side
        .iter()
        .find(|hash| their_side.contains(hash))
        .cloned()
        .ok_or_else(|| ApiError::conflict("the branches share no common ancestor"))
}

pub async fn merge_branches(
    State(state): State<ApiState>,
    Path(project): Path<String>,
    Json(body): Json<MergeRequest>,
) -> Result<(StatusCode, Json<Value>), ApiError> {
    validate_name("branch name", &body.branch)?;
    validate_name("branch name", &body.other)?;

    let ours_tip = state
        .store
        .branch_tip(&project, &body.branch)
        .map_err(map_store_error)?
        .ok_or_else(|| ApiError::not_found(format!("branch {}", body.branch)))?;
    let theirs_tip = state
        .store
        .branch_tip(&project, &body.other)
        .map_err(map_store_error)?
        .ok_or_else(|| ApiError::not_found(format!("branch {}", body.other)))?;

    let base_hash = common_ancestor(&state, &project, &ours_tip, &theirs_tip)?;
    let base = load_model(&state, &project, &base_hash)?;
    let ours = load_model(&state, &project, &ours_tip)?;
    let theirs = load_model(&state, &project, &theirs_tip)?;

    let outcome = merge(&base, &ours, &theirs);
    if !outcome.conflicts.is_empty() {
        // A conflict is not a transport failure: nothing is written, and the caller gets
        // every conflicting subject with its base, ours and theirs values so a human or an
        // agent can resolve it deliberately rather than guess.
        return Ok((
            StatusCode::CONFLICT,
            Json(json!({
                "base": base_hash,
                "branch": body.branch,
                "other": body.other,
                "conflicts": outcome.conflicts
            })),
        ));
    }

    let merged = outcome
        .merged
        .ok_or_else(|| ApiError::internal("the merge reported no conflicts but produced nothing"))?;
    let bytes = serde_json::to_vec(&merged).map_err(|e| {
        eprintln!("merged model could not be serialised: {}", e);
        ApiError::internal("the merged model could not be stored")
    })?;
    let okf_hash = state.store.put_blob(&bytes).map_err(map_store_error)?;
    let commit = state
        .store
        .commit_merge(
            &project,
            &body.branch,
            &[ours_tip, theirs_tip],
            &okf_hash,
            &body.author,
            &body.message,
        )
        .map_err(map_store_error)?;

    Ok((
        StatusCode::CREATED,
        Json(json!({ "commit": commit_json(&commit), "base": base_hash })),
    ))
}
```

This requires three items to be public in server/src/api.rs: ApiState (already public),
map_store_error (already public), validate_name (already public), and commit_json and
load_model, which the implementer must make public (they are currently private helpers of
api.rs and gate_api.rs respectively). Move load_model into api.rs if that is simpler, and
delete the copy in gate_api.rs so there is exactly one loader.

- [ ] **Step 2: Add the route**

In server/src/lib.rs add `pub mod merge_api;` and:

```rust
        .route("/projects/:project/merge", post(merge_api::merge_branches))
```

- [ ] **Step 3: Write server/tests/merge_api.rs**

Three tests, each starting from a fresh temporary store:

```rust
// SPDX-License-Identifier: AGPL-3.0-or-later
//! The merge endpoint end to end: a clean merge writes a two-parent commit, a conflict
//! writes nothing and names the conflicts, and the branch tips are left as they were.

use axum::body::Body;
use axum::http::{Request, StatusCode};
use http_body_util::BodyExt;
use serde_json::{json, Value};
use tower::ServiceExt;

fn state(dir: &std::path::Path) -> server::AppState {
    let store = server::store::sqlite::SqliteStore::open(&dir.join("mw.db")).unwrap();
    server::AppState {
        store: std::sync::Arc::new(store),
        evidence_dir: dir.to_path_buf(),
    }
}

fn post(uri: &str, body: Value) -> Request<Body> {
    Request::builder()
        .method("POST")
        .uri(uri)
        .header("content-type", "application/json")
        .body(Body::from(body.to_string()))
        .unwrap()
}

fn get(uri: &str) -> Request<Body> {
    Request::builder().uri(uri).body(Body::empty()).unwrap()
}

async fn json_body(response: axum::response::Response) -> Value {
    let bytes = response.into_body().collect().await.unwrap().to_bytes();
    serde_json::from_slice(&bytes).unwrap()
}

fn model(block_name: &str) -> Value {
    json!({
        "project": "coffee",
        "exportedAt": "2026-09-17T00:00:00Z",
        "summary": {},
        "stateMachine": {"name": "sm", "regions": []},
        "requirements": [{
            "id": "r1", "name": "r1", "kind": "requirement",
            "stereotypes": ["Requirement"], "attributes": [], "documentation": "",
            "reqId": "1.1", "reqText": "text"
        }],
        "structure": [{
            "id": "b1", "name": block_name, "kind": "block",
            "stereotypes": ["Block"], "attributes": [], "documentation": ""
        }],
        "graph": {
            "nodes": [
                {"id": "b1", "kind": "block", "name": "Block"},
                {"id": "r1", "kind": "requirement", "name": "r1"}
            ],
            "edges": [{"source": "b1", "target": "r1", "kind": "dependency", "label": "Satisfy"}]
        }
    })
}

async fn seed(router: &axum::Router) -> String {
    router
        .clone()
        .oneshot(post("/projects", json!({ "name": "coffee" })))
        .await
        .unwrap();
    let committed = router
        .clone()
        .oneshot(post(
            "/projects/coffee/commits",
            json!({ "branch": "main", "author": "alex", "message": "base", "okf": model("Block") }),
        ))
        .await
        .unwrap();
    let hash = json_body(committed).await["hash"].as_str().unwrap().to_string();
    router
        .clone()
        .oneshot(post(
            "/projects/coffee/branches",
            json!({ "name": "feature", "from": hash }),
        ))
        .await
        .unwrap();
    hash
}

#[tokio::test]
async fn a_clean_merge_writes_a_two_parent_commit() {
    let dir = tempfile::tempdir().unwrap();
    let router = server::app(state(dir.path()));
    let _base = seed(&router).await;

    // The feature branch renames the block; main is untouched.
    router
        .clone()
        .oneshot(post(
            "/projects/coffee/commits",
            json!({ "branch": "feature", "author": "alex", "message": "rename", "okf": model("Renamed") }),
        ))
        .await
        .unwrap();

    let merged = router
        .clone()
        .oneshot(post(
            "/projects/coffee/merge",
            json!({ "branch": "main", "other": "feature", "author": "alex", "message": "merge feature" }),
        ))
        .await
        .unwrap();
    assert_eq!(merged.status(), StatusCode::CREATED);
    let body = json_body(merged).await;
    assert_eq!(body["commit"]["parents"].as_array().unwrap().len(), 2);

    // The merged model is what the branch now serves, and it carries the rename.
    let tip = body["commit"]["hash"].as_str().unwrap().to_string();
    let fetched = router
        .oneshot(get(&format!("/projects/coffee/commits/{}", tip)))
        .await
        .unwrap();
    let served = json_body(fetched).await;
    assert_eq!(served["structure"][0]["name"], "Renamed");
}

#[tokio::test]
async fn a_conflicting_merge_writes_nothing_and_names_every_conflict() {
    let dir = tempfile::tempdir().unwrap();
    let router = server::app(state(dir.path()));
    seed(&router).await;

    router
        .clone()
        .oneshot(post(
            "/projects/coffee/commits",
            json!({ "branch": "feature", "author": "alex", "message": "theirs", "okf": model("Theirs") }),
        ))
        .await
        .unwrap();
    router
        .clone()
        .oneshot(post(
            "/projects/coffee/commits",
            json!({ "branch": "main", "author": "alex", "message": "ours", "okf": model("Ours") }),
        ))
        .await
        .unwrap();

    let conflicted = router
        .clone()
        .oneshot(post(
            "/projects/coffee/merge",
            json!({ "branch": "main", "other": "feature", "author": "alex", "message": "merge" }),
        ))
        .await
        .unwrap();
    assert_eq!(conflicted.status(), StatusCode::CONFLICT);
    let body = json_body(conflicted).await;
    let conflicts = body["conflicts"].as_array().unwrap();
    assert_eq!(conflicts.len(), 1);
    assert_eq!(conflicts[0]["kind"], "bothModified");

    // Nothing was written: main still points at our commit, not at a merge.
    let history = router
        .oneshot(get("/projects/coffee/commits?branch=main"))
        .await
        .unwrap();
    let history = json_body(history).await;
    let commits = history.as_array().unwrap();
    assert_eq!(commits.len(), 2, "the base commit and ours, and no merge commit");
    for commit in commits {
        assert_eq!(commit["parents"].as_array().unwrap().len(), 1);
    }
}

#[tokio::test]
async fn merging_an_unknown_branch_is_not_found() {
    let dir = tempfile::tempdir().unwrap();
    let router = server::app(state(dir.path()));
    seed(&router).await;
    let response = router
        .oneshot(post(
            "/projects/coffee/merge",
            json!({ "branch": "main", "other": "nope", "author": "alex", "message": "merge" }),
        ))
        .await
        .unwrap();
    assert_eq!(response.status(), StatusCode::NOT_FOUND);
}
```

- [ ] **Step 4: Run, lint and commit**

```powershell
cargo test -p mw-server --no-fail-fast
cargo fmt --all
cargo clippy -p mw-server --all-targets -- -D warnings
git add server
git commit -m "feat: merge two branches with element-level conflict reporting"
```

Expected: 28 tests pass.

---


