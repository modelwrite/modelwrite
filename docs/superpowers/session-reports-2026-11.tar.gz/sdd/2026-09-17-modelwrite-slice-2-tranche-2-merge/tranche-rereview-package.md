﻿# Tranche 2 fix re-review package

## Full diff (-U10) of the fix round

diff --git a/server/src/api.rs b/server/src/api.rs
index 238e9c8..9689934 100644
--- a/server/src/api.rs
+++ b/server/src/api.rs
@@ -74,22 +74,28 @@ pub fn load_model(
 ) -> Result<okf::types::OkfRoot, ApiError> {
     let commit = state
         .store
         .commit(project, hash)
         .map_err(map_store_error)?
         .ok_or_else(|| ApiError::not_found(format!("commit {}", hash)))?;
     let bytes = state
         .store
         .blob(&commit.okf_hash)
         .map_err(map_store_error)?
-        .ok_or_else(|| ApiError::internal(format!("missing blob {}", commit.okf_hash)))?;
-    serde_json::from_slice(&bytes).map_err(|e| ApiError::internal(e.to_string()))
+        .ok_or_else(|| {
+            eprintln!("missing blob {}", commit.okf_hash);
+            ApiError::internal("the stored model is missing")
+        })?;
+    serde_json::from_slice(&bytes).map_err(|e| {
+        eprintln!("stored model is not readable: {}", e);
+        ApiError::internal("the stored model could not be read")
+    })
 }
 
 pub fn commit_json(commit: &Commit) -> Value {
     json!({
         "hash": commit.hash,
         "project": commit.project,
         "branch": commit.branch,
         "parents": commit.parents,
         "okfHash": commit.okf_hash,
         "author": commit.author,
@@ -290,20 +296,28 @@ pub struct ResetBranch {
 
 /// Restore a branch to the CONTENT of an earlier commit by appending a new commit. The
 /// history is never rewritten: the old tip stays reachable, and the revert is itself a
 /// commit with an author and a message.
 pub async fn reset_branch(
     State(state): State<ApiState>,
     Path((project, name)): Path<(String, String)>,
     Json(body): Json<ResetBranch>,
 ) -> Result<(StatusCode, Json<Value>), ApiError> {
     validate_name("branch name", &name)?;
+    if state
+        .store
+        .project(&project)
+        .map_err(map_store_error)?
+        .is_none()
+    {
+        return Err(ApiError::not_found(format!("project {}", project)));
+    }
     if state
         .store
         .branch_tip(&project, &name)
         .map_err(map_store_error)?
         .is_none()
     {
         return Err(ApiError::not_found(format!("branch {}", name)));
     }
     let target = state
         .store
diff --git a/server/src/merge.rs b/server/src/merge.rs
index 98c88b1..0509f78 100644
--- a/server/src/merge.rs
+++ b/server/src/merge.rs
@@ -67,47 +67,48 @@ fn resolve(
 fn merge_keyed<T, K, F>(
     section: &str,
     base: &[T],
     ours: &[T],
     theirs: &[T],
     key: F,
     conflicts: &mut Vec<Conflict>,
 ) -> Vec<T>
 where
     T: Clone + Serialize + serde::de::DeserializeOwned,
-    K: Ord + Clone + std::fmt::Debug,
+    K: Ord + Clone + std::fmt::Debug + std::hash::Hash + Eq,
     F: Fn(&T) -> K,
 {
     let to_map = |items: &[T]| -> BTreeMap<K, (String, T)> {
         items
             .iter()
             .map(|item| (key(item), (json(item).unwrap_or_default(), item.clone())))
             .collect()
     };
     let base_map = to_map(base);
     let ours_map = to_map(ours);
     let theirs_map = to_map(theirs);
 
     // Our order first, then what only theirs added, in their order. Iterating the maps
     // would sort by key, and a merge that silently reshuffles a document makes every
     // merge look like a rewrite. A key present only in base was deleted by both sides, so
     // it never appears here - which is exactly what should happen to it.
     let mut keys: Vec<K> = Vec::new();
+    let mut known: std::collections::HashSet<K> = std::collections::HashSet::new();
     for item in ours {
         let k = key(item);
-        if !keys.contains(&k) {
+        if known.insert(k.clone()) {
             keys.push(k);
         }
     }
     for item in theirs {
         let k = key(item);
-        if !keys.contains(&k) {
+        if known.insert(k.clone()) {
             keys.push(k);
         }
     }
 
     let mut out: Vec<T> = Vec::new();
     for k in keys {
         let subject = format!("{}:{:?}", section, k);
         let b = base_map.get(&k).map(|(j, _)| j);
         let o = ours_map.get(&k).map(|(j, _)| j);
         let t = theirs_map.get(&k).map(|(j, _)| j);
@@ -141,28 +142,72 @@ where
     match resolve(subject, b.as_ref(), o.as_ref(), t.as_ref()) {
         Ok(Some(chosen)) => serde_json::from_str(&chosen).ok(),
         Ok(None) => None,
         Err(conflict) => {
             conflicts.push(conflict);
             None
         }
     }
 }
 
-fn edge_key(edge: &GraphEdge) -> String {
-    let parts = [
-        edge.source.as_str(),
-        edge.target.as_str(),
-        edge.kind.as_str(),
-        edge.label.as_str(),
-    ];
-    serde_json::to_string(&parts).unwrap_or_default()
+/// One relationship as a unit: a source, a target, a kind, and the set of labels carried
+/// between them.
+///
+/// Keying an edge by ALL of its fields, label included, makes key-equality the same thing
+/// as content-equality - so the three-way rule's conflict branches can never fire for an
+/// edge, and an edit on one side looks like a delete plus an add. Concretely: if ours
+/// removes a Satisfy link while theirs relabels it Verify, both sides drop the old key and
+/// theirs adds a new one, so ours' deletion is silently discarded. Grouping by identity
+/// (source, target, kind) and comparing the label SET as content is what makes that case a
+/// modifiedVersusDeleted conflict, as it should be. The label set also means two edges
+/// sharing a triple are never collapsed into one.
+#[derive(Clone, Serialize, serde::Deserialize)]
+struct EdgeUnit {
+    source: String,
+    target: String,
+    kind: String,
+    labels: Vec<String>,
+}
+
+fn edge_units(edges: &[GraphEdge]) -> Vec<EdgeUnit> {
+    let mut grouped: BTreeMap<(String, String, String), std::collections::BTreeSet<String>> =
+        BTreeMap::new();
+    for edge in edges {
+        grouped
+            .entry((edge.source.clone(), edge.target.clone(), edge.kind.clone()))
+            .or_default()
+            .insert(edge.label.clone());
+    }
+    grouped
+        .into_iter()
+        .map(|((source, target, kind), labels)| EdgeUnit {
+            source,
+            target,
+            kind,
+            labels: labels.into_iter().collect(),
+        })
+        .collect()
+}
+
+fn edges_from_units(units: &[EdgeUnit]) -> Vec<GraphEdge> {
+    let mut edges = Vec::new();
+    for unit in units {
+        for label in &unit.labels {
+            edges.push(GraphEdge {
+                source: unit.source.clone(),
+                target: unit.target.clone(),
+                kind: unit.kind.clone(),
+                label: label.clone(),
+            });
+        }
+    }
+    edges
 }
 
 /// Recompute the derived counts so the merged document cannot contradict itself.
 fn recompute_summary(merged: &mut OkfRoot) {
     merged.summary = Summary {
         blocks: merged.structure.len() as u64,
         requirements: merged.requirements.len() as u64,
         interfaces: merged.interfaces.len() as u64,
         signals: merged.signals.len() as u64,
         activities: merged.activities.len() as u64,
@@ -225,20 +270,23 @@ pub fn merge(base: &OkfRoot, ours: &OkfRoot, theirs: &OkfRoot) -> MergeOutcome {
         theirs.state_machine.as_ref(),
         &mut conflicts,
     );
     let activities: Vec<Activity> = merge_unit(
         "doc:activities",
         Some(&base.activities),
         Some(&ours.activities),
         Some(&theirs.activities),
         &mut conflicts,
     )
+    // merge_unit returns None only when it pushed a conflict, and a conflict aborts the
+    // merge before this value is used; the fallback exists so the type checks out, not to
+    // silently prefer ours.
     .unwrap_or_else(|| ours.activities.clone());
 
     let base_nodes = base
         .graph
         .as_ref()
         .map(|g| g.nodes.clone())
         .unwrap_or_default();
     let our_nodes = ours
         .graph
         .as_ref()
@@ -266,28 +314,28 @@ pub fn merge(base: &OkfRoot, ours: &OkfRoot, theirs: &OkfRoot) -> MergeOutcome {
     let our_edges = ours
         .graph
         .as_ref()
         .map(|g| g.edges.clone())
         .unwrap_or_default();
     let their_edges = theirs
         .graph
         .as_ref()
         .map(|g| g.edges.clone())
         .unwrap_or_default();
-    let edges = merge_keyed(
+    let edges = edges_from_units(&merge_keyed(
         "edge",
-        &base_edges,
-        &our_edges,
-        &their_edges,
-        edge_key,
+        &edge_units(&base_edges),
+        &edge_units(&our_edges),
+        &edge_units(&their_edges),
+        |unit: &EdgeUnit| format!("{}|{}|{}", unit.source, unit.target, unit.kind),
         &mut conflicts,
-    );
+    ));
 
     if !conflicts.is_empty() {
         return MergeOutcome {
             merged: None,
             conflicts,
         };
     }
 
     let mut merged = ours.clone();
     merged.structure = structure;
diff --git a/server/src/merge_api.rs b/server/src/merge_api.rs
index e651bf1..7747223 100644
--- a/server/src/merge_api.rs
+++ b/server/src/merge_api.rs
@@ -10,72 +10,114 @@ use crate::error::ApiError;
 use crate::merge::merge;
 
 #[derive(Deserialize)]
 pub struct MergeRequest {
     pub branch: String,
     pub other: String,
     pub author: String,
     pub message: String,
 }
 
-/// Every commit reachable from a tip, tip first. The walk stops at a commit already seen,
-/// so a malformed cycle in stored data cannot loop forever.
-fn ancestry(state: &ApiState, project: &str, tip: &str) -> Result<Vec<String>, ApiError> {
-    // Order matters (the first shared commit is the merge base), so the walk keeps a Vec;
-    // membership is a HashSet so the walk stays linear rather than quadratic in history.
-    let mut seen: Vec<String> = Vec::new();
-    let mut known: std::collections::HashSet<String> = std::collections::HashSet::new();
+/// Every commit reachable from a tip, as a set. The walk stops at a commit already seen, so
+/// a malformed cycle in stored data cannot loop forever, and membership is constant time.
+fn ancestry_set(
+    state: &ApiState,
+    project: &str,
+    tip: &str,
+) -> Result<std::collections::HashSet<String>, ApiError> {
+    let mut seen: std::collections::HashSet<String> = std::collections::HashSet::new();
     let mut stack: Vec<String> = vec![tip.to_string()];
     while let Some(hash) = stack.pop() {
-        if !known.insert(hash.clone()) {
+        if !seen.insert(hash.clone()) {
             continue;
         }
         if let Some(commit) = state
             .store
             .commit(project, &hash)
             .map_err(map_store_error)?
         {
             for parent in &commit.parents {
                 stack.push(parent.clone());
             }
         }
-        seen.push(hash);
     }
     Ok(seen)
 }
 
-/// The nearest commit both branches share, found by walking our ancestry and taking the
-/// first hash that theirs also reaches. With a linear history that is exactly the fork
-/// point; with merge commits it is an approximation, which is documented rather than
-/// hidden: a general lowest-common-ancestor is a later refinement.
+/// The LOWEST commit both branches share: a shared commit that is not an ancestor of any
+/// other shared commit.
+///
+/// Taking the first shared commit in walk order is not the same thing, and the difference
+/// is not cosmetic. Once a merge commit exists, a walk can meet an older common ancestor
+/// before the real one, and an older base silently DISCARDS a change: if theirs reverted a
+/// value that ours already carries, then at the older base theirs looks unchanged, so ours
+/// wins and the revert disappears with no conflict reported. When the search finds more
+/// than one lowest candidate - a criss-cross history - it refuses with a conflict rather
+/// than guessing, because either guess can lose work.
 fn common_ancestor(
     state: &ApiState,
     project: &str,
     ours: &str,
     theirs: &str,
 ) -> Result<String, ApiError> {
-    let our_side = ancestry(state, project, ours)?;
-    let their_side = ancestry(state, project, theirs)?;
-    our_side
-        .iter()
-        .find(|hash| their_side.contains(*hash))
-        .cloned()
-        .ok_or_else(|| ApiError::conflict("the branches share no common ancestor"))
+    let our_side = ancestry_set(state, project, ours)?;
+    let their_side = ancestry_set(state, project, theirs)?;
+    let mut shared: Vec<String> = our_side.intersection(&their_side).cloned().collect();
+    if shared.is_empty() {
+        return Err(ApiError::conflict("the branches share no common ancestor"));
+    }
+    shared.sort();
+
+    let mut lowest: Vec<String> = Vec::new();
+    for candidate in &shared {
+        let mut is_ancestor_of_another = false;
+        for other in &shared {
+            if other == candidate {
+                continue;
+            }
+            let other_side = ancestry_set(state, project, other)?;
+            if other_side.contains(candidate) {
+                is_ancestor_of_another = true;
+                break;
+            }
+        }
+        if !is_ancestor_of_another {
+            lowest.push(candidate.clone());
+        }
+    }
+
+    match lowest.len() {
+        1 => Ok(lowest.remove(0)),
+        0 => Err(ApiError::internal(
+            "no shared commit survived the merge base search",
+        )),
+        _ => Err(ApiError::conflict(
+            "the branches have more than one possible merge base, so the merge cannot be computed automatically",
+        )),
+    }
 }
 
 pub async fn merge_branches(
     State(state): State<ApiState>,
     Path(project): Path<String>,
     Json(body): Json<MergeRequest>,
 ) -> Result<(StatusCode, Json<Value>), ApiError> {
     validate_name("branch name", &body.branch)?;
     validate_name("branch name", &body.other)?;
+    if state
+        .store
+        .project(&project)
+        .map_err(map_store_error)?
+        .is_none()
+    {
+        return Err(ApiError::not_found(format!("project {}", project)));
+    }
 
     let ours_tip = state
         .store
         .branch_tip(&project, &body.branch)
         .map_err(map_store_error)?
         .ok_or_else(|| ApiError::not_found(format!("branch {}", body.branch)))?;
     let theirs_tip = state
         .store
         .branch_tip(&project, &body.other)
         .map_err(map_store_error)?
@@ -98,20 +140,32 @@ pub async fn merge_branches(
                 "branch": body.branch,
                 "other": body.other,
                 "conflicts": outcome.conflicts
             })),
         ));
     }
 
     let merged = outcome.merged.ok_or_else(|| {
         ApiError::internal("the merge reported no conflicts but produced nothing")
     })?;
+
+    // Every commit path validates before it stores. A merge must not be the one that skips
+    // it: if a future rule ever produced a document that contradicts itself, this turns a
+    // silent bad write into a loud failure.
+    let report = okf::validate::validate(&merged);
+    if !report.valid {
+        eprintln!("merged model failed validation: {:?}", report.errors);
+        return Err(ApiError::internal(
+            "the merged model failed validation and was not stored",
+        ));
+    }
+
     let bytes = serde_json::to_vec(&merged).map_err(|e| {
         eprintln!("merged model could not be serialised: {}", e);
         ApiError::internal("the merged model could not be stored")
     })?;
     let okf_hash = state.store.put_blob(&bytes).map_err(map_store_error)?;
     let commit = state
         .store
         .commit_merge(
             &project,
             &body.branch,
diff --git a/server/src/store/sqlite.rs b/server/src/store/sqlite.rs
index d3596d3..3639387 100644
--- a/server/src/store/sqlite.rs
+++ b/server/src/store/sqlite.rs
@@ -239,20 +239,44 @@ impl Store for SqliteStore {
             )));
         }
         let guard = self
             .connection
             .lock()
             .map_err(|_| StoreError::Backend("connection lock poisoned".to_string()))?;
         let tx = guard
             .unchecked_transaction()
             .map_err(|e| StoreError::Backend(e.to_string()))?;
 
+        // The first parent must still BE the branch tip. A merge is computed from tips read
+        // BEFORE this call, so if anything landed in between - another commit, a merge or a
+        // reset - writing this commit would move the branch off that work and leave it
+        // unreachable: a stored commit no branch explains, which is silent loss. Refusing
+        // with a conflict is the same check-then-write discipline commit_model applies.
+        let current_tip: Option<String> = (|| -> rusqlite::Result<Option<String>> {
+            let mut stmt =
+                tx.prepare("SELECT tip FROM branches WHERE project = ?1 AND name = ?2")?;
+            let mut rows = stmt.query(params![project, branch])?;
+            match rows.next()? {
+                Some(row) => Ok(Some(row.get(0)?)),
+                None => Ok(None),
+            }
+        })()
+        .map_err(|e| StoreError::Backend(e.to_string()))?;
+        if current_tip.as_deref() != Some(parents[0].as_str()) {
+            return Err(StoreError::Conflict(format!(
+                "branch {} moved while the merge was being prepared (expected {}, found {})",
+                branch,
+                parents[0],
+                current_tip.as_deref().unwrap_or("nothing")
+            )));
+        }
+
         // Every parent must already exist: a merge commit can only cite ancestry that is
         // really there, never invent it.
         for parent in parents {
             let exists: bool = (|| -> rusqlite::Result<bool> {
                 let mut stmt =
                     tx.prepare("SELECT 1 FROM commits WHERE project = ?1 AND hash = ?2")?;
                 let mut rows = stmt.query(params![project, parent])?;
                 Ok(rows.next()?.is_some())
             })()
             .map_err(|e| StoreError::Backend(e.to_string()))?;
diff --git a/server/tests/merge.rs b/server/tests/merge.rs
index 88d1766..99fe231 100644
--- a/server/tests/merge.rs
+++ b/server/tests/merge.rs
@@ -228,10 +228,44 @@ fn deleting_the_same_element_on_both_sides_merges_cleanly() {
     let theirs = okf(model("Block", false));
     let outcome = merge(&base, &ours, &theirs);
     assert!(outcome.conflicts.is_empty(), "{:?}", outcome.conflicts);
     let merged = outcome.merged.expect("a shared deletion merges cleanly");
     assert_eq!(merged.requirements.len(), 1);
     assert!(
         merged.requirements.iter().all(|r| r.id != "r2"),
         "the element both sides deleted must not come back"
     );
 }
+#[test]
+fn deleting_an_edge_while_the_other_relabels_it_conflicts() {
+    // The case the old keying could not see: keyed by every field, ours deleting the edge
+    // and theirs relabelling it looked like agreement to delete plus an addition, so ours'
+    // deletion was silently discarded. Identity (source, target, kind) makes it a conflict.
+    let base = okf(model("Block", false));
+    let mut our_value = model("Block", false);
+    our_value["graph"]["edges"] = json!([]);
+    let ours = okf(our_value);
+
+    let mut their_value = model("Block", false);
+    their_value["graph"]["edges"][0]["label"] = json!("Verify");
+    let theirs = okf(their_value);
+
+    let outcome = merge(&base, &ours, &theirs);
+    assert!(
+        outcome.merged.is_none(),
+        "a relationship removed by one side and changed by the other must conflict"
+    );
+    assert_eq!(outcome.conflicts.len(), 1);
+    assert_eq!(outcome.conflicts[0].kind, "modifiedVersusDeleted");
+}
+
+#[test]
+fn two_different_relabels_of_one_edge_conflict() {
+    let base = okf(model("Block", false));
+    let mut our_value = model("Block", false);
+    our_value["graph"]["edges"][0]["label"] = json!("Verify");
+    let mut their_value = model("Block", false);
+    their_value["graph"]["edges"][0]["label"] = json!("Refine");
+    let outcome = merge(&base, &okf(our_value), &okf(their_value));
+    assert!(outcome.merged.is_none());
+    assert_eq!(outcome.conflicts[0].kind, "bothModified");
+}
diff --git a/server/tests/merge_api.rs b/server/tests/merge_api.rs
index aeec53a..ae64cf0 100644
--- a/server/tests/merge_api.rs
+++ b/server/tests/merge_api.rs
@@ -200,10 +200,124 @@ async fn merging_an_unknown_branch_is_not_found() {
     seed(&router).await;
     let response = router
         .oneshot(post(
             "/projects/coffee/merge",
             json!({ "branch": "main", "other": "nope", "author": "alex", "message": "merge" }),
         ))
         .await
         .unwrap();
     assert_eq!(response.status(), StatusCode::NOT_FOUND);
 }
+/// Commit a document onto a branch and return the commit hash.
+async fn commit(router: &axum::Router, branch: &str, message: &str, okf: Value) -> String {
+    let response = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/commits",
+            json!({ "branch": branch, "author": "alex", "message": message, "okf": okf }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(response.status(), StatusCode::CREATED, "commit {}", message);
+    json_body(response).await["hash"]
+        .as_str()
+        .unwrap()
+        .to_string()
+}
+
+#[tokio::test]
+async fn a_second_merge_uses_the_lowest_common_ancestor() {
+    // A merge base that is too OLD silently discards a change, and the change it discards
+    // is a revert - the most expensive kind to lose, because the model goes back to a value
+    // nobody chose. This is the scenario: once a merge commit exists, a walk can meet an
+    // older shared ancestor before the real one, and at that older base the reverted value
+    // looks unchanged, so ours wins and the revert disappears with no conflict reported.
+    let dir = tempfile::tempdir().unwrap();
+    let router = server::app(state(dir.path()));
+    router
+        .clone()
+        .oneshot(post("/projects", json!({ "name": "coffee" })))
+        .await
+        .unwrap();
+
+    // R: the shared root, where the edge is labelled Satisfy.
+    let root = commit(&router, "main", "root", model("Block")).await;
+
+    // m1: main relabels the edge to Verify, and that becomes the true merge base later.
+    let mut verified = model("Block");
+    verified["graph"]["edges"][0]["label"] = json!("Verify");
+    let m1 = commit(&router, "main", "relabel", verified.clone()).await;
+
+    // A side branch from R, with a change that does not touch the edge.
+    router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/branches",
+            json!({ "name": "side", "from": root }),
+        ))
+        .await
+        .unwrap();
+    let mut side_model = model("Block");
+    side_model["requirements"]
+        .as_array_mut()
+        .unwrap()
+        .push(json!({
+            "id": "r2", "name": "r2", "kind": "requirement",
+            "stereotypes": ["Requirement"], "attributes": [], "documentation": "",
+            "reqId": "1.2", "reqText": "added on the side"
+        }));
+    let _side = commit(&router, "side", "side change", side_model).await;
+
+    // X: the first merge, which is what makes an older base reachable.
+    let first_merge = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/merge",
+            json!({ "branch": "main", "other": "side", "author": "alex", "message": "merge side" }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(first_merge.status(), StatusCode::CREATED);
+
+    // feature: branched from m1, and it REVERTS the edge back to Satisfy.
+    router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/branches",
+            json!({ "name": "feature", "from": m1 }),
+        ))
+        .await
+        .unwrap();
+    let _revert_commit = commit(&router, "feature", "revert the relabel", model("Block")).await;
+
+    // The second merge. The base must be m1, not R.
+    let second_merge = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/merge",
+            json!({ "branch": "main", "other": "feature", "author": "alex", "message": "merge feature" }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(second_merge.status(), StatusCode::CREATED);
+    let body = json_body(second_merge).await;
+    assert_eq!(
+        body["base"],
+        json!(m1),
+        "the base must be the lowest common ancestor, not the older root"
+    );
+
+    // And the revert survives: the label is back to Satisfy, not still Verify.
+    let merged = router
+        .oneshot(get(&format!(
+            "/projects/coffee/commits/{}",
+            body["commit"]["hash"].as_str().unwrap()
+        )))
+        .await
+        .unwrap();
+    let served = json_body(merged).await;
+    assert_eq!(
+        served["graph"]["edges"][0]["label"],
+        json!("Satisfy"),
+        "an older base would have silently discarded the revert"
+    );
+}
diff --git a/server/tests/store.rs b/server/tests/store.rs
index 63d1af9..3b1fefa 100644
--- a/server/tests/store.rs
+++ b/server/tests/store.rs
@@ -148,10 +148,58 @@ fn concurrent_commits_to_one_branch_form_a_linear_chain() {
             .expect("the tip and its ancestors must all be in the history");
         cursor = commit.parents.first().cloned();
         seen.push(hash);
     }
     assert_eq!(
         seen.len(),
         8,
         "walking back from the tip must reach all eight commits"
     );
 }
+#[test]
+fn a_merge_refuses_when_the_branch_moved_under_it() {
+    // A merge is computed from tips read before the write. If a commit lands in between,
+    // writing the merge would move the branch off that commit and orphan it: stored, but
+    // unreachable from any branch. The store must refuse instead of losing it.
+    let (store, _dir) = store();
+    store.create_project("coffee").unwrap();
+    let root = store
+        .commit_model("coffee", "main", "okf-root", "alex", "root")
+        .unwrap();
+    store
+        .create_branch("coffee", "feature", &root.hash)
+        .unwrap();
+    let their_side = store
+        .commit_model("coffee", "feature", "okf-feature", "alex", "feature")
+        .unwrap();
+
+    // The concurrent commit: main moves AFTER the merge read its tips.
+    let concurrent = store
+        .commit_model("coffee", "main", "okf-concurrent", "alex", "concurrent")
+        .unwrap();
+
+    let refused = store.commit_merge(
+        "coffee",
+        "main",
+        &[root.hash.clone(), their_side.hash.clone()],
+        "okf-merged",
+        "alex",
+        "merge",
+    );
+    match refused {
+        Err(StoreError::Conflict(_)) => {}
+        other => panic!("expected a conflict, got {:?}", other.map(|c| c.hash)),
+    }
+
+    // Nothing moved, and the concurrent commit is still the tip.
+    assert_eq!(
+        store.branch_tip("coffee", "main").unwrap().unwrap(),
+        concurrent.hash
+    );
+    let merges: Vec<_> = store
+        .commits_on("coffee", "main")
+        .unwrap()
+        .into_iter()
+        .filter(|c| c.parents.len() == 2)
+        .collect();
+    assert!(merges.is_empty(), "no merge commit may be written");
+}
