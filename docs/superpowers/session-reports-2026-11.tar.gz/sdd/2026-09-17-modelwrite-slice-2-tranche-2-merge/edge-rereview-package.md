﻿# Edge identity rework - re-review package

## Full diff (-U10)

diff --git a/server/src/merge.rs b/server/src/merge.rs
index 0509f78..0ad8ada 100644
--- a/server/src/merge.rs
+++ b/server/src/merge.rs
@@ -142,67 +142,86 @@ where
     match resolve(subject, b.as_ref(), o.as_ref(), t.as_ref()) {
         Ok(Some(chosen)) => serde_json::from_str(&chosen).ok(),
         Ok(None) => None,
         Err(conflict) => {
             conflicts.push(conflict);
             None
         }
     }
 }
 
-/// One relationship as a unit: a source, a target, a kind, and the set of labels carried
-/// between them.
+/// One relationship as a unit: the PAIR of elements is the identity, and the links carried
+/// between them - each a kind and a label - are the content.
 ///
-/// Keying an edge by ALL of its fields, label included, makes key-equality the same thing
-/// as content-equality - so the three-way rule's conflict branches can never fire for an
-/// edge, and an edit on one side looks like a delete plus an add. Concretely: if ours
-/// removes a Satisfy link while theirs relabels it Verify, both sides drop the old key and
-/// theirs adds a new one, so ours' deletion is silently discarded. Grouping by identity
-/// (source, target, kind) and comparing the label SET as content is what makes that case a
-/// modifiedVersusDeleted conflict, as it should be. The label set also means two edges
-/// sharing a triple are never collapsed into one.
+/// Two earlier keyings were wrong in the same way, and the difference matters because each
+/// failed silently rather than loudly.
+///
+/// Keying an edge by every field including the label makes key-equality the same thing as
+/// content-equality, so the three-way rule's conflict branches can never fire: ours deleting
+/// a Satisfy link while theirs relabels it Verify reads as agreement-to-delete plus an
+/// addition, and our deletion disappears.
+///
+/// Keying it by (source, target, kind) fixes that and moves the same failure onto kind: a
+/// change of kind becomes a delete plus an add, so both the old and the new link survive and
+/// the graph claims a relationship nobody made.
+///
+/// Identity is therefore the pair alone, and the key is the pair TUPLE rather than a joined
+/// string, because a joined string can collide on its separator and silently drop a unit.
+/// The identity is coarse on purpose: two independent edits between the same two elements
+/// conflict instead of merging, and a visible conflict is resolvable while a silently
+/// duplicated or discarded relationship is not.
 #[derive(Clone, Serialize, serde::Deserialize)]
 struct EdgeUnit {
     source: String,
     target: String,
-    kind: String,
-    labels: Vec<String>,
+    /// Sorted (kind, label) pairs, so a unit is order-insensitive and deterministic.
+    links: Vec<(String, String)>,
 }
 
 fn edge_units(edges: &[GraphEdge]) -> Vec<EdgeUnit> {
-    let mut grouped: BTreeMap<(String, String, String), std::collections::BTreeSet<String>> =
+    // First appearance decides the order, so merging does not reshuffle graph.edges.
+    let mut order: Vec<(String, String)> = Vec::new();
+    let mut grouped: BTreeMap<(String, String), std::collections::BTreeSet<(String, String)>> =
         BTreeMap::new();
     for edge in edges {
+        let pair = (edge.source.clone(), edge.target.clone());
+        if !grouped.contains_key(&pair) {
+            order.push(pair.clone());
+        }
         grouped
-            .entry((edge.source.clone(), edge.target.clone(), edge.kind.clone()))
+            .entry(pair)
             .or_default()
-            .insert(edge.label.clone());
+            .insert((edge.kind.clone(), edge.label.clone()));
     }
-    grouped
+    order
         .into_iter()
-        .map(|((source, target, kind), labels)| EdgeUnit {
-            source,
-            target,
-            kind,
-            labels: labels.into_iter().collect(),
+        .map(|(source, target)| {
+            let links = grouped.get(&(source.clone(), target.clone()));
+            EdgeUnit {
+                source,
+                target,
+                links: links
+                    .map(|set| set.iter().cloned().collect())
+                    .unwrap_or_default(),
+            }
         })
         .collect()
 }
 
 fn edges_from_units(units: &[EdgeUnit]) -> Vec<GraphEdge> {
     let mut edges = Vec::new();
     for unit in units {
-        for label in &unit.labels {
+        for (kind, label) in &unit.links {
             edges.push(GraphEdge {
                 source: unit.source.clone(),
                 target: unit.target.clone(),
-                kind: unit.kind.clone(),
+                kind: kind.clone(),
                 label: label.clone(),
             });
         }
     }
     edges
 }
 
 /// Recompute the derived counts so the merged document cannot contradict itself.
 fn recompute_summary(merged: &mut OkfRoot) {
     merged.summary = Summary {
@@ -319,21 +338,21 @@ pub fn merge(base: &OkfRoot, ours: &OkfRoot, theirs: &OkfRoot) -> MergeOutcome {
     let their_edges = theirs
         .graph
         .as_ref()
         .map(|g| g.edges.clone())
         .unwrap_or_default();
     let edges = edges_from_units(&merge_keyed(
         "edge",
         &edge_units(&base_edges),
         &edge_units(&our_edges),
         &edge_units(&their_edges),
-        |unit: &EdgeUnit| format!("{}|{}|{}", unit.source, unit.target, unit.kind),
+        |unit: &EdgeUnit| (unit.source.clone(), unit.target.clone()),
         &mut conflicts,
     ));
 
     if !conflicts.is_empty() {
         return MergeOutcome {
             merged: None,
             conflicts,
         };
     }
 
diff --git a/server/src/merge_api.rs b/server/src/merge_api.rs
index 7747223..9347d66 100644
--- a/server/src/merge_api.rs
+++ b/server/src/merge_api.rs
@@ -60,40 +60,48 @@ fn common_ancestor(
     theirs: &str,
 ) -> Result<String, ApiError> {
     let our_side = ancestry_set(state, project, ours)?;
     let their_side = ancestry_set(state, project, theirs)?;
     let mut shared: Vec<String> = our_side.intersection(&their_side).cloned().collect();
     if shared.is_empty() {
         return Err(ApiError::conflict("the branches share no common ancestor"));
     }
     shared.sort();
 
+    // Each candidate's ancestry is computed ONCE. The comparison below is quadratic in the
+    // number of candidates, and recomputing a whole history walk inside that loop turned a
+    // quadratic into something much worse for no reason.
+    let mut ancestries: std::collections::HashMap<String, std::collections::HashSet<String>> =
+        std::collections::HashMap::new();
+    for candidate in &shared {
+        ancestries.insert(candidate.clone(), ancestry_set(state, project, candidate)?);
+    }
+
     let mut lowest: Vec<String> = Vec::new();
     for candidate in &shared {
-        let mut is_ancestor_of_another = false;
-        for other in &shared {
-            if other == candidate {
-                continue;
-            }
-            let other_side = ancestry_set(state, project, other)?;
-            if other_side.contains(candidate) {
-                is_ancestor_of_another = true;
-                break;
-            }
-        }
+        let is_ancestor_of_another = shared.iter().any(|other| {
+            other != candidate
+                && ancestries
+                    .get(other)
+                    .map(|side| side.contains(candidate))
+                    .unwrap_or(false)
+        });
         if !is_ancestor_of_another {
             lowest.push(candidate.clone());
         }
     }
 
     match lowest.len() {
         1 => Ok(lowest.remove(0)),
+        // Unreachable in a finite history: the reachability relation is a partial order, so
+        // a non-empty set of shared commits always has a maximal element. Kept as a refusal
+        // rather than a panic, in case the data ever stops being a finite history.
         0 => Err(ApiError::internal(
             "no shared commit survived the merge base search",
         )),
         _ => Err(ApiError::conflict(
             "the branches have more than one possible merge base, so the merge cannot be computed automatically",
         )),
     }
 }
 
 pub async fn merge_branches(
diff --git a/server/tests/merge.rs b/server/tests/merge.rs
index 99fe231..7bf057e 100644
--- a/server/tests/merge.rs
+++ b/server/tests/merge.rs
@@ -262,10 +262,27 @@ fn deleting_an_edge_while_the_other_relabels_it_conflicts() {
 fn two_different_relabels_of_one_edge_conflict() {
     let base = okf(model("Block", false));
     let mut our_value = model("Block", false);
     our_value["graph"]["edges"][0]["label"] = json!("Verify");
     let mut their_value = model("Block", false);
     their_value["graph"]["edges"][0]["label"] = json!("Refine");
     let outcome = merge(&base, &okf(our_value), &okf(their_value));
     assert!(outcome.merged.is_none());
     assert_eq!(outcome.conflicts[0].kind, "bothModified");
 }
+#[test]
+fn changing_an_edge_kind_on_one_side_does_not_duplicate_it() {
+    // With kind folded into identity, a kind edit became a delete plus an add, so the old
+    // and the new link BOTH survived and the merged graph claimed a relationship nobody
+    // made. Identity is the element pair, so this is an ordinary one-sided change.
+    let base = okf(model("Block", false));
+    let ours = okf(model("Block", false));
+    let mut their_value = model("Block", false);
+    their_value["graph"]["edges"][0]["kind"] = json!("allocation");
+    let theirs = okf(their_value);
+
+    let outcome = merge(&base, &ours, &theirs);
+    assert!(outcome.conflicts.is_empty(), "{:?}", outcome.conflicts);
+    let edges = outcome.merged.expect("clean merge").graph.unwrap().edges;
+    assert_eq!(edges.len(), 1, "the edited link must replace the old one");
+    assert_eq!(edges[0].kind, "allocation");
+}
