﻿### Task 4: Revert without rewriting history

**Files:**
- Modify: server/src/api.rs (one handler)
- Modify: server/src/lib.rs (one route)
- Test: server/tests/api.rs (one test)

**Interfaces:**
- Consumes: store::{commit, commit_model, blob, branch_tip}; validate_name; commit_json.
- Produces: POST /projects/:project/branches/:name/reset {"to": commit-hash, "author", "message"} -> 201 {"commit": {...}} where the new commit's CONTENT equals the target commit's content and its parent is the branch's previous tip. 404 when the branch or the target commit is unknown.

Why a new commit rather than a move: a branch pointer that moves backwards makes every
hash that was built on the old tip unreachable from the branch while still stored, so a
colleague who already pulled it holds a history the repository no longer explains. A revert
commit keeps every commit reachable and records who restored what.

- [ ] **Step 1: Add the handler to server/src/api.rs**

```rust
#[derive(Deserialize)]
pub struct ResetBranch {
    pub to: String,
    pub author: String,
    pub message: String,
}

/// Restore a branch to the CONTENT of an earlier commit by appending a new commit. The
/// history is never rewritten: the old tip stays reachable, and the revert is itself a
/// commit with an author and a message.
pub async fn reset_branch(
    State(state): State<ApiState>,
    Path((project, name)): Path<(String, String)>,
    Json(body): Json<ResetBranch>,
) -> Result<(StatusCode, Json<Value>), ApiError> {
    validate_name("branch name", &name)?;
    if state.store.branch_tip(&project, &name).map_err(map_store_error)?.is_none() {
        return Err(ApiError::not_found(format!("branch {}", name)));
    }
    let target = state
        .store
        .commit(&project, &body.to)
        .map_err(map_store_error)?
        .ok_or_else(|| ApiError::not_found(format!("commit {}", body.to)))?;
    // The target's model is already stored, so this reuses its blob rather than copying
    // the bytes: the restored content is byte-identical to the original by construction.
    let commit = state
        .store
        .commit_model(&project, &name, &target.okf_hash, &body.author, &body.message)
        .map_err(map_store_error)?;
    Ok((StatusCode::CREATED, Json(commit_json(&commit))))
}
```

- [ ] **Step 2: Add the route**

```rust
        .route(
            "/projects/:project/branches/:name/reset",
            post(api::reset_branch),
        )
```

- [ ] **Step 3: Test it**

Append to server/tests/api.rs:

```rust
#[tokio::test]
async fn a_reset_appends_a_commit_and_keeps_the_old_tip_reachable() {
    let dir = tempfile::tempdir().unwrap();
    let router = server::app(state(dir.path()));
    router
        .clone()
        .oneshot(post("/projects", serde_json::json!({ "name": "coffee" })))
        .await
        .unwrap();
    let first = router
        .clone()
        .oneshot(post(
            "/projects/coffee/commits",
            serde_json::json!({ "branch": "main", "author": "alex", "message": "one", "okf": tiny_okf() }),
        ))
        .await
        .unwrap();
    let first_hash = json_body(first).await["hash"].as_str().unwrap().to_string();

    let mut second_model = tiny_okf();
    second_model["project"] = serde_json::json!("changed");
    let second = router
        .clone()
        .oneshot(post(
            "/projects/coffee/commits",
            serde_json::json!({ "branch": "main", "author": "alex", "message": "two", "okf": second_model }),
        ))
        .await
        .unwrap();
    let second_hash = json_body(second).await["hash"].as_str().unwrap().to_string();

    let reset = router
        .clone()
        .oneshot(post(
            "/projects/coffee/branches/main/reset",
            serde_json::json!({ "to": first_hash, "author": "alex", "message": "revert to one" }),
        ))
        .await
        .unwrap();
    assert_eq!(reset.status(), StatusCode::CREATED);
    let revert = json_body(reset).await;
    assert_eq!(revert["parents"], serde_json::json!([second_hash]));

    // The reverted content matches the target, and the superseded commit is still there.
    let tip = revert["hash"].as_str().unwrap().to_string();
    let fetched = router
        .clone()
        .oneshot(
            Request::builder()
                .uri(format!("/projects/coffee/commits/{}", tip))
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();
    assert_eq!(json_body(fetched).await, tiny_okf());

    let superseded = router
        .oneshot(
            Request::builder()
                .uri(format!("/projects/coffee/commits/{}", second_hash))
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();
    assert_eq!(superseded.status(), StatusCode::OK);
}
```

- [ ] **Step 4: Run, lint and commit**

```powershell
cargo test --workspace --no-fail-fast
cargo fmt --all
cargo clippy --workspace --all-targets -- -D warnings
git add server
git commit -m "feat: revert a branch by appending a commit"
```

Expected: 29 service tests pass, and the whole workspace with them.

---


