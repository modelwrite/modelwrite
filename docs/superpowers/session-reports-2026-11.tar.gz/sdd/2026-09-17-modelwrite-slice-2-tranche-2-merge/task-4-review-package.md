﻿# Tranche 2 Task 4 review package (revert)

## Full diff (-U10) of the revert work

diff --git a/server/src/api.rs b/server/src/api.rs
index 25cc5ac..238e9c8 100644
--- a/server/src/api.rs
+++ b/server/src/api.rs
@@ -273,10 +273,54 @@ pub async fn delete_branch(
     State(state): State<ApiState>,
     Path((project, name)): Path<(String, String)>,
 ) -> Result<StatusCode, ApiError> {
     validate_name("branch name", &name)?;
     state
         .store
         .delete_branch(&project, &name)
         .map_err(map_store_error)?;
     Ok(StatusCode::NO_CONTENT)
 }
+
+#[derive(Deserialize)]
+pub struct ResetBranch {
+    pub to: String,
+    pub author: String,
+    pub message: String,
+}
+
+/// Restore a branch to the CONTENT of an earlier commit by appending a new commit. The
+/// history is never rewritten: the old tip stays reachable, and the revert is itself a
+/// commit with an author and a message.
+pub async fn reset_branch(
+    State(state): State<ApiState>,
+    Path((project, name)): Path<(String, String)>,
+    Json(body): Json<ResetBranch>,
+) -> Result<(StatusCode, Json<Value>), ApiError> {
+    validate_name("branch name", &name)?;
+    if state
+        .store
+        .branch_tip(&project, &name)
+        .map_err(map_store_error)?
+        .is_none()
+    {
+        return Err(ApiError::not_found(format!("branch {}", name)));
+    }
+    let target = state
+        .store
+        .commit(&project, &body.to)
+        .map_err(map_store_error)?
+        .ok_or_else(|| ApiError::not_found(format!("commit {}", body.to)))?;
+    // The target's model is already stored, so this reuses its blob rather than copying
+    // the bytes: the restored content is byte-identical to the original by construction.
+    let commit = state
+        .store
+        .commit_model(
+            &project,
+            &name,
+            &target.okf_hash,
+            &body.author,
+            &body.message,
+        )
+        .map_err(map_store_error)?;
+    Ok((StatusCode::CREATED, Json(commit_json(&commit))))
+}
diff --git a/server/src/lib.rs b/server/src/lib.rs
index 808ea2c..b47a565 100644
--- a/server/src/lib.rs
+++ b/server/src/lib.rs
@@ -44,20 +44,24 @@ pub fn app(state: AppState) -> Router {
         )
         .route("/projects/:project/commits/:hash", get(api::get_commit))
         .route(
             "/projects/:project/branches",
             post(api::create_branch).get(api::list_branches),
         )
         .route(
             "/projects/:project/branches/:name",
             axum::routing::delete(api::delete_branch),
         )
+        .route(
+            "/projects/:project/branches/:name/reset",
+            post(api::reset_branch),
+        )
         .route("/projects/:project/gate", post(gate_api::run_gate))
         .route("/projects/:project/merge", post(merge_api::merge_branches))
         .route(
             "/projects/:project/gate-runs",
             get(gate_api::list_gate_runs),
         )
         .with_state(api_state)
 }
 
 async fn health() -> Json<serde_json::Value> {
diff --git a/server/tests/api.rs b/server/tests/api.rs
index b6943ac..374c0eb 100644
--- a/server/tests/api.rs
+++ b/server/tests/api.rs
@@ -394,10 +394,82 @@ async fn branch_routes_report_an_unknown_project() {
             Request::builder()
                 .method("DELETE")
                 .uri("/projects/nope/branches/main")
                 .body(Body::empty())
                 .unwrap(),
         )
         .await
         .unwrap();
     assert_eq!(deleted.status(), StatusCode::NOT_FOUND);
 }
+
+#[tokio::test]
+async fn a_reset_appends_a_commit_and_keeps_the_old_tip_reachable() {
+    let dir = tempfile::tempdir().unwrap();
+    let router = server::app(state(dir.path()));
+    router
+        .clone()
+        .oneshot(post("/projects", serde_json::json!({ "name": "coffee" })))
+        .await
+        .unwrap();
+    let first = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/commits",
+            serde_json::json!({ "branch": "main", "author": "alex", "message": "one", "okf": tiny_okf() }),
+        ))
+        .await
+        .unwrap();
+    let first_hash = json_body(first).await["hash"].as_str().unwrap().to_string();
+
+    let mut second_model = tiny_okf();
+    second_model["project"] = serde_json::json!("changed");
+    let second = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/commits",
+            serde_json::json!({ "branch": "main", "author": "alex", "message": "two", "okf": second_model }),
+        ))
+        .await
+        .unwrap();
+    let second_hash = json_body(second).await["hash"]
+        .as_str()
+        .unwrap()
+        .to_string();
+
+    let reset = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/branches/main/reset",
+            serde_json::json!({ "to": first_hash, "author": "alex", "message": "revert to one" }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(reset.status(), StatusCode::CREATED);
+    let revert = json_body(reset).await;
+    assert_eq!(revert["parents"], serde_json::json!([second_hash]));
+
+    // The reverted content matches the target, and the superseded commit is still there.
+    let tip = revert["hash"].as_str().unwrap().to_string();
+    let fetched = router
+        .clone()
+        .oneshot(
+            Request::builder()
+                .uri(format!("/projects/coffee/commits/{}", tip))
+                .body(Body::empty())
+                .unwrap(),
+        )
+        .await
+        .unwrap();
+    assert_eq!(json_body(fetched).await, tiny_okf());
+
+    let superseded = router
+        .oneshot(
+            Request::builder()
+                .uri(format!("/projects/coffee/commits/{}", second_hash))
+                .body(Body::empty())
+                .unwrap(),
+        )
+        .await
+        .unwrap();
+    assert_eq!(superseded.status(), StatusCode::OK);
+}
