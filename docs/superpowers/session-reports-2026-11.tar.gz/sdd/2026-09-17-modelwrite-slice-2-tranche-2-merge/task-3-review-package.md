﻿# Tranche 2 Task 3 review package

## Commit

e7c8275 feat: merge two branches with element-level conflict reporting

## Full diff (-U10) of the merge endpoint work

diff --git a/server/src/api.rs b/server/src/api.rs
index 7c735ba..25cc5ac 100644
--- a/server/src/api.rs
+++ b/server/src/api.rs
@@ -59,21 +59,40 @@ pub fn map_store_error(e: StoreError) -> ApiError {
     match e {
         StoreError::NotFound(m) => ApiError::not_found(m),
         StoreError::Conflict(m) => ApiError::conflict(m),
         StoreError::Backend(m) => {
             eprintln!("storage error: {}", m);
             ApiError::internal("internal storage error")
         }
     }
 }
 
-fn commit_json(commit: &Commit) -> Value {
+/// Load the OKF document behind a commit hash.
+pub fn load_model(
+    state: &ApiState,
+    project: &str,
+    hash: &str,
+) -> Result<okf::types::OkfRoot, ApiError> {
+    let commit = state
+        .store
+        .commit(project, hash)
+        .map_err(map_store_error)?
+        .ok_or_else(|| ApiError::not_found(format!("commit {}", hash)))?;
+    let bytes = state
+        .store
+        .blob(&commit.okf_hash)
+        .map_err(map_store_error)?
+        .ok_or_else(|| ApiError::internal(format!("missing blob {}", commit.okf_hash)))?;
+    serde_json::from_slice(&bytes).map_err(|e| ApiError::internal(e.to_string()))
+}
+
+pub fn commit_json(commit: &Commit) -> Value {
     json!({
         "hash": commit.hash,
         "project": commit.project,
         "branch": commit.branch,
         "parents": commit.parents,
         "okfHash": commit.okf_hash,
         "author": commit.author,
         "message": commit.message,
         "createdAt": commit.created_at
     })
diff --git a/server/src/gate_api.rs b/server/src/gate_api.rs
index 88b994f..9e577ff 100644
--- a/server/src/gate_api.rs
+++ b/server/src/gate_api.rs
@@ -1,39 +1,20 @@
 // SPDX-License-Identifier: AGPL-3.0-or-later
 use axum::extract::{Path, State};
 use axum::Json;
 use serde::Deserialize;
 use serde_json::{json, Value};
 
-use crate::api::{map_store_error, ApiState};
+use crate::api::{load_model, map_store_error, ApiState};
 use crate::error::ApiError;
 use crate::store::{now_epoch, GateRun};
 
-/// Load the OKF document behind a commit hash.
-fn load_model(
-    state: &ApiState,
-    project: &str,
-    hash: &str,
-) -> Result<okf::types::OkfRoot, ApiError> {
-    let commit = state
-        .store
-        .commit(project, hash)
-        .map_err(map_store_error)?
-        .ok_or_else(|| ApiError::not_found(format!("commit {}", hash)))?;
-    let bytes = state
-        .store
-        .blob(&commit.okf_hash)
-        .map_err(map_store_error)?
-        .ok_or_else(|| ApiError::internal(format!("missing blob {}", commit.okf_hash)))?;
-    serde_json::from_slice(&bytes).map_err(|e| ApiError::internal(e.to_string()))
-}
-
 #[derive(Deserialize)]
 pub struct GateRequest {
     pub reference: String,
     pub candidate: String,
 }
 
 pub async fn run_gate(
     State(state): State<ApiState>,
     Path(project): Path<String>,
     Json(body): Json<GateRequest>,
diff --git a/server/src/lib.rs b/server/src/lib.rs
index aa4b295..808ea2c 100644
--- a/server/src/lib.rs
+++ b/server/src/lib.rs
@@ -1,15 +1,16 @@
 // SPDX-License-Identifier: AGPL-3.0-or-later
 pub mod api;
 pub mod error;
 pub mod gate_api;
 pub mod merge;
+pub mod merge_api;
 pub mod store;
 
 pub use error::ApiError;
 
 use std::sync::Arc;
 
 use axum::routing::{get, post};
 use axum::{Json, Router};
 use serde_json::json;
 
@@ -44,20 +45,21 @@ pub fn app(state: AppState) -> Router {
         .route("/projects/:project/commits/:hash", get(api::get_commit))
         .route(
             "/projects/:project/branches",
             post(api::create_branch).get(api::list_branches),
         )
         .route(
             "/projects/:project/branches/:name",
             axum::routing::delete(api::delete_branch),
         )
         .route("/projects/:project/gate", post(gate_api::run_gate))
+        .route("/projects/:project/merge", post(merge_api::merge_branches))
         .route(
             "/projects/:project/gate-runs",
             get(gate_api::list_gate_runs),
         )
         .with_state(api_state)
 }
 
 async fn health() -> Json<serde_json::Value> {
     Json(json!({ "status": "ok" }))
 }
diff --git a/server/src/merge_api.rs b/server/src/merge_api.rs
new file mode 100644
index 0000000..1f989eb
--- /dev/null
+++ b/server/src/merge_api.rs
@@ -0,0 +1,126 @@
+// SPDX-License-Identifier: AGPL-3.0-or-later
+use axum::extract::{Path, State};
+use axum::http::StatusCode;
+use axum::Json;
+use serde::Deserialize;
+use serde_json::{json, Value};
+
+use crate::api::{commit_json, load_model, map_store_error, validate_name, ApiState};
+use crate::error::ApiError;
+use crate::merge::merge;
+
+#[derive(Deserialize)]
+pub struct MergeRequest {
+    pub branch: String,
+    pub other: String,
+    pub author: String,
+    pub message: String,
+}
+
+/// Every commit reachable from a tip, tip first. The walk stops at a commit already seen,
+/// so a malformed cycle in stored data cannot loop forever.
+fn ancestry(state: &ApiState, project: &str, tip: &str) -> Result<Vec<String>, ApiError> {
+    let mut seen: Vec<String> = Vec::new();
+    let mut stack: Vec<String> = vec![tip.to_string()];
+    while let Some(hash) = stack.pop() {
+        if seen.contains(&hash) {
+            continue;
+        }
+        if let Some(commit) = state
+            .store
+            .commit(project, &hash)
+            .map_err(map_store_error)?
+        {
+            for parent in &commit.parents {
+                stack.push(parent.clone());
+            }
+        }
+        seen.push(hash);
+    }
+    Ok(seen)
+}
+
+/// The nearest commit both branches share, found by walking our ancestry and taking the
+/// first hash that theirs also reaches. With a linear history that is exactly the fork
+/// point; with merge commits it is an approximation, which is documented rather than
+/// hidden: a general lowest-common-ancestor is a later refinement.
+fn common_ancestor(
+    state: &ApiState,
+    project: &str,
+    ours: &str,
+    theirs: &str,
+) -> Result<String, ApiError> {
+    let our_side = ancestry(state, project, ours)?;
+    let their_side = ancestry(state, project, theirs)?;
+    our_side
+        .iter()
+        .find(|hash| their_side.contains(*hash))
+        .cloned()
+        .ok_or_else(|| ApiError::conflict("the branches share no common ancestor"))
+}
+
+pub async fn merge_branches(
+    State(state): State<ApiState>,
+    Path(project): Path<String>,
+    Json(body): Json<MergeRequest>,
+) -> Result<(StatusCode, Json<Value>), ApiError> {
+    validate_name("branch name", &body.branch)?;
+    validate_name("branch name", &body.other)?;
+
+    let ours_tip = state
+        .store
+        .branch_tip(&project, &body.branch)
+        .map_err(map_store_error)?
+        .ok_or_else(|| ApiError::not_found(format!("branch {}", body.branch)))?;
+    let theirs_tip = state
+        .store
+        .branch_tip(&project, &body.other)
+        .map_err(map_store_error)?
+        .ok_or_else(|| ApiError::not_found(format!("branch {}", body.other)))?;
+
+    let base_hash = common_ancestor(&state, &project, &ours_tip, &theirs_tip)?;
+    let base = load_model(&state, &project, &base_hash)?;
+    let ours = load_model(&state, &project, &ours_tip)?;
+    let theirs = load_model(&state, &project, &theirs_tip)?;
+
+    let outcome = merge(&base, &ours, &theirs);
+    if !outcome.conflicts.is_empty() {
+        // A conflict is not a transport failure: nothing is written, and the caller gets
+        // every conflicting subject with its base, ours and theirs values so a human or an
+        // agent can resolve it deliberately rather than guess.
+        return Ok((
+            StatusCode::CONFLICT,
+            Json(json!({
+                "base": base_hash,
+                "branch": body.branch,
+                "other": body.other,
+                "conflicts": outcome.conflicts
+            })),
+        ));
+    }
+
+    let merged = outcome.merged.ok_or_else(|| {
+        ApiError::internal("the merge reported no conflicts but produced nothing")
+    })?;
+    let bytes = serde_json::to_vec(&merged).map_err(|e| {
+        eprintln!("merged model could not be serialised: {}", e);
+        ApiError::internal("the merged model could not be stored")
+    })?;
+    let okf_hash = state.store.put_blob(&bytes).map_err(map_store_error)?;
+    let commit = state
+        .store
+        .commit_merge(
+            &project,
+            &body.branch,
+            &[ours_tip, theirs_tip],
+            &okf_hash,
+            &body.author,
+            &body.message,
+        )
+        .map_err(map_store_error)?;
+
+    Ok((
+        StatusCode::CREATED,
+        Json(json!({ "commit": commit_json(&commit), "base": base_hash })),
+    ))
+}
diff --git a/server/tests/merge_api.rs b/server/tests/merge_api.rs
new file mode 100644
index 0000000..c6dc543
--- /dev/null
+++ b/server/tests/merge_api.rs
@@ -0,0 +1,199 @@
+// SPDX-License-Identifier: AGPL-3.0-or-later
+//! The merge endpoint end to end: a clean merge writes a two-parent commit, a conflict
+//! writes nothing and names the conflicts, and the branch tips are left as they were.
+
+use axum::body::Body;
+use axum::http::{Request, StatusCode};
+use http_body_util::BodyExt;
+use serde_json::{json, Value};
+use tower::ServiceExt;
+
+fn state(dir: &std::path::Path) -> server::AppState {
+    let store = server::store::sqlite::SqliteStore::open(&dir.join("mw.db")).unwrap();
+    server::AppState {
+        store: std::sync::Arc::new(store),
+        evidence_dir: dir.to_path_buf(),
+    }
+}
+
+fn post(uri: &str, body: Value) -> Request<Body> {
+    Request::builder()
+        .method("POST")
+        .uri(uri)
+        .header("content-type", "application/json")
+        .body(Body::from(body.to_string()))
+        .unwrap()
+}
+
+fn get(uri: &str) -> Request<Body> {
+    Request::builder().uri(uri).body(Body::empty()).unwrap()
+}
+
+async fn json_body(response: axum::response::Response) -> Value {
+    let bytes = response.into_body().collect().await.unwrap().to_bytes();
+    serde_json::from_slice(&bytes).unwrap()
+}
+
+fn model(block_name: &str) -> Value {
+    json!({
+        "project": "coffee",
+        "exportedAt": "2026-09-17T00:00:00Z",
+        "summary": {},
+        "stateMachine": {"name": "sm", "regions": []},
+        "requirements": [{
+            "id": "r1", "name": "r1", "kind": "requirement",
+            "stereotypes": ["Requirement"], "attributes": [], "documentation": "",
+            "reqId": "1.1", "reqText": "text"
+        }],
+        "structure": [{
+            "id": "b1", "name": block_name, "kind": "block",
+            "stereotypes": ["Block"], "attributes": [], "documentation": ""
+        }],
+        "graph": {
+            "nodes": [
+                {"id": "b1", "kind": "block", "name": "Block"},
+                {"id": "r1", "kind": "requirement", "name": "r1"}
+            ],
+            "edges": [{"source": "b1", "target": "r1", "kind": "dependency", "label": "Satisfy"}]
+        }
+    })
+}
+
+async fn seed(router: &axum::Router) -> String {
+    router
+        .clone()
+        .oneshot(post("/projects", json!({ "name": "coffee" })))
+        .await
+        .unwrap();
+    let committed = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/commits",
+            json!({ "branch": "main", "author": "alex", "message": "base", "okf": model("Block") }),
+        ))
+        .await
+        .unwrap();
+    let hash = json_body(committed).await["hash"]
+        .as_str()
+        .unwrap()
+        .to_string();
+    router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/branches",
+            json!({ "name": "feature", "from": hash }),
+        ))
+        .await
+        .unwrap();
+    hash
+}
+
+#[tokio::test]
+async fn a_clean_merge_writes_a_two_parent_commit() {
+    let dir = tempfile::tempdir().unwrap();
+    let router = server::app(state(dir.path()));
+    let _base = seed(&router).await;
+
+    // The feature branch renames the block; main is untouched.
+    router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/commits",
+            json!({ "branch": "feature", "author": "alex", "message": "rename", "okf": model("Renamed") }),
+        ))
+        .await
+        .unwrap();
+
+    let merged = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/merge",
+            json!({ "branch": "main", "other": "feature", "author": "alex", "message": "merge feature" }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(merged.status(), StatusCode::CREATED);
+    let body = json_body(merged).await;
+    assert_eq!(body["commit"]["parents"].as_array().unwrap().len(), 2);
+
+    // The merged model is what the branch now serves, and it carries the rename.
+    let tip = body["commit"]["hash"].as_str().unwrap().to_string();
+    let fetched = router
+        .oneshot(get(&format!("/projects/coffee/commits/{}", tip)))
+        .await
+        .unwrap();
+    let served = json_body(fetched).await;
+    assert_eq!(served["structure"][0]["name"], "Renamed");
+}
+
+#[tokio::test]
+async fn a_conflicting_merge_writes_nothing_and_names_every_conflict() {
+    let dir = tempfile::tempdir().unwrap();
+    let router = server::app(state(dir.path()));
+    seed(&router).await;
+
+    router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/commits",
+            json!({ "branch": "feature", "author": "alex", "message": "theirs", "okf": model("Theirs") }),
+        ))
+        .await
+        .unwrap();
+    router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/commits",
+            json!({ "branch": "main", "author": "alex", "message": "ours", "okf": model("Ours") }),
+        ))
+        .await
+        .unwrap();
+
+    let conflicted = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/merge",
+            json!({ "branch": "main", "other": "feature", "author": "alex", "message": "merge" }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(conflicted.status(), StatusCode::CONFLICT);
+    let body = json_body(conflicted).await;
+    let conflicts = body["conflicts"].as_array().unwrap();
+    assert_eq!(conflicts.len(), 1);
+    assert_eq!(conflicts[0]["kind"], "bothModified");
+
+    // Nothing was written: main still points at our commit, not at a merge.
+    let history = router
+        .oneshot(get("/projects/coffee/commits?branch=main"))
+        .await
+        .unwrap();
+    let history = json_body(history).await;
+    let commits = history.as_array().unwrap();
+    assert_eq!(
+        commits.len(),
+        2,
+        "the base commit and ours, and no merge commit"
+    );
+    for commit in commits {
+        assert!(
+            commit["parents"].as_array().unwrap().len() < 2,
+            "a conflict must not leave a merge commit"
+        );
+    }
+}
+
+#[tokio::test]
+async fn merging_an_unknown_branch_is_not_found() {
+    let dir = tempfile::tempdir().unwrap();
+    let router = server::app(state(dir.path()));
+    seed(&router).await;
+    let response = router
+        .oneshot(post(
+            "/projects/coffee/merge",
+            json!({ "branch": "main", "other": "nope", "author": "alex", "message": "merge" }),
+        ))
+        .await
+        .unwrap();
+    assert_eq!(response.status(), StatusCode::NOT_FOUND);
+}
