﻿### Task 1: Branch listing and deletion

**Files:**
- Modify: server/src/store/mod.rs (add delete_branch)
- Modify: server/src/store/sqlite.rs (implement it)
- Modify: server/src/api.rs (two handlers)
- Modify: server/src/lib.rs (two routes)
- Test: server/tests/api.rs (branch lifecycle)

**Interfaces:**
- Consumes: the existing Store trait, list_branches (already implemented but unrouted), ApiState, validate_name, map_store_error.
- Produces:
  - Store::delete_branch(&self, project: &str, name: &str) -> Result<(), StoreError>, which returns NotFound when the branch does not exist and never touches the commits table.
  - GET /projects/:project/branches -> 200 [{"name", "tip"}], 404 when the project is unknown.
  - DELETE /projects/:project/branches/:name -> 204 on success, 404 when the branch or project is unknown, and it never deletes commits.

- [ ] **Step 1: Add delete_branch to the trait**

In server/src/store/mod.rs, after create_branch:

```rust
    /// Remove a branch pointer. This never deletes commits: the objects a branch pointed
    /// at stay in the store, so a deleted branch can be recreated at the same hash and no
    /// history is ever lost.
    fn delete_branch(&self, project: &str, name: &str) -> Result<(), StoreError>;
```

- [ ] **Step 2: Implement it in the SQLite backend**

In server/src/store/sqlite.rs, after create_branch:

```rust
    fn delete_branch(&self, project: &str, name: &str) -> Result<(), StoreError> {
        let removed = self.with(|c| {
            c.execute(
                "DELETE FROM branches WHERE project = ?1 AND name = ?2",
                params![project, name],
            )
        })?;
        if removed == 0 {
            return Err(StoreError::NotFound(format!("branch {}", name)));
        }
        Ok(())
    }
```

- [ ] **Step 3: Add the handlers**

In server/src/api.rs:

```rust
pub async fn list_branches(
    State(state): State<ApiState>,
    Path(project): Path<String>,
) -> Result<Json<Value>, ApiError> {
    if state.store.project(&project).map_err(map_store_error)?.is_none() {
        return Err(ApiError::not_found(format!("project {}", project)));
    }
    let branches = state.store.list_branches(&project).map_err(map_store_error)?;
    let out: Vec<Value> = branches
        .iter()
        .map(|(name, tip)| json!({ "name": name, "tip": tip }))
        .collect();
    Ok(Json(Value::Array(out)))
}

pub async fn delete_branch(
    State(state): State<ApiState>,
    Path((project, name)): Path<(String, String)>,
) -> Result<StatusCode, ApiError> {
    validate_name("branch name", &name)?;
    state
        .store
        .delete_branch(&project, &name)
        .map_err(map_store_error)?;
    Ok(StatusCode::NO_CONTENT)
}
```

- [ ] **Step 4: Add the routes**

In server/src/lib.rs, next to the existing branch route:

```rust
        .route(
            "/projects/:project/branches",
            post(api::create_branch).get(api::list_branches),
        )
        .route(
            "/projects/:project/branches/:name",
            axum::routing::delete(api::delete_branch),
        )
```

- [ ] **Step 5: Test the branch lifecycle**

Append to server/tests/api.rs:

```rust
#[tokio::test]
async fn branches_can_be_listed_and_deleted_without_losing_commits() {
    let dir = tempfile::tempdir().unwrap();
    let router = server::app(state(dir.path()));
    router
        .clone()
        .oneshot(post("/projects", serde_json::json!({ "name": "coffee" })))
        .await
        .unwrap();
    let committed = router
        .clone()
        .oneshot(post(
            "/projects/coffee/commits",
            serde_json::json!({ "branch": "main", "author": "alex", "message": "m", "okf": tiny_okf() }),
        ))
        .await
        .unwrap();
    let hash = json_body(committed).await["hash"].as_str().unwrap().to_string();
    router
        .clone()
        .oneshot(post(
            "/projects/coffee/branches",
            serde_json::json!({ "name": "review", "from": hash }),
        ))
        .await
        .unwrap();

    let listed = router
        .clone()
        .oneshot(get("/projects/coffee/branches"))
        .await
        .unwrap();
    let branches = json_body(listed).await;
    let names: Vec<String> = branches
        .as_array()
        .unwrap()
        .iter()
        .map(|b| b["name"].as_str().unwrap().to_string())
        .collect();
    assert!(names.contains(&"main".to_string()));
    assert!(names.contains(&"review".to_string()));

    let deleted = router
        .clone()
        .oneshot(
            Request::builder()
                .method("DELETE")
                .uri("/projects/coffee/branches/review")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();
    assert_eq!(deleted.status(), StatusCode::NO_CONTENT);

    // The commit the deleted branch pointed at must still be readable.
    let still_there = router
        .clone()
        .oneshot(
            Request::builder()
                .uri(format!("/projects/coffee/commits/{}", hash))
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();
    assert_eq!(still_there.status(), StatusCode::OK);

    let gone = router
        .oneshot(
            Request::builder()
                .method("DELETE")
                .uri("/projects/coffee/branches/review")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();
    assert_eq!(gone.status(), StatusCode::NOT_FOUND);
}
```

The test file already has a helper `get(uri)`; if it does not, add one next to `post`.

- [ ] **Step 6: Run, lint and commit**

```powershell
cargo test -p mw-server --no-fail-fast
cargo fmt --all
cargo clippy -p mw-server --all-targets -- -D warnings
git add server
git commit -m "feat: list and delete branches without touching history"
```

Expected: 19 tests pass.

---

