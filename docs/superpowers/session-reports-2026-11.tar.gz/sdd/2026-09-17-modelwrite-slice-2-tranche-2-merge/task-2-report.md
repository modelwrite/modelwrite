# Task 2 Report: The three-way merge engine

## Status

DONE

## Commits

- `2fb5df1` feat: add the three-way merge engine and multi-parent commits

## Test summary

25 passed; 0 failed — api 8, corpus 1, gate_api 3, http 2, merge 6, store 5 (plus 0 lib and 0 bin unit tests).

## Concerns

- `merge` always sets `merged.graph` to `Some(Graph { .. })`, even when every input had
  `graph: None`. This is the brief's prescribed code, so no behavior was invented here, but a
  caller whose documents omitted the graph will receive an empty graph rather than `None`. No
  test exercises that case.
- `commit_merge` mirrors `commit_model`'s branch upsert, so it implicitly creates the target
  branch if absent. The brief only required rejecting a non-existent *parent*, which is done
  (`NotFound`), so this matches the prescribed "same pattern as commit_model".

## Deviation

- In `merge_keyed` the bound `K: Ord + Clone` was widened to
  `K: Ord + Clone + std::fmt::Debug`, because the brief's subject line uses
  `format!("{}:{:?}", section, k)`, which requires `K: Debug`. Every concrete key is
  `String`, so the added bound is always satisfied and the behavior is unchanged. This is the
  minimal, behavior-neutral change the implementation notes anticipated for generic bounds.
