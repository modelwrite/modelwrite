﻿# Merge ordering fix re-review package

## Full diff (-U10) of the fix

diff --git a/server/src/merge.rs b/server/src/merge.rs
index c3c9c1a..98c88b1 100644
--- a/server/src/merge.rs
+++ b/server/src/merge.rs
@@ -80,24 +80,35 @@ where
     let to_map = |items: &[T]| -> BTreeMap<K, (String, T)> {
         items
             .iter()
             .map(|item| (key(item), (json(item).unwrap_or_default(), item.clone())))
             .collect()
     };
     let base_map = to_map(base);
     let ours_map = to_map(ours);
     let theirs_map = to_map(theirs);
 
-    let mut keys: Vec<K> = ours_map.keys().cloned().collect();
-    for k in theirs_map.keys() {
-        if !keys.contains(k) {
-            keys.push(k.clone());
+    // Our order first, then what only theirs added, in their order. Iterating the maps
+    // would sort by key, and a merge that silently reshuffles a document makes every
+    // merge look like a rewrite. A key present only in base was deleted by both sides, so
+    // it never appears here - which is exactly what should happen to it.
+    let mut keys: Vec<K> = Vec::new();
+    for item in ours {
+        let k = key(item);
+        if !keys.contains(&k) {
+            keys.push(k);
+        }
+    }
+    for item in theirs {
+        let k = key(item);
+        if !keys.contains(&k) {
+            keys.push(k);
         }
     }
 
     let mut out: Vec<T> = Vec::new();
     for k in keys {
         let subject = format!("{}:{:?}", section, k);
         let b = base_map.get(&k).map(|(j, _)| j);
         let o = ours_map.get(&k).map(|(j, _)| j);
         let t = theirs_map.get(&k).map(|(j, _)| j);
         match resolve(&subject, b, o, t) {
@@ -278,18 +289,24 @@ pub fn merge(base: &OkfRoot, ours: &OkfRoot, theirs: &OkfRoot) -> MergeOutcome {
         };
     }
 
     let mut merged = ours.clone();
     merged.structure = structure;
     merged.interfaces = interfaces;
     merged.signals = signals;
     merged.requirements = requirements;
     merged.state_machine = state_machine;
     merged.activities = activities;
-    merged.graph = Some(okf::types::Graph { nodes, edges });
+    // A graph section is only emitted if some input had one: inventing an empty graph
+    // would turn a document that never had one into one that appears to.
+    merged.graph = if base.graph.is_some() || ours.graph.is_some() || theirs.graph.is_some() {
+        Some(okf::types::Graph { nodes, edges })
+    } else {
+        None
+    };
     recompute_summary(&mut merged);
 
     MergeOutcome {
         merged: Some(merged),
         conflicts,
     }
 }
diff --git a/server/src/store/sqlite.rs b/server/src/store/sqlite.rs
index b794765..d3596d3 100644
--- a/server/src/store/sqlite.rs
+++ b/server/src/store/sqlite.rs
@@ -222,20 +222,29 @@ impl Store for SqliteStore {
 
     fn commit_merge(
         &self,
         project: &str,
         branch: &str,
         parents: &[String],
         okf_hash: &str,
         author: &str,
         message: &str,
     ) -> Result<Commit, StoreError> {
+        // A merge commit has exactly two parents. Anything else is a caller mistake, and it
+        // would quietly write a root commit or an ordinary single-parent commit under the
+        // name of a merge.
+        if parents.len() != 2 {
+            return Err(StoreError::Backend(format!(
+                "a merge commit needs exactly two parents, got {}",
+                parents.len()
+            )));
+        }
         let guard = self
             .connection
             .lock()
             .map_err(|_| StoreError::Backend("connection lock poisoned".to_string()))?;
         let tx = guard
             .unchecked_transaction()
             .map_err(|e| StoreError::Backend(e.to_string()))?;
 
         // Every parent must already exist: a merge commit can only cite ancestry that is
         // really there, never invent it.
diff --git a/server/tests/merge.rs b/server/tests/merge.rs
index f183ddb..eaee9a0 100644
--- a/server/tests/merge.rs
+++ b/server/tests/merge.rs
@@ -137,10 +137,84 @@ fn deleting_on_one_side_while_the_other_modifies_is_a_conflict() {
     let base = okf(model("Block", true));
     let ours = okf(model("Block", false)); // r2 deleted here
     let mut their_value = model("Block", true);
     their_value["requirements"][1]["reqText"] = json!("changed by them");
     let theirs = okf(their_value);
     let outcome = merge(&base, &ours, &theirs);
     assert!(outcome.merged.is_none());
     assert_eq!(outcome.conflicts.len(), 1);
     assert_eq!(outcome.conflicts[0].kind, "modifiedVersusDeleted");
 }
+#[test]
+fn our_section_order_is_preserved() {
+    // A merge must not reshuffle a document: if it did, every merge would look like a
+    // rewrite and a reviewer could not see what actually changed. The ids here are
+    // deliberately NOT in sorted order, so a key-sorted merge fails this test.
+    let mut base_value = model("Block", false);
+    base_value["structure"] = json!([
+        {"id": "b2", "name": "Second", "kind": "block", "stereotypes": ["Block"], "attributes": [], "documentation": ""},
+        {"id": "b1", "name": "First", "kind": "block", "stereotypes": ["Block"], "attributes": [], "documentation": ""}
+    ]);
+    let base = okf(base_value.clone());
+    let ours = okf(base_value.clone());
+
+    // They add a third block, which must land AFTER our two, not sorted among them.
+    let mut their_value = base_value;
+    their_value["structure"]
+        .as_array_mut()
+        .unwrap()
+        .push(json!({
+            "id": "b0", "name": "Added", "kind": "block",
+            "stereotypes": ["Block"], "attributes": [], "documentation": ""
+        }));
+    let theirs = okf(their_value);
+
+    let outcome = merge(&base, &ours, &theirs);
+    assert!(outcome.conflicts.is_empty(), "{:?}", outcome.conflicts);
+    let names: Vec<String> = outcome
+        .merged
+        .expect("clean merge")
+        .structure
+        .iter()
+        .map(|e| e.name.clone())
+        .collect();
+    assert_eq!(names, vec!["Second", "First", "Added"]);
+}
+
+#[test]
+fn both_sides_adding_the_same_element_differently_conflicts() {
+    let base = okf(model("Block", false));
+    let mut our_value = model("Block", false);
+    our_value["requirements"]
+        .as_array_mut()
+        .unwrap()
+        .push(json!({
+            "id": "r9", "name": "Ours", "kind": "requirement",
+            "stereotypes": ["Requirement"], "attributes": [], "documentation": "",
+            "reqId": "9.1", "reqText": "ours"
+        }));
+    let mut their_value = model("Block", false);
+    their_value["requirements"]
+        .as_array_mut()
+        .unwrap()
+        .push(json!({
+            "id": "r9", "name": "Theirs", "kind": "requirement",
+            "stereotypes": ["Requirement"], "attributes": [], "documentation": "",
+            "reqId": "9.2", "reqText": "theirs"
+        }));
+    let outcome = merge(&base, &okf(our_value), &okf(their_value));
+    assert!(outcome.merged.is_none());
+    assert_eq!(outcome.conflicts.len(), 1);
+    assert_eq!(outcome.conflicts[0].kind, "bothAdded");
+}
+
+#[test]
+fn a_different_project_name_conflicts() {
+    let base = okf(model("Block", false));
+    let mut our_value = model("Block", false);
+    our_value["project"] = json!("one");
+    let mut their_value = model("Block", false);
+    their_value["project"] = json!("two");
+    let outcome = merge(&base, &okf(our_value), &okf(their_value));
+    assert!(outcome.merged.is_none());
+    assert_eq!(outcome.conflicts[0].subject, "doc:project");
+}
