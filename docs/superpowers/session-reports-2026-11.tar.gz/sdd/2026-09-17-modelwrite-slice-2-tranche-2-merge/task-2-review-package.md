﻿# Tranche 2 Task 2 review package

## Commit

7a82203 fix: name the missing project on branch deletion and cover both 404 paths

## Full diff (-U10) of the merge work

diff --git a/server/src/lib.rs b/server/src/lib.rs
index fb2d996..aa4b295 100644
--- a/server/src/lib.rs
+++ b/server/src/lib.rs
@@ -1,14 +1,15 @@
 // SPDX-License-Identifier: AGPL-3.0-or-later
 pub mod api;
 pub mod error;
 pub mod gate_api;
+pub mod merge;
 pub mod store;
 
 pub use error::ApiError;
 
 use std::sync::Arc;
 
 use axum::routing::{get, post};
 use axum::{Json, Router};
 use serde_json::json;
 
diff --git a/server/src/merge.rs b/server/src/merge.rs
new file mode 100644
index 0000000..c3c9c1a
--- /dev/null
+++ b/server/src/merge.rs
@@ -0,0 +1,295 @@
+// SPDX-License-Identifier: AGPL-3.0-or-later
+//! Three-way merge over OKF documents, as a pure function.
+//!
+//! Two elements are the same when their canonical JSON is the same, which is the same
+//! discipline the engine's diff uses. Nothing here touches storage or HTTP, so every rule
+//! is unit-testable on its own.
+
+use std::collections::BTreeMap;
+
+use okf::types::{
+    Activity, Element, GraphEdge, GraphNode, OkfRoot, Requirement, StateMachine, Summary,
+};
+use serde::Serialize;
+
+#[derive(Debug, Clone, Serialize, PartialEq)]
+#[serde(rename_all = "camelCase")]
+pub struct Conflict {
+    pub subject: String,
+    pub kind: String,
+    pub base: Option<String>,
+    pub ours: Option<String>,
+    pub theirs: Option<String>,
+}
+
+#[derive(Debug)]
+pub struct MergeOutcome {
+    pub merged: Option<OkfRoot>,
+    pub conflicts: Vec<Conflict>,
+}
+
+fn json<T: Serialize>(value: &T) -> Option<String> {
+    serde_json::to_string(value).ok()
+}
+
+/// Resolve one key by the three-way rule. Returns Ok(Some(value)) to take a value,
+/// Ok(None) when the key is absent in the result, or Err(conflict).
+fn resolve(
+    subject: &str,
+    base: Option<&String>,
+    ours: Option<&String>,
+    theirs: Option<&String>,
+) -> Result<Option<String>, Conflict> {
+    if ours == theirs {
+        return Ok(ours.cloned());
+    }
+    if ours == base {
+        return Ok(theirs.cloned());
+    }
+    if theirs == base {
+        return Ok(ours.cloned());
+    }
+    let kind = match (base, ours, theirs) {
+        (None, Some(_), Some(_)) => "bothAdded",
+        (Some(_), Some(_), None) | (Some(_), None, Some(_)) => "modifiedVersusDeleted",
+        _ => "bothModified",
+    };
+    Err(Conflict {
+        subject: subject.to_string(),
+        kind: kind.to_string(),
+        base: base.cloned(),
+        ours: ours.cloned(),
+        theirs: theirs.cloned(),
+    })
+}
+
+/// Merge a Vec of items keyed by some id, keeping our order and appending theirs.
+fn merge_keyed<T, K, F>(
+    section: &str,
+    base: &[T],
+    ours: &[T],
+    theirs: &[T],
+    key: F,
+    conflicts: &mut Vec<Conflict>,
+) -> Vec<T>
+where
+    T: Clone + Serialize + serde::de::DeserializeOwned,
+    K: Ord + Clone + std::fmt::Debug,
+    F: Fn(&T) -> K,
+{
+    let to_map = |items: &[T]| -> BTreeMap<K, (String, T)> {
+        items
+            .iter()
+            .map(|item| (key(item), (json(item).unwrap_or_default(), item.clone())))
+            .collect()
+    };
+    let base_map = to_map(base);
+    let ours_map = to_map(ours);
+    let theirs_map = to_map(theirs);
+
+    let mut keys: Vec<K> = ours_map.keys().cloned().collect();
+    for k in theirs_map.keys() {
+        if !keys.contains(k) {
+            keys.push(k.clone());
+        }
+    }
+
+    let mut out: Vec<T> = Vec::new();
+    for k in keys {
+        let subject = format!("{}:{:?}", section, k);
+        let b = base_map.get(&k).map(|(j, _)| j);
+        let o = ours_map.get(&k).map(|(j, _)| j);
+        let t = theirs_map.get(&k).map(|(j, _)| j);
+        match resolve(&subject, b, o, t) {
+            Ok(Some(chosen)) => {
+                if let Ok(item) = serde_json::from_str::<T>(&chosen) {
+                    out.push(item);
+                }
+            }
+            Ok(None) => {}
+            Err(conflict) => conflicts.push(conflict),
+        }
+    }
+    out
+}
+
+/// Merge a document-level value that is treated as one unit.
+fn merge_unit<T>(
+    subject: &str,
+    base: Option<&T>,
+    ours: Option<&T>,
+    theirs: Option<&T>,
+    conflicts: &mut Vec<Conflict>,
+) -> Option<T>
+where
+    T: Clone + Serialize + serde::de::DeserializeOwned,
+{
+    let b = base.and_then(json);
+    let o = ours.and_then(json);
+    let t = theirs.and_then(json);
+    match resolve(subject, b.as_ref(), o.as_ref(), t.as_ref()) {
+        Ok(Some(chosen)) => serde_json::from_str(&chosen).ok(),
+        Ok(None) => None,
+        Err(conflict) => {
+            conflicts.push(conflict);
+            None
+        }
+    }
+}
+
+fn edge_key(edge: &GraphEdge) -> String {
+    let parts = [
+        edge.source.as_str(),
+        edge.target.as_str(),
+        edge.kind.as_str(),
+        edge.label.as_str(),
+    ];
+    serde_json::to_string(&parts).unwrap_or_default()
+}
+
+/// Recompute the derived counts so the merged document cannot contradict itself.
+fn recompute_summary(merged: &mut OkfRoot) {
+    merged.summary = Summary {
+        blocks: merged.structure.len() as u64,
+        requirements: merged.requirements.len() as u64,
+        interfaces: merged.interfaces.len() as u64,
+        signals: merged.signals.len() as u64,
+        activities: merged.activities.len() as u64,
+        graph_nodes: merged.graph.as_ref().map(|g| g.nodes.len()).unwrap_or(0) as u64,
+        graph_edges: merged.graph.as_ref().map(|g| g.edges.len()).unwrap_or(0) as u64,
+    };
+}
+
+pub fn merge(base: &OkfRoot, ours: &OkfRoot, theirs: &OkfRoot) -> MergeOutcome {
+    let mut conflicts: Vec<Conflict> = Vec::new();
+
+    if base.project != ours.project || base.project != theirs.project {
+        conflicts.push(Conflict {
+            subject: "doc:project".to_string(),
+            kind: "bothModified".to_string(),
+            base: Some(base.project.clone()),
+            ours: Some(ours.project.clone()),
+            theirs: Some(theirs.project.clone()),
+        });
+    }
+
+    let structure = merge_keyed(
+        "structure",
+        &base.structure,
+        &ours.structure,
+        &theirs.structure,
+        |e: &Element| e.id.clone(),
+        &mut conflicts,
+    );
+    let interfaces = merge_keyed(
+        "interfaces",
+        &base.interfaces,
+        &ours.interfaces,
+        &theirs.interfaces,
+        |e: &Element| e.id.clone(),
+        &mut conflicts,
+    );
+    let signals = merge_keyed(
+        "signals",
+        &base.signals,
+        &ours.signals,
+        &theirs.signals,
+        |e: &Element| e.id.clone(),
+        &mut conflicts,
+    );
+    let requirements = merge_keyed(
+        "requirements",
+        &base.requirements,
+        &ours.requirements,
+        &theirs.requirements,
+        |r: &Requirement| r.id.clone(),
+        &mut conflicts,
+    );
+
+    // Ordered structures merge all or nothing: see the rule list above.
+    let state_machine: Option<StateMachine> = merge_unit(
+        "doc:stateMachine",
+        base.state_machine.as_ref(),
+        ours.state_machine.as_ref(),
+        theirs.state_machine.as_ref(),
+        &mut conflicts,
+    );
+    let activities: Vec<Activity> = merge_unit(
+        "doc:activities",
+        Some(&base.activities),
+        Some(&ours.activities),
+        Some(&theirs.activities),
+        &mut conflicts,
+    )
+    .unwrap_or_else(|| ours.activities.clone());
+
+    let base_nodes = base
+        .graph
+        .as_ref()
+        .map(|g| g.nodes.clone())
+        .unwrap_or_default();
+    let our_nodes = ours
+        .graph
+        .as_ref()
+        .map(|g| g.nodes.clone())
+        .unwrap_or_default();
+    let their_nodes = theirs
+        .graph
+        .as_ref()
+        .map(|g| g.nodes.clone())
+        .unwrap_or_default();
+    let nodes = merge_keyed(
+        "graphnode",
+        &base_nodes,
+        &our_nodes,
+        &their_nodes,
+        |n: &GraphNode| n.id.clone(),
+        &mut conflicts,
+    );
+
+    let base_edges = base
+        .graph
+        .as_ref()
+        .map(|g| g.edges.clone())
+        .unwrap_or_default();
+    let our_edges = ours
+        .graph
+        .as_ref()
+        .map(|g| g.edges.clone())
+        .unwrap_or_default();
+    let their_edges = theirs
+        .graph
+        .as_ref()
+        .map(|g| g.edges.clone())
+        .unwrap_or_default();
+    let edges = merge_keyed(
+        "edge",
+        &base_edges,
+        &our_edges,
+        &their_edges,
+        edge_key,
+        &mut conflicts,
+    );
+
+    if !conflicts.is_empty() {
+        return MergeOutcome {
+            merged: None,
+            conflicts,
+        };
+    }
+
+    let mut merged = ours.clone();
+    merged.structure = structure;
+    merged.interfaces = interfaces;
+    merged.signals = signals;
+    merged.requirements = requirements;
+    merged.state_machine = state_machine;
+    merged.activities = activities;
+    merged.graph = Some(okf::types::Graph { nodes, edges });
+    recompute_summary(&mut merged);
+
+    MergeOutcome {
+        merged: Some(merged),
+        conflicts,
+    }
+}
diff --git a/server/src/store/mod.rs b/server/src/store/mod.rs
index 0c29e09..b8892a2 100644
--- a/server/src/store/mod.rs
+++ b/server/src/store/mod.rs
@@ -106,20 +106,32 @@ pub trait Store: Send + Sync {
     /// fork the history, the later one orphaning the earlier while the branch lists both.
     fn commit_model(
         &self,
         project: &str,
         branch: &str,
         okf_hash: &str,
         author: &str,
         message: &str,
     ) -> Result<Commit, StoreError>;
 
+    /// Write a commit with EXPLICIT parents and move the branch tip, in one transaction.
+    /// A merge commit has two parents, so the parent list cannot be derived from the tip.
+    fn commit_merge(
+        &self,
+        project: &str,
+        branch: &str,
+        parents: &[String],
+        okf_hash: &str,
+        author: &str,
+        message: &str,
+    ) -> Result<Commit, StoreError>;
+
     fn commit(&self, project: &str, hash: &str) -> Result<Option<Commit>, StoreError>;
     fn commits_on(&self, project: &str, branch: &str) -> Result<Vec<Commit>, StoreError>;
     fn branch_tip(&self, project: &str, branch: &str) -> Result<Option<String>, StoreError>;
     fn create_branch(&self, project: &str, name: &str, from: &str) -> Result<(), StoreError>;
 
     /// Remove a branch pointer. This never deletes commits: the objects a branch pointed
     /// at stay in the store, so a deleted branch can be recreated at the same hash and no
     /// history is ever lost.
     fn delete_branch(&self, project: &str, name: &str) -> Result<(), StoreError>;
     fn list_branches(&self, project: &str) -> Result<Vec<(String, String)>, StoreError>;
diff --git a/server/src/store/sqlite.rs b/server/src/store/sqlite.rs
index bad5c19..e7cc4fd 100644
--- a/server/src/store/sqlite.rs
+++ b/server/src/store/sqlite.rs
@@ -213,20 +213,85 @@ impl Store for SqliteStore {
             project: project.to_string(),
             branch: branch.to_string(),
             parents,
             okf_hash: okf_hash.to_string(),
             author: author.to_string(),
             message: message.to_string(),
             created_at,
         })
     }
 
+    fn commit_merge(
+        &self,
+        project: &str,
+        branch: &str,
+        parents: &[String],
+        okf_hash: &str,
+        author: &str,
+        message: &str,
+    ) -> Result<Commit, StoreError> {
+        let guard = self
+            .connection
+            .lock()
+            .map_err(|_| StoreError::Backend("connection lock poisoned".to_string()))?;
+        let tx = guard
+            .unchecked_transaction()
+            .map_err(|e| StoreError::Backend(e.to_string()))?;
+
+        // Every parent must already exist: a merge commit can only cite ancestry that is
+        // really there, never invent it.
+        for parent in parents {
+            let exists: bool = (|| -> rusqlite::Result<bool> {
+                let mut stmt =
+                    tx.prepare("SELECT 1 FROM commits WHERE project = ?1 AND hash = ?2")?;
+                let mut rows = stmt.query(params![project, parent])?;
+                Ok(rows.next()?.is_some())
+            })()
+            .map_err(|e| StoreError::Backend(e.to_string()))?;
+            if !exists {
+                return Err(StoreError::NotFound(format!("parent commit {}", parent)));
+            }
+        }
+
+        let parents: Vec<String> = parents.to_vec();
+        let created_at = now_epoch();
+        let hash = super::commit_hash(project, branch, &parents, okf_hash, author, message);
+        let parents_json =
+            serde_json::to_string(&parents).map_err(|e| StoreError::Backend(e.to_string()))?;
+
+        // Plain INSERT, not OR IGNORE: a constraint failure must abort this transaction
+        // rather than move a branch tip to a hash that has no commit row.
+        tx.execute(
+            "INSERT INTO commits (hash, project, branch, parents, okf_hash, author, message, created_at) VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8)",
+            params![hash, project, branch, parents_json, okf_hash, author, message, created_at],
+        )
+        .map_err(|e| StoreError::Backend(e.to_string()))?;
+        tx.execute(
+            "INSERT INTO branches (project, name, tip) VALUES (?1, ?2, ?3) ON CONFLICT(project, name) DO UPDATE SET tip = ?3",
+            params![project, branch, hash],
+        )
+        .map_err(|e| StoreError::Backend(e.to_string()))?;
+        tx.commit()
+            .map_err(|e| StoreError::Backend(e.to_string()))?;
+
+        Ok(Commit {
+            hash,
+            project: project.to_string(),
+            branch: branch.to_string(),
+            parents,
+            okf_hash: okf_hash.to_string(),
+            author: author.to_string(),
+            message: message.to_string(),
+            created_at,
+        })
+    }
+
     fn commit(&self, project: &str, hash: &str) -> Result<Option<Commit>, StoreError> {
         // The row is read inside the lock and the parents column is parsed outside it, so
         // that corruption can surface as a storage error rather than a query error.
         let row: Option<CommitRow> = self.with(|c| {
                 let mut stmt = c.prepare(
                     "SELECT hash, project, branch, parents, okf_hash, author, message, created_at FROM commits WHERE project = ?1 AND hash = ?2",
                 )?;
                 let mut rows = stmt.query(params![project, hash])?;
                 match rows.next()? {
                     Some(row) => Ok(Some((
diff --git a/server/tests/merge.rs b/server/tests/merge.rs
new file mode 100644
index 0000000..f183ddb
--- /dev/null
+++ b/server/tests/merge.rs
@@ -0,0 +1,146 @@
+// SPDX-License-Identifier: AGPL-3.0-or-later
+use okf::types::OkfRoot;
+use serde_json::json;
+use server::merge::merge;
+
+fn okf(value: serde_json::Value) -> OkfRoot {
+    serde_json::from_value(value).expect("test document parses")
+}
+
+fn requirement(id: &str, req_id: &str) -> serde_json::Value {
+    json!({
+        "id": id,
+        "name": id,
+        "kind": "requirement",
+        "stereotypes": ["Requirement"],
+        "attributes": [],
+        "documentation": "",
+        "reqId": req_id,
+        "reqText": "text"
+    })
+}
+
+/// One block, one requirement and the satisfy edge between them, optionally plus a second
+/// requirement and its edge, so a test can change exactly one thing at a time.
+fn model(block_name: &str, with_second_requirement: bool) -> serde_json::Value {
+    let mut requirements = vec![requirement("r1", "1.1")];
+    let mut nodes = vec![
+        json!({"id": "b1", "kind": "block", "name": "Block"}),
+        json!({"id": "r1", "kind": "requirement", "name": "r1"}),
+    ];
+    let mut edges = vec![json!({
+        "source": "b1",
+        "target": "r1",
+        "kind": "dependency",
+        "label": "Satisfy"
+    })];
+    if with_second_requirement {
+        requirements.push(requirement("r2", "1.2"));
+        nodes.push(json!({"id": "r2", "kind": "requirement", "name": "r2"}));
+        edges.push(json!({
+            "source": "b1",
+            "target": "r2",
+            "kind": "dependency",
+            "label": "Satisfy"
+        }));
+    }
+    json!({
+        "project": "coffee",
+        "exportedAt": "2026-09-17T00:00:00Z",
+        "summary": {},
+        "stateMachine": {"name": "sm", "regions": []},
+        "requirements": requirements,
+        "structure": [{
+            "id": "b1",
+            "name": block_name,
+            "kind": "block",
+            "stereotypes": ["Block"],
+            "attributes": [],
+            "documentation": ""
+        }],
+        "graph": {"nodes": nodes, "edges": edges}
+    })
+}
+
+#[test]
+fn a_change_on_one_side_is_taken() {
+    let base = okf(model("Block", false));
+    let ours = okf(model("Block", false));
+    let theirs = okf(model("Renamed", false));
+    let outcome = merge(&base, &ours, &theirs);
+    assert!(outcome.conflicts.is_empty(), "{:?}", outcome.conflicts);
+    assert_eq!(outcome.merged.unwrap().structure[0].name, "Renamed");
+}
+
+#[test]
+fn identical_changes_merge_without_conflict() {
+    let base = okf(model("Block", false));
+    let ours = okf(model("Renamed", false));
+    let theirs = okf(model("Renamed", false));
+    let outcome = merge(&base, &ours, &theirs);
+    assert!(outcome.conflicts.is_empty(), "{:?}", outcome.conflicts);
+    assert_eq!(outcome.merged.unwrap().structure[0].name, "Renamed");
+}
+
+#[test]
+fn two_different_changes_to_one_element_conflict() {
+    let base = okf(model("Block", false));
+    let ours = okf(model("Ours", false));
+    let theirs = okf(model("Theirs", false));
+    let outcome = merge(&base, &ours, &theirs);
+    assert!(
+        outcome.merged.is_none(),
+        "a conflict must not produce a document"
+    );
+    assert_eq!(outcome.conflicts.len(), 1);
+    assert_eq!(outcome.conflicts[0].kind, "bothModified");
+    assert!(outcome.conflicts[0].subject.contains("b1"));
+    assert!(outcome.conflicts[0].ours.is_some());
+    assert!(outcome.conflicts[0].theirs.is_some());
+}
+
+#[test]
+fn an_element_added_by_one_side_is_kept_and_the_summary_is_recomputed() {
+    let base = okf(model("Block", false));
+    let ours = okf(model("Block", false));
+    let theirs = okf(model("Block", true));
+    let outcome = merge(&base, &ours, &theirs);
+    assert!(outcome.conflicts.is_empty(), "{:?}", outcome.conflicts);
+    let merged = outcome.merged.expect("clean merge");
+    assert_eq!(merged.requirements.len(), 2);
+    assert_eq!(merged.summary.requirements, 2, "the summary is recomputed");
+}
+
+#[test]
+fn an_edge_added_by_one_side_is_kept() {
+    let base = okf(model("Block", false));
+    let mut our_value = model("Block", false);
+    our_value["graph"]["edges"]
+        .as_array_mut()
+        .unwrap()
+        .push(json!({
+            "source": "b1",
+            "target": "r1",
+            "kind": "dependency",
+            "label": "Verify"
+        }));
+    let ours = okf(our_value);
+    let theirs = okf(model("Block", false));
+    let outcome = merge(&base, &ours, &theirs);
+    assert!(outcome.conflicts.is_empty(), "{:?}", outcome.conflicts);
+    let merged = outcome.merged.expect("clean merge");
+    assert_eq!(merged.graph.as_ref().unwrap().edges.len(), 2);
+}
+
+#[test]
+fn deleting_on_one_side_while_the_other_modifies_is_a_conflict() {
+    let base = okf(model("Block", true));
+    let ours = okf(model("Block", false)); // r2 deleted here
+    let mut their_value = model("Block", true);
+    their_value["requirements"][1]["reqText"] = json!("changed by them");
+    let theirs = okf(their_value);
+    let outcome = merge(&base, &ours, &theirs);
+    assert!(outcome.merged.is_none());
+    assert_eq!(outcome.conflicts.len(), 1);
+    assert_eq!(outcome.conflicts[0].kind, "modifiedVersusDeleted");
+}
