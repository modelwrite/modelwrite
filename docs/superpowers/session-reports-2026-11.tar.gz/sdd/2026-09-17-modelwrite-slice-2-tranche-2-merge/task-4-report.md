# Task 4 Report: Revert without rewriting history

## Status
DONE

## Commits
- `8aa37c7` feat: revert a branch by appending a commit

## Test summary
`cargo test --workspace --no-fail-fast` is green: 77 tests passed, 0 failed across all binaries.
Service suite is 33 tests (was 32): api 10, corpus 1, gate_api 3, http 2, merge 9, merge_api 3, store 5.
Full per-binary counts: capi 4, gate 5, graph 7, mcp 13, okf_diff 8, okf_validation 7,
server 33 (api 10 / corpus 1 / gate_api 3 / http 2 / merge 9 / merge_api 3 / store 5),
plus 0-test unit/doc targets elsewhere. Doc-tests for every crate: 0.

## Verification
- `cargo fmt --all`: clean (exit 0).
- `cargo clippy --workspace --all-targets -- -D warnings`: clean (exit 0).
- Only `server/` was staged and committed (3 files: src/api.rs, src/lib.rs, tests/api.rs).
- Self-review confirms: the new commit's parent is the previous tip (test asserts
  `parents == [second_hash]`), the restored content is byte-identical to the target by
  construction (the handler reuses `target.okf_hash`), the superseded commit is still
  readable after the reset (test asserts 200), and no assertion was weakened.

## Concerns
None. The brief's "29 service tests" figure is stale; the actual service suite is 33,
consistent with the task description.

## Deviation
None — handler, route, and test were taken verbatim from the brief.
