﻿# Tranche 2 Task 1 review package

## Commit

fd43323 feat: list and delete branches without touching history

## Diff stat

 server/src/api.rs          | 35 ++++++++++++++++++
 server/src/lib.rs          |  9 ++++-
 server/src/store/mod.rs    |  5 +++
 server/src/store/sqlite.rs | 13 +++++++
 server/tests/api.rs        | 88 ++++++++++++++++++++++++++++++++++++++++++++++
 5 files changed, 149 insertions(+), 1 deletion(-)

## Full diff (-U10)

diff --git a/server/src/api.rs b/server/src/api.rs
index 8cc8d4f..7c735ba 100644
--- a/server/src/api.rs
+++ b/server/src/api.rs
@@ -219,10 +219,45 @@ pub async fn create_branch(
     validate_name("branch name", &body.name)?;
     state
         .store
         .create_branch(&project, &body.name, &body.from)
         .map_err(map_store_error)?;
     Ok((
         StatusCode::CREATED,
         Json(json!({ "name": body.name, "tip": body.from })),
     ))
 }
+
+pub async fn list_branches(
+    State(state): State<ApiState>,
+    Path(project): Path<String>,
+) -> Result<Json<Value>, ApiError> {
+    if state
+        .store
+        .project(&project)
+        .map_err(map_store_error)?
+        .is_none()
+    {
+        return Err(ApiError::not_found(format!("project {}", project)));
+    }
+    let branches = state
+        .store
+        .list_branches(&project)
+        .map_err(map_store_error)?;
+    let out: Vec<Value> = branches
+        .iter()
+        .map(|(name, tip)| json!({ "name": name, "tip": tip }))
+        .collect();
+    Ok(Json(Value::Array(out)))
+}
+
+pub async fn delete_branch(
+    State(state): State<ApiState>,
+    Path((project, name)): Path<(String, String)>,
+) -> Result<StatusCode, ApiError> {
+    validate_name("branch name", &name)?;
+    state
+        .store
+        .delete_branch(&project, &name)
+        .map_err(map_store_error)?;
+    Ok(StatusCode::NO_CONTENT)
+}
diff --git a/server/src/lib.rs b/server/src/lib.rs
index 68d5d63..fb2d996 100644
--- a/server/src/lib.rs
+++ b/server/src/lib.rs
@@ -34,21 +34,28 @@ pub fn app(state: AppState) -> Router {
         .route("/version", get(version))
         .route(
             "/projects",
             post(api::create_project).get(api::list_projects),
         )
         .route(
             "/projects/:project/commits",
             post(api::create_commit).get(api::list_commits),
         )
         .route("/projects/:project/commits/:hash", get(api::get_commit))
-        .route("/projects/:project/branches", post(api::create_branch))
+        .route(
+            "/projects/:project/branches",
+            post(api::create_branch).get(api::list_branches),
+        )
+        .route(
+            "/projects/:project/branches/:name",
+            axum::routing::delete(api::delete_branch),
+        )
         .route("/projects/:project/gate", post(gate_api::run_gate))
         .route(
             "/projects/:project/gate-runs",
             get(gate_api::list_gate_runs),
         )
         .with_state(api_state)
 }
 
 async fn health() -> Json<serde_json::Value> {
     Json(json!({ "status": "ok" }))
diff --git a/server/src/store/mod.rs b/server/src/store/mod.rs
index 848c2f6..0c29e09 100644
--- a/server/src/store/mod.rs
+++ b/server/src/store/mod.rs
@@ -110,14 +110,19 @@ pub trait Store: Send + Sync {
         branch: &str,
         okf_hash: &str,
         author: &str,
         message: &str,
     ) -> Result<Commit, StoreError>;
 
     fn commit(&self, project: &str, hash: &str) -> Result<Option<Commit>, StoreError>;
     fn commits_on(&self, project: &str, branch: &str) -> Result<Vec<Commit>, StoreError>;
     fn branch_tip(&self, project: &str, branch: &str) -> Result<Option<String>, StoreError>;
     fn create_branch(&self, project: &str, name: &str, from: &str) -> Result<(), StoreError>;
+
+    /// Remove a branch pointer. This never deletes commits: the objects a branch pointed
+    /// at stay in the store, so a deleted branch can be recreated at the same hash and no
+    /// history is ever lost.
+    fn delete_branch(&self, project: &str, name: &str) -> Result<(), StoreError>;
     fn list_branches(&self, project: &str) -> Result<Vec<(String, String)>, StoreError>;
     fn record_gate_run(&self, run: &GateRun) -> Result<(), StoreError>;
     fn gate_runs(&self, project: &str) -> Result<Vec<GateRun>, StoreError>;
 }
diff --git a/server/src/store/sqlite.rs b/server/src/store/sqlite.rs
index 8f582b3..bad5c19 100644
--- a/server/src/store/sqlite.rs
+++ b/server/src/store/sqlite.rs
@@ -324,20 +324,33 @@ impl Store for SqliteStore {
         })?;
         if inserted == 0 {
             return Err(StoreError::Conflict(format!(
                 "branch {} already exists",
                 name
             )));
         }
         Ok(())
     }
 
+    fn delete_branch(&self, project: &str, name: &str) -> Result<(), StoreError> {
+        let removed = self.with(|c| {
+            c.execute(
+                "DELETE FROM branches WHERE project = ?1 AND name = ?2",
+                params![project, name],
+            )
+        })?;
+        if removed == 0 {
+            return Err(StoreError::NotFound(format!("branch {}", name)));
+        }
+        Ok(())
+    }
+
     fn list_branches(&self, project: &str) -> Result<Vec<(String, String)>, StoreError> {
         self.with(|c| {
             let mut stmt =
                 c.prepare("SELECT name, tip FROM branches WHERE project = ?1 ORDER BY name")?;
             let rows = stmt.query_map(params![project], |row| Ok((row.get(0)?, row.get(1)?)))?;
             rows.collect()
         })
     }
 
     fn record_gate_run(&self, run: &GateRun) -> Result<(), StoreError> {
diff --git a/server/tests/api.rs b/server/tests/api.rs
index 7ad9440..13e2ea5 100644
--- a/server/tests/api.rs
+++ b/server/tests/api.rs
@@ -14,20 +14,24 @@ fn state(dir: &std::path::Path) -> server::AppState {
 
 fn post(uri: &str, body: serde_json::Value) -> Request<Body> {
     Request::builder()
         .method("POST")
         .uri(uri)
         .header("content-type", "application/json")
         .body(Body::from(body.to_string()))
         .unwrap()
 }
 
+fn get(uri: &str) -> Request<Body> {
+    Request::builder().uri(uri).body(Body::empty()).unwrap()
+}
+
 async fn json_body(response: axum::response::Response) -> serde_json::Value {
     let bytes = response.into_body().collect().await.unwrap().to_bytes();
     serde_json::from_slice(&bytes).unwrap()
 }
 
 fn tiny_okf() -> serde_json::Value {
     serde_json::json!({
         "project": "tiny",
         "exportedAt": "2026-09-17T00:00:00Z",
         "summary": {},
@@ -282,10 +286,94 @@ async fn names_that_could_escape_a_path_are_rejected() {
 
     let accepted = router
         .oneshot(post(
             "/projects",
             serde_json::json!({ "name": "coffee-machine.v2" }),
         ))
         .await
         .unwrap();
     assert_eq!(accepted.status(), StatusCode::CREATED);
 }
+
+#[tokio::test]
+async fn branches_can_be_listed_and_deleted_without_losing_commits() {
+    let dir = tempfile::tempdir().unwrap();
+    let router = server::app(state(dir.path()));
+    router
+        .clone()
+        .oneshot(post("/projects", serde_json::json!({ "name": "coffee" })))
+        .await
+        .unwrap();
+    let committed = router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/commits",
+            serde_json::json!({ "branch": "main", "author": "alex", "message": "m", "okf": tiny_okf() }),
+        ))
+        .await
+        .unwrap();
+    let hash = json_body(committed).await["hash"]
+        .as_str()
+        .unwrap()
+        .to_string();
+    router
+        .clone()
+        .oneshot(post(
+            "/projects/coffee/branches",
+            serde_json::json!({ "name": "review", "from": hash }),
+        ))
+        .await
+        .unwrap();
+
+    let listed = router
+        .clone()
+        .oneshot(get("/projects/coffee/branches"))
+        .await
+        .unwrap();
+    let branches = json_body(listed).await;
+    let names: Vec<String> = branches
+        .as_array()
+        .unwrap()
+        .iter()
+        .map(|b| b["name"].as_str().unwrap().to_string())
+        .collect();
+    assert!(names.contains(&"main".to_string()));
+    assert!(names.contains(&"review".to_string()));
+
+    let deleted = router
+        .clone()
+        .oneshot(
+            Request::builder()
+                .method("DELETE")
+                .uri("/projects/coffee/branches/review")
+                .body(Body::empty())
+                .unwrap(),
+        )
+        .await
+        .unwrap();
+    assert_eq!(deleted.status(), StatusCode::NO_CONTENT);
+
+    // The commit the deleted branch pointed at must still be readable.
+    let still_there = router
+        .clone()
+        .oneshot(
+            Request::builder()
+                .uri(format!("/projects/coffee/commits/{}", hash))
+                .body(Body::empty())
+                .unwrap(),
+        )
+        .await
+        .unwrap();
+    assert_eq!(still_there.status(), StatusCode::OK);
+
+    let gone = router
+        .oneshot(
+            Request::builder()
+                .method("DELETE")
+                .uri("/projects/coffee/branches/review")
+                .body(Body::empty())
+                .unwrap(),
+        )
+        .await
+        .unwrap();
+    assert_eq!(gone.status(), StatusCode::NOT_FOUND);
+}
