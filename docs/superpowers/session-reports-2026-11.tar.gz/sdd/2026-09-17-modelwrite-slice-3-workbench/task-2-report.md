# Task 2 report - The model views

## Status

DONE

## Commits

- `96cf177` feat: add the model views (staged only `server/` and `Cargo.lock`; 8 files, 916 insertions, 2 deletions)

## Test summary

`cargo test --workspace --no-fail-fast`: **211 passed, 0 failed, 16 ignored** (the 16 ignored are the PostgreSQL suite, which CI runs against a real database). Baseline at dispatch was 205 passed + 13 ignored; this task adds 3 UI tests (`server/tests/ui.rs` goes 6 -> 9). Three further passing tests and three ignored tests arrived on the branch concurrently from other in-flight tasks during this session, which is why the total is 211 + 16 rather than 208 + 13.

Per-binary passed counts: capi 4; cli 34 (22 unit + 12 integration); gate 5; graph 7; mcp 13; okf 15 (8 diff + 7 validation); server lib unit 14; api 11; audit 12; auth 32; corpus 1; gate_api 4; http 4; locks 15; merge 15; merge_api 4; store 12; ui 9 (new: +3); postgres 0 passed + 16 ignored.

`cargo fmt --all` clean; `cargo clippy --workspace --all-targets -- -D warnings` clean.

## The one rule that matters most

The traceability matrix calls `graph::requirement_coverage` and renders its fields verbatim (`total`, `covered`, `satisfied`, `refined`, `verified`, `allocated`, `uncovered`) - it never recomputes coverage. The page shows "25 requirements: 15 covered, 10 uncovered · 20 satisfy, 3 refine, 1 verify, 0 allocate", byte-for-byte the numbers the engine's own pinned test (`corpus_coverage_is_pinned` in `engine/graph/tests/graph_stats.rs`) asserts.

This rule caught a real defect in my first draft: my hand-written test asserted "4 refine, 3 allocate" (a naive edge-label count), while the engine reports "3 refine, 0 allocate" (one Refine edge does not target a requirement, and none of the three Allocate edges touches a requirement). I corrected the test to the engine's numbers. A second implementation would have disagreed with the gate exactly as the brief warned.

## Self-review evidence

- `GET /ui/projects/coffee/model` renders all four sections (Structure, Requirements, Traceability, State and activity), asserted in `the_model_page_renders_all_four_sections_of_the_corpus`.
- Counts pinned in that test: 49 structure elements, 25 requirements (and 25 matrix rows), 9 signals, 8 activities, 7 states, 8 transitions.
- Ten uncovered requirements are visibly marked (`class="uncovered"` x10) and fifteen marked covered (`class="covered"` x15), matching the engine's coverage report.
- The two dangling edges render as explicit broken links: `class="unresolved-edge"` x2, with both missing endpoint ids shown.
- The page reads the model through `crate::api::load_model` - the same function the gate and reset handlers use - guarded by the same identity resolution, `Read` permission and project-scope checks. No store method was added. `a_scoped_identity_cannot_see_another_projects_model` proves the scope refusal.
- No network references: a grep over `server/src/ui` finds no `http://`, `https://`, `<script`, `<img`, `<link`, `@import` or `url(`. Everything is server-rendered HTML with the one inline stylesheet.
- `?branch=` and `?commit=` both resolve, and unknown branch/commit render 404 (`the_model_page_resolves_branch_and_commit_and_404s_unknown`).

## Concerns

- This session ran in a shared working tree while other tasks on the branch committed concurrently: HEAD advanced several commits during the session, and midway `crate::api::load_model` was refactored from `(&ApiState) -> Result<OkfRoot, ApiError>` to `(&dyn Store) -> Result<OkfRoot, StoreError>`. I adapted the model page to the current signature (`load_model(state.store.as_ref(), project, &hash).map_err(map_store_error)?`) and re-verified; the commit sits cleanly on the then-current HEAD `5d88ae2`. Anyone re-basing should re-check that this call still matches `load_model`'s signature.
- The structure section is a forest, not a single tree: the corpus has seventeen roots and one block (`Boiler`) that is a part of two different parents. The renderer visits each element exactly once at its first-discovered parent's depth, so a DAG cannot duplicate or drop an element (49 elements always render).

## Deviations

- None in scope. The brief does not state a literal commit message, so I used the project's conventional-commit style derived from the task title, exactly as Task 1 did.
- The brief lists only four sections; the corpus's nine signals are rendered as a "Signals" list inside the Structure section (they share the `Element` type and the section renders element kind/stereotypes/documentation), so the four-section shape is preserved while the acceptance count of 9 signals is still satisfied.
