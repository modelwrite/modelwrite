# Task 4 report - Editing that becomes a commit

## Status

DONE

## Commits

- `cff0671` feat: add editing that becomes a commit (staged only `server/`; 6 files, 998 insertions, 5 deletions). `Cargo.lock` was not staged because no dependency was added.

## Test summary

`cargo test --workspace --no-fail-fast`: **223 passed, 0 failed, 16 ignored** (the 16 ignored are the PostgreSQL suite, which CI runs against a real database). Baseline at dispatch was 217 passed + 16 ignored; this task adds 6 UI tests (`server/tests/ui.rs` goes 15 -> 21).

Per-binary passed counts: capi 4; cli 34 (22 unit + 12 integration); gate 5; graph 7; mcp 13; okf 15 (8 diff + 7 validation); server lib unit 14; api 11; audit 12; auth 32; corpus 1; gate_api 4; http 4; locks 15; merge 15; merge_api 4; store 12; ui 21 (new: +6); postgres 0 passed + 16 ignored.

`cargo fmt --all` clean; `cargo clippy --workspace --all-targets -- -D warnings` clean.

## The four guarantees

1. **The edit goes through the existing commit path.** The form builds a candidate `OkfRoot`, validates it with `okf::validate::validate`, computes the touched set with `api::touched_elements`, and hands the document to `store.commit_model` wrapped in `api::commit_refusal_guard` - the SAME validation, lock guard inside the transaction, audit row and permission decisions the JSON `create_commit` handler uses. There is no UI-only write path.
2. **A lock is taken for the request.** On submit the page calls `store.acquire_locks` on the element with the verified identity as the holder, and releases it (`store.release_locks`) before returning whatever the commit did, so the element is never left locked. The form shows the other holder and disables its submit button while the element is held, naming the holder.
3. **An invalid result is shown, not crashed.** A candidate the validator rejects re-renders the form with `report.errors` listed next to it and stores nothing (422, no blob, no commit).
4. **The verified identity is the author.** The commit's author is `identity.subject`; there is no author field in the form and any submitted `author` value is ignored.

## Self-review evidence

- `editing_a_block_documentation_commits_with_the_identity_author` - a documentation edit through the form returns 201, the new commit's author is the fixed identity `alice` (not the bogus `author=evil` field sent in the form body), the edited documentation and both attributes survive the round-trip, and `store.locks("coffee", now)` is empty after the request.
- `an_element_held_by_another_holder_is_refused_and_names_the_holder` - a lease held by `bob` renders in the GET form ("Held by another holder", submit disabled), and the POST is refused with 409 naming `bob`, with the branch still at one commit.
- `an_invalid_edit_renders_the_validator_errors_and_stores_nothing` - emptying the element id returns 422 rendering "empty element id" next to the form, and no commit is stored.
- `an_unauthenticated_edit_is_a_sign_in_prompt` and `a_viewer_cannot_edit` - an unauthenticated GET/POST is a 401 sign-in page and a viewer's POST is a 403 "write permission required" page.
- `the_edit_form_renders_the_corpus_block_with_its_attributes` - the form renders the corpus "Coffee Machine" block with its indexed attribute rows, so the only model every contributor has is editable.

## Concerns

- The form carries an `id` field in addition to the brief's four fields. It is the only element field the OKF validator checks (empty or duplicate id), so it is the only way an edit can produce an invalid model - the acceptance that requires the validator's errors to render. Renaming an id does not rewrite the graph's node/edge ids, so a rename leaves dangling-edge WARNINGS rather than errors; that is the engine's existing, deliberate behaviour, not new code here.

## Deviations

- The brief's file list names `pages.rs` (modify), but the element editor has no natural entry point on the project/branch list pages; its entry point is the model page's structure tree, so `server/src/ui/model.rs` carries the per-element "edit" link instead. This is a supporting edit outside the brief's list, matching the Task 2/3 precedent of adding `pub mod ...` and CSS beyond the named files; `server/src/ui/layout.rs` also gained CSS for the edit form. `pages.rs` required no functional change.
- The brief does not state a literal commit message, so I used the project's conventional-commit style derived from the task title, exactly as Tasks 1-3 did.
