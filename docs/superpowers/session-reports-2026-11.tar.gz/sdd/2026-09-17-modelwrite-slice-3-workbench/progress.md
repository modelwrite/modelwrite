# SDD ledger - plan: docs/superpowers/plans/2026-09-17-modelwrite-slice-3-workbench.md

Working branch: slice-2-repository (pull request #2).

## Why this slice

Slice 2 built a repository that engineers cannot see. Everything it can do requires writing HTTP by hand. This slice is where the platform becomes usable by the people who did not install it: a browser interface over the SAME API, so the permissions, locks, audit log and gate all apply unchanged.

## Rulings

Ruling: NO BUILD STEP. The workbench is server-rendered HTML with inline SVG and a small amount of vanilla JavaScript, served by the same axum service. No npm, no bundler, no asset pipeline. Cost if wrong: less interactive than a single-page application, and a later move to one is a rewrite of the view layer. Benefit: an air-gapped organisation with a security policy against an npm supply chain can actually install it, and a page that cannot be built cannot be audited.
Ruling: STRUCTURED EDITING, NOT DIAGRAM DRAWING. This slice edits an element's name, documentation, stereotypes and attributes through a form that becomes a commit. Diagrams are RENDERED deterministically from the model. Cost if wrong: an engineer used to placing boxes by hand will find the diagram view rigid. Benefit: a model whose meaning lives in hand-placed geometry is a model that cannot be merged, diffed or proved, which is the entire point of this platform; geometry that carries meaning belongs in binding extensions, preserved and round-tripped rather than invented here.
Ruling: the UI is a CLIENT of the existing API, never a second implementation. Every view reads what the handlers return, and every action goes through a handler, so a UI-only write path cannot exist to bypass a permission, a lock or the audit log.
Ruling: the traceability matrix uses the EXISTING coverage code in the graph crate. A second implementation would disagree with the gate, and a reviewer would trust the wrong one.

## Environment facts

- Baseline: 199 workspace tests passing, 13 ignored locally (the PostgreSQL suite, which CI runs for real), fmt and clippy clean, CI green.
- The server crate is at rust-version 1.88 and binds loopback by default; MW_BIND and MW_ALLOW_OPEN control exposure.
- The coffee-machine corpus at sample/corpus/coffee-machine is the model every view must render usefully: 49 blocks, 25 requirements, 9 signals, 8 activities, 99 graph nodes, 165 edges, 10 requirements uncovered and 2 dangling edges.

## Progress

Task 1: dispatched

Task 1 (the workbench shell): implementation complete (fd49c71), 205 workspace tests, fmt and clippy clean, and the implementer separately verified that the workspace builds at the declared MSRV of 1.88 - the same check the new CI job performs.
Templating: maud, chosen because it is compile-time HTML that escapes dynamic values BY CONSTRUCTION rather than by remembering to escape. That matters here more than in most projects: a model is untrusted input from a colleague, a supplier or an import, and a project name is a string somebody typed. The one place raw HTML is allowed is the inline stylesheet, which is the author's own.
The implementer reported a stale line in the CONTROLLER'S PLAN: it said the server crate is at rust-version 1.85, which was true when the plan was written and false after the MSRV was raised. It followed the manifest rather than the plan and said so, which is the right call; the plan is corrected. A plan that contradicts the code is a trap for the next person to read it.
Task 1 review and Task 2 (the model views) dispatched.
