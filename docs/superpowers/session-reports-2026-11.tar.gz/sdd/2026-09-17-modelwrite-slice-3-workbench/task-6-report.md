# Task 6 report — The diagram view

## Status
DONE

## Commits
- `915820a` feat: render the diagram deterministically from the model
  - new: server/src/ui/diagram.rs
  - modified: server/src/ui/mod.rs, server/src/ui/model.rs, server/src/lib.rs, server/tests/ui.rs

## Test summary
`cargo test --workspace --no-fail-fast` → **233 passed, 0 failed, 16 ignored** (the skipped PostgreSQL suite).
By crate: cli 34, server 153 (ui 29, auth 32, locks 15, merge 15, store 12, audit 12, api 11, gate_api 4, http 4, merge_api 4, corpus 1, lib-unittests 14), okf 17, mcp 13, gate 5, graph 7, capi 4.

## What was built
- `GET /ui/projects/:project/diagram?branch=&commit=` — the model's graph rendered as inline SVG, with the same identity resolution, Read-permission check, project-scope check and branch/commit resolution as the model page (the `resolve_hash` helper is now shared, not duplicated).
- Nodes grouped by kind into columns (a fixed kind order with alphabetical fallback), each column stacked vertically by (name, id); requirement nodes are visually distinct (amber fill/stroke). Edges are straight lines between node or marker centers, labelled with the edge label. Unresolved endpoints — an edge source or target that names no node — are drawn as explicit red diamond "unresolved" markers in a left-hand lane, never dropped.
- The model page links to the diagram and the diagram links back, so the two views stay consistent.

## Layout algorithm and why
Nodes are laid out on a grid grouped by kind: each distinct node kind is one column (ordered by a fixed KIND_ORDER list, with unknown kinds sorted alphabetically after it), and each kind's nodes are stacked vertically sorted by name then id. Unresolved edge endpoints occupy a separate left-hand lane of diamond markers, sorted by id. Edges are sorted by (source, target, kind, label) and drawn as lines; multiple edges sharing a source–target pair are spread a fixed amount perpendicular to the line so each stays visible. Every coordinate is a pure function of a few named constants plus the sorted iteration order, so the same model always produces byte-identical SVG.

Why this and not a graph-drawing framework: the slice's ruling is that geometry carrying meaning must not be invented in the view (it belongs in a later binding extension), and the task forbids adding a drawing library. A deterministic grid grouped by kind is the simplest arrangement that (a) is a pure function of the model, (b) cannot wobble between renders, and (c) trivially keeps every node and edge present and diffable. No hash-map iteration order is ever observed; everything iterated is sorted first.

## Acceptance evidence (asserted in tests/ui.rs)
- Rendering the coffee-machine corpus twice produces **byte-identical** output (`assert_eq!(first_html, second_html)`).
- Every node and edge appears: 99 `class='node'` and 165 `class='edge'`.
- Both dangling endpoints are drawn: 2 `class='dangling'` markers, and the two ids (`_2026x_1_12a70364_1789524431087_459748_5711`, `_2026x_1_12a70364_1789524431091_435540_5713`) are present.
- Requirement nodes are visually distinct: 25 nodes carry the requirement fill.
- The SVG contains no `<script>`, no `href`, no `url(`, no `<image>`, `<use>` or `<foreignObject>` — asserted on the extracted SVG.
- A hostile node name, edge label and dangling-endpoint id are all XML-escaped (`&lt;script&gt;…`), with no raw `<script` reaching the SVG.
- Branch/commit resolution and 404s for unknown branch/commit; an unauthenticated diagram request is a 401 sign-in prompt (the URI was added to the existing auth loop).

## Verification
- `cargo fmt --all` — clean.
- `cargo clippy --workspace --all-targets -- -D warnings` — clean.

## Concerns
- The layout is rigid by design: one column per kind means the 42 blocks form a tall column, and edge routing is naive straight lines rather than an orthogonal/force-directed arrangement. This is the direct cost of the no-hand-placed-geometry and no-drawing-library rulings; the SVG carries a viewBox and scales to the container width, so a reviewer can zoom. A smarter (still deterministic) layout would be a future enhancement, not a change to the determinism/completeness/safety guarantees.

## Deviation
- The brief's "Files" line listed `server/src/ui/pages.rs` as the file to modify, but the task description's ownership list and its explicit instruction ("The model page with its navigation and meta header is the natural place to link the diagram from") point to the model page. I therefore added the diagram link to `server/src/ui/model.rs` and did not touch `pages.rs`. Everything else (new diagram.rs, mod.rs declaration, lib.rs route, tests/ui.rs) is exactly as specified. Cargo.lock was unchanged (no dependency added) and staged as instructed.
