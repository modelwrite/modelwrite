# Refactor: shared write cores (Slice 3)

## Status

DONE

## Commits

- `de0ac3d` refactor: centralize the audit-action vocabulary
- `d731793` refactor: share the commit and merge write cores between the API and the workbench
- `0223052` refactor: route the editor and merge page through the shared write cores

All three touch only `server/`. Nothing was amended.

## Test summary

`cargo test --workspace --no-fail-fast`: **239 passed, 0 failed, 16 ignored** (the 16 ignored are the PostgreSQL tests, which skip because `MW_TEST_DATABASE_URL` is unset). `cargo fmt --all -- --check` clean; `cargo clippy --workspace --all-targets -- -D warnings` clean.

Per-binary passed counts: binding harness 5 · capi 4 · cli 34 (22 main + 12 tests) · gate 5 · graph 7 · mcp 13 · okf 17 (8 diff + 9 validation) · server lib 14 · api 11 · audit 12 · auth 32 · corpus 1 · gate_api 4 · http 4 · locks 15 · merge 15 · merge_api 4 · postgres 0 (16 ignored) · store 12 · ui 30.

## What is now shared (one implementation)

- **Audit-action vocabulary** — `server/src/audit.rs` holds the one constant for every action name (`project.create`, `commit.create`, `commit.refused`, `branch.create/delete/reset`, `merge.clean`, `merge.conflict`, `lock.acquire/release/denied`, `gate.run`). Every handler — JSON and page alike — records the same name from the same place.
- **Commit sequence** — `api::commit_core` is the single implementation of: validate the document, compute the touched-element set (`commit_touched`), build the `CommitGuard` with its expected tip, `put_blob` the exact bytes, build the `commit.create` audit entry, and call `commit_model` wrapped in `commit_refusal_guard`. Both `create_commit` (JSON) and the editor's `perform_edit` (page) call it.
- **Merge sequence** — `merge_api::merge_core` is the single implementation of: resolve the two branch tips and their lowest common ancestor, run the three-way merge, then either record `merge.conflict` or validate + lock-guard + `put_blob` + `commit_merge` with the `merge.clean` audit entry. Both `merge_branches` (JSON) and the merge page's `perform_merge` call it.

## What is deliberately different (kept explicit)

- **The editor's lease.** A plain commit holds no element; the editor acquires a 60-second lease as the verified subject for the duration of the request and releases it before returning. That difference is NOT averaged away: it lives in `perform_edit`, which passes its held subject into `commit_core` as the guard's `holder`. The core documents that an empty holder means "no lease held".
- **create_commit's cheap pre-refusal.** The optional-holder-field optimisation ("refuse before `put_blob` so a rejected commit leaves no orphaned blob") stays in `create_commit` rather than in the core, because it is tied to the optional-holder-field semantics that the editor's lease strategy replaces. The authoritative guard check still runs inside the store transaction for both.
- **Author resolution.** The JSON handlers resolve a *claimed* author via `resolve_author` (its documented surface). The workbench forms take the author from the verified identity and have no author field — this is the trap (b) fix.
- **Rendering.** The cores return plain values (`Commit`, `MergeOutcome`); each caller renders its own surface (JSON vs HTML).

## Test assertion changes

None. No test file was modified, and no assertion was weakened or adjusted. All 239 tests pass unchanged against the refactor.

## The two traps

- **(a) — fixed.** The edit link on the model page now renders only for an identity with `Write` (`model.rs`, threaded through `structure_section`/`render_tree`), and the editor's submit button is disabled when the identity lacks `Write` (`edit.rs`). Server-side refusal is unchanged: `POST` still enforces `Write`.
- **(b) — fixed.** The merge form's author field is removed from the markup and from `MergeForm`; `perform_merge` now takes the author from the verified identity, exactly as the editor does. The JSON merge API still accepts an author field (resolve_author enforces identity in configured mode).

## Concerns

- The merge core's defensive 500 paths (a merge that produces no document, a merged model that fails validation, or a serialisation failure) now return `StoreError::Backend`, which `map_store_error` reports as the generic 500 `"internal storage error"` (status unchanged) instead of the previous bespoke message strings. These are unreachable without a merge-rule or serialisation bug, no test asserts their message, and the detail is still logged. I did not change any message on a reachable path.
- `cargo fmt --all` ran against the whole workspace; the `engine/` and `cli/` crates were left untouched by this work (only `server/` is committed).

## Notes

- The branch moved under this session: `edffe28` (`feat: add the binding contract and the fidelity harness`) and `049a24c` (`fix: prove the fidelity harness measures rather than believes a binding`) landed while the refactor was in flight. My three commits sit on top of them, and the final green run is against that combined HEAD.
