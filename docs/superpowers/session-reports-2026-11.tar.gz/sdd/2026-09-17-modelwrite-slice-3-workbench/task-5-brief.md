## Global Constraints

- Rust stable; edition 2021. The server crate is at rust-version 1.85.
- Every source file begins with: // SPDX-License-Identifier: AGPL-3.0-or-later
- Cargo is not on PATH in fresh shells: begin every shell command sequence with $env:Path = "$env:USERPROFILE\\.cargo\\bin;" + $env:Path
- Use --no-fail-fast when running a test suite.
- Stage and commit only the paths a task owns. Never amend or rewrite a commit.
- THE UI IS A CLIENT OF THE EXISTING API, NOT A SECOND IMPLEMENTATION. Every action the UI performs goes through the same handlers, the same permission checks and the same audit log. A UI-only write path would be a hole in every guarantee the previous slices established.
- The UI must respect authentication: with auth configured, an unauthenticated request to a UI route is a 401 rendered as a sign-in prompt, never a crash or a silent empty page.
- HTML ESCAPING IS NOT OPTIONAL: every value that comes from a model, a commit message, a branch name or an error must be escaped. A model is untrusted input from a colleague, a supplier or an import.
- Every view must render usefully for the coffee-machine corpus, which is the only model every contributor has.
- Tests drive the router in process and assert on the HTML, so a view that stops rendering a section fails the suite.

## Task 5: The gate, rendered where a reviewer looks

**Files:**
- Create: server/src/ui/gate.rs
- Modify: server/src/ui/pages.rs, server/src/lib.rs
- Test: server/tests/ui.rs

**Interfaces:**
- Produces: `GET /ui/projects/:project/gate` listing recent gate runs newest first with their verdict, reference and candidate hashes and a link to the evidence file; `GET /ui/projects/:project/gate/:reference/:candidate` rendering one run in full: pass or fail, the fidelity failures by name, the coverage numbers, and the evidence record.

**Acceptance:** the corpus self-pass renders green with its counts; the corrupted pair renders red naming the missing element and the isolated node; a viewer without Review sees the list but not the detail, matching the API's permissions.

---

