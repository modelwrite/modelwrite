## Global Constraints

- Rust stable; edition 2021. The server crate is at rust-version 1.85.
- Every source file begins with: // SPDX-License-Identifier: AGPL-3.0-or-later
- Cargo is not on PATH in fresh shells: begin every shell command sequence with $env:Path = "$env:USERPROFILE\\.cargo\\bin;" + $env:Path
- Use --no-fail-fast when running a test suite.
- Stage and commit only the paths a task owns. Never amend or rewrite a commit.
- THE UI IS A CLIENT OF THE EXISTING API, NOT A SECOND IMPLEMENTATION. Every action the UI performs goes through the same handlers, the same permission checks and the same audit log. A UI-only write path would be a hole in every guarantee the previous slices established.
- The UI must respect authentication: with auth configured, an unauthenticated request to a UI route is a 401 rendered as a sign-in prompt, never a crash or a silent empty page.
- HTML ESCAPING IS NOT OPTIONAL: every value that comes from a model, a commit message, a branch name or an error must be escaped. A model is untrusted input from a colleague, a supplier or an import.
- Every view must render usefully for the coffee-machine corpus, which is the only model every contributor has.
- Tests drive the router in process and assert on the HTML, so a view that stops rendering a section fails the suite.

## Task 3: Diff and conflict review

**Files:**
- Create: server/src/ui/review.rs
- Modify: server/src/ui/pages.rs, server/src/lib.rs
- Test: server/tests/ui.rs

**Interfaces:**
- Produces: `GET /ui/projects/:project/compare?from=&to=` rendering the engine's section-scoped diff grouped by section, with added, removed and changed entries, and the gate verdict for the pair with a link to the evidence. `POST /ui/projects/:project/merge` performs a merge and, on 409, renders each conflict with base, ours and theirs side by side and a resolution form.
- The diff is the ENGINE's diff. The UI must not compute its own, or the two would disagree and the reviewer would trust the wrong one.

**Acceptance:** comparing the clean and corrupted corpus commits shows the missing requirement and the isolated node exactly as the gate reports them, and shows the failed verdict with the evidence path.

---

