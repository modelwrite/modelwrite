# Task 1 report - The workbench shell and the project list

## Status

DONE

## Commits

- `fd49c71` feat: add the workbench shell and project list (staged only `server/` and `Cargo.lock`)

## Test summary

`cargo test --workspace --no-fail-fast`: 205 passed, 0 failed, 13 ignored (the 13 ignored are the PostgreSQL suite, which CI runs against a real database). Baseline was 199 passed + 13 ignored; the 6 new UI tests in `server/tests/ui.rs` bring it to 205.

Per-binary passed counts: capi 4; cli 32 (21 unit + 11 integration); gate 5; graph 7; mcp 13; okf 15 (8 diff + 7 validation); server lib unit 14; api 11; audit 12; auth 32; corpus 1; gate_api 3; http 4; locks 15; merge 15; merge_api 4; store 12; ui 6 (new); postgres 0 passed + 13 ignored.

`cargo fmt --all -- --check` clean; `cargo clippy --workspace --all-targets -- -D warnings` clean.

## Templating approach

maud 0.27.0, declared only in `server/Cargo.toml`. Chosen because it is compile-time HTML: every dynamic value (project name, commit message, branch name, author, error text) is spliced through maud's `Render` trait, which HTML-escapes by construction. The only way to emit markup is `maud::PreEscaped`, and the one use of it in the workbench is the developer-written inline stylesheet. Escaping is therefore structural rather than by convention, and there is no runtime template engine or asset pipeline. Verified against the declared MSRV: `cargo +1.88.0 build --workspace --locked` passes (maud_macros and its only new transitive dep, proc-macro2-diagnostics, compile on 1.88).

## Concerns

- The brief and the plan doc both say "The server crate is at rust-version 1.85", but `server/Cargo.toml` actually declares `rust-version = "1.88"` (and the CI MSRV job pins 1.88.0, per the comment in `.github/workflows/ci.yml`). I followed the real manifest (1.88) and confirmed the maud addition builds on 1.88.0. This is a stale line in the docs, not a blocker, and I did not change it.

## Deviations

- None in scope. The brief/plan do not state a literal commit message, so I used the project's conventional-commit style derived from the task title: "feat: add the workbench shell and project list".

## Self-review evidence

- `/ui` lists the coffee corpus with branch count ("1 branch") and the latest commit message ("import the exported model"); `/ui/projects/coffee` lists `main` with that message and author `alex` (asserted in `the_project_list_and_page_render_the_coffee_corpus`).
- A viewer identity renders both pages (asserted in `a_viewer_sees_the_pages`, which also checks the header names the subject and mechanism).
- With `AuthConfig::static_token`, `/ui` and `/ui/projects/coffee` without a token return 401 with an HTML "Sign in required" prompt and never echo the token (`an_unauthenticated_request_renders_a_sign_in_prompt`).
- A project named `<script>alert(1)</script>` inserted directly into the store renders as `&lt;script&gt;alert(1)&lt;/script&gt;` with no raw `<script` anywhere (`a_hostile_project_name_is_escaped`).
- Routes are registered with axum 0.7 `:param` syntax (`/ui/projects/:project`).
- The UI reads only the existing `Store` trait methods (`list_projects`, `list_branches`, `commit`, `project`) - no new store method or API handler was added.
