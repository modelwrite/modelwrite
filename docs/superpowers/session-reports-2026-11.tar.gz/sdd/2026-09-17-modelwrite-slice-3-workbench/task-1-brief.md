## Global Constraints

- Rust stable; edition 2021. The server crate is at rust-version 1.85.
- Every source file begins with: // SPDX-License-Identifier: AGPL-3.0-or-later
- Cargo is not on PATH in fresh shells: begin every shell command sequence with $env:Path = "$env:USERPROFILE\\.cargo\\bin;" + $env:Path
- Use --no-fail-fast when running a test suite.
- Stage and commit only the paths a task owns. Never amend or rewrite a commit.
- THE UI IS A CLIENT OF THE EXISTING API, NOT A SECOND IMPLEMENTATION. Every action the UI performs goes through the same handlers, the same permission checks and the same audit log. A UI-only write path would be a hole in every guarantee the previous slices established.
- The UI must respect authentication: with auth configured, an unauthenticated request to a UI route is a 401 rendered as a sign-in prompt, never a crash or a silent empty page.
- HTML ESCAPING IS NOT OPTIONAL: every value that comes from a model, a commit message, a branch name or an error must be escaped. A model is untrusted input from a colleague, a supplier or an import.
- Every view must render usefully for the coffee-machine corpus, which is the only model every contributor has.
- Tests drive the router in process and assert on the HTML, so a view that stops rendering a section fails the suite.

## Task 1: The workbench shell and the project list

**Files:**
- Modify: server/Cargo.toml (the templating dependency, declared here only)
- Create: server/src/ui/mod.rs, server/src/ui/layout.rs, server/src/ui/pages.rs
- Modify: server/src/lib.rs (a /ui route, the module)
- Test: server/tests/ui.rs

**Interfaces:**
- Produces: `GET /ui` renders the project list with, per project, its branch count and its latest commit; `GET /ui/projects/:project` renders the project's branches, each with its tip and the tip's message and author. Both require Read and render a sign-in prompt on 401. The layout provides a header (project name, identity subject, auth mechanism) and a navigation rail that later tasks extend.

**Acceptance:** with the coffee-machine corpus loaded, `/ui` lists it; `/ui/projects/coffee` lists `main` with the tip commit's message; a viewer sees the pages; an unauthenticated request with auth configured sees a sign-in prompt and status 401; a project name containing `<script>` is escaped and cannot execute.

---

