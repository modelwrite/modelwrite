## Global Constraints

- Rust stable; edition 2021. The server crate is at rust-version 1.85.
- Every source file begins with: // SPDX-License-Identifier: AGPL-3.0-or-later
- Cargo is not on PATH in fresh shells: begin every shell command sequence with $env:Path = "$env:USERPROFILE\\.cargo\\bin;" + $env:Path
- Use --no-fail-fast when running a test suite.
- Stage and commit only the paths a task owns. Never amend or rewrite a commit.
- THE UI IS A CLIENT OF THE EXISTING API, NOT A SECOND IMPLEMENTATION. Every action the UI performs goes through the same handlers, the same permission checks and the same audit log. A UI-only write path would be a hole in every guarantee the previous slices established.
- The UI must respect authentication: with auth configured, an unauthenticated request to a UI route is a 401 rendered as a sign-in prompt, never a crash or a silent empty page.
- HTML ESCAPING IS NOT OPTIONAL: every value that comes from a model, a commit message, a branch name or an error must be escaped. A model is untrusted input from a colleague, a supplier or an import.
- Every view must render usefully for the coffee-machine corpus, which is the only model every contributor has.
- Tests drive the router in process and assert on the HTML, so a view that stops rendering a section fails the suite.

## Task 2: The model views

**Files:**
- Create: server/src/ui/model.rs
- Modify: server/src/ui/pages.rs, server/src/lib.rs (routes)
- Test: server/tests/ui.rs

**Interfaces:**
- Produces: `GET /ui/projects/:project/model?branch=&commit=` rendering four sections of the OKF document: **structure** as an indented tree of elements with kind, stereotypes and documentation; **requirements** as a table with id, reqId, text and the elements that satisfy it; **traceability** as a matrix of requirements against the elements allocated to them, with uncovered requirements visibly marked; **state and activity** as a list of regions, states and transitions, and activities with their nodes.
- The traceability matrix is computed by the EXISTING coverage code in the graph crate, not re-implemented in the UI.
- Unresolved edges (the corpus has two) render as explicit broken links rather than being hidden.

**Acceptance:** the coffee-machine corpus renders 49 blocks, 25 requirements, 9 signals and 8 activities; ten uncovered requirements are visibly marked, matching the coverage report; the two dangling edges are shown as unresolved.

---

