# Task 5 report — The gate, rendered where a reviewer looks

## Status
DONE

## Commits
- `82c3bc8` feat: render the gate where reviewers look
  - new: server/src/ui/gate.rs
  - modified: server/src/ui/mod.rs, server/src/ui/pages.rs, server/src/lib.rs, server/tests/ui.rs

## Test summary
`cargo test --workspace --no-fail-fast` → **228 passed, 0 failed, 16 ignored** (the skipped PostgreSQL suite).
By crate: cli 34, server 150 (ui 26, auth 32, locks 15, merge 15, store 12, audit 12, api 11, gate_api 4, http 4, merge_api 4, corpus 1, lib-unittests 14), okf 15, mcp 13, gate 5, graph 7, capi 4.

## What was built
- `GET /ui/projects/:project/gate` — recorded runs newest first, each with its verdict, the reference and candidate hashes, its branch, and the evidence file name, each linking to the detail.
- `GET /ui/projects/:project/gate/:reference/:candidate` — one run in full: verdict (green pass / red fail), the fidelity failures BY NAME (missing/extra elements, missing/extra edges, changed attributes), the isolated nodes named, the coverage numbers, validation errors/warnings, and the full evidence record.
- Both pages read the RECORDED run and its evidence through the existing Store trait; no new store method and no new JSON handler were added.

## Permission model
- The list requires Write OR Review — exactly the JSON `list_gate_runs` handler, in the same order, so a caller that may not read a run is refused (403) rather than shown an empty list.
- The detail requires Review (the evidence record is the reviewer's artifact).
- Consequence: an author (Write, no Review) sees the list but not the detail; a `viewer` role (neither Write nor Review) is refused on both. This is the reading of "a viewer without Review sees the list but not the detail".

## Acceptance evidence (asserted in tests/ui.rs)
- Corpus self-pass renders `passed` (green) with `25 requirements: 15 covered, 10 uncovered · 20 satisfy, 3 refine, 1 verify, 0 allocate` and `1 connected component`.
- Corrupted pair renders `failed` (red), naming the missing element `requirements:_2026x_1_12a70364_1789522470210_613186_5619` and the isolated node `_2026x_1_12a70364_1789602694801_483599_6108`, and renders the full evidence record.
- A failed gate is a 200 page, never an error page.
- Hostile content inside the evidence record is escaped.

## Verification
- `cargo fmt --all` — clean.
- `cargo clippy --workspace --all-targets -- -D warnings` — clean.

## Concerns
- An unrelated, uncommitted change to `engine/okf/src/validate.rs` (adds a graph-node cross-check warning) appeared in the working tree during this task, outside my owned files. I did not modify or stage it; the commit above contains only my five owned files. The full suite passes with it present. It appears to belong to a concurrent task in this shared workbench.

## Deviation
None. The only judgment call was the detail-page permission (Review-only), documented above.
