## Global Constraints

- Rust stable; edition 2021. The server crate is at rust-version 1.85.
- Every source file begins with: // SPDX-License-Identifier: AGPL-3.0-or-later
- Cargo is not on PATH in fresh shells: begin every shell command sequence with $env:Path = "$env:USERPROFILE\\.cargo\\bin;" + $env:Path
- Use --no-fail-fast when running a test suite.
- Stage and commit only the paths a task owns. Never amend or rewrite a commit.
- THE UI IS A CLIENT OF THE EXISTING API, NOT A SECOND IMPLEMENTATION. Every action the UI performs goes through the same handlers, the same permission checks and the same audit log. A UI-only write path would be a hole in every guarantee the previous slices established.
- The UI must respect authentication: with auth configured, an unauthenticated request to a UI route is a 401 rendered as a sign-in prompt, never a crash or a silent empty page.
- HTML ESCAPING IS NOT OPTIONAL: every value that comes from a model, a commit message, a branch name or an error must be escaped. A model is untrusted input from a colleague, a supplier or an import.
- Every view must render usefully for the coffee-machine corpus, which is the only model every contributor has.
- Tests drive the router in process and assert on the HTML, so a view that stops rendering a section fails the suite.

## Task 4: Editing that becomes a commit

**Files:**
- Create: server/src/ui/edit.rs
- Modify: server/src/ui/pages.rs, server/src/lib.rs
- Test: server/tests/ui.rs

**Interfaces:**
- Produces: `GET /ui/projects/:project/edit/:element` rendering a form for an element's name, documentation, stereotypes and attributes; `POST` the same path to commit the change. The commit carries the verified identity as its author, takes a lock on the element for the duration of the request, and is refused with the gate's reasons if the result is invalid. The form shows which OTHER holders currently hold the element, and refuses to submit while it does.

**Acceptance:** editing a block's documentation through the form creates a commit whose author is the identity; editing an element locked by another holder is refused with the holder named; an edit that would produce an invalid model is refused with the validator's errors rendered, not a 500.

---

