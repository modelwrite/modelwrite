## Global Constraints

- Rust stable; edition 2021. The server crate is at rust-version 1.85.
- Every source file begins with: // SPDX-License-Identifier: AGPL-3.0-or-later
- Cargo is not on PATH in fresh shells: begin every shell command sequence with $env:Path = "$env:USERPROFILE\\.cargo\\bin;" + $env:Path
- Use --no-fail-fast when running a test suite.
- Stage and commit only the paths a task owns. Never amend or rewrite a commit.
- THE UI IS A CLIENT OF THE EXISTING API, NOT A SECOND IMPLEMENTATION. Every action the UI performs goes through the same handlers, the same permission checks and the same audit log. A UI-only write path would be a hole in every guarantee the previous slices established.
- The UI must respect authentication: with auth configured, an unauthenticated request to a UI route is a 401 rendered as a sign-in prompt, never a crash or a silent empty page.
- HTML ESCAPING IS NOT OPTIONAL: every value that comes from a model, a commit message, a branch name or an error must be escaped. A model is untrusted input from a colleague, a supplier or an import.
- Every view must render usefully for the coffee-machine corpus, which is the only model every contributor has.
- Tests drive the router in process and assert on the HTML, so a view that stops rendering a section fails the suite.

## Task 6: The diagram view

**Files:**
- Create: server/src/ui/diagram.rs
- Modify: server/src/ui/pages.rs, server/src/lib.rs
- Test: server/tests/ui.rs

**Interfaces:**
- Produces: `GET /ui/projects/:project/diagram?branch=&commit=` rendering the graph as inline SVG with a DETERMINISTIC layout: nodes grouped by kind on a grid, edges drawn as lines with labels, requirement nodes visually distinct, and unresolved endpoints drawn as dangling markers. The same model must always produce byte-identical SVG, so that a diagram can be diffed and cached.

**Acceptance:** rendering the coffee-machine corpus twice produces identical SVG; every node and edge appears; an unresolved endpoint is drawn rather than dropped; the SVG contains no script and no external reference, so it is safe to render in any browser and to embed in a report.

---

