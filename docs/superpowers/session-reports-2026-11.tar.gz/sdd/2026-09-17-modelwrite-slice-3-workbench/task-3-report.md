# Task 3 report - Diff and conflict review

## Status

DONE

## Commits

- `1e1edfd` feat: add diff and conflict review (staged only `server/`; 6 files, 1066 insertions, 1 deletion)

## Test summary

`cargo test --workspace --no-fail-fast`: **216 passed, 0 failed, 16 ignored** (the 16 ignored are the PostgreSQL suite, which CI runs against a real database). Baseline at dispatch was 211 passed + 16 ignored; this task adds 5 UI tests (`server/tests/ui.rs` goes 9 -> 14).

Per-binary passed counts: capi 4; cli 34 (22 unit + 12 integration); gate 5; graph 7; mcp 13; okf 15 (8 diff + 7 validation); server lib unit 14; api 11; audit 12; auth 32; corpus 1; gate_api 4; http 4; locks 15; merge 15; merge_api 4; store 12; ui 14 (new: +5); postgres 0 passed + 16 ignored.

`cargo fmt --all` clean; `cargo clippy --workspace --all-targets -- -D warnings` clean.

## The two rules that mattered most

1. **The diff is the engine's diff.** The compare page calls `okf::diff::diff` and `gate::run` directly and renders their output — it never computes its own difference. The missing requirement renders as the exact key the gate's roundtrip reports (`requirements:_2026x_1_12a70364_1789522470210_613186_5619`), and the isolated node renders as the exact id the gate's integration reports (`_2026x_1_12a70364_1789602694801_483599_6108`), read straight out of `evidence.integration.isolated` rather than recomputed. The gate verdict (passed/failed), its failures, and the deterministic evidence path (`server-<from>-<to>.json`) are all shown.

2. **A conflict shows base, ours and theirs.** The merge form performs the merge through the same public functions the JSON handler uses (`common_ancestor`, `crate::merge::merge`, `load_model`, `resolve_author`, `verify_actor`, `validate_name`, `commit_refusal_guard`, `touched_elements`, `lock_refusal_message`), in the same order with the same audit entries, and renders a 409 conflict as a page — three columns (base/ours/theirs) side by side for every conflict, plus a resolution form — never as an error page.

## Self-review evidence

- `GET /ui/projects/coffee/compare?from=<imported>&to=<corrupted>` asserts the missing requirement key and the isolated node id exactly as the gate reports them, the `>failed<` verdict, and the `server-<from>-<to>.json` evidence path (`the_compare_page_shows_the_engine_diff_and_gate_verdict`). The branch-name form (`from=main&to=corrupted`) resolves to the same pair.
- A conflicting merge (main and feature both rename the block) returns 409 and renders three `class="conflict-side"` columns with the base/ours/theirs values and the resolution form (`a_conflicting_merge_renders_base_ours_and_theirs`).
- A clean merge through the form returns 201, renders the success page, and really writes a two-parent commit on main (`a_clean_merge_through_the_form_succeeds`).
- An unauthenticated merge POST is a 401 sign-in page, and the compare route was added to the existing unauth 401 loop (`an_unauthenticated_merge_is_a_sign_in_prompt`, `an_unauthenticated_request_renders_a_sign_in_prompt`). A viewer (Read only) cannot merge — 403 "write permission required" (`a_viewer_cannot_merge`).
- No new store method and no new JSON handler were added; the compare page reads through `load_model` and the store's own `commit`/`branch_tip` lookups, and the merge form writes through the store's `commit_merge`.
- No network references: `server/src/ui/review.rs` contains no `http://`, `https://`, `<script`, `<img`, `<link`, `@import` or `url(`. Every dynamic value is spliced through maud, which escapes by construction; the only raw HTML remains the inline stylesheet.

## Concerns

- The merge form mirrors `merge_api::merge_branches` in `review.rs` rather than literally invoking that handler, because a UI route must render a page where the JSON handler returns JSON, and the brief's file list scopes the change to `review.rs`/`pages.rs`/`lib.rs`. It reuses the same public functions in the same order, so the permission, scope, lock and audit decisions cannot drift today, but a future change to the merge handler's ordering would need to be mirrored by hand.
- The merge `Form` extractor runs before in-body identity resolution, so an unauthenticated POST carrying a malformed form body gets axum's 400/415 rejection rather than the 401 sign-in page; with a well-formed body the 401 sign-in page renders as required (tested). No data is leaked and nothing crashes.

## Deviations

- The brief's file list names `review.rs` (create) and `pages.rs` + `lib.rs` (modify). Two supporting edits outside that list were required for the page to exist and render: `server/src/ui/mod.rs` (register `pub mod review;`) and `server/src/ui/layout.rs` (CSS for the diff and the three-column conflict). This matches the Task 2 precedent, which added `pub mod model;` and CSS beyond its own file list. No dependency was added, so `Cargo.toml`/`Cargo.lock` were untouched.
- The brief does not state a literal commit message, so I used the project's conventional-commit style derived from the task title, exactly as Tasks 1 and 2 did.
