# TMT reqId Blocker — the validator now accepts our own binding's document

## Status
DONE_WITH_CONCERNS. The SECOND blocker (our own validator refusing a document our own binding
produced) is fixed at the right layer: an empty reqId is a WARNING, not an error. The imported
36 MB TMT model now validates, so the only remaining blocker is the 48,553 unaccepted losses.
Full workspace suite green, fmt clean, clippy clean.

## Commits
- `04096b3` — "chore: repair the .gitignore line…" (the controller's sweep, NOT mine): this
  commit contains the validator fix (`engine/okf/src/validate.rs`), the small fixture
  (`engine/binding-xmi/fixtures/requirement-no-id.xmi`), the fixtures README update, and the
  two unit tests (`engine/okf/tests/okf_validation.rs`, `engine/binding-xmi/tests/xmi.rs`).
  My work landed here via the controller's repo-wide `git add`; the message does not name it.
- `fb6dfba` — "test(xmi): prove the real TMT model validates; empty reqId is a warning" (mine):
  the #[ignore]d TMT validation proof test plus `cargo fmt` of the swept unit tests.
- `bac3144` — "test(server): invalid-proposal fixture uses an empty element id" (mine): the one
  server test that encoded the old behaviour, re-pointed at a still-invalid trigger.

## One-line test summary
`cargo test --workspace --no-fail-fast` → 660 passed, 0 failed, 27 ignored; `cargo fmt --all`
clean; `cargo clippy --workspace --all-targets -- -D warnings` clean.

## The cause

The SOURCE has no identifier for two requirements. It is not a binding parsing gap.

Two `<sysml:Requirement>` stereotype applications in the TMT XMI carry an EMPTY `Id`
attribute — present but `Id=''`, not absent — so their reqId is legitimately empty. Both are
template requirements, "#parent" and "#child":

```
<sysml:Requirement xmi:id='_17_0_2_3_b4c02e1_1401221134741_493959_101827'
    base_Class='_17_0_2_3_b4c02e1_1401221134741_575510_101826' Text='' Id=''/>
<sysml:Requirement xmi:id='_17_0_2_3_b4c02e1_1401221145689_646480_101881'
    base_Class='_17_0_2_3_b4c02e1_1401221145688_801672_101880' Text='' Id=''/>
```

Their `base_Class` classes are (xmi:id → name):
- `_17_0_2_3_b4c02e1_1401221134741_575510_101826` → `#parent`
- `_17_0_2_3_b4c02e1_1401221145688_801672_101880` → `#child`

The binding reads the empty `Id` faithfully — `engine/binding-xmi/src/lib.rs` (the
Requirement stereotype arm) does
`plain_attr(node, "Id").unwrap_or("").to_string()`, which returns `""` because the attribute
IS present and empty, then carries it as `req_id: meta.req_id.clone()`. So the empty reqId is a
fact about the model, not a misread.

The validator (`engine/okf/src/validate.rs`) then refused it as an ERROR
(`requirement {id} has an empty reqId`). That rule was guarding the WRONG key: the traceability
key is the ELEMENT id (`r.id`), which `add_id` already requires to be present and unique and
which every graph node, edge, coverage and layout answer keys on (`engine/graph/src/lib.rs`
line 138 maps requirements by `r.id`, never `r.req_id`). reqId is a human-facing SysML label,
used only for display. So the validator was refusing a document over a missing display label that
the source never claimed to have — the closed loop the brief described.

## The fix

Changed the empty-reqId check from ERROR to WARNING in `engine/okf/src/validate.rs`. The
requirement still carries an empty reqId (honest — nothing is fabricated), the element id is
still enforced (present + unique), and the empty reqId is NAMED, not hidden:

```
requirement {id} has an empty reqId
```

What the rule no longer catches: it no longer REFUSES a document whose requirement lacks a
human-facing SysML id. It still reports that requirement by element id (a warning). The
traceability guarantee — a unique, non-empty element id — is untouched and remains an error.

No derived key was minted. Derivation ("reqId = element id") would invent a human identifier the
source never had, and it is unnecessary because reqId is not a traceability key. The task's
candidate-fix condition — "if the rule exists to guarantee traceability keys" — does not hold
here, so the simpler, honest path (empty reqId, accepted) applies.

## TMT outcome

The imported 36 MB TMT model now VALIDATES. `the_real_tmt_model_validates_so_the_only_blocker_is_the_losses`
(#[ignore]d, run explicitly) reports:

```
valid                 : true
errors                : 0
empty-reqId warnings  : 2
  warning: requirement _17_0_2_3_b4c02e1_1401221134741_575510_101826 has an empty reqId
  warning: requirement _17_0_2_3_b4c02e1_1401221145688_801672_101880 has an empty reqId
unnamed requirements  : ["_17_0_2_3_b4c02e1_1401221134741_575510_101826 (name="#parent", reqId="")",
                         "_17_0_2_3_b4c02e1_1401221145688_801672_101880 (name="#child", reqId="")"]
```

Verbatim, the two requirements carry:
- `reqId=""` (empty string) for element `_17_0_2_3_b4c02e1_1401221134741_575510_101826` (name `#parent`)
- `reqId=""` (empty string) for element `_17_0_2_3_b4c02e1_1401221145688_801672_101880` (name `#child`)

The existing server streaming test (`server/tests/tmt_import.rs`, run read-only) confirms the
honest end state at the import boundary:

```
source bytes  : 36158244
artifact hash : 76e5c008df30906edeb337348ac1afb84b1468e688689759d28ca1feeaba5a3e
outcome       : Blocking (refused: 48553 blocking losses not accepted)
binding       : sysml-v1-xmi@2.4
```

Combined with the existing round-trip fidelity test (which passes), the chain is now: import
succeeds → round-trip fidelity holds → validation passes → the ONLY remaining blocker is the
48,553 unaccepted losses. "Accept 48,553 losses and it commits."

The full commit (accept all losses and land the commit with provenance) was NOT demonstrated end
to end: that requires a `server/tests` change to pass `accept_losses`, and `server/` is the
other task's ownership (rule 4). The validator blocker that made that proof impossible is removed.

## Concerns
1. SWEPT COMMIT: my validator fix and unit tests landed in `04096b3`, a commit whose message
   ("chore: repair the .gitignore line…") does not name them, because the controller's
   repo-wide `git add` swept my in-flight work. Nothing was lost and the content is correct, but
   the record is misleading. Per instruction I did not amend or force-push.
2. CROSS-BOUNDARY TEST TOUCH: my validator change made one server test
   (`server/tests/proposal_assist.rs::an_invalid_model_change_is_refused_with_the_validators_errors`)
   fail, because it used an empty reqId as its deliberately-invalid model. To keep the workspace
   green (a hard rule) I re-pointed that fixture at an empty ELEMENT id (still a validation
   error) in `bac3144`, preserving the test's purpose. This is the only `server/` file I
   touched, and only its test fixture, not `server/src`.
3. SPEC DRIFT (out of scope to fix): `docs/okf/okf-1.0-spec.md` §7 rule 5 still states
   "Every requirement has a non-empty reqId" as a normative validation rule. That is now a
   warning, not a failure, so the spec and the validator disagree. Updating the spec (one line,
   "an empty reqId is a warning, not a failure; the element id is the traceability key") is a
   docs task, which rule 4 assigns elsewhere.
4. The full end-to-end commit-with-accepted-losses proof is deferred to the `server/` owner,
   who can now add it without hitting the validator.
