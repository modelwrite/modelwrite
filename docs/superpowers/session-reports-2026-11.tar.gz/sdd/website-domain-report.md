# Website domain: modelwrite.org -> GitHub Pages

Status: **DONE_WITH_CONCERNS** — apex and www resolve to GitHub Pages, the real
site is served at the apex over HTTP, and the trial subdomain is unaffected.
The only open item is HTTPS certificate issuance (see "TLS state").

## What changed

1. **DNS (Cloudflare zone `modelwrite.org`, zone id `869c1664050c14a7da2b7e6b3f0a94a0`).**
   Added the four GitHub Pages apex `A` records, the four matching `AAAA`
   records, and a `www` CNAME — **all DNS-only (grey cloud, `proxied=false`)**.
2. **Repo.** Committed `website/CNAME` (contents `modelwrite.org`) and a new
   `docs/deploy/website.md` to `main` (the Pages deploy branch). The
   `pages.yml` workflow uploads the whole `website/` directory
   (`path: website`), so the CNAME file is carried into the artifact with
   **no workflow change required**.
3. **Pages custom domain.** Already `modelwrite.org` (confirmed via
   `gh api repos/modelwrite/modelwrite/pages`); the deployed CNAME file keeps
   it consistent.

## Old state of records touched (before change)

- `modelwrite.org` apex: **no A or AAAA records** (resolved to SOA only).
- `www.modelwrite.org`: **no records**.
- The zone contained exactly one record: `trial.modelwrite.org` (proxied CNAME
  to the idc-1 tunnel), which was **not touched**.

## Records created (all DNS-only / not proxied)

Apex `A`: `185.199.108.153`, `185.199.109.153`, `185.199.110.153`, `185.199.111.153`

Apex `AAAA`: `2606:50c0:8000::153`, `2606:50c0:8001::153`, `2606:50c0:8002::153`, `2606:50c0:8003::153`

`www`: `www.modelwrite.org  CNAME  modelwrite.github.io`

`trial.modelwrite.org`: untouched (still proxied CNAME
`895153ce-0e3a-44dd-ae05-d2546302cdcb.cfargotunnel.com`).

## Verbatim fetch evidence

Resolved apex A (via 1.1.1.1):

```
modelwrite.org    A 185.199.110.153
modelwrite.org    A 185.199.111.153
modelwrite.org    A 185.199.109.153
modelwrite.org    A 185.199.108.153
```

Resolved apex AAAA (via 1.1.1.1):

```
modelwrite.org AAAA 2606:50c0:8000::153
modelwrite.org AAAA 2606:50c0:8001::153
modelwrite.org AAAA 2606:50c0:8002::153
modelwrite.org AAAA 2606:50c0:8003::153
```

Resolved www CNAME (via 1.1.1.1):

```
www.modelwrite.org CNAME modelwrite.github.io
```

(8.8.8.8 returns the same four apex A records.)

HTTP fetch:

```
curl http://modelwrite.org/
[HTTP 200 url=http://modelwrite.org/ redirect=] remote_ip=2606:50c0:8001::153
<title>Modelwrite: the model you can prove</title>
```

Unique-to-site phrase confirmed in the served body: "The model you can prove."
and "round-trip gate". This is the real `website/index.html` (27191 bytes,
`Last-Modified` matching this deployment), not a parked page, 404, or
redirect loop.

## TLS state

**Not yet issued (provisioning).** HTTPS resolves and connects, and the GitHub
edge already serves the correct site over TLS (HTTP 200, 27191 bytes,
`Server: GitHub.com`, `Last-Modified` = deploy time), but the certificate
presented still lacks `modelwrite.org` in its SAN, so a client fails
verification with schannel `SEC_E_WRONG_PRINCIPAL` ("target principal name is
incorrect"). This is the classic "custom-domain certificate not yet issued"
state.

Attempts made while polling (~40 min elapsed from DNS pointing to GitHub Pages):

- Polled HTTPS for ~35 min — no issuance.
- CNAME toggle (remove `website/CNAME`, deploy, restore `website/CNAME`,
  deploy) — **ineffective**: the effective Pages `cname` is a persistent
  repository setting and did not change when the artifact CNAME was removed, so
  GitHub did not re-process the domain. Net state restored correctly (see
  commits `4fe5b74` remove, `7d7ff6d` restore).
- Re-saved the custom domain via `PUT /repos/modelwrite/modelwrite/pages` — no
  immediate change (domain value was already `modelwrite.org`).

What remains: GitHub Pages must issue its Let's Encrypt certificate for
`modelwrite.org`. This is automatic and typically completes within minutes to
~1 hour of DNS pointing correctly. If it stays stuck, the documented fix is to
re-save the custom domain in the GitHub Pages settings UI (Settings → Pages →
Custom domain → Save); there is no public API to observe or force cert
issuance directly.

## Trial health (unchanged)

```
curl https://trial.modelwrite.org/health
{"authMode":"open","status":"ok"}
[HTTP 200]
```

The trial subdomain still responds (HTTP 200) and now reports open auth mode
(per the concurrently-running trial task). The DNS change did **not** take the
trial down.

## Concerns

1. **HTTPS TLS not yet issued** — the only remaining item. HTTP is fully
   working; DNS and the custom domain are correct and DNS-only. The cert is
   GitHub's to issue; no further DNS/repo change should be needed.
2. The CNAME-toggle experiment left two intermediate commits on `main`
   (`4fe5b74` remove, `7d7ff6d` restore); net state is correct (CNAME
   present). `website/CNAME` is committed to `main`. On the concurrent
   `slice-2-repository` branch the same file is still untracked in the
   working tree; that branch is left alone to avoid disturbing the concurrent
   trial-config task.

## Revert

Delete the eight apex records and the `www` CNAME from the Cloudflare zone
(record ids in the dashboard / via `GET /zones/869c1664050c14a7da2b7e6b3f0a94a0/dns_records`).
Do not touch `trial.modelwrite.org`.
