# Packaging report: modelwrite as an npm package and a ghcr image

## status

DONE_WITH_CONCERNS

Both deliverables are built and verified locally. Two things are deliberately or
necessarily not executed from this machine, and both are called out below:
publishing to the public npm registry (the owner's irreversible decision) and
pushing the container image to ghcr.io (no Docker on this machine, and the local
token lacks the write:packages scope). The image push is wired to run in CI on a
release tag; it has not been observed to succeed because it cannot run here.

## commits

One commit, staged and committed in this branch (slice-2-repository):

- `ci: ship modelwrite as an npm package and a ghcr image`

It contains ONLY:

- `packages/modelwrite-mcp/` — the npm package (package.json, install.js,
  bin/mw-mcp.js, README.md, LICENSE).
- `.github/workflows/ci.yml` — extended with a `publish` job that pushes the
  image to ghcr.io on a `v*` tag, using GITHUB_TOKEN + `packages: write`.
- `.github/workflows/release.yml` — new; builds the mw-mcp binary for five
  platforms and attaches them to the GitHub Release the npm package downloads from.

No engine/, server/, cli/, website/, docs/ or Cargo files were touched.

## what a user can now install

- `npm install modelwrite-mcp` (once published) gives an MCP client the
  `mw-mcp` binary for Windows (x64), macOS (x64 and arm64) and Linux (x64 and
  arm64). The binary is fetched at install time from the GitHub Release for the
  matching version; a failed download fails the install loudly.
- `docker pull ghcr.io/modelwrite/modelwrite:<version>` (once a release tag is
  pushed) gives the `mw-server` container image, tagged with the version plus
  moving `:<major>`, `:<major>.<minor>` and `:latest` tags.

## verified (ran the commands, saw the output)

- `cargo build --release --locked -p mw-mcp` succeeds; the binary answers
  `initialize` (serverInfo name modelwrite-mcp, version 0.1.0) and
  `tools/list` (13 tools: 4 document + 9 repository).
- `npm pack` in `packages/modelwrite-mcp` succeeds: tarball
  `modelwrite-mcp-0.1.0.tgz`, size 15,396 bytes (~15 KB), 5 entries
  (LICENSE, README.md, bin/mw-mcp.js, install.js, package.json); no binary is
  bundled — it is fetched at install.
- `npm install <tarball>` with the download base pointed at a local HTTP server
  fetched `bin/mw-mcp.exe` (991,232 bytes) via postinstall, and BOTH the
  `node_modules/.bin/mw-mcp` shim and the wrapper spawned it and returned a
  valid `initialize` response.
- Fail-loudly paths verified: missing binary exits 1 with instructions; a 404
  download exits 1 naming the URL/version/asset and leaves no partial binary.
- Full workspace suite is green: `cargo test --workspace` exits 0 — all tests
  pass with the 24 PostgreSQL tests ignored (the known PostgreSQL suite).
  (An earlier job showed exit 1 only because of PowerShell's `2>&1` stderr
  quirk; a clean re-run reports CARGO_EXIT_CODE=0.)
- Both workflow files parse as YAML.

## prepared but NOT published, and the exact command

1. npm package — do not publish from this machine. The npm account that WOULD
   publish is `alexkovaceski` (`npm whoami --registry=https://registry.npmjs.org/`).
   Note: the default registry in ~/.npmrc is `https://registry.npmmirror.com`
   (a read-only mirror), so a bare `npm publish` targets the mirror and would
   fail/mislead. The exact publish command is:

   ```
   cd packages/modelwrite-mcp && npm publish --registry=https://registry.npmjs.org/
   ```

   Order matters: push a release tag first (below) so the binary download source
   exists before anyone installs the package.

2. Container image — automated, no manual command. Pushing tag `v0.1.0` runs
   the `publish` job (ghcr.io/modelwrite/modelwrite:0.1.0, :0.1, :0, :latest)
   and `release.yml` (binary assets). The trigger is:

   ```
   git tag v0.1.0 && git push origin v0.1.0
   ```

## concerns

- ghcr push NOT observed: Docker is not installed on this machine and the local
  `gh` token (alexkovaceski) has scopes gist/read:org/repo/workflow — no
  write:packages — so a real push could not be executed here. The CI path uses
  GITHUB_TOKEN + `packages: write`, which is the correct mechanism, but the
  first release push is unverified until the tag is pushed.
- npm publish deliberately not run (irreversible; owner's decision).
- The Intel macOS runner label `macos-15-intel` replaces the retiring
  `macos-13`; if that label is not yet enabled for this repo, the darwin-x64
  release job fails and the label must be adjusted.
- crates.io is out of scope by design (no cargo credentials here, and the
  name/version/yank decisions belong to the owner). Remaining work for the owner.
- Pre-existing untracked files at the repo root (`.superpowers/`, `e2e-*.log`,
  `trial-*.log`, `trial.db`) were left alone; a trial server appears to be
  running and writing them. Not part of this commit.
