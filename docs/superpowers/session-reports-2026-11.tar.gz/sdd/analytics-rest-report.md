# Package 3 (REST) — analytics interfaces

Status: **DONE_WITH_CONCERNS**

## Commits

- `652d30a` feat(server): analytics REST surface over mw-analytics-schema@1 (9 files, +2967)
  - pushed to `origin/slice-2-repository`

## Test summary (one line)

`cargo test --workspace --no-fail-fast` → 0 failed (11 new analytics contract tests pass, plus the 1 #[ignore]d TMT streaming proof passes when run explicitly); `cargo clippy --workspace --all-targets -- -D warnings` and `cargo fmt --all` clean.

## The TMT streaming proof (verbatim)

Open-MBEE TMT.mdzip 2022x, `sample/examples/sysml-v1/openmbee-tmt/tmt-2022x.model.xmi` (36,158,244 bytes), read through the XMI binding (`binding read: 2.1s`):

| table | rows |
|---|---|
| projects | 1 |
| commits | 1 |
| elements | 362 |
| relationships | 633 |
| requirements | 7 |
| metrics | 25 |
| metric_definitions | 25 |
| import_losses | **50,784** |

Loss report: **50,784 mappings** = 45,725 content losses + 2,828 lossy + 2,231 declarations (48,553 blocking) — pinned exactly as `engine/binding-xmi/tests/real_tmt.rs`.

Streaming: the 50,784 import_losses rows are built LAZILY from the owned mappings and streamed through the SAME `Body::from_stream` primitive the table endpoint uses — never collected into a whole-table vector. `50,784 rows in 1.16s; RSS 57.8 -> 62.1 MB` (~4 MB delta; the whole table was not materialised). The 2 empty-reqId requirements the commit validator refuses are printed, not hidden.

## The byte-identical proof

`csv_and_ndjson_are_byte_identical_across_two_runs` (in `server/tests/analytics.rs`): two requests for `/analytics/coffee/tables/elements?commit=…&format=csv` and `…format=ndjson` return byte-identical bodies. No timestamp is added by the export; the CSV header is the at-rest snake_case `project,commit,element_id,…`.

## Shape matches

- **MCP (engine/mcp)** — all five pass-through tools match exactly: `repo.analyticsSchema` → `GET /analytics/schema`; `repo.metrics` → `GET /analytics/{p}/metrics`; `repo.trend` → `GET /analytics/{p}/trend?metric=&branch=&from=&to=`; `repo.table` → `GET /analytics/{p}/tables/{table}` (flat `limit/cursor/commit/branch` + `key=value` filters); `repo.losses` → `GET /analytics/{p}/tables/import_losses`. No edits to engine/mcp were needed.
- **CLI (cli/src)** — `AnalyticsSchema`, `AnalyticsMetrics`, `AnalyticsTrend` match. **Divergence:** `AnalyticsTables` stubs `GET /analytics/{p}/tables` (a list-tables endpoint, Package 4's `mw analytics tables`); it is not one of Package 3's five endpoints and is not implemented here.

## Concerns

1. **The TMT model cannot be committed.** `okf::validate::validate` refuses it on two requirements with an empty `reqId` (the XMI binding carries no reqId for them). This is a pre-existing binding/validator matter (engine), outside Package 3's ownership, and it is why the HTTP import_losses endpoint could not be exercised against a *committed* TMT import. The streaming claim is proven instead (a) directly over the real 50,784-mapping loss report, and (b) end-to-end over HTTP at small scale (the SysML v2 drone import). Flagging for the binding/validator owner.
2. **camelCase wire vs the MCP test fixture.** `spec/analytics/README.md` mandates camelCase on the JSON wire (`basis_element_count` -> `basisElementCount`), which this transport implements. `engine/mcp/tests/repository.rs` mocks the metric/table rows in snake_case; that is a fixture, not validated against the service, and the MCP pass-through is name-agnostic (forwards the service's JSON verbatim), so there is no functional mismatch — but Package 7's equivalence test must reconcile the mechanical name map (REST camelCase vs CLI --db snake_case).
3. **`engine_version` on metric rows** reads the transport crate's `CARGO_PKG_VERSION` (server 0.2.0), matching the CLI's existing behaviour; it is not the engine crate's version. All crates are 0.2.0 today, so nothing diverges yet.
4. `futures-util` was added to `server/Cargo.toml` (`default-features = false, features = ["std"]`) solely to feed `axum::body::Body::from_stream` for streaming; it was already in the tree via axum-core, so no new crate was downloaded.
