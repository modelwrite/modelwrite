# Engine crates: crates.io publish report

## Status

DONE_WITH_CONCERNS

7 of 10 engine crates are live on crates.io at 0.1.0. The remaining 3
(mw-binding, mw-binding-xmi, mw-agent) are BLOCKED by a pre-existing
dev-dependency cycle that cannot be broken without source/test restructuring
(outside the scope I was authorized to touch).

## Commits

- `174e39e8a32e4fbd9e5da7661109155f9448c602` — "chore: prepare the engine crates for crates.io"
  (20 files: the 10 engine `Cargo.toml` files + 10 new per-crate `README.md` files).

## Per-crate results

| Crate | Result | Version |
|-------|--------|---------|
| mw-okf | published | 0.1.0 |
| mw-test-support | published | 0.1.0 |
| mw-graph | published | 0.1.0 |
| mw-gate | published | 0.1.0 |
| mw-capi | published | 0.1.0 |
| mw-analytics | published | 0.1.0 |
| mw-mcp | published | 0.1.0 |
| mw-binding | BLOCKED (dev-dependency cycle) | — |
| mw-binding-xmi | BLOCKED (dev-dependency cycle) | — |
| mw-agent | BLOCKED (depends on blocked mw-binding) | — |

## Actual publish order (differs from the brief)

The brief ordered `mw-okf` before `mw-test-support`. In practice `cargo
publish` requires **dev-dependencies** to already be on crates.io, and every
engine crate dev-depends on `mw-test-support`, so the real order was:

1. mw-test-support
2. mw-okf
3. mw-graph
4. mw-gate
5. mw-capi
6. mw-analytics
7. mw-mcp

## Why the three crates are blocked

`cargo publish` strips the `path` from every dependency (including
dev-dependencies) and resolves the `version` against crates.io. The engine
has a dev-dependency cycle:

- `mw-binding` dev-depends on `mw-binding-xmi` (its `tests/xmi_harness.rs`
  uses `binding_xmi::XmiBinding`).
- `mw-binding-xmi` **production**-depends on `mw-binding` (it implements the
  `Binding` trait).

This is a two-crate cycle in the combined prod+dev graph, so neither can be
published first. Exact dry-run errors:

- mw-binding: `no matching package named 'mw-binding-xmi' found`
- mw-binding-xmi: `no matching package named 'mw-binding' found`
- mw-agent: `no matching package named 'mw-binding' found` (production dep)

Breaking the cycle would require removing `mw-binding`'s dev-dependency on
`mw-binding-xmi` (which breaks `cargo test` for mw-binding) or restructuring
the source. Both are outside the scope I was given (I was forbidden from editing
`.rs` files and from breaking the build).

## Concerns

1. **Dev-dependency cycle** blocks 3 crates (see above). A follow-up should
   restructure so the binding round-trip harness no longer creates a prod/dev
   cycle (e.g. move the XMI round-trip test into the mw-binding-xmi crate, or
   make mw-binding's dev-dependency one-directional).

2. **All ten engine crates had `publish = false`**, not just server/ and cli/
   as the brief implied. I removed `publish = false` from the ten engine
   crates to enable publishing; server/ and cli/ were left untouched.

3. **crates.io rate-limits new-crate publishes.** After the first burst of five,
   each subsequent new crate needed a ~6–9 minute wait (429 with retry-after).
   mw-analytics and mw-mcp were each published after waiting out the window.

4. **mw-mcp keyword too long.** `model-context-protocol` is 23 chars; crates.io
   caps keywords at 20. This is only rejected at upload (not by dry-run). I
   shortened it to `model-context`.

5. **mw-test-support fixtures are monorepo-relative** (`repo_root()` resolves
   `env!("CARGO_MANIFEST_DIR")/../..`). As a published dev-dependency this
   points at the extracted registry copy, not the corpus, so the fixtures only
   work in-repo. Low impact (it is an internal dev-dependency), but noted.

6. **Concurrent editing:** another task was modifying `engine/binding-xmi`
   source files (`src/lib.rs`, `src/model.rs`, `tests/xmi.rs`,
   `tests/real_magicdraw.rs`, a fixture, and `fixtures/README.md`) while I
   worked. I committed only my 20 manifest/README files and left their changes
   untouched in the working tree.

## Verification

`cargo check --workspace` was green (exit 0) after all manifest edits and again
before committing. Final crates.io API check: 7 crates return 200 at
`max_version = 0.1.0`; mw-binding, mw-binding-xmi, and mw-agent return 404
(not published).
