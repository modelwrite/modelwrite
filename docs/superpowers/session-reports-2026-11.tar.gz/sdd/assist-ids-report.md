# Assist human-readable ids — report

## Status

DONE_WITH_CONCERNS

## Commit

- `492020f` — assist: demand short, human-readable element ids in the live reasoner

## One-line test summary

`cargo test -p mw-server --lib` 35 passed / 0 failed (incl. the 2 new unit tests); `cargo test -p mw-server --test proposal_assist` 4 passed / 0 failed; `cargo fmt --all` clean; `cargo clippy --workspace --all-targets -- -D warnings` clean.

## What changed

- `server/src/assist.rs`: the shared strict-JSON `system_prompt()` (used by BOTH the Anthropic and the local OpenAI-compatible backends) now tells the model to give every new element/requirement a SHORT, HUMAN-READABLE kebab-case id (`heater-block`, `heat-requirement`), unique within the document, and to never invent an opaque corpus-internal `_2026x_…` id. The JSON shape example now shows `"id": "heater-block"`.
- Validation now enforces the three rules in one place, `validate_changes`: (a) non-empty id (trimmed), (b) unique across the whole proposed document, (c) the existing element-id shape rules via `validate_element_name` (no control chars, ≤256 bytes). `ModelChange::validate` still enforces the per-change shape; both `parse_and_validate` (live answers) and `assist_core` (scripted path) call `validate_changes`, so every reasoner path is covered.
- Style is deliberately prompt-only: an opaque-but-valid id is still accepted by validation (per the brief — do not reject a valid model over style); the prompt makes the readable form the default.

## Concerns

- The full workspace suite is NOT green, but the 3 failures are all in concurrent-task-owned code, none in `server/src/assist.rs` and none caused by this change:
  1. `cli::offline_gate_matches_the_server_verdict_on_the_corpus_pair` — offline vs server gate verdict differ (offline now emits a `composition` section the server path lacks).
  2. `server/tests/references.rs::the_single_model_gate_is_unchanged_by_references` — gate `passed` flag is now false.
  3. `server/tests/references.rs::a_platform_model_reference_resolves_and_is_listed` — reference object now carries an extra `bounds` field.
  These live in `engine/gate`, `engine/okf` (`types.rs`/gate schema) and the references/gate_api surface the brief assigns to concurrent tasks, so I left them untouched and did not commit them.
- A stale `mw-server.exe` (PID 164256) left over from the earlier live-fleet verification was holding `target/debug/mw-server.exe`, causing an initial `Access is denied (os error 5)` build failure; I stopped that process and the build then completed cleanly for my package.
