# Manifest re-capture — canonical-hash reset safety net (idc-1)

**Status:** DONE — the reset's hash verification is restored and proven; the skip-guard still skips.

## Commit deployed
- **Commit:** `2772b5f76a7e30aecd4497a373db4c72cc87cc9d` — `feat(server): wire the SysML v2 reader into the workbench import surface`, the **current tip** of `slice-2-repository` (read via `git ls-remote`/fetch, not assumed). It sits directly on `6ea0913 fix(content-address): one canonical serialisation across every write path`, which is the change that broke the old manifest.
- **Image:** `modelwrite/modelwrite:idc-1-trial` id `5167eca952df`, rebuilt on the host with `--cpuset-cpus=0-3` (cargo build bounded to 4 CPUs; the vLLM fleet was not starved).
- **Previous image / commit (revert):** image `d767a42f08f7`, commit `55f653ceaf2222c7314d818f2d72bbc27330bf72`, preserved on the host as tag `modelwrite/modelwrite:idc-1-trial-pre-canonical-55f653c`. The pre-fix manifest is preserved at `/opt/modelwrite/seed/manifest.json.pre-canonical.bak`.

## New canonical hashes (old pre-fix -> new)

| project / branch | pre-fix expectedHash | new canonical expectedHash |
|---|---|---|
| coffee-machine / main | `8e373a72c8b5a2b7c38b57a2b26dd749ead41d631450bd9e459958615f9ba498` | `1ec97db8f80df53f22972fdc5cadd0a99528bef38be798ce74012c0e7784faed` |
| sandwich-toaster / main | `3082f48039afa052f9a619c6d07bb8b181be35dda0b96fd92098c15f1ff77d71` | `0399697d7e9798db4303a38bd25559b09749495ff9002a2a10c325b8fb06f8cb` |
| purchasing-terminal / main | `caeecbeac90554eac71c84e1d1041d79d614f0f5efc36b65d625021a40a2d0ce` | `87be9f0740dae1fb16b573904c4428c2849a1cc081d6a36964a90631652c45c6` |
| floor-robot / main | `18dce0588f0065ffbc7b4f3e891fc5cbeaef2dbd48d81d45d1c68387893ec44c` | `8e42ad84dda9063ffaa95e1a6e5c72914fcd2c14bced42443e712b975b319bfa` |
| microduck / main | `44949abc083ddd59ebe66d6dd806bd6a9e2eb5fa274b92e6de357fc0f3da04ca` | `d181960375a853ffd817a96174a04735d613858e829ab41613d65900141c4368` |
| fire-suppression / main | `c661ab075e995f117e2dce212e1ae861402befd246a201e5a79c52e49fce6ce1` | `dfe72915a94f730abea06ee7550757915d4d1ed96db451de2087f52dbf56d804` |
| cafe-stand / main | `dd905e708e8c21a6ea0660a4ea08e2b0814d1a3fe3dc32e16481942681d208f1` | `b38ea131c48233164523aff4a26e49ee0803f0ddadb360e589f8e915da888036` |
| cafe-stand / with-microduck | `33e1914b17bc6218fd84ff17c97b0d9a870e31de7c05753241006dcc05080ecb` | `173cf8adb7dbe58ac570dabfb7c531cc99543847ea0c5e6f5e445057b59d90e8` |

All eight changed (the pre-fix HTTP path stored BTreeMap/alphabetic-order blobs; the fix
canonicalises to struct order with a re-derived summary). `seed.mjs` reproduced the new
values independently, and `capture-seed.py` captured the same values as `expectedHash`.

## Replay proof (FORCE=1 full rebuild)

`sudo env FORCE=1 /opt/modelwrite/deploy/reset-trial.sh` exited 0. Key verbatim lines:

```
FORCE=1 set - bypassing change-detection guard, forcing full reset
commit coffee-machine/main -> 1ec97db8f80df53f22972fdc5cadd0a99528bef38be798ce74012c0e7784faed
commit sandwich-toaster/main -> 0399697d7e9798db4303a38bd25559b09749495ff9002a2a10c325b8fb06f8cb
commit purchasing-terminal/main -> 87be9f0740dae1fb16b573904c4428c2849a1cc081d6a36964a90631652c45c6
commit floor-robot/main -> 8e42ad84dda9063ffaa95e1a6e5c72914fcd2c14bced42443e712b975b319bfa
commit microduck/main -> d181960375a853ffd817a96174a04735d613858e829ab41613d65900141c4368
commit fire-suppression/main -> dfe72915a94f730abea06ee7550757915d4d1ed96db451de2087f52dbf56d804
commit cafe-stand/main -> b38ea131c48233164523aff4a26e49ee0803f0ddadb360e589f8e915da888036
commit cafe-stand/with-microduck -> 173cf8adb7dbe58ac570dabfb7c531cc99543847ea0c5e6f5e445057b59d90e8
verify /projects -> ['cafe-stand', 'coffee-machine', 'fire-suppression', 'floor-robot', 'microduck', 'purchasing-terminal', 'sandwich-toaster']
seed replay verified: seven models present
fresh DB verified: all seven models present
cafe-stand main references resolve: ..."resolves":true (all four references resolves:true)
swapped fresh database into /opt/modelwrite/data/modelwrite.db
=== modelwrite trial reset complete ===
```

Every reproduced commit hash matched its `expectedHash` (no `seed drifted` failure), all
seven models present, cafe-stand's four references resolve. The fresh DB was swapped in and
the live service restarted on it (confirmed: live cafe-stand tips `b38ea131…` /
`173cf8ad…`, fire-suppression tip `dfe72915…`).

## Skip proof (change-detection guard)

Run twice without FORCE; both logged and exited 0:

```
no changes since the last reset, skipping (service not restarted, no backup taken)
```

`ActiveEnterTimestamp` and the container `StartedAt` were both `2026-09-21T10:47:34Z`
before and after both runs — the service was NOT restarted, no backup was taken (backup count
unchanged). `modelwrite.service` (3102) and `modelwrite-app.service` (3103) both stayed
active throughout.

## Other stale hashes / references found

- **Repo `docs/`:** no hardcoded full hashes anywhere (the 8 pre-fix hashes do not occur in
  the repo). `docs/deploy/seed-trial.mjs` hardcodes no hashes — it re-derives them, so it
  needed no change. `docs/deploy/idc-1-trial.md` had the stale pinned commit/image
  (`55f653c`/`d767a42f08f7`) — updated to `2772b5f`/`5167eca952df` with the new revert
  note.
- **Host `/opt/modelwrite/README.md`:** was two deploys stale (still `47efbf1`/`50c8623ed6ac`,
  "six models"). Updated to `2772b5f`/`5167eca952df`, revert `d767a42f08f7`/`55f653c`,
  "seven models" (no hashes in it).
- **Host `/opt/modelwrite/seed/README.md`:** stale ("six models", "every night"). Updated to
  seven models (fire-suppression added to the list) and hourly. No hashes.
- **Weekly verify timer/service drop-ins:** no hardcoded hashes — they just run
  `reset-trial.sh` with `Environment=FORCE=1`. Clean. Left as built.
- **Historical `.superpowers/sdd` reports** (`idc-1-trial-deploy-2-report.md`,
  `reset-verify-report.md`): contain truncated pre-fix prefixes (`8e373a72…`,
  `dd905e70…`, `33e1914b…`) as point-in-time records. These are historical and were left
  untouched (flagged, not rewritten).

## Concerns

1. **The tip moved mid-task.** `6ea0913` (canonical fix) was assumed; the SysML-v2 task
   committed + pushed `2772b5f` on top of it before I built. I built the actual tip as
   instructed ("read it, do not assume"). The SysML-v2 change is import-surface only and does
   not touch the commit-hash or seed path, so the new hashes are the canonical-hash fix's
   alone.
2. **Offline CLI is not in the reset path.** The image builds only `mw-server` (the
   Dockerfile's `cargo build -p mw-server`); no `mw-cli` binary exists on the host, and
   the reset replays via HTTP (`seed-from-manifest.py`). `cli/src/offline.rs`'s commit
   path now uses `okf::hash::canonical_bytes` (verified in source), and the committed
   cross-path test (`cli/tests/cli.rs::the_same_document_commits_to_one_hash_through_every_path`)
   proves store/HTTP/offline/binding agree — so the offline CLI is consistent with the
   manifest, but it is not exercised by the reset.
3. **Weekly canary is armed and will pass.** Monday 03:30 UTC the verify timer runs the same
   FORCE path I just proved; no action needed, but the first one after this change is the
   real third-party confirmation.
4. **Concurrent work.** The SysML-v2 task's `server/` edits are uncommitted in the shared
   workstation tree (and committed as `2772b5f` on the remote). I did not touch
   `server/`, `engine/`, or their `Cargo.toml`/`Cargo.lock`; the docs commit is
   `docs/deploy/idc-1-trial.md` only.
5. **Re-captured document sizes shifted** (e.g. coffee-machine 96 KB -> 98 KB) because the
   fix re-derives the summary into the stored document; content is unchanged (verified by
   references resolving + seven models present + every commit hash verified).
6. **Open-mode note:** `MW_AUTH_TOKEN` is blank / `MW_ALLOW_OPEN=yes` — unchanged; the
   hourly reset remains the load-bearing bound on the open trial.
