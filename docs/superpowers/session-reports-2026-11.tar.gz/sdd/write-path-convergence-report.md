# Write-Path Convergence Report

## Status

DONE

## Commits

- `fa263f7` — `fix(store): derive the OKF summary at the commit convergence point` (code + tests; branch `slice-2-repository`)

## One-line test summary

Full workspace suite green (`cargo test --workspace --no-fail-fast`: 0 failed, 24 postgres tests ignored for a missing `MW_TEST_DATABASE_URL`), and the new convergence test was verified to FAIL when the derivation is removed from the store.

## The write-path inventory

Every model-write path, and whether it reaches the store's commit path (the convergence point):

| # | Write path | Caller → entry | Reaches convergence point? |
|---|-----------|----------------|---------------------------|
| 1 | HTTP JSON commit | `api.rs` `create_commit` → `commit_core` → `store.commit_model` | YES |
| 2 | HTTP editor edit | `ui/edit.rs` `perform_edit` → `commit_core` → `store.commit_model` | YES |
| 3 | HTTP workbench create | `ui/create.rs` → `commit_core` → `store.commit_model` | YES |
| 4 | HTTP import | `binding_api.rs` → `commit_core` → `store.commit_model` (import provenance) | YES |
| 5 | HTTP proposal acceptance | `proposal_api.rs` → `commit_core` → `store.commit_accepted` | YES |
| 6 | HTTP branch reset | `api.rs` reset handler → `store.commit_model` (reuses target blob) | YES |
| 7 | HTTP merge | `merge_api.rs` → `store.commit_merge` | YES |
| 8 | **Offline CLI commit** | `cli/offline.rs` → `store.commit_model` | **YES (was the gap)** |
| 9 | Offline CLI reset | `cli/offline.rs` → `store.commit_model` (reuses target blob) | YES |
| 10 | Offline CLI merge | `cli/offline.rs` → `store.commit_merge` | YES |

`store.put_blob` is also called by `binding_api.rs` to retain the source XMI *artifact* (not a model); that is not a model write and correctly does not derive a summary. No production model write reaches the blob store without passing through one of the three store commit methods (`commit_model` / `commit_accepted` / `commit_merge`).

## What is derived where

- The OKF `summary` (one count per element section plus graph node/edge counts) is the only DERIVED field in the document. `okf::summary::derive`/`recompute` remain the single place the counts are decided (`engine/okf/src/summary.rs`).
- The derivation is now enforced in the STORE at the convergence point: `server/src/store/mod.rs::derived_okf_hash`, invoked at the top of `commit_model`, `commit_accepted` and `commit_merge` in BOTH backends (`sqlite.rs` and `postgres.rs`). The store reads the stored document bytes by content address, recomputes the summary, and — when the supplied summary was false — re-stores the corrected bytes under their own address and commits against that corrected address.
- The HTTP-layer shared core (`api.rs::commit_core`) no longer recomputes the summary; it stores the caller's bytes verbatim and lets the store derive on write. There is now exactly one derivation site, so no second copy exists at the CLI.

## Tests proving the convergence

- `server/tests/governance.rs::the_store_derives_the_summary_so_every_commit_path_inherits_a_true_summary` — drives `store.commit_model` directly with a stale-summary document and asserts the committed document carries a true summary. Verified to FAIL (`assertion left != right: the summary must have been re-derived`) when the derivation is removed from the store.
- `cli/tests/cli.rs::offline_commit_derives_a_true_summary` — the new test: commits a stale-summary document through the offline CLI and asserts the stored model's summary is true.
- `server/tests/api.rs::a_commit_regenerates_a_stale_summary_to_match_its_content` — still passes (HTTP path), proving the move did not regress the existing HTTP behavior.
- `server/tests/proposal_assist.rs::an_accepted_change_writes_a_model_whose_summary_agrees_with_its_content` and the merge tests still pass, covering `commit_accepted` and `commit_merge`.

## Concerns

- **Tolerant derivation, stated rather than hidden.** `derived_okf_hash` returns the supplied address unchanged when the referenced blob is missing or does not parse as an OKF document. This keeps the store's existing generic-blob semantics (and the store-mechanics tests that use non-model hashes) intact. A real model always parses, so a real model always gets a true summary; a commit already pointing at a non-model blob was already broken before this rule, and it is not this task's scope to refuse it.
- **Reset now re-derives a stale target.** A branch reset reuses the target commit's blob address; if that target was itself committed with a stale summary (e.g. by the pre-fix offline CLI), the reset commit now points at the corrected bytes rather than a byte-identical copy. This is the intended consequence of "every write carries a true summary", and it is the convergence the task asked for.
- **Postgres path is compile-verified, not run.** The postgres integration tests are skipped without `MW_TEST_DATABASE_URL`. The postgres backend applies the same `derived_okf_hash` at the same points and compiles under `cargo clippy --workspace --all-targets`, but it was not exercised against a live database in this session.
